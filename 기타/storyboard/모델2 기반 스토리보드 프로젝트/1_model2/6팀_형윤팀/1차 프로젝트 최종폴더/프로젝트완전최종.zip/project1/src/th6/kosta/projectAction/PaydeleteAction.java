package th6.kosta.projectAction;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import th6.kosta.project.ProjectDAO;

public class PaydeleteAction implements CommandAction{

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("utf-8");
		
		HttpSession session = request.getSession();
		String memoId = (String)session.getAttribute("user");
		String contents = request.getParameter("memocontents");
		int memopay = Integer.parseInt(request.getParameter("memopay"));
		int memoday = Integer.parseInt(request.getParameter("memoday"));
		int memoyear = Integer.parseInt(request.getParameter("memoyear"));
		int memomonth = Integer.parseInt(request.getParameter("memomonth"));
		ProjectDAO dao = ProjectDAO.getInstance();
		
		int result = dao.scaduledelete(memoId, contents, memopay, memoday, memoyear, memomonth);
		
		
		
		return "/manage/paydelete.jsp";
	}

}
