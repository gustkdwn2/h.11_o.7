package th6.kosta.projectAction;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import th6.kosta.project.ProjectDAO;
import th6.kosta.project.ProjectVO;

public class PayForm0Action implements CommandAction{

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub
		ProjectDAO dao = ProjectDAO.getInstance();
		HttpSession session = request.getSession(false);
		String empno = (String)session.getAttribute("sess");
		ProjectVO info = dao.SelectInfo(empno); 
		System.out.println("info = "+info);
		request.setAttribute("info", info);
		
		Date from = new Date();
		SimpleDateFormat years = new SimpleDateFormat("yyyy");
		SimpleDateFormat months = new SimpleDateFormat("MM");
		
	
		
		String year =  years.format(from);
		String month = months.format(from);
		
		System.out.println("바꾸기전 month = " + month);
		
		int monthch = Integer.parseInt(month)-1;
		if (monthch == 0) {
			monthch = 12;
		}
		if (monthch <= 9) {
			month ="0"+String.valueOf(monthch);
		}else month = String.valueOf(monthch); 
		
		System.out.println("month 확인 : " + month);
		
		//if(request.getParameter("year") != null && request.getParameter("month") != null ){
		if(year != null && month != null ){
			
			System.out.println("year:"+year+", month : "+ month);
					
			ProjectVO vo = dao.selectPay(empno, year, month);   //dao.selectPay(empno, year, month);
			System.out.println("vo : " + vo);
			request.setAttribute("vo", vo);
		}
	
		return "/manage/payForm.jsp";
	}
	
	

}
