package th6.kosta.projectAction;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import th6.kosta.project.ProjectDAO;
import th6.kosta.project.ProjectVO;

public class ProfileAction implements CommandAction{

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {

		HttpSession session = request.getSession();
		String empno = (String) session.getAttribute("sess");
		
		ProjectDAO dao = ProjectDAO.getInstance();	
		ProjectVO vo = dao.getDataDetail(empno);
		
		request.setAttribute("vo", vo);
		if (vo.getImagepath() == null) {
			int name = 99;
			request.setAttribute("orno", name);
			
			
		}else {
			int name = 98;
			request.setAttribute("orno", name);
			request.setAttribute("filename", vo.getImagepath());
		}
		
		return "/manage/profile.jsp";
	}

}
