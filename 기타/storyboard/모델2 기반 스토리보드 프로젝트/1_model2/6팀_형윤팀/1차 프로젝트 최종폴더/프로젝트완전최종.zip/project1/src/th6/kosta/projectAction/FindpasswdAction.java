package th6.kosta.projectAction;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import th6.kosta.project.ProjectVO;

public class FindpasswdAction implements CommandAction{

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {

		
		return "/manage/findpasswd.jsp";
	}

}
