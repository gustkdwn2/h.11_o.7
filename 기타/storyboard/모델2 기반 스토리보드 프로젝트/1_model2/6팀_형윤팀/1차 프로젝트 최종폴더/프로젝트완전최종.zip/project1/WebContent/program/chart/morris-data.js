$(function() {

    Morris.Bar({
        element: 'morris-bar-chart',
        data: [{
            y: document.chart.month.value,
            a: document.chart.pay.value,
        }, {
            y: document.chart.month1.value,
            a: document.chart.pay1.value,
        }, {
            y: document.chart.month2.value,
            a: document.chart.pay2.value,
        }, {
            y: document.chart.month3.value,
            a: document.chart.pay3.value,
        }, {
            y: document.chart.month4.value,
            a: document.chart.pay4.value,
        }, {
            y: document.chart.month5.value,
            a: document.chart.pay5.value,
        }, {
            y: document.chart.month6.value,
            a: document.chart.pay6.value,
        }],
        xkey: 'y',
        ykeys: ['a'],
        labels: ['지출 금액 : '],
        hideHover: 'auto',
        resize: true
    });
    
});
