package th6.kosta.projectAction;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import th6.kosta.project.ProjectDAO;
import th6.kosta.project.ProjectVO;

public class ProfilemodiAction implements CommandAction{

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		
		
		String empno = (String)request.getParameter("empno");
		
		ProjectDAO dao = ProjectDAO.getInstance();	
		ProjectVO vo = dao.getDataDetail(empno);
		
		request.setAttribute("vo", vo);
		System.out.println("asdasd" + vo.getImagepath());
		
		if (vo.getImagepath() == null) {
			int name = 99;
			request.setAttribute("orno", name);
			
			
		}else {
			int name = 98;
			request.setAttribute("orno", name);
			request.setAttribute("filename", vo.getImagepath());
		}
		
		return "/manage/profilemodi.jsp";
		
	}

}
