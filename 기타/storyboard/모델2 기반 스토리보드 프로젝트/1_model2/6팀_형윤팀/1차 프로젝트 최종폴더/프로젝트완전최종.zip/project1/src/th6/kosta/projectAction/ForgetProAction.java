package th6.kosta.projectAction;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import th6.kosta.project.ProjectDAO;
import th6.kosta.project.ProjectVO;

public class ForgetProAction implements  CommandAction{

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("utf-8");
		
		String empno = request.getParameter("empno");
		String name = request.getParameter("name");
		String birth = request.getParameter("birth");
		String findpass = null;
		
		System.out.println("empno : " + empno);
		
		ProjectVO vo = new ProjectVO();
		vo.setEmpno(request.getParameter("empno"));
		vo.setName(request.getParameter("name"));
		vo.setBirth(request.getParameter("birth"));
		
		ProjectDAO dao = ProjectDAO.getInstance();
		int check = dao.enumfind(empno , name , birth);
		request.setAttribute("check", check);
		
		if(check == 1){
			HttpSession session = request.getSession();
			session.setAttribute("findpass", dao.passwdfind(empno));
		}
		
		System.out.println("check : " + check);
		
		System.out.println("findpass : " + dao.passwdfind(empno));
		
		return "/manage/forgetpasswdpro.jsp";
	}

}