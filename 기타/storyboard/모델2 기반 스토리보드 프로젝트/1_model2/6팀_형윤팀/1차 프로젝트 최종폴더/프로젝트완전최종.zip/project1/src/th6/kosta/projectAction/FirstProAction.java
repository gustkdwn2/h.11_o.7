package th6.kosta.projectAction;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import th6.kosta.project.*;

public class FirstProAction implements CommandAction{

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("utf-8");
		
		String passwd = request.getParameter("passwd");
		String enum_id = request.getParameter("enum_id");
		
		
		ProjectVO vo = new ProjectVO();
		vo.setEmpno(request.getParameter("enum_id"));
		vo.setPwd(request.getParameter("passwd"));

		ProjectDAO dao = ProjectDAO.getInstance();
		int check = dao.login(enum_id, passwd);
		request.setAttribute("check", check);
		
		if (check == 1) {
			HttpSession session = request.getSession();
			
			String user = dao.user(enum_id);
			
			session.setAttribute("sess", request.getParameter("enum_id"));
			System.out.println("sess : " + request.getParameter("enum_id"));
			System.out.println("user : " + user);
			session.setAttribute("user", user);
			
		}
		
		System.out.println("check : " + check);
		
		return "/manage/firstPro.jsp";
	}

}
