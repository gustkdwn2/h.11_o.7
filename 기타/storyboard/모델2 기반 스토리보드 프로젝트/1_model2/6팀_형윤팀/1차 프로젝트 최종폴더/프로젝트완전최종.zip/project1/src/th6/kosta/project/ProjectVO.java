package th6.kosta.project;

import java.sql.Timestamp;

public class ProjectVO {
	private String empno,name,dept,position,phone,year,birth,years,month,pay,pwd,imagepath,memocontents,check,bank,account,memoid,total_date;
	private Timestamp go_date,back_date;
	public String getMemoid() {
		return memoid;
	}

	public String getCheck() {
		return check;
	}

	public void setCheck(String check) {
		this.check = check;
	}

	public String getBank() {
		return bank;
	}

	public void setBank(String bank) {
		this.bank = bank;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public String getTotal_date() {
		return total_date;
	}

	public void setTotal_date(String total_date) {
		this.total_date = total_date;
	}

	public Timestamp getGo_date() {
		return go_date;
	}

	public void setGo_date(Timestamp go_date) {
		this.go_date = go_date;
	}

	public Timestamp getBack_date() {
		return back_date;
	}

	public void setBack_date(Timestamp back_date) {
		this.back_date = back_date;
	}

	public void setMemoid(String memoid) {
		this.memoid = memoid;
	}

	private  int memoyear, memomonth, memoday, memopay;
	
	
	public int getMemopay() {
		return memopay;
	}

	public void setMemopay(int memopay) {
		this.memopay = memopay;
	}

	public String getMemocontents() {
		return memocontents;
	}

	public void setMemocontents(String memocontents) {
		this.memocontents = memocontents;
	}

	
	public int getMemoyear() {
		return memoyear;
	}

	public void setMemoyear(int memoyear) {
		this.memoyear = memoyear;
	}

	public int getMemomonth() {
		return memomonth;
	}

	public void setMemomonth(int memomonth) {
		this.memomonth = memomonth;
	}

	public int getMemoday() {
		return memoday;
	}

	public void setMemoday(int memoday) {
		this.memoday = memoday;
	}

	public String getImagepath() {
		return imagepath;
	}

	public void setImagepath(String imagepath) {
		this.imagepath = imagepath;
	}

	public String getEmpno() {
		return empno;
	}

	public void setEmpno(String empno) {
		this.empno = empno;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDept() {
		return dept;
	}

	public void setDept(String dept) {
		this.dept = dept;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public String getBirth() {
		return birth;
	}

	public void setBirth(String birth) {
		this.birth = birth;
	}

	public String getYears() {
		return years;
	}

	public void setYears(String years) {
		this.years = years;
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public String getPay() {
		return pay;
	}

	public void setPay(String pay) {
		this.pay = pay;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

}