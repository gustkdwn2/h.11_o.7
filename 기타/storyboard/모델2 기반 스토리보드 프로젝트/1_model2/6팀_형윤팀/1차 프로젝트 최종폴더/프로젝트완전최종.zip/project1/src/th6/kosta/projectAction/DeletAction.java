package th6.kosta.projectAction;

import java.io.File;
import java.util.Enumeration;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import th6.kosta.project.ProjectDAO;

public class DeletAction implements CommandAction{

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		request.setCharacterEncoding("utf-8");
		
		HttpSession session = request.getSession();
		String empno1 = (String)session.getAttribute("sess");
		System.out.println("현재 세션 확인" + empno1);

		String realPath = "";	//웹 어플리케이션상의 절대경로
		String savePath = "upload";	//저장하는 곳.?
		String encType = "utf-8";	//타입 설정.
		String uppath = "";
		int maxSize = 1024 * 1024 * 5;	//최대업로드 파일 크기 (5M)

		ServletContext context = request.getSession().getServletContext();	//현재 jsp 페이지의 웹 어플리케이션상의 절대경로를 구함
		realPath = context.getRealPath(savePath + "\\");	//절대경로 주소 받아옴.
		System.out.println("realPath is : " + realPath);

		try{
			MultipartRequest multi = null; //전송을 담당할 컴포넌트를 생성하고 파일을 전송
			multi = new MultipartRequest(
											request,
											realPath,
											maxSize,
											encType,
											new DefaultFileRenamePolicy()
					);
			Enumeration files = multi.getFileNames();
			while(files.hasMoreElements()){
				String name = (String )files.nextElement();
				String fileName = multi.getFilesystemName(name); //물리적경로
				String original = multi.getOriginalFileName(name);	//오리지널 파일명
				String type = multi.getContentType(name);
				
				File file = multi.getFile(name);
				
				
				uppath =fileName;
				System.out.println("uppath 는!!!   =  " + uppath);
				if( file != null){
					System.out.println("크기 : " + file.length());
						
				}//if end
			} //end while
			
		
		
		String empno = multi.getParameter("empno");
		String passwd = multi.getParameter("passwd");
		
	
		
		ProjectDAO dao = ProjectDAO.getInstance();

		request.setAttribute("check", dao.delete(empno,passwd,empno1));
		
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return "/manage/deletpro.jsp";
	}

}
