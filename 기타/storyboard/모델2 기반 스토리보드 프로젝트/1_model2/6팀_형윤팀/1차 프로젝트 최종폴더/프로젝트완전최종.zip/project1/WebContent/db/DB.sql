drop table login;
drop table emp_pay;
drop table employee;
drop table CALENDARMEMO;
drop table emp_hour_pay;
drop table emp_bank;
drop table go;
drop table back;

select * from employee;
select * from EMP_PAY;
select * from LOGIN;
select * from CALENDARMEMO;
select * from emp_hour_pay;
select * from emp_bank;
select * from go;
select * from back;

create table employee (
empno varchar2(10) ,
name varchar2(10) not null,
dept varchar2(10) not null,
position varchar2(20) not null,
phone varchar2(20) not null,
year  varchar2(20) not null,
birth varchar2(10) not null,
imagepath varchar2(500),
CONSTRAINT emp_pk PRIMARY KEY(empno)
);

CREATE TABLE login(
enum_id varchar2(10),
passwd varchar2(10),
CONSTRAINT login_fk FOREIGN KEY(enum_id)
REFERENCES employee(empno));


CREATE table emp_pay(
empno varchar2(10) ,
year varchar2(10)not null,
month varchar2(10)not null,
pay number(10) not null,
CONSTRAINT pay_fk FOREIGN KEY(empno)
REFERENCES employee(empno)
);

CREATE TABLE CALENDARMEMO(
CALENDARMEMO_ID varchar2(10),
CALENDARMEMO_CONTENTS VARCHAR2(500),
CALENDARMEMO_YEAR NUMBER,
CALENDARMEMO_MONTH NUMBER,
CALENDARMEMO_DAY NUMBER,
CALENDARMEMO_PAY NUMBER
)

create table emp_hour_pay(
 empno varchar2(20),
 year varchar2(20),
 month varchar2(20),
 day varchar2(20),
 pay number(20),
 CONSTRAINT hour_pk primary key(empno,year,month,day));
 
 
create table emp_bank(
empno varchar2(20),
bank varchar2(30),
account varchar2(30),
CONSTRAINT bank_fk foreign key(empno)
REFERENCES employee(empno));
 
create table go(
empno varchar2(30),
go_date date,
CONSTRAINT go_pk primary key(empno,go_date));

create table back(
empno varchar2(30),
back_date date,
CONSTRAINT back_pk primary key(empno,back_date));

insert into employee(empno,name,dept,position,phone,year,birth,imagepath) values ('0000','김형윤',
'실무부','사장','0109126697','2014-09','910902','');
insert into employee(empno,name,dept,position,phone,year,birth,imagepath) values ('0001','박준형',
'실무부','부사장','01091204521','2014-09','821029','');
insert into employee(empno,name,dept,position,phone,year,birth,imagepath) values ('0002','민진호',
'실무부','전무','01008714038','2014-09','871119','');
insert into employee(empno,name,dept,position,phone,year,birth,imagepath) values ('0003','최낙준',
'실무부','본부장','01054992789','2014-09','910914','');
insert into employee(empno,name,dept,position,phone,year,birth,imagepath) values ('0004','지상동',
'실무부','실장','01031317995','2014-09','920530','');
insert into employee(empno,name,dept,position,phone,year,birth,imagepath) values ('0010','김재윤',
'영업부','부장','01011112222','2015-01','940317','');
insert into employee(empno,name,dept,position,phone,year,birth,imagepath) values ('0011','홍길동',
'영업부','차장','01022223333','2015-02','970627','');
insert into employee(empno,name,dept,position,phone,year,birth,imagepath) values ('0012','차두리',
'영업부','과장','01033334444','2015-03','970827','');
insert into employee(empno,name,dept,position,phone,year,birth,imagepath) values ('0013','차범근',
'영업부','대리','01044445555','2015-04','970317','');
insert into employee(empno,name,dept,position,phone,year,birth,imagepath) values ('0014','판도라',
'영업부','사원','01055556666','2015-05','980211','');

insert into emp_pay(empno,year,month,pay) values ('0000','2014','10','10000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2014','11','10000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2014','12','10000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2015','01','11000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2015','02','11000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2015','03','11000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2015','04','11000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2015','05','11000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2015','06','11000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2015','07','11000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2015','08','11000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2015','09','11000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2015','10','11000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2015','11','11000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2015','12','11000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2016','01','11000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2016','02','11000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2016','03','11000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2016','04','11000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2016','05','11000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2016','06','11000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2016','07','11000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2016','08','11000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2016','09','11000000');

insert into emp_pay(empno,year,month,pay) values ('0000','2014','10','10000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2014','11','10000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2014','12','10000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2015','01','11000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2015','02','11000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2015','03','11000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2015','04','11000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2015','05','11000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2015','06','11000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2015','07','11000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2015','08','11000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2015','09','11000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2015','10','11000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2015','11','11000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2015','12','11000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2016','01','11000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2016','02','11000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2016','03','11000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2016','04','11000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2016','05','11000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2016','06','11000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2016','07','11000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2016','08','11000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2016','09','11000000');

insert into emp_pay(empno,year,month,pay) values ('0004','2014','10','10000000');
insert into emp_pay(empno,year,month,pay) values ('0004','2014','11','10000000');
insert into emp_pay(empno,year,month,pay) values ('0004','2014','12','10000000');
insert into emp_pay(empno,year,month,pay) values ('0004','2015','01','11000000');
insert into emp_pay(empno,year,month,pay) values ('0004','2015','02','11000000');
insert into emp_pay(empno,year,month,pay) values ('0004','2015','03','11000000');
insert into emp_pay(empno,year,month,pay) values ('0004','2015','04','11000000');
insert into emp_pay(empno,year,month,pay) values ('0004','2015','05','11000000');
insert into emp_pay(empno,year,month,pay) values ('0004','2015','06','11000000');
insert into emp_pay(empno,year,month,pay) values ('0004','2015','07','11000000');
insert into emp_pay(empno,year,month,pay) values ('0004','2015','08','11000000');
insert into emp_pay(empno,year,month,pay) values ('0004','2015','09','11000000');
insert into emp_pay(empno,year,month,pay) values ('0004','2015','10','11000000');
insert into emp_pay(empno,year,month,pay) values ('0004','2015','11','11000000');
insert into emp_pay(empno,year,month,pay) values ('0004','2015','12','11000000');
insert into emp_pay(empno,year,month,pay) values ('0004','2016','01','11000000');
insert into emp_pay(empno,year,month,pay) values ('0004','2016','02','11000000');
insert into emp_pay(empno,year,month,pay) values ('0004','2016','03','11000000');
insert into emp_pay(empno,year,month,pay) values ('0004','2016','04','11000000');
insert into emp_pay(empno,year,month,pay) values ('0004','2016','05','11000000');
insert into emp_pay(empno,year,month,pay) values ('0004','2016','06','11000000');
insert into emp_pay(empno,year,month,pay) values ('0004','2016','07','11000000');
insert into emp_pay(empno,year,month,pay) values ('0004','2016','08','11000000');
insert into emp_pay(empno,year,month,pay) values ('0004','2016','09','11000000');

insert into emp_pay(empno,year,month,pay) values ('0004','2014','10','10000000');
insert into emp_pay(empno,year,month,pay) values ('0004','2014','11','10000000');
insert into emp_pay(empno,year,month,pay) values ('0004','2014','12','10000000');
insert into emp_pay(empno,year,month,pay) values ('0004','2015','01','11000000');
insert into emp_pay(empno,year,month,pay) values ('0004','2015','02','11000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2015','03','11000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2015','04','11000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2015','05','11000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2015','06','11000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2015','07','11000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2015','08','11000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2015','09','11000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2015','10','11000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2015','11','11000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2015','12','11000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2016','01','11000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2016','02','11000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2016','03','11000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2016','04','11000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2016','05','11000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2016','06','11000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2016','07','11000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2016','08','11000000');
insert into emp_pay(empno,year,month,pay) values ('0000','2016','09','11000000');









insert into emp_pay(empno,year,month,pay) values ('0001','2014','10','9000000');
insert into emp_pay(empno,year,month,pay) values ('0001','2014','11','9000000');
insert into emp_pay(empno,year,month,pay) values ('0001','2014','12','9000000');
insert into emp_pay(empno,year,month,pay) values ('0001','2015','01','10000000');
insert into emp_pay(empno,year,month,pay) values ('0001','2015','02','10000000');
insert into emp_pay(empno,year,month,pay) values ('0001','2015','03','10000000');
insert into emp_pay(empno,year,month,pay) values ('0001','2015','04','10000000');
insert into emp_pay(empno,year,month,pay) values ('0001','2015','05','10000000');
insert into emp_pay(empno,year,month,pay) values ('0001','2015','06','10000000');
insert into emp_pay(empno,year,month,pay) values ('0001','2015','07','10000000');
insert into emp_pay(empno,year,month,pay) values ('0002','2014','10','8000000');
insert into emp_pay(empno,year,month,pay) values ('0002','2014','11','8000000');
insert into emp_pay(empno,year,month,pay) values ('0002','2014','12','8000000');
insert into emp_pay(empno,year,month,pay) values ('0002','2015','01','9000000');
insert into emp_pay(empno,year,month,pay) values ('0002','2015','02','9000000');
insert into emp_pay(empno,year,month,pay) values ('0002','2015','03','9000000');
insert into emp_pay(empno,year,month,pay) values ('0002','2015','04','9000000');
insert into emp_pay(empno,year,month,pay) values ('0002','2015','05','9000000');
insert into emp_pay(empno,year,month,pay) values ('0002','2015','06','9000000');
insert into emp_pay(empno,year,month,pay) values ('0002','2015','07','9000000');
insert into emp_pay(empno,year,month,pay) values ('0003','2014','10','7000000');
insert into emp_pay(empno,year,month,pay) values ('0003','2014','11','7000000');
insert into emp_pay(empno,year,month,pay) values ('0003','2014','12','7000000');
insert into emp_pay(empno,year,month,pay) values ('0003','2015','01','8000000');
insert into emp_pay(empno,year,month,pay) values ('0003','2015','02','8000000');
insert into emp_pay(empno,year,month,pay) values ('0003','2015','03','8000000');
insert into emp_pay(empno,year,month,pay) values ('0003','2015','04','8000000');
insert into emp_pay(empno,year,month,pay) values ('0003','2015','05','8000000');
insert into emp_pay(empno,year,month,pay) values ('0003','2015','06','8000000');
insert into emp_pay(empno,year,month,pay) values ('0003','2015','07','8000000');
insert into emp_pay(empno,year,month,pay) values ('0003','2016','09','8000000');
insert into emp_pay(empno,year,month,pay) values ('0003','2014','01','5000000');

insert into emp_pay(empno,year,month,pay) values ('0004','2014','10','6000000');
insert into emp_pay(empno,year,month,pay) values ('0004','2014','11','6000000');
insert into emp_pay(empno,year,month,pay) values ('0004','2014','12','6000000');
insert into emp_pay(empno,year,month,pay) values ('0004','2015','01','7000000');
insert into emp_pay(empno,year,month,pay) values ('0004','2015','02','7000000');
insert into emp_pay(empno,year,month,pay) values ('0004','2015','03','7000000');
insert into emp_pay(empno,year,month,pay) values ('0004','2015','04','7000000');
insert into emp_pay(empno,year,month,pay) values ('0004','2015','05','7000000');
insert into emp_pay(empno,year,month,pay) values ('0004','2015','06','7000000');
insert into emp_pay(empno,year,month,pay) values ('0004','2015','07','7000000');

insert into emp_pay(empno,year,month,pay) values ('0010','2015','02','4000000');
insert into emp_pay(empno,year,month,pay) values ('0010','2015','03','4000000');
insert into emp_pay(empno,year,month,pay) values ('0010','2015','04','4000000');
insert into emp_pay(empno,year,month,pay) values ('0010','2015','05','4000000');
insert into emp_pay(empno,year,month,pay) values ('0010','2015','06','4000000');
insert into emp_pay(empno,year,month,pay) values ('0010','2015','07','4000000');
insert into emp_pay(empno,year,month,pay) values ('0011','2015','03','3000000');
insert into emp_pay(empno,year,month,pay) values ('0011','2015','04','3000000');
insert into emp_pay(empno,year,month,pay) values ('0011','2015','05','3000000');
insert into emp_pay(empno,year,month,pay) values ('0011','2015','06','3000000');
insert into emp_pay(empno,year,month,pay) values ('0011','2015','07','3000000');

insert into emp_pay(empno,year,month,pay) values ('0012','2015','04','2500000');
insert into emp_pay(empno,year,month,pay) values ('0012','2015','05','2500000');
insert into emp_pay(empno,year,month,pay) values ('0012','2015','06','2500000');
insert into emp_pay(empno,year,month,pay) values ('0012','2015','07','2500000');
insert into emp_pay(empno,year,month,pay) values ('0013','2015','05','2000000');
insert into emp_pay(empno,year,month,pay) values ('0013','2015','06','2000000');
insert into emp_pay(empno,year,month,pay) values ('0013','2015','07','2000000');
insert into emp_pay(empno,year,month,pay) values ('0014','2015','06','1800000');
insert into emp_pay(empno,year,month,pay) values ('0014','2015','07','1800000');

select * from LOGIN;

insert into login(enum_id,passwd) VALUES ('0000','910902');
insert into login(enum_id,passwd) VALUES ('0001','821029');
insert into login(enum_id,passwd) VALUES ('0002','871119');
insert into login(enum_id,passwd) VALUES ('0003','910914');
insert into login(enum_id,passwd) VALUES ('0004','920530');
insert into login(enum_id,passwd) VALUES ('0010','940317');
insert into login(enum_id,passwd) VALUES ('0011','970627');
insert into login(enum_id,passwd) VALUES ('0012','970827');
insert into login(enum_id,passwd) VALUES ('0013','970317');
insert into login(enum_id,passwd) VALUES ('0014','980211');  

insert into emp_bank values ('0000','우리은행','000-000-000011');
insert into emp_bank values ('0001','신한은행','1111-11-11111');
insert into emp_bank values ('0002','농협은행','121-2221-111');
insert into emp_bank values ('0003','하나은행','1235-48465-54847');
insert into emp_bank values ('0004','우리은행','1234-548-25487');
insert into emp_bank values ('0010','국민은행','1254-5487-2548');
insert into emp_bank values ('0011','씨티은행','1554-4794-84687');
insert into emp_bank values ('0012','기업은행','2187-7587-4879');
insert into emp_bank values ('0013','제일은행','21846-7548-75452');
insert into emp_bank values ('0014','기업은행','587-847-8213');


select empno, name, dept, position, year, rownum r  from EMPLOYEE order by empno ;


INSERT into back values('0000',to_date('2016-10-06 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-10-04 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','10','04',56000);

INSERT into back values('0000',to_date('2016-10-05 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-10-04 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','10','04',56000);


INSERT into back values('0000',to_date('2016-10-04 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-10-04 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','10','04',56000);

INSERT into back values('0000',to_date('2016-10-03 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-10-03 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','10','03',56000);

INSERT into back values('0000',to_date('2016-10-02 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-10-02 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','10','02',56000);

INSERT into back values('0000',to_date('2016-10-01 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-10-01 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','10','01',56000);

INSERT into back values('0000',to_date('2016-09-30 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-09-30 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','09','30',56000);

INSERT into back values('0000',to_date('2016-09-29 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-09-29 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','09','29',56000);

INSERT into back values('0000',to_date('2016-09-28 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-09-28 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','09','28',49000);

INSERT into back values('0000',to_date('2016-09-27 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-09-27 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','09','27',49000);

INSERT into back values('0000',to_date('2016-09-26 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-09-26 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','09','26',49000);

INSERT into back values('0000',to_date('2016-09-25 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-09-25 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','09','25',49000);

INSERT into back values('0000',to_date('2016-09-24 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-09-24 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','09','24',56000);

INSERT into back values('0000',to_date('2016-09-23 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-09-23 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','09','23',56000);

INSERT into back values('0000',to_date('2016-09-22 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-09-22 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','09','22',56000);

INSERT into back values('0000',to_date('2016-09-21 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-09-21 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','09','21',56000);

INSERT into back values('0000',to_date('2016-09-20 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-09-20 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','09','20',56000);

INSERT into back values('0000',to_date('2016-09-19 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-09-19 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','09','19',56000);

INSERT into back values('0000',to_date('2016-09-18 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-09-18 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','09','18',49000);

INSERT into back values('0000',to_date('2016-09-17 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-09-17 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','09','17',49000);

INSERT into back values('0000',to_date('2016-09-16 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-09-16 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','09','16',49000);

INSERT into back values('0000',to_date('2016-09-15 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-09-15 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','09','15',49000);

INSERT into back values('0000',to_date('2016-09-14 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-09-14 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','09','14',49000);

INSERT into back values('0000',to_date('2016-09-13 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-09-13 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','09','13',49000);

INSERT into back values('0000',to_date('2016-09-12 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-09-12 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','09','12',49000);

INSERT into back values('0000',to_date('2016-09-11 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-09-11 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','09','11',49000);

INSERT into back values('0000',to_date('2016-09-10 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-09-10 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','09','10',49000);

INSERT into back values('0000',to_date('2016-09-09 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-09-09 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','09','09',56000);

INSERT into back values('0000',to_date('2016-09-08 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-09-08 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','09','08',56000);

INSERT into back values('0000',to_date('2016-09-07 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-09-07 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','09','07',56000);

INSERT into back values('0000',to_date('2016-09-06 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-09-06 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','09','06',56000);

INSERT into back values('0000',to_date('2016-09-05 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-09-05 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','09','05',56000);

INSERT into back values('0000',to_date('2016-09-04 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-09-04 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','09','04',56000);

INSERT into back values('0000',to_date('2016-09-03 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-09-03 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','09','03',56000);

INSERT into back values('0000',to_date('2016-09-02 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-09-02 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','09','02',56000);

INSERT into back values('0000',to_date('2016-09-01 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-09-01 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','09','01',56000);

--////////////////////////////
--8월
INSERT into back values('0000',to_date('2016-08-31 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-08-31 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','08','31',56000);

INSERT into back values('0000',to_date('2016-08-30 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-08-30 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','08','30',56000);

INSERT into back values('0000',to_date('2016-08-29 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-08-29 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','08','29',56000);

INSERT into back values('0000',to_date('2016-08-28 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-08-28 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','08','28',49000);

INSERT into back values('0000',to_date('2016-08-27 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-08-27 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','08','27',49000);

INSERT into back values('0000',to_date('2016-08-26 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-08-26 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','08','26',49000);

INSERT into back values('0000',to_date('2016-08-25 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-08-25 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','08','25',49000);

INSERT into back values('0000',to_date('2016-08-24 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-08-24 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','08','24',49000);

INSERT into back values('0000',to_date('2016-08-23 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-08-23 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','08','23',56000);

INSERT into back values('0000',to_date('2016-08-22 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-08-22 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','08','22',56000);

INSERT into back values('0000',to_date('2016-08-21 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-08-21 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','08','21',56000);

INSERT into back values('0000',to_date('2016-08-20 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-08-20 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','08','20',56000);

INSERT into back values('0000',to_date('2016-08-19 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-08-19 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','08','19',56000);

INSERT into back values('0000',to_date('2016-08-18 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-08-18 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','08','18',49000);

INSERT into back values('0000',to_date('2016-08-17 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-08-17 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','08','17',49000);

INSERT into back values('0000',to_date('2016-08-16 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-08-16 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','08','16',49000);

INSERT into back values('0000',to_date('2016-08-15 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-08-15 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','08','15',49000);

INSERT into back values('0000',to_date('2016-08-14 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-08-14 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','08','14',49000);

INSERT into back values('0000',to_date('2016-08-13 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-08-13 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','08','13',49000);

INSERT into back values('0000',to_date('2016-08-12 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-08-12 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','08','12',49000);

INSERT into back values('0000',to_date('2016-08-11 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-08-11 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','08','11',49000);

INSERT into back values('0000',to_date('2016-08-10 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-08-10 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','08','10',49000);

INSERT into back values('0000',to_date('2016-08-09 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-08-09 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','08','09',56000);

INSERT into back values('0000',to_date('2016-08-08 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-08-08 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','08','08',56000);

INSERT into back values('0000',to_date('2016-08-07 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-08-07 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','08','07',56000);

INSERT into back values('0000',to_date('2016-08-06 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-08-06 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','08','06',56000);

INSERT into back values('0000',to_date('2016-08-05 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-08-05 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','08','05',56000);

INSERT into back values('0000',to_date('2016-08-04 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-08-04 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','08','04',56000);

INSERT into back values('0000',to_date('2016-08-03 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-08-03 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','08','03',56000);

INSERT into back values('0000',to_date('2016-08-02 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-08-02 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','08','02',56000);

INSERT into back values('0000',to_date('2016-08-01 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-08-01 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','08','01',56000);
--///////////////////////


--////////////////////////////
--7월
INSERT into back values('0000',to_date('2016-07-31 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-07-31 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','07','31',56000);

INSERT into back values('0000',to_date('2016-07-30 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-07-30 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','07','30',56000);

INSERT into back values('0000',to_date('2016-07-29 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-07-29 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','07','29',56000);

INSERT into back values('0000',to_date('2016-07-28 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-07-28 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','07','28',49000);

INSERT into back values('0000',to_date('2016-07-27 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-07-27 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','07','27',49000);

INSERT into back values('0000',to_date('2016-07-26 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-07-26 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','07','26',49000);

INSERT into back values('0000',to_date('2016-07-25 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-07-25 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','07','25',49000);

INSERT into back values('0000',to_date('2016-07-24 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-07-24 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','07','24',56000);

INSERT into back values('0000',to_date('2016-07-23 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-07-23 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','07','23',56000);

INSERT into back values('0000',to_date('2016-07-22 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-07-22 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','07','22',56000);

INSERT into back values('0000',to_date('2016-07-21 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-07-21 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','07','21',56000);

INSERT into back values('0000',to_date('2016-07-20 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-07-20 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','07','20',56000);

INSERT into back values('0000',to_date('2016-07-19 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-07-19 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','07','19',56000);

INSERT into back values('0000',to_date('2016-07-18 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-07-18 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','07','18',49000);

INSERT into back values('0000',to_date('2016-07-17 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-07-17 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','07','17',49000);

INSERT into back values('0000',to_date('2016-07-16 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-07-16 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','07','16',49000);

INSERT into back values('0000',to_date('2016-07-15 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-07-15 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','07','15',49000);

INSERT into back values('0000',to_date('2016-07-14 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-07-14 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','07','14',49000);

INSERT into back values('0000',to_date('2016-07-13 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-07-13 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','07','13',49000);

INSERT into back values('0000',to_date('2016-07-12 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-07-12 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','07','12',49000);

INSERT into back values('0000',to_date('2016-07-11 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-07-11 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','07','11',49000);

INSERT into back values('0000',to_date('2016-07-10 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-07-10 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','07','10',49000);

INSERT into back values('0000',to_date('2016-07-09 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-07-09 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','07','09',56000);

INSERT into back values('0000',to_date('2016-07-08 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-07-08 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','07','08',56000);

INSERT into back values('0000',to_date('2016-07-07 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-07-07 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','07','07',56000);

INSERT into back values('0000',to_date('2016-07-06 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-07-06 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','07','06',56000);

INSERT into back values('0000',to_date('2016-07-05 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-07-05 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','07','05',56000);

INSERT into back values('0000',to_date('2016-07-04 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-07-04 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','07','04',56000);

INSERT into back values('0000',to_date('2016-07-03 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-07-03 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','07','03',56000);

INSERT into back values('0000',to_date('2016-07-02 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-07-02 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','07','02',56000);

INSERT into back values('0000',to_date('2016-07-01 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-07-01 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','07','01',56000);
--///////////////////////

--////////////////////////////
--6월

INSERT into back values('0000',to_date('2016-06-30 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-06-30 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','06','30',56000);

INSERT into back values('0000',to_date('2016-06-29 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-06-29 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','06','29',56000);

INSERT into back values('0000',to_date('2016-06-28 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-06-28 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','06','28',49000);

INSERT into back values('0000',to_date('2016-06-27 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-06-27 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','06','27',49000);

INSERT into back values('0000',to_date('2016-06-26 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-06-26 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','06','26',49000);

INSERT into back values('0000',to_date('2016-06-25 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-06-25 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','06','25',49000);

INSERT into back values('0000',to_date('2016-06-24 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-06-24 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','06','24',56000);

INSERT into back values('0000',to_date('2016-06-23 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-06-23 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','06','23',56000);

INSERT into back values('0000',to_date('2016-06-22 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-06-22 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','06','22',56000);

INSERT into back values('0000',to_date('2016-06-21 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-06-21 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','06','21',56000);

INSERT into back values('0000',to_date('2016-06-20 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-06-20 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','06','20',56000);

INSERT into back values('0000',to_date('2016-06-19 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-06-19 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','06','19',56000);

INSERT into back values('0000',to_date('2016-06-18 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-06-18 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','06','18',49000);

INSERT into back values('0000',to_date('2016-06-17 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-06-17 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','06','17',49000);

INSERT into back values('0000',to_date('2016-06-16 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-06-16 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','06','16',49000);

INSERT into back values('0000',to_date('2016-06-15 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-06-15 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','06','15',49000);

INSERT into back values('0000',to_date('2016-06-14 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-06-14 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','06','14',49000);

INSERT into back values('0000',to_date('2016-06-13 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-06-13 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','06','13',49000);

INSERT into back values('0000',to_date('2016-06-12 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-06-12 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','06','12',49000);

INSERT into back values('0000',to_date('2016-06-11 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-06-11 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','06','11',49000);

INSERT into back values('0000',to_date('2016-06-10 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-06-10 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','06','10',49000);

INSERT into back values('0000',to_date('2016-06-09 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-06-09 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','06','09',56000);

INSERT into back values('0000',to_date('2016-06-08 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-06-08 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','06','08',56000);

INSERT into back values('0000',to_date('2016-06-07 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-06-07 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','06','07',56000);

INSERT into back values('0000',to_date('2016-06-06 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-06-06 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','06','06',56000);

INSERT into back values('0000',to_date('2016-06-05 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-06-05 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','06','05',56000);

INSERT into back values('0000',to_date('2016-06-04 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-06-04 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','06','04',56000);

INSERT into back values('0000',to_date('2016-06-03 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-06-03 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','06','03',56000);

INSERT into back values('0000',to_date('2016-06-02 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-06-02 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','06','02',56000);

INSERT into back values('0000',to_date('2016-06-01 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-06-01 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','06','01',56000);
--///////////////////////

--////////////////////////////
--5월

INSERT into back values('0000',to_date('2016-05-31 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-05-31 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','05','31',56000);

INSERT into back values('0000',to_date('2016-05-30 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-05-30 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','05','30',56000);

INSERT into back values('0000',to_date('2016-05-29 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-05-29 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','05','29',56000);

INSERT into back values('0000',to_date('2016-05-28 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-05-28 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','05','28',49000);

INSERT into back values('0000',to_date('2016-05-27 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-05-27 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','05','27',49000);

INSERT into back values('0000',to_date('2016-05-26 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-05-26 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','05','26',49000);

INSERT into back values('0000',to_date('2016-05-25 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-05-25 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','05','25',49000);

INSERT into back values('0000',to_date('2016-05-24 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-05-24 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','05','24',56000);

INSERT into back values('0000',to_date('2016-05-23 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-05-23 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','05','23',56000);

INSERT into back values('0000',to_date('2016-05-22 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-05-22 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','05','22',56000);

INSERT into back values('0000',to_date('2016-05-21 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-05-21 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','05','21',56000);

INSERT into back values('0000',to_date('2016-05-20 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-05-20 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','05','20',56000);

INSERT into back values('0000',to_date('2016-05-19 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-05-19 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','05','19',56000);

INSERT into back values('0000',to_date('2016-05-18 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-05-18 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','05','18',49000);

INSERT into back values('0000',to_date('2016-05-17 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-05-17 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','05','17',49000);

INSERT into back values('0000',to_date('2016-05-16 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-05-16 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','05','16',49000);

INSERT into back values('0000',to_date('2016-05-15 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-05-15 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','05','15',49000);

INSERT into back values('0000',to_date('2016-05-14 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-05-14 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','05','14',49000);

INSERT into back values('0000',to_date('2016-05-13 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-05-13 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','05','13',49000);

INSERT into back values('0000',to_date('2016-05-12 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-05-12 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','05','12',49000);

INSERT into back values('0000',to_date('2016-05-11 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-05-11 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','05','11',49000);

INSERT into back values('0000',to_date('2016-05-10 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-05-10 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','05','10',49000);

INSERT into back values('0000',to_date('2016-05-09 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-05-09 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','05','09',56000);

INSERT into back values('0000',to_date('2016-05-08 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-05-08 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','05','08',56000);

INSERT into back values('0000',to_date('2016-05-07 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-05-07 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','05','07',56000);

INSERT into back values('0000',to_date('2016-05-06 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-05-06 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','05','06',56000);

INSERT into back values('0000',to_date('2016-05-05 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-05-05 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','05','05',56000);

INSERT into back values('0000',to_date('2016-05-04 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-05-04 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','05','04',56000);

INSERT into back values('0000',to_date('2016-05-03 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-05-03 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','05','03',56000);

INSERT into back values('0000',to_date('2016-05-02 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-05-02 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','05','02',56000);

INSERT into back values('0000',to_date('2016-05-01 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-05-01 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','05','01',56000);
--///////////////////////

--////////////////////////////
--4월

INSERT into back values('0000',to_date('2016-04-30 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-04-30 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','04','30',56000);

INSERT into back values('0000',to_date('2016-04-29 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-04-29 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','04','29',56000);

INSERT into back values('0000',to_date('2016-04-28 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-04-28 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','04','28',49000);

INSERT into back values('0000',to_date('2016-04-27 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-04-27 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','04','27',49000);

INSERT into back values('0000',to_date('2016-04-26 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-04-26 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','04','26',49000);

INSERT into back values('0000',to_date('2016-04-25 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-04-25 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','04','25',49000);

INSERT into back values('0000',to_date('2016-04-24 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-04-24 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','04','24',56000);

INSERT into back values('0000',to_date('2016-04-23 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-04-23 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','04','23',56000);

INSERT into back values('0000',to_date('2016-04-22 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-04-22 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','04','22',56000);

INSERT into back values('0000',to_date('2016-04-21 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-04-21 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','04','21',56000);

INSERT into back values('0000',to_date('2016-04-20 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-04-20 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','04','20',56000);

INSERT into back values('0000',to_date('2016-04-19 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-04-19 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','04','19',56000);

INSERT into back values('0000',to_date('2016-04-18 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-04-18 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','04','18',49000);

INSERT into back values('0000',to_date('2016-04-17 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-04-17 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','04','17',49000);

INSERT into back values('0000',to_date('2016-04-16 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-04-16 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','04','16',49000);

INSERT into back values('0000',to_date('2016-04-15 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-04-15 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','04','15',49000);

INSERT into back values('0000',to_date('2016-04-14 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-04-14 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','04','14',49000);

INSERT into back values('0000',to_date('2016-04-13 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-04-13 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','04','13',49000);

INSERT into back values('0000',to_date('2016-04-12 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-04-12 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','04','12',49000);

INSERT into back values('0000',to_date('2016-04-11 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-04-11 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','04','11',49000);

INSERT into back values('0000',to_date('2016-04-10 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-04-10 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','04','10',49000);

INSERT into back values('0000',to_date('2016-04-09 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-04-09 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','04','09',56000);

INSERT into back values('0000',to_date('2016-04-08 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-04-08 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','04','08',56000);

INSERT into back values('0000',to_date('2016-04-07 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-04-07 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','04','07',56000);

INSERT into back values('0000',to_date('2016-04-06 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-04-06 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','04','06',56000);

INSERT into back values('0000',to_date('2016-04-05 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-04-05 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','04','05',56000);

INSERT into back values('0000',to_date('2016-04-04 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-04-04 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','04','04',56000);

INSERT into back values('0000',to_date('2016-04-03 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-04-03 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','04','03',56000);

INSERT into back values('0000',to_date('2016-04-02 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-04-02 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','04','02',56000);

INSERT into back values('0000',to_date('2016-04-01 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-04-01 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','04','01',56000);
--///////////////////////


--////////////////////////////
--3월

INSERT into back values('0000',to_date('2016-03-31 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-03-31 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','03','31',56000);

INSERT into back values('0000',to_date('2016-03-30 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-03-30 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','03','30',56000);

INSERT into back values('0000',to_date('2016-03-29 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-03-29 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','03','29',56000);

INSERT into back values('0000',to_date('2016-03-28 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-03-28 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','03','28',49000);

INSERT into back values('0000',to_date('2016-03-27 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-03-27 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','03','27',49000);

INSERT into back values('0000',to_date('2016-03-26 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-03-26 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','03','26',49000);

INSERT into back values('0000',to_date('2016-03-25 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-03-25 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','03','25',49000);

INSERT into back values('0000',to_date('2016-03-24 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-03-24 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','03','24',56000);

INSERT into back values('0000',to_date('2016-03-23 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-03-23 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','03','23',56000);

INSERT into back values('0000',to_date('2016-03-22 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-03-22 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','03','22',56000);

INSERT into back values('0000',to_date('2016-03-21 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-03-21 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','03','21',56000);

INSERT into back values('0000',to_date('2016-03-20 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-03-20 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','03','20',56000);

INSERT into back values('0000',to_date('2016-03-19 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-03-19 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','03','19',56000);

INSERT into back values('0000',to_date('2016-03-18 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-03-18 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','03','18',49000);

INSERT into back values('0000',to_date('2016-03-17 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-03-17 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','03','17',49000);

INSERT into back values('0000',to_date('2016-03-16 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-03-16 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','03','16',49000);

INSERT into back values('0000',to_date('2016-03-15 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-03-15 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','03','15',49000);

INSERT into back values('0000',to_date('2016-03-14 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-03-14 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','03','14',49000);

INSERT into back values('0000',to_date('2016-03-13 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-03-13 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','03','13',49000);

INSERT into back values('0000',to_date('2016-03-12 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-03-12 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','03','12',49000);

INSERT into back values('0000',to_date('2016-03-11 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-03-11 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','03','11',49000);

INSERT into back values('0000',to_date('2016-03-10 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-03-10 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','03','10',49000);

INSERT into back values('0000',to_date('2016-03-09 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-03-09 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','03','09',56000);

INSERT into back values('0000',to_date('2016-03-08 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-03-08 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','03','08',56000);

INSERT into back values('0000',to_date('2016-03-07 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-03-07 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','03','07',56000);

INSERT into back values('0000',to_date('2016-03-06 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-03-06 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','03','06',56000);

INSERT into back values('0000',to_date('2016-03-05 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-03-05 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','03','05',56000);

INSERT into back values('0000',to_date('2016-03-04 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-03-04 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','03','04',56000);

INSERT into back values('0000',to_date('2016-03-03 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-03-03 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','03','03',56000);

INSERT into back values('0000',to_date('2016-03-02 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-03-02 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','03','02',56000);

INSERT into back values('0000',to_date('2016-03-01 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-03-01 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','03','01',56000);
--///////////////////////


--////////////////////////////
--2월

INSERT into back values('0000',to_date('2016-02-29 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-02-29 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','02','29',56000);

INSERT into back values('0000',to_date('2016-02-28 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-02-28 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','02','28',49000);

INSERT into back values('0000',to_date('2016-02-27 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-02-27 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','02','27',49000);

INSERT into back values('0000',to_date('2016-02-26 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-02-26 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','02','26',49000);

INSERT into back values('0000',to_date('2016-02-25 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-02-25 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','02','25',49000);

INSERT into back values('0000',to_date('2016-02-24 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-02-24 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','02','24',56000);

INSERT into back values('0000',to_date('2016-02-23 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-02-23 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','02','23',56000);

INSERT into back values('0000',to_date('2016-02-22 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-02-22 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','02','22',56000);

INSERT into back values('0000',to_date('2016-02-21 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-02-21 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','02','21',56000);

INSERT into back values('0000',to_date('2016-02-20 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-02-20 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','02','20',56000);

INSERT into back values('0000',to_date('2016-02-19 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-02-19 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','02','19',56000);

INSERT into back values('0000',to_date('2016-02-18 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-02-18 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','02','18',49000);

INSERT into back values('0000',to_date('2016-02-17 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-02-17 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','02','17',49000);

INSERT into back values('0000',to_date('2016-02-16 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-02-16 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','02','16',49000);

INSERT into back values('0000',to_date('2016-02-15 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-02-15 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','02','15',49000);

INSERT into back values('0000',to_date('2016-02-14 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-02-14 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','02','14',49000);

INSERT into back values('0000',to_date('2016-02-13 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-02-13 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','02','13',49000);

INSERT into back values('0000',to_date('2016-02-12 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-02-12 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','02','12',49000);

INSERT into back values('0000',to_date('2016-02-11 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-02-11 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','02','11',49000);

INSERT into back values('0000',to_date('2016-02-10 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-02-10 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','02','10',49000);

INSERT into back values('0000',to_date('2016-02-09 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-02-09 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','02','09',56000);

INSERT into back values('0000',to_date('2016-02-08 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-02-08 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','02','08',56000);

INSERT into back values('0000',to_date('2016-02-07 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-02-07 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','02','07',56000);

INSERT into back values('0000',to_date('2016-02-06 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-02-06 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','02','06',56000);

INSERT into back values('0000',to_date('2016-02-05 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-02-05 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','02','05',56000);

INSERT into back values('0000',to_date('2016-02-04 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-02-04 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','02','04',56000);

INSERT into back values('0000',to_date('2016-02-03 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-02-03 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','02','03',56000);

INSERT into back values('0000',to_date('2016-02-02 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-02-02 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','02','02',56000);

INSERT into back values('0000',to_date('2016-02-01 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-02-01 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','02','01',56000);
--///////////////////////

--////////////////////////////
--1월

INSERT into back values('0000',to_date('2016-01-31 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-01-31 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','01','31',56000);

INSERT into back values('0000',to_date('2016-01-30 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-01-30 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','01','30',56000);

INSERT into back values('0000',to_date('2016-01-29 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-01-29 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','01','29',56000);

INSERT into back values('0000',to_date('2016-01-28 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-01-28 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','01','28',49000);

INSERT into back values('0000',to_date('2016-01-27 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-01-27 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','01','27',49000);

INSERT into back values('0000',to_date('2016-01-26 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-01-26 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','01','26',49000);

INSERT into back values('0000',to_date('2016-01-25 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-01-25 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','01','25',49000);

INSERT into back values('0000',to_date('2016-01-24 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-01-24 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','01','24',56000);

INSERT into back values('0000',to_date('2016-01-23 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-01-23 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','01','23',56000);

INSERT into back values('0000',to_date('2016-01-22 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-01-22 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','01','22',56000);

INSERT into back values('0000',to_date('2016-01-21 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-01-21 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','01','21',56000);

INSERT into back values('0000',to_date('2016-01-20 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-01-20 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','01','20',56000);

INSERT into back values('0000',to_date('2016-01-19 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-01-19 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','01','19',56000);

INSERT into back values('0000',to_date('2016-01-18 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-01-18 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','01','18',49000);

INSERT into back values('0000',to_date('2016-01-17 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-01-17 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','01','17',49000);

INSERT into back values('0000',to_date('2016-01-16 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-01-16 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','01','16',49000);

INSERT into back values('0000',to_date('2016-01-15 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-01-15 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','01','15',49000);

INSERT into back values('0000',to_date('2016-01-14 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-01-14 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','01','14',49000);

INSERT into back values('0000',to_date('2016-01-13 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-01-13 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','01','13',49000);

INSERT into back values('0000',to_date('2016-01-12 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-01-12 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','01','12',49000);

INSERT into back values('0000',to_date('2016-01-11 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-01-11 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','01','11',49000);

INSERT into back values('0000',to_date('2016-01-10 16:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-01-10 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','01','10',49000);

INSERT into back values('0000',to_date('2016-01-09 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-01-09 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','01','09',56000);

INSERT into back values('0000',to_date('2016-01-08 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-01-08 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','01','08',56000);

INSERT into back values('0000',to_date('2016-01-07 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-01-07 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','01','07',56000);

INSERT into back values('0000',to_date('2016-01-06 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-01-06 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','01','06',56000);

INSERT into back values('0000',to_date('2016-01-05 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-01-05 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','01','05',56000);

INSERT into back values('0000',to_date('2016-01-04 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-01-04 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','01','04',56000);

INSERT into back values('0000',to_date('2016-01-03 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-01-03 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','01','03',56000);

INSERT into back values('0000',to_date('2016-01-02 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-01-02 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','01','02',56000);

INSERT into back values('0000',to_date('2016-01-01 17:00:00','yyyy-MM-dd hh24:mi:SS'));
INSERT into go values('0000',to_date('2016-01-01 09:00:00','yyyy-MM-dd hh24:mi:SS'));
insert into emp_hour_pay values('0000','2016','01','01',56000);
--///////////////////////