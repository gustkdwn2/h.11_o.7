package th6.kosta.projectAction;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import th6.kosta.project.ProjectDAO;
import th6.kosta.project.ProjectVO;

public class BackAction implements CommandAction{

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub
		 ProjectDAO dao = ProjectDAO.getInstance();
	       HttpSession session = request.getSession();
	       String empno = (String)session.getAttribute("sess");
	       dao.insert_back(empno);
	       ProjectVO vo = dao.select_check_back(empno);
	      /* request.setAttribute("vo2", vo);*/
	       
	      return "/manage/backpro.jsp";
		
		
		
	}
	
}
