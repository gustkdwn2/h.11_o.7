package th6.kosta.projectAction;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import th6.kosta.project.ProjectDAO;
import th6.kosta.project.ProjectVO;

public class DailywageAction implements CommandAction{

	  @Override
	   public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
	      HttpSession session = request.getSession(false);
	     
	      String empno = (String)session.getAttribute("sess");
	   SimpleDateFormat sdf = new SimpleDateFormat("YYYY/MM/dd HH:mm:ss");
	      ProjectDAO dao = ProjectDAO.getInstance();
	      ProjectVO vo = dao.select_check_go(empno);
	      ProjectVO vo1 = dao.select_check_back(empno);
	      System.out.println("이것도 너프해 보시지 : "+vo1.getBack_date());
	      request.setAttribute("vo_go", vo);
	      request.setAttribute("vo_back", vo1);
	      if(vo.getGo_date() != null && vo1.getBack_date() !=  null){
	    	 
	
	    	  
	    	  ProjectVO vo2 = dao.minusTime(vo.getGo_date(), vo1.getBack_date(),empno);
	    	  System.out.println(vo2.getTotal_date());
	    	  
	    	  int pay =  (int) Math.round(((Double.parseDouble(vo2.getTotal_date()))/60)*7000);
	    	  request.setAttribute("pay", pay);
	      }
	  
	      return "/manage/dailywage.jsp";
	   }

}
