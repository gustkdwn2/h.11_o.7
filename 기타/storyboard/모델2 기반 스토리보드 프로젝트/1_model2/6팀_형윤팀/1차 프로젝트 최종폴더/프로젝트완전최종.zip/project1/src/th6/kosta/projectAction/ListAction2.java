package th6.kosta.projectAction;

import java.util.Collections;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import th6.kosta.project.ProjectDAO;

public class ListAction2 implements CommandAction{

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		int count = 0;
		List list = null;
	      
		ProjectDAO dao = ProjectDAO.getInstance();  //db 연결 
		count = dao.getlistAllCount();
		
		if (count > 0) {
			list = dao.getSelectAll();
		}else {
			list=Collections.EMPTY_LIST;
		}
		request.setAttribute("list", list);

		return "/manage/list2.jsp";
	}

}
