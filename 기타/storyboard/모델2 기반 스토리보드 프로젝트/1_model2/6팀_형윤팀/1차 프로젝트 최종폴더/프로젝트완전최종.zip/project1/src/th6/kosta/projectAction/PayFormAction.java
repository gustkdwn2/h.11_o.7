package th6.kosta.projectAction;

import java.util.List;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import th6.kosta.project.ProjectDAO;
import th6.kosta.project.ProjectVO;

public class PayFormAction implements CommandAction{

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub
		ProjectDAO dao = ProjectDAO.getInstance();
		HttpSession session = request.getSession(false);
		String empno = (String)session.getAttribute("sess");
		ProjectVO info = dao.SelectInfo(empno); 
		System.out.println("info = "+info);
		request.setAttribute("info", info);
		
		String year = request.getParameter("year");
		String month = request.getParameter("month");
		
		//if(request.getParameter("year") != null && request.getParameter("month") != null ){
		if(year != null && month != null ){
			
			System.out.println("year:"+year+", month : "+ month);
					
			ProjectVO vo = dao.selectPay(empno, year, month);   //dao.selectPay(empno, year, month);
			System.out.println("vo : " + vo);
			request.setAttribute("vo", vo);
		}
		
		
		
	
		
		
		
		return "/manage/payForm.jsp";
	}
	
	

}
