package th6.kosta.projectAction;

import java.util.GregorianCalendar;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class PayAction implements CommandAction{

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub
		String empno = request.getParameter("empno");
		GregorianCalendar today = new GregorianCalendar ( ); 
		int year = today.get(today.YEAR);
		int month = today.get(today.MONTH)+1;
		
		System.out.println("현재 년도 : " + year+", 현재 월 : "+ month);
		request.setAttribute("year", year);
		request.setAttribute("month", month);
		request.setAttribute("empno", empno);
		
		
		return "/manage/pay.jsp";
	}

}
