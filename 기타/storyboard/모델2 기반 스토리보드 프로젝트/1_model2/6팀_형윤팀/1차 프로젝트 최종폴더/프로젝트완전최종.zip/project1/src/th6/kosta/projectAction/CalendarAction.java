package th6.kosta.projectAction;

import java.util.Calendar;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import th6.kosta.project.ProjectDAO;

public class CalendarAction implements CommandAction{

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {

		Calendar cal= Calendar.getInstance(); //Calendar객체 cal생성
		  int currentYear=cal.get(Calendar.YEAR); //현재 날짜 기억
		  int currentMonth=cal.get(Calendar.MONTH);
		  int currentDate=cal.get(Calendar.DATE);
		  String Year=request.getParameter("year"); //나타내고자 하는 날짜
		  String Month=request.getParameter("month");
		  int year, month;
		  if(Year == null && Month == null){ //처음 호출했을 때
		  year=currentYear;
		  month=currentMonth;
		  }
		  else { //나타내고자 하는 날짜를 숫자로 변환
		   year=Integer.parseInt(Year);
		   month=Integer.parseInt(Month);
		   if(month<0) { month=11; year=year-1; } //1월부터 12월까지 범위 지정.
		   if(month>11) { month=0; year=year+1; }
		  }
		  
		  
		  cal.set(year, month, 1); //현재 날짜를 현재 월의 1일로 설정
		   int startDay=cal.get(Calendar.DAY_OF_WEEK); //현재날짜(1일)의 요일
		   int end=cal.getActualMaximum(Calendar.DAY_OF_MONTH); //이 달의 끝나는 날
		   int br=0; //7일마다 줄 바꾸기
		   
		   System.out.println("스타트 데이" + Calendar.DAY_OF_WEEK);
		   
		   List list = null;
		   HttpSession session = request.getSession();
		   String memoId = (String)session.getAttribute("user");
		   
		   ProjectDAO dao = ProjectDAO.getInstance();
		   list = dao.getscadule(memoId);
		 
		 int pay = dao.getscadulepay(memoId, year, month);
		  
		  
		request.setAttribute("year", new Integer(year));
		request.setAttribute("month", new Integer(month));
		request.setAttribute("currentYear", new Integer(currentYear));
		request.setAttribute("currentMonth", new Integer(currentMonth));
		request.setAttribute("currentDate", new Integer(currentDate));
		request.setAttribute("startDay", new Integer(startDay));
		request.setAttribute("end", new Integer(end));
		request.setAttribute("br", br);
		request.setAttribute("pay", pay);
		request.setAttribute("list", list);
		
		System.out.println("여기까진 완료!@@@@@");
		return "/manage/calendar.jsp";
	}

}
