package th6.kosta.projectAction;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import th6.kosta.project.ProjectDAO;
import th6.kosta.project.ProjectVO;

public class CalendarProAction implements CommandAction{

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("utf-8");
		HttpSession session = request.getSession();
		ProjectVO vo = new ProjectVO();
		
		vo.setMemoid((String)session.getAttribute("user"));
		vo.setMemoyear(Integer.parseInt(request.getParameter("memoYear")));
		vo.setMemomonth(Integer.parseInt(request.getParameter("memoMonth")));
		vo.setMemoday(Integer.parseInt(request.getParameter("memoDay")));
		vo.setMemocontents(request.getParameter("memoContents"));
		vo.setMemopay(Integer.parseInt(request.getParameter("memoPay")));

		
		
		
		ProjectDAO dao = ProjectDAO.getInstance();
		dao.memoinsert(vo);
		
		return "/manage/calendarpro.jsp";
	}

}
