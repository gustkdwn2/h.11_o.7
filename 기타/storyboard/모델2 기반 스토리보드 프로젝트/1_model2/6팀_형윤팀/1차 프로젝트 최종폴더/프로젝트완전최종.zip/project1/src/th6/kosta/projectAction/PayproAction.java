package th6.kosta.projectAction;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import th6.kosta.project.ProjectDAO;
import th6.kosta.project.ProjectVO;

public class PayproAction implements CommandAction{

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub
		String empno = request.getParameter("empno");
		String year = request.getParameter("year");
		String month = request.getParameter("month");
		String result = null;
		ProjectDAO dao = ProjectDAO.getInstance();

		if (empno != null) {

			ProjectVO vo = dao.selectBankinfo(empno);
			ProjectVO vo1 = dao.inpay(empno, year, month);
			String bank = vo.getBank();
			String account = vo.getAccount();
			String pay = vo1.getPay();
			request.setAttribute("empno", empno);
			request.setAttribute("bank", bank);
			request.setAttribute("year", year);
			request.setAttribute("month", month);
			request.setAttribute("account", account);
			request.setAttribute("pay", pay);

		}
		return "/manage/pay.jsp";
	}

}
