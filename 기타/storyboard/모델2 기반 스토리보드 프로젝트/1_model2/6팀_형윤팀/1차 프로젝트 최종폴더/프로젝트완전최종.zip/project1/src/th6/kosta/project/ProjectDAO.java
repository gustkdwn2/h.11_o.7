package th6.kosta.project;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.naming.InitialContext;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import dbclose.util.CloseUtil;



public class ProjectDAO {
	private static ProjectDAO instance = new ProjectDAO();

	public static ProjectDAO getInstance() {
		return instance;
	}

	public ProjectDAO() {
	}

	public Connection getConnection() throws Exception {
		InitialContext ctx = new InitialContext();
		// Context envContext = (Context) ctx.lookup("java:comp/env");
		DataSource ds = (DataSource) ctx.lookup("java:comp/env/jdbc:ProjectDB");

		return ds.getConnection();
	} // getConnection() end
	
	
	public int login(String enum_id, String passwd) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String dbpasswd = "";
		int result = 0;
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement("select passwd from login where enum_id = ?");
			pstmt.setString(1, enum_id);
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				dbpasswd = rs.getString("passwd");
				
				if (dbpasswd.equals(passwd)) {
					
					
					result = 1;
				} 
				
				else
					result = 0;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}

		return result;
	}

	public String user(String enum_id) {

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		String user = "";
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement("select name from employee where empno = ?");
			pstmt.setString(1, enum_id);
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				user = rs.getString("name");

			}
			System.out.println("dao에 있는 " + user);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}

		return user;
		
		
	}

	public int enumfind(String enums ,String name ,String birth) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String dbenum = "";
		int result = 0;
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement("select empno from employee where name = ? and birth = ?");
			pstmt.setString(1, name);
			pstmt.setString(2, birth);
			
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				dbenum = rs.getString("empno");
				
				if (dbenum.equals(enums)) {
					
					result = 1;
				} 
				
				else
					result = 0;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}

		System.out.println(result);
		return result;
	}
	
	
	public String passwdfind(String enums) {

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		String passwd = "";
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement("select passwd from login where enum_id = ?");
			pstmt.setString(1, enums);
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				passwd = rs.getString("passwd");

			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}

		return passwd;
	}
	
	public int signup(String empno ,String name ,String birth ,String dept ,String position ,String year ,String phone, String realPath1) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int result = 0;
		
		try {
			conn = getConnection();
			
			pstmt = conn.prepareStatement("insert into employee(empno,name,dept,position,phone,year,birth,imagepath) values (?,?,?,?,?,?,?,?)");
			pstmt.setString(1, empno);
			System.out.println("empnoDB : " + empno);
			pstmt.setString(2, name);
			pstmt.setString(3, dept);
			pstmt.setString(4, position);
			pstmt.setString(5, phone);
			pstmt.setString(6, year);
			pstmt.setString(7, birth);
			System.out.println(realPath1);
			pstmt.setString(8, realPath1);
			System.out.println("됨");
			
			rs = pstmt.executeQuery();
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		
		result = 1;
		System.out.println(result);
		return result;
	}
	
	public int signup2(String empno ,String passwd) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int result = 0;
		
		try {
			conn = getConnection();
			
			pstmt = conn.prepareStatement("insert into  login(enum_id,passwd) values (?,?)");
			pstmt.setString(1, empno);
			pstmt.setString(2, passwd);
			System.out.println("passwd : " + passwd);
	
			
			rs = pstmt.executeQuery();
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		
		result = 1;
		System.out.println(result);
		return result;
	}
	
	public List<ProjectDAO> getSelectAll() {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List list = null; // 글 목록 저장 변수
		StringBuffer sb = new StringBuffer();
		
		try {
			conn = getConnection();
			sb.append("select empno, name, dept, position, year, birth, rownum r  from EMPLOYEE order by empno");
			
			pstmt = conn.prepareStatement(sb.toString());
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				list = new ArrayList();
				
				do {
					ProjectVO vo = new ProjectVO();
					vo.setEmpno(rs.getString("empno"));
					vo.setName(rs.getString("name"));
					vo.setDept(rs.getString("dept"));
					vo.setPosition(rs.getString("position"));
					vo.setYear(rs.getString("year"));
					vo.setBirth(rs.getString("birth"));
					
					list.add(vo);
					
				} while (rs.next());
			}
			
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			CloseUtil.close(conn);
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
		}
		
		
		
		return list;
		
	}
	
	public int getlistAllCount() {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int count = 0;
		
		try {
			
			conn = getConnection();
			pstmt = conn.prepareStatement("select count(*) from EMPLOYEE");
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				count = rs.getInt(1);
				
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			CloseUtil.close(conn); CloseUtil.close(pstmt); CloseUtil.close(rs);
		}
		
		return count;
	}
	public ProjectVO  getDataDetail(String empno) {
		Connection  conn = null;
		PreparedStatement pstmt = null;
		ResultSet  rs = null;
		ProjectVO  vo = null;
		
		try {
			System.out.println("vo입력 전 확인 : " + empno);
			
			conn = getConnection();
			pstmt = conn.prepareStatement("SELECT * FROM employee WHERE empno = ?" );
			pstmt.setString(1, empno);
			rs = pstmt.executeQuery();
			
			if( rs.next() ) {
				vo = new ProjectVO();
				vo.setEmpno(rs.getString("empno"));
				vo.setName(rs.getString("name"));
				vo.setBirth(rs.getString("birth"));
				vo.setDept(rs.getString("dept"));
				vo.setPosition(rs.getString("position"));
				vo.setYear(rs.getString("year"));
				vo.setPhone(rs.getString("phone"));
				vo.setImagepath(rs.getString("imagepath"));
				System.out.println("주소 잘 받아오나 확인" + rs.getString("imagepath"));
				System.out.println("vo입력 확인 : " + empno);
				
				
			} // if end
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			 CloseUtil.close(rs);			 CloseUtil.close(pstmt);			 CloseUtil.close(conn);
		}	
		
		return vo ;
	} // getDataDetail(num) end
	
	
	
	
	public int update(String empno ,String name ,String birth ,String dept ,String position ,String year ,String phone , String passwd ,String empno1, String uppath) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int result = 0;
		String dbpasswd = "";
		
		try {
			conn = getConnection();
			
			pstmt = conn.prepareStatement("select passwd from login where enum_id = ?");
			pstmt.setString(1, empno1);
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				dbpasswd = rs.getString("passwd");
				
				if (dbpasswd.equals(passwd)) {
					
					pstmt = conn.prepareStatement("update employee set name = ? , dept = ? , position = ? , phone = ? , year = ? ,birth = ? , imagepath = ? where empno = ?");
					
					System.out.println("empnoDBdd : " + empno);
					pstmt.setString(1, name);
					pstmt.setString(2, dept);
					pstmt.setString(3, position);
					pstmt.setString(4, phone);
					pstmt.setString(5, year);
					pstmt.setString(6, birth);	
					pstmt.setString(7, uppath);	
					pstmt.setString(8, empno);
					System.out.println("됨");
					
					rs = pstmt.executeQuery();
					
					
					result = 1;
				} 
				
				else
					result = 0;
			}
			
			
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}

		System.out.println(result);
		return result;
	}
	
	public ProjectVO SelectInfo(String empno) throws Exception{
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ProjectVO vo =null;
		StringBuffer sb = new StringBuffer();
		try {
			conn=getConnection();
			sb.append("select empno , name, dept, position, phone, year, birth ");
			sb.append("from employee where empno = ? ");
			pstmt = conn.prepareStatement(sb.toString());
			pstmt.setString(1, empno);
			rs = pstmt.executeQuery();
			
			
			
			while(rs.next()) {
				System.out.println("지금이순간");
				do {
					vo = new ProjectVO();
					vo.setEmpno(rs.getString("empno"));
					vo.setName(rs.getString("name"));
					vo.setDept(rs.getString("dept"));
					vo.setPosition(rs.getString("position"));
					vo.setPhone(rs.getString("phone"));
					vo.setYear(rs.getString("year"));
					vo.setBirth(rs.getString("birth"));
					
					
				} while (rs.next());
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			//e.printStackTrace();
		}
		
		return vo;
		
	}
	
	public ProjectVO selectPay(String empno,String year,String month){
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ProjectVO  vo = null;
		
	      StringBuffer sb = new StringBuffer();
	      System.out.println("이까진옴54354354354   ");
	      System.out.println("empno:  "+empno+" year : "+year+" month: "+month);
	      try {
	         conn = getConnection();
	         /*sb.append("select employee.empno,employee.name,employee.dept,employee.position,employee.phone,employee.year,employee.birth,");
	         sb.append("emp_pay.year,emp_pay.month, emp_pay.pay from employee  inner join emp_pay on employee.empno=emp_pay.empno ");*/
	         sb.append("select employee.empno, emp_pay.pay from employee inner join emp_pay on employee.empno=emp_pay.empno ");
	         sb.append(" where employee.empno= ? and emp_pay.year= ? and emp_pay.month= ? ");
	         
	         pstmt = conn.prepareStatement(sb.toString());
	         
	        /* String sql = "select employee.empno, emp_pay.pay from employee inner join emp_pay on employee.empno=emp_pay.empno ";
	        		sql += " where employee.empno= ? and emp_pay.year= ? and emp_pay.month= ?";*/
	        		
	       	        
	         pstmt.setString(1, empno);
	         pstmt.setString(2, year);
	         pstmt.setString(3, month);
	         
	        	        
	         rs = pstmt.executeQuery();
	           
	         
	         while(rs.next()) {
	        	 vo = new ProjectVO();
	            	
	           	  System.out.println("여기서부터 확인해야함");
	           	 
	           	  vo.setEmpno(rs.getString("empno"));
	           	  
	              vo.setPay(rs.getString("pay"));
	              vo.setYear(year);
	              vo.setMonth(month);
	              //return vo;
	         }
     	 
	      } catch (Exception e) { 
	    	  System.out.println(e.getMessage());
	    	  //e.printStackTrace();
	      }
		
		return vo;
	}
	
	
	public int delete(String empno , String passwd , String empno1) {
		Connection  conn = null;
		PreparedStatement pstmt = null;
		ResultSet  rs = null;
		
		String dbpasswd = "";
		int result = -1;
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement("select  passwd  from login where enum_id = ?" );
			pstmt.setString(1, empno1);
			rs = pstmt.executeQuery();
			
			
			
			if( rs.next() ) {
				dbpasswd = rs.getString("passwd");
				
				System.out.println("delet DAO dppasswd : " + dbpasswd);
				System.out.println("passwd : " + passwd);
				System.out.println("empno : " + empno);
				System.out.println("empno1 : " + empno1);
				
				if( dbpasswd.equals(passwd)) {
					
					pstmt = conn.prepareStatement("delete from login where enum_id=?");
					pstmt.setString(1,empno);
					pstmt.executeQuery();   //
					
					pstmt = conn.prepareStatement("delete from employee where empno=?");
					pstmt.setString(1,empno);
					pstmt.executeQuery();   //
					
					pstmt = conn.prepareStatement("delete from emp_pay where empno=?");
					pstmt.setString(1,empno);
					pstmt.executeQuery();   //
					
					result = 1;   // 업데이트 성공시 1 리턴...
					System.out.println("result 11= "+ result);
				} else {
					result = 0; // 비번이 틀렸을때 
				} // if in end		
			} // if out end
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			 CloseUtil.close(rs);			 CloseUtil.close(pstmt);			 CloseUtil.close(conn);
		}			
		
		return result;
	} // update(BoardVO vo ) end

	public List<ProjectVO> getscadule(String memoId) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ProjectVO vo = null;
		List list = null;
	
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement("SELECT calendarmemo_year, calendarmemo_month, calendarmemo_day, calendarmemo_contents, calendarmemo_pay FROM calendarmemo where CALENDARMEMO_ID = ? ");
			
			pstmt.setString(1, memoId);
			
			rs= pstmt.executeQuery();
			
		
			
			 list = new ArrayList();
			 
			 while(rs.next()) {
				 vo = new ProjectVO();
				
				 
				vo.setMemoyear(rs.getInt("calendarmemo_year"));
				vo.setMemomonth(rs.getInt("calendarmemo_month"));
				vo.setMemoday(rs.getInt("calendarmemo_day"));
				vo.setMemocontents(rs.getString("calendarmemo_contents"));
				vo.setMemopay(rs.getInt("calendarmemo_pay"));
							
				list.add(vo);
				
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			CloseUtil.close(conn);
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
		}
		
		
		
		
		return list;
	}

	public void memoinsert(ProjectVO vo) {

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		
		
		int memoYear = vo.getMemoyear();
		int memoMonth = vo.getMemomonth();
		int memoDay = vo.getMemoday();
		int memoPay = vo.getMemopay();
		String memoId = vo.getMemoid();
		String memoContents = vo.getMemocontents();
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement("INSERT INTO CALENDARMEMO(CALENDARMEMO_ID, CALENDARMEMO_CONTENTS, CALENDARMEMO_YEAR, CALENDARMEMO_MONTH, CALENDARMEMO_DAY, CALENDARMEMO_PAY) VALUES (?, ?, ?, ?, ?, ?) ");
			pstmt.setString(1, memoId);
			pstmt.setString(2, memoContents);
			pstmt.setInt(3, memoYear);
			pstmt.setInt(4, memoMonth);
			pstmt.setInt(5, memoDay);
			pstmt.setInt(6, memoPay);
			
			
			rs=pstmt.executeQuery();
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			CloseUtil.close(conn); CloseUtil.close(rs); CloseUtil.close(pstmt); 
		}
		
	}

	public int getscadulepay(String memoId, int year, int month) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		
		
		int pay = 0;
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement("select calendarmemo_pay from CALENDARMEMO where CALENDARMEMO_ID = ? AND CALENDARMEMO_YEAR = ? AND CALENDARMEMO_MONTH = ?");
			
			
			
			pstmt.setString(1, memoId);
			pstmt.setInt(2, year);
			pstmt.setInt(3, month+1);
			
			rs=pstmt.executeQuery();
			
			while (rs.next()) {
				pay = pay + rs.getInt(1);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			CloseUtil.close(conn); CloseUtil.close(rs); CloseUtil.close(pstmt); 
		}
		
		System.out.println("pay 는 = " + pay);
		
		return pay;
	}

	public int scaduledelete(String memoId, String contents, int memopay, int memoday, int memoyear, int memomonth) {
		
		Connection  conn = null;
		PreparedStatement pstmt = null;
		ResultSet  rs = null;
		StringBuffer sb = new StringBuffer();
		int result = 0;
		
		try {
			conn = getConnection();
			
			sb.append("delete from CALENDARMEMO where CALENDARMEMO_ID = ? and CALENDARMEMO_CONTENTS = ? ");
			sb.append(" and CALENDARMEMO_YEAR = ? and CALENDARMEMO_MONTH = ? and CALENDARMEMO_DAY = ? ");
			sb.append(" and CALENDARMEMO_PAY = ? ");
			
			pstmt = conn.prepareStatement(sb.toString());
			
			pstmt.setString(1, memoId);
			pstmt.setString(2, contents);
			pstmt.setInt(3, memoyear);
			pstmt.setInt(4, memomonth);
			pstmt.setInt(5, memoday);
			pstmt.setInt(6, memopay);
			
			pstmt.executeUpdate();
			
			result = 1;
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			CloseUtil.close(conn); CloseUtil.close(rs); CloseUtil.close(pstmt); 
		}
		
		
		return result;
	}

	public void insert_back(String empno) {
		Connection conn = null;
		PreparedStatement pstmt = null;

		ResultSet rs = null;
		String sql = "";

		try {
			conn = getConnection();
			sql = "insert into back values(?,sysdate)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, empno);
			pstmt.executeUpdate();

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
	}

	public ProjectVO select_check_back(String empno) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		SimpleDateFormat sfd = new SimpleDateFormat("yyyy/MM/dd");
		java.util.Date date = new java.util.Date();
		ResultSet rs = null;
		ProjectVO vo = new ProjectVO();
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(
					"select to_char(back_date,'yyyy/MM/dd') from back where empno =? and ROWNUM = (select min(ROWNUM) from back where empno = ? )order by back_date desc");
			pstmt.setString(1, empno);
			pstmt.setString(2, empno);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				String years = rs.getString("to_char(back_date,'yyyy/MM/dd')");
				System.out.println("years : " +years);
				if (years.equals(sfd.format(date))) {
					System.out.println("sfd.format(date) : " + sfd.format(date));
					vo.setCheck("1");

					pstmt = conn.prepareStatement(
							"select back_date from back where empno =? and ROWNUM = (select min(ROWNUM) from back where empno = ? )order by back_date desc");
					pstmt.setString(1, empno);
					pstmt.setString(2, empno);
					rs = pstmt.executeQuery();
					if (rs.next()) {
						vo.setBack_date(rs.getTimestamp("back_date"));
						System.out.println("vo.getBack_date() : "+vo.getBack_date());
					}
				}else {
					vo.setCheck("0");
				}
			} else {
				vo.setCheck("0");
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		return vo;
	}

	public int correctBank(String bank, String empno) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ProjectVO vo = null;
		int check = 0;
		String result = null;
		StringBuffer sb = new StringBuffer();
		try {
			conn = getConnection();
			sb.append("select bank from emp_bank ");
			sb.append("where empno = ?");
			pstmt = conn.prepareStatement(sb.toString());
			pstmt.setString(1, empno);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				result = rs.getString("bank");
				System.out.println("result : " + result);
				System.out.println("bank : " + bank);
				if (result.equalsIgnoreCase(bank)) {
					System.out.println("result : " + result);
					check = 1;
				} else {
					check = 0;
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return check;
	}

	public ProjectVO insertPay(String empno, String year, String month, String pay) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ProjectVO vo = new ProjectVO();
		String sql = "";
		try {
			conn = getConnection();
			sql  = "select pay from emp_pay where empno = ? and year = ? and month = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, empno);
			pstmt.setString(2, year);
			pstmt.setString(3, month);
			rs = pstmt.executeQuery();
			if(rs.next()){
				vo.setCheck("0");
			}else{
			sql = "insert into emp_pay values(?,?,?,?)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, empno);
			pstmt.setString(2, year);
			pstmt.setString(3, month);
			pstmt.setString(4, pay);
			pstmt.executeUpdate();
			vo.setCheck("1");
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		return vo;
	}

	public ProjectVO select_check_go(String empno) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		SimpleDateFormat sfd = new SimpleDateFormat("yyyy/MM/dd");
		java.util.Date date = new java.util.Date();
		ResultSet rs = null;
		ProjectVO vo = new ProjectVO();
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(
					"select to_char(go_date,'yyyy/MM/dd') from go where empno =? and ROWNUM = (select min(ROWNUM) from go where empno = ? )order by go_date desc");
			pstmt.setString(1, empno);
			pstmt.setString(2, empno);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				String years = rs.getString("to_char(go_date,'yyyy/MM/dd')");
				System.out.println("years : " +years);
				if (years.equals(sfd.format(date))) {
					System.out.println("sfd.format(date) : " + sfd.format(date));
					vo.setCheck("1");

					pstmt = conn.prepareStatement(
							"select go_date from go where empno =? and ROWNUM = (select min(ROWNUM) from go where empno = ? )order by go_date desc");
					pstmt.setString(1, empno);
					pstmt.setString(2, empno);
					rs = pstmt.executeQuery();
					if (rs.next()) {
						vo.setGo_date(rs.getTimestamp("go_date"));
					}
				}else {
					vo.setCheck("0");
				}
			} else {
				vo.setCheck("0");
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		return vo;
	}

	public ProjectVO minusTime(Timestamp time1, Timestamp time2,String empno){
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ProjectVO vo = new ProjectVO();
		System.out.println("이건 출력될껄? :"+time1+","+time2);
		SimpleDateFormat sdf = new SimpleDateFormat("YYYY");
		SimpleDateFormat sdf1 = new SimpleDateFormat("MM");
		SimpleDateFormat sdf2 = new SimpleDateFormat("dd");
		String year = sdf.format(time2);
		String month = sdf1.format(time2);
		String day = sdf2.format(time2);
		
		String sql = "";
		try {
			System.out.println("이건 출력될껄? :"+time1+","+time2);
			
			
				sql = "SELECT MI * 1 * 24 * 60 as ti FROM (SELECT TO_DATE(to_char(?,'yyyy-mm-dd hh24:mi:ss'),'YYYY-MM-DD HH24:MI:SS') - TO_DATE(to_char(?,'yyyy-mm-dd hh24:mi:ss'),'YYYY-MM-DD HH24:MI:SS') MI FROM dual )";
				//sql = "WITH t AS(  SELECT TO_DATE(to_char(?,'yyyy-mm-dd hh24:mi:ss'), 'yyyy-mm-dd hh24:mi:ss') sdt, TO_DATE(to_char(?,'yyyy-mm-dd hh24:mi:ss'),'yyyy-mm-dd hh24:mi:ss') edt    FROM dual) SELECT (edt - sdt)*24*60*60  sssss1  FROM t ";
				conn = getConnection();
				pstmt = conn.prepareStatement(sql);
				pstmt.setTimestamp(1 ,time2 );
				pstmt.setTimestamp(2 ,time1 );
				rs = pstmt.executeQuery();
				
				if (rs.next()) {
					vo.setTotal_date(rs.getString("ti"));
				}
				
				sql = "select pay from emp_hour_pay where year=? and month = ? and day =?";
				
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1 ,year );
				pstmt.setString(2 ,month );
				pstmt.setString(3 ,day );
				rs = pstmt.executeQuery();
				
				if (rs.next()) {

				}else{
					int pay = (int) Math.round(((Double.parseDouble(vo.getTotal_date()))/60)*7000);
					sql  = "insert into emp_hour_pay values(?,?,?,?,?)";
					pstmt = conn.prepareStatement(sql);
					pstmt.setString(1,empno);
					pstmt.setString(2,year);
					pstmt.setString(3,month);
					pstmt.setString(4,day);
					pstmt.setInt(5, pay);
					pstmt.executeUpdate();
				}
			
		} catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
		}finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		return vo;
	}

	public void insert_go(String empno) {
		Connection conn = null;
		PreparedStatement pstmt = null;

		ResultSet rs = null;
		String sql = "";

		try {
			conn = getConnection();
			sql = "insert into go values(?,sysdate)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, empno);
			pstmt.executeUpdate();

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
	}

	public ProjectVO selectBankinfo(String empno) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ProjectVO vo = null;
		StringBuffer sb = new StringBuffer();
		try {
			conn = getConnection();
			sb.append("select bank,account from emp_bank where empno = ?");
			pstmt = conn.prepareStatement(sb.toString());
			pstmt.setString(1, empno);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				vo = new ProjectVO();
				vo.setAccount(rs.getString("account"));
				vo.setBank(rs.getString("bank"));
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		return vo;
	}

	public ProjectVO inpay(String empno, String year, String month) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ProjectVO vo = new ProjectVO();
		String sql = "";
		try {
			conn = getConnection();
			sql = "select empno,year,month,sum(pay) as total from emp_hour_pay where empno = ? and year = ? and month = ?  group by empno,year,month";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, empno);
			pstmt.setString(2, year);
			pstmt.setString(3, month);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				vo.setPay(rs.getString("total"));
			}

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		return vo;
	}

	public int signup3(String empno ,String bank,String account) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int result = 0;
		
		try {
			conn = getConnection();
			
			pstmt = conn.prepareStatement("insert into  emp_bank(empno,bank,account) values (?,?,?) ");
			pstmt.setString(1, empno);
			pstmt.setString(2, bank);
			pstmt.setString(3, account);
			
			rs = pstmt.executeQuery();
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		
		result = 1;
		System.out.println(result);
		return result;
	}
			
	
}
