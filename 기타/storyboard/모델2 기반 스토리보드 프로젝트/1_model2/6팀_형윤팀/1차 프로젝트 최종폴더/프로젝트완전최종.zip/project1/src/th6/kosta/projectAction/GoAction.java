package th6.kosta.projectAction;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import th6.kosta.project.ProjectDAO;
import th6.kosta.project.ProjectVO;

public class GoAction implements CommandAction{

		   @Override
		   public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		       ProjectDAO dao = ProjectDAO.getInstance();
		       HttpSession session = request.getSession();
		       String empno = (String)session.getAttribute("sess");
		       dao.insert_go(empno);
		       ProjectVO vo = dao.select_check_go(empno);
		       
		      return "/manage/gopro.jsp";
		   }


	}
	

