package th6.kosta.projectController;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import th6.kosta.projectAction.CommandAction;

public class ProjectController extends HttpServlet {
   
   private Map commandMap = new HashMap<>();

   protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      process(request, response);
   }
   

   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      process(request, response);
   }

   public void init(ServletConfig config) throws ServletException {
      String props = config.getInitParameter("propertyConfig"); //web.xml ���� ���� �о����
      Properties pr = new Properties();
      FileInputStream f = null;
      
      try {
         f=new FileInputStream(props);
         pr.load(f);
         
      } catch (Exception e) {
         e.printStackTrace();
      } finally{
         if(f!=null) try{f.close();} catch(Exception e){e.printStackTrace();}
      }
      Iterator keyIter = (Iterator)pr.keySet().iterator();
      
      while(keyIter.hasNext()){
         String command=(String)keyIter.next();
         String className = pr.getProperty(command); // value : edu.kosta.boardAction.WriteFormAction
         try {
            Class commandClass = Class.forName(className);
            Object commandInstance = commandClass.newInstance();
            
            commandMap.put(command, commandInstance);
         } catch (Exception e) {
            e.printStackTrace();
         }
      }
   }

   protected void process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      String view = null;
      CommandAction ca = null;
      //System.out.println(commandMap);
      try {
         String command = request.getRequestURI();
         
         
         System.out.println("command : "+command); 
         System.out.println("request.getContextPath()"+request.getContextPath()); //day52_boardMVC
         
         
         if(command.indexOf(request.getContextPath())==0){
            command = command.substring(request.getContextPath().length()+1);
            System.out.println(command);
         }
         
         ca=(CommandAction)commandMap.get(command);
         System.out.println("ca : "+ca);
         
         view = ca.process(request, response);
         System.out.println("view : "+view);
         
      } catch (Exception e) {
         e.printStackTrace();
      }
      
      if (view.equals("/manage/first.jsp") || view.equals("/manage/firstPro.jsp") || 
      		view.equals("/manage/findpasswd.jsp") ||  view.equals("/manage/forgetpasswdpro.jsp") || view.equals("/manage/forgetpasswd.jsp") ) {
      	  System.out.println("비교넘어옴");
    	  
    
    		  
    		  request.setAttribute("CONTENT", view);
    		  System.out.println("첫번째 저장된 content = " + view);
              RequestDispatcher dispatcher = request.getRequestDispatcher("/template/template1.jsp");
              dispatcher.forward(request, response);
	
		
	}else{
		
      request.setAttribute("CONTENT", view);
      System.out.println("엘즈 view" + view);
      RequestDispatcher dispatcher = request.getRequestDispatcher("/template/template2.jsp");
      dispatcher.forward(request, response);
		
	}
   }
   }

