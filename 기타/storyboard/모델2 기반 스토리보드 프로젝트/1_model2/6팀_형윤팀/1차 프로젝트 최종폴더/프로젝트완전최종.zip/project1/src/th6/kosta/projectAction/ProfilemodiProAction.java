package th6.kosta.projectAction;

import java.io.File;
import java.util.Enumeration;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import th6.kosta.project.ProjectDAO;
import th6.kosta.project.ProjectVO;

public class ProfilemodiProAction implements CommandAction{

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
request.setCharacterEncoding("utf-8");
		
HttpSession session = request.getSession();
String empno1 = (String)session.getAttribute("sess");
System.out.println("현재 세션 확인" + empno1);

String realPath = "";	//웹 어플리케이션상의 절대경로
String savePath = "upload";	//저장하는 곳.?
String encType = "utf-8";	//타입 설정.
String uppath = "";
int maxSize = 1024 * 1024 * 5;	//최대업로드 파일 크기 (5M)

ServletContext context = request.getSession().getServletContext();	//현재 jsp 페이지의 웹 어플리케이션상의 절대경로를 구함
realPath = context.getRealPath(savePath + "\\");	//절대경로 주소 받아옴.
System.out.println("realPath is : " + realPath);

try{
	MultipartRequest multi = null; //전송을 담당할 컴포넌트를 생성하고 파일을 전송
	multi = new MultipartRequest(
									request,
									realPath,
									maxSize,
									encType,
									new DefaultFileRenamePolicy()
			);
	Enumeration files = multi.getFileNames();
	while(files.hasMoreElements()){
		String name = (String )files.nextElement();
		String fileName = multi.getFilesystemName(name); //물리적경로
		String original = multi.getOriginalFileName(name);	//오리지널 파일명
		String type = multi.getContentType(name);
		
		File file = multi.getFile(name);
		
		System.out.println("파라미터 이름 : " + name);
		System.out.println("실제 파일 이름 : " + fileName);
		System.out.println("저장된 파일 이름 : " + original);
		System.out.println("파일 타입 : " + type);
		
		uppath =fileName;
		System.out.println("uppath 는!!!   =  " + uppath);
		if( file != null){
			System.out.println("크기 : " + file.length());
				
		}//if end
	} //end while
	

		String empno = multi.getParameter("empno");
		String name = multi.getParameter("name");
		String birth = multi.getParameter("birth");
		String passwd = multi.getParameter("passwd");
		String dept = multi.getParameter("dept");
		String position = multi.getParameter("position");
		String year = multi.getParameter("year");
		String phone = multi.getParameter("phone");
		String realPath1 = uppath;
	
		
		System.out.println("proAc empno :"+name);
		
		ProjectVO vo = new ProjectVO();
		vo.setEmpno(multi.getParameter("empno"));
		vo.setName(multi.getParameter("name"));
		vo.setBirth(multi.getParameter("birth"));
		vo.setPwd(multi.getParameter("passwd"));
		vo.setDept(multi.getParameter("dept"));
		vo.setPosition(multi.getParameter("position"));
		vo.setYear(multi.getParameter("year"));
		vo.setPhone(multi.getParameter("phone"));
		vo.setImagepath(uppath);
	
		
		
		
		System.out.println("proAc2 empno :"+empno);
		ProjectDAO dao = ProjectDAO.getInstance();
		int check = dao.update(empno , name , birth , dept , position , year , phone , passwd ,empno1, uppath);
		
		request.setAttribute("check", check);
		
}catch (Exception e) {
	e.printStackTrace();
}finally{
	
}
		return "/manage/profilemodiPro.jsp";
	}
}
