package th6.kosta.projectAction;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import th6.kosta.project.ProjectDAO;
import th6.kosta.project.ProjectVO;

public class BankCorrectAction implements CommandAction{

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("utf-8");
		String bank = request.getParameter("bank");
		System.out.println("java bank : "+bank);
		String empno = request.getParameter("empno");
		String year = request.getParameter("year");
		String month = request.getParameter("month");
		String pay = request.getParameter("pay");
		ProjectDAO dao = ProjectDAO.getInstance();
		int check = dao.correctBank(bank, empno);
		ProjectVO check2 = dao.insertPay(empno, year, month, pay);
		request.setAttribute("check", check);
		System.out.println("check1 : "+check +",check2.getCheck() : " +check2.getCheck());
		request.setAttribute("check2", check2.getCheck());
		
		
		return "/manage/paypro.jsp";
	}

}
