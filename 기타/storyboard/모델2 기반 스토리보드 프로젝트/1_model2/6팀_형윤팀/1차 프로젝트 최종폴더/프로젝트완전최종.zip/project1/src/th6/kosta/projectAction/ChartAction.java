package th6.kosta.projectAction;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import th6.kosta.project.ProjectDAO;

public class ChartAction implements CommandAction{

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		java.util.Calendar cal=java.util.Calendar.getInstance(); //Calendar객체 cal생성
		  int currentYear=cal.get(java.util.Calendar.YEAR); //현재 날짜 기억
		  int currentMonth=cal.get(java.util.Calendar.MONTH);
		  
		  HttpSession session = request.getSession();
		  String memoId = (String)session.getAttribute("user");
		  ProjectDAO dao = ProjectDAO.getInstance();
		  
		  int month = currentMonth-1;
		  int month1 = currentMonth-2;
		  int month2 = currentMonth-3;
		  int month3 = currentMonth-4;
		  int month4 = currentMonth-5;
		  int month5 = currentMonth-6;
		  int month6 = currentMonth-7;
		  int year = currentYear;
		  int year1 = currentYear;
		  int year2 = currentYear;
		  int year3 = currentYear;
		  int year4 = currentYear;
		  int year5 = currentYear;
		  int year6 = currentYear;
		  	
		  if (month <= 0){ month = 12 + (0+month); year = year-1; }
		  if (month1 <= 0){ month1 = 12 + (0+month); year1 = year1-1; }
		  if (month2 <= 0){ month2 = 12 + (0+month); year2 = year2-1; }
		  if (month3 <= 0){ month3 = 12 + (0+month); year3 = year3-1;}
		  if (month4 <= 0){ month4 = 12 + (0+month); year4 = year4-1;}
		  if (month5 <= 0){ month5 = 12 + (0+month); year5 = year5-1;}
		  if (month6 <= 0){ month6 = 12 + (0+month); year6 = year6-1;}
		
		  
		  int pay = dao.getscadulepay(memoId, year, month);
		  int pay1 = dao.getscadulepay(memoId, year1, month1);
		  int pay2 = dao.getscadulepay(memoId, year2, month2);
		  int pay3 = dao.getscadulepay(memoId, year3, month3);
		  int pay4 = dao.getscadulepay(memoId, year4, month4);
		  int pay5 = dao.getscadulepay(memoId, year5, month5);
		  int pay6 = dao.getscadulepay(memoId, year6, month6);
		  

		
		  request.setAttribute("year", currentYear);
		  request.setAttribute("month", month+1);
		  request.setAttribute("month1", month1+1);
		  request.setAttribute("month2", month2+1);
		  request.setAttribute("month3", month3+1);
		  request.setAttribute("month4", month4+1);
		  request.setAttribute("month5", month5+1);
		  request.setAttribute("month6", month6+1);
		  request.setAttribute("pay", pay);
		  request.setAttribute("pay1", pay1);
		  request.setAttribute("pay2", pay2);
		  request.setAttribute("pay3", pay3);
		  request.setAttribute("pay4", pay4);
		  request.setAttribute("pay5", pay5);
		  request.setAttribute("pay6", pay6);
		  
		  
		return "/manage/chart.jsp";
	}

}
