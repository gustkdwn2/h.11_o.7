//-------------테이블 검색, 이전, 다음 버튼에 대한 기능. ----------------------
$(document).ready(function() {
        $('#dataTables-example').DataTable({
            responsive: true
        });
    });
    
    $(function() {
        $("#upload").on('change', function(){
            readURL(this);
        });
    });

    function readURL(input) {
        if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
                $('#imupload').attr('src', e.target.result);
            }

          reader.readAsDataURL(input.files[0]);
        }
    }

    function mysubmit(index) {
        if (index == 1) {
          document.form1.action='profilemodiPro.do';
        }
        if (index == 2) {
          document.form1.action='delet.do';
        }
        document.form1.submit();
      }
    
    $(function() {
    	  $("#datepicker").datepicker();
    	 });
    
//   이동 스크롤@@@@@@@@@@@@@@@@
    
    $(document).ready(function(){
        var topHeight = parseInt($(".content-scroll").css("top").substring(0,$(".content-scroll").css("top").indexOf("px")))
        $(window).scroll(function () { 
            offset = topHeight+$(document).scrollTop()+"px";
            //duration으로 스크롤 내릴때 같이 동작하는 속도 조절
            $(".content-scroll").animate({top:offset},{duration:0,queue:false});
        });
    });