package team2.miniproject.DAO_VO;

public class employeeVO {
	String emp_num, emp_name, emp_pwd, major, emp_grade, money, mon_lev,
			emp_email, tel;

	public String getEmp_num() {
		return emp_num;
	}

	public void setEmp_num(String emp_num) {
		this.emp_num = emp_num;
	}

	public String getEmp_name() {
		return emp_name;
	}

	public void setEmp_name(String emp_name) {
		this.emp_name = emp_name;
	}

	public String getEmp_pwd() {
		return emp_pwd;
	}

	public void setEmp_pwd(String emp_pwd) {
		this.emp_pwd = emp_pwd;
	}

	public String getMajor() {
		return major;
	}

	public void setMajor(String major) {
		this.major = major;
	}

	public String getEmp_grade() {
		return emp_grade;
	}

	public void setEmp_grade(String emp_grade) {
		this.emp_grade = emp_grade;
	}

	public String getMoney() {
		return money;
	}

	public void setMoney(String money) {
		this.money = money;
	}

	public String getMon_lev() {
		return mon_lev;
	}

	public void setMon_lev(String mon_lev) {
		this.mon_lev = mon_lev;
	}

	public String getEmp_email() {
		return emp_email;
	}

	public void setEmp_email(String emp_email) {
		this.emp_email = emp_email;
	}

	public String getTel() {
		return tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	
	
	
}
