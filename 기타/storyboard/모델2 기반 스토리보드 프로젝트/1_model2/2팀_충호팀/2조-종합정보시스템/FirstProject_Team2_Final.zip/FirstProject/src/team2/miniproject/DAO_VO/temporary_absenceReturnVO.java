package team2.miniproject.DAO_VO;

public class temporary_absenceReturnVO {
	String stu_num, stu_name, stu_grade, major, stu_birthday, stu_professor, stu_email, address, tel, absence, return_semester;

	public String getStu_num() {
		return stu_num;
	}

	public void setStu_num(String stu_num) {
		this.stu_num = stu_num;
	}

	public String getStu_name() {
		return stu_name;
	}

	public void setStu_name(String stu_name) {
		this.stu_name = stu_name;
	}

	public String getStu_grade() {
		return stu_grade;
	}

	public void setStu_grade(String stu_grade) {
		this.stu_grade = stu_grade;
	}

	public String getMajor() {
		return major;
	}

	public void setMajor(String major) {
		this.major = major;
	}

	public String getStu_birthday() {
		return stu_birthday;
	}

	public void setStu_birthday(String stu_birthday) {
		this.stu_birthday = stu_birthday;
	}

	public String getStu_professor() {
		return stu_professor;
	}

	public void setStu_professor(String stu_professor) {
		this.stu_professor = stu_professor;
	}

	public String getStu_email() {
		return stu_email;
	}

	public void setStu_email(String stu_email) {
		this.stu_email = stu_email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getTel() {
		return tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	public String getAbsence() {
		return absence;
	}

	public void setAbsence(String absence) {
		this.absence = absence;
	}

	public String getReturn_semester() {
		return return_semester;
	}

	public void setReturn_semester(String return_semester) {
		this.return_semester = return_semester;
	}	
	
	
}
