package team2.miniproject.DAO_VO;

public class StudentVO {
	String stu_num, stu_name, stu_pwd, stu_sex, stu_birthday, stu_state, stu_professor, stu_email,
			major, submajor, grade, address, tel, home_tel;

	public String getStu_num() {
		return stu_num;
	}

	public void setStu_num(String stu_num) {
		this.stu_num = stu_num;
	}

	public String getStu_name() {
		return stu_name;
	}

	public void setStu_name(String stu_name) {
		this.stu_name = stu_name;
	}

	public String getStu_pwd() {
		return stu_pwd;
	}

	public void setStu_pwd(String stu_pwd) {
		this.stu_pwd = stu_pwd;
	}

	public String getStu_sex() {
		return stu_sex;
	}

	public void setStu_sex(String stu_sex) {
		this.stu_sex = stu_sex;
	}

	public String getStu_birthday() {
		return stu_birthday;
	}

	public void setStu_birthday(String stu_birthday) {
		this.stu_birthday = stu_birthday;
	}

	public String getStu_state() {
		return stu_state;
	}

	public void setStu_state(String stu_state) {
		this.stu_state = stu_state;
	}

	public String getStu_professor() {
		return stu_professor;
	}

	public void setStu_professor(String stu_professor) {
		this.stu_professor = stu_professor;
	}

	public String getStu_email() {
		return stu_email;
	}

	public void setStu_email(String stu_email) {
		this.stu_email = stu_email;
	}

	public String getMajor() {
		return major;
	}

	public void setMajor(String major) {
		this.major = major;
	}

	public String getSubmajor() {
		return submajor;
	}

	public void setSubmajor(String submajor) {
		this.submajor = submajor;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getTel() {
		return tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	public String getHome_tel() {
		return home_tel;
	}

	public void setHome_tel(String home_tel) {
		this.home_tel = home_tel;
	}
	
	
}
