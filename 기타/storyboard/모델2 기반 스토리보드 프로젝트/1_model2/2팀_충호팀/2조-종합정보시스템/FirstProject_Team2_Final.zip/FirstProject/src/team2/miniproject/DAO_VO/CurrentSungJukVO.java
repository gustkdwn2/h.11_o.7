package team2.miniproject.DAO_VO;

public class CurrentSungJukVO {
	String stu_num, sj_year, sj_grade, sj_term, sub_grade, sub_code, sub_name, sub_hakjum, emp_name;

	public String getStu_num() {
		return stu_num;
	}

	public void setStu_num(String stu_num) {
		this.stu_num = stu_num;
	}

	public String getSj_year() {
		return sj_year;
	}

	public void setSj_year(String sj_year) {
		this.sj_year = sj_year;
	}

	public String getSj_grade() {
		return sj_grade;
	}

	public void setSj_grade(String sj_grade) {
		this.sj_grade = sj_grade;
	}

	public String getSj_term() {
		return sj_term;
	}

	public void setSj_term(String sj_term) {
		this.sj_term = sj_term;
	}

	public String getSub_grade() {
		return sub_grade;
	}

	public void setSub_grade(String sub_grade) {
		this.sub_grade = sub_grade;
	}

	public String getSub_code() {
		return sub_code;
	}

	public void setSub_code(String sub_code) {
		this.sub_code = sub_code;
	}

	public String getSub_name() {
		return sub_name;
	}

	public void setSub_name(String sub_name) {
		this.sub_name = sub_name;
	}

	public String getSub_hakjum() {
		return sub_hakjum;
	}

	public void setSub_hakjum(String sub_hakjum) {
		this.sub_hakjum = sub_hakjum;
	}

	public String getEmp_name() {
		return emp_name;
	}

	public void setEmp_name(String emp_name) {
		this.emp_name = emp_name;
	}
	
	
}
