package team2.miniproject.DAO_VO;

public class SubjectVO {
	String sub_code, sub_name, sub_hakjum, emp_name, sub_time;

	public String getSub_code() {
		return sub_code;
	}

	public void setSub_code(String sub_code) {
		this.sub_code = sub_code;
	}

	public String getSub_name() {
		return sub_name;
	}

	public void setSub_name(String sub_name) {
		this.sub_name = sub_name;
	}

	public String getSub_hakjum() {
		return sub_hakjum;
	}

	public void setSub_hakjum(String sub_hakjum) {
		this.sub_hakjum = sub_hakjum;
	}

	public String getEmp_name() {
		return emp_name;
	}

	public void setEmp_name(String emp_name) {
		this.emp_name = emp_name;
	}

	public String getSub_time() {
		return sub_time;
	}

	public void setSub_time(String sub_time) {
		this.sub_time = sub_time;
	}
	
	
}
