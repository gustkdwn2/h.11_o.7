package team2.miniproject.DAO_VO;

public class LectureMaterialVO {

		String submit_week, sub_code,	 emp_num, submit_title, submit_content, 
			filename, description;
		int filesize;
		
		

		public String getFilename() {
			return filename;
		}

		public void setFilename(String filename) {
			this.filename = filename;
		}

		public String getDescription() {
			return description;
		}

		public void setDescription(String description) {
			this.description = description;
		}

		public int getFilesize() {
			return filesize;
		}

		public void setFilesize(int filesize) {
			this.filesize = filesize;
		}

		public String getSubmit_week() {
			return submit_week;
		}

		public void setSubmit_week(String submit_week) {
			this.submit_week = submit_week;
		}

		public String getSub_code() {
			return sub_code;
		}

		public void setSub_code(String sub_code) {
			this.sub_code = sub_code;
		}

		public String getEmp_num() {
			return emp_num;
		}

		public void setEmp_num(String emp_num) {
			this.emp_num = emp_num;
		}

		public String getSubmit_title() {
			return submit_title;
		}

		public void setSubmit_title(String submit_title) {
			this.submit_title = submit_title;
		}

		public String getSubmit_content() {
			return submit_content;
		}

		public void setSubmit_content(String submit_content) {
			this.submit_content = submit_content;
		}
		
		
}
