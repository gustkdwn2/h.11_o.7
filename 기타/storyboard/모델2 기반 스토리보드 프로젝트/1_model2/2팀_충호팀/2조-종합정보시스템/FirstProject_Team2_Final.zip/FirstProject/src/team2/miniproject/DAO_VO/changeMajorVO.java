package team2.miniproject.DAO_VO;

public class changeMajorVO {
	String stu_num, stu_name, stu_grade, major, stu_birthday, stu_professor, stu_email, tel, change_major, reason_why;

	public String getStu_num() {
		return stu_num;
	}

	public void setStu_num(String stu_num) {
		this.stu_num = stu_num;
	}

	public String getStu_name() {
		return stu_name;
	}

	public void setStu_name(String stu_name) {
		this.stu_name = stu_name;
	}

	public String getStu_grade() {
		return stu_grade;
	}

	public void setStu_grade(String stu_grade) {
		this.stu_grade = stu_grade;
	}

	public String getMajor() {
		return major;
	}

	public void setMajor(String major) {
		this.major = major;
	}

	public String getStu_birthday() {
		return stu_birthday;
	}

	public void setStu_birthday(String stu_birthday) {
		this.stu_birthday = stu_birthday;
	}

	public String getStu_professor() {
		return stu_professor;
	}

	public void setStu_professor(String stu_professor) {
		this.stu_professor = stu_professor;
	}

	public String getStu_email() {
		return stu_email;
	}

	public void setStu_email(String stu_email) {
		this.stu_email = stu_email;
	}

	public String getTel() {
		return tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	public String getChange_major() {
		return change_major;
	}

	public void setChange_major(String change_major) {
		this.change_major = change_major;
	}

	public String getReason_why() {
		return reason_why;
	}

	public void setReason_why(String reason_why) {
		this.reason_why = reason_why;
	}
	
	
}
