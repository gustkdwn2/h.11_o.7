package team2.miniproject.DAO_VO;

public class JanghakVO {
	
	public String stu_num,jh_year, jh_term, jh_name;
	int money_su, money_ip;
	
	public String getStu_num() {
		return stu_num;
	}

	public void setStu_num(String stu_num) {
		this.stu_num = stu_num;
	}

	public String getJh_year() {
		return jh_year;
	}

	public void setJh_year(String jh_year) {
		this.jh_year = jh_year;
	}

	public String getJh_term() {
		return jh_term;
	}

	public void setJh_term(String jh_term) {
		this.jh_term = jh_term;
	}

	public String getJh_name() {
		return jh_name;
	}

	public void setJh_name(String jh_name) {
		this.jh_name = jh_name;
	}

	public int getMoney_su() {
		return money_su;
	}

	public void setMoney_su(int money_su) {
		this.money_su = money_su;
	}

	public int getMoney_ip() {
		return money_ip;
	}

	public void setMoney_ip(int money_ip) {
		this.money_ip = money_ip;
	}



	
}
