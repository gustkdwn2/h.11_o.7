package team2.miniproject.DAO_VO;

public class Sub_detailVO {
	String sub_code ,sub_name ,sub_hakjum ,emp_name ,sub_time ,lec_detail
	,lec_purpose,lec_exam;

	public String getLec_purpose() {
		return lec_purpose;
	}

	public void setLec_purpose(String lec_purpose) {
		this.lec_purpose = lec_purpose;
	}

	public String getLec_exam() {
		return lec_exam;
	}

	public void setLec_exam(String lec_exam) {
		this.lec_exam = lec_exam;
	}

	public String getSub_code() {
		return sub_code;
	}

	public void setSub_code(String sub_code) {
		this.sub_code = sub_code;
	}

	public String getSub_name() {
		return sub_name;
	}

	public void setSub_name(String sub_name) {
		this.sub_name = sub_name;
	}

	public String getSub_hakjum() {
		return sub_hakjum;
	}

	public void setSub_hakjum(String sub_hakjum) {
		this.sub_hakjum = sub_hakjum;
	}

	public String getEmp_name() {
		return emp_name;
	}

	public void setEmp_name(String emp_name) {
		this.emp_name = emp_name;
	}

	public String getSub_time() {
		return sub_time;
	}

	public void setSub_time(String sub_time) {
		this.sub_time = sub_time;
	}

	public String getLec_detail() {
		return lec_detail;
	}

	public void setLec_detail(String lec_detail) {
		this.lec_detail = lec_detail;
	}
	
	
	
}
