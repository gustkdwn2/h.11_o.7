package edu.kosta.cookcook.controller.admin;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.kosta.cookcook.controller.main.CommandAction;
import edu.kosta.cookcook.model.CookCookDAO;

public class AdminUserDeleteFormAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {

		request.setCharacterEncoding("UTF-8");
		
		CookCookDAO dao = CookCookDAO.getInstance();
		
		List list = dao.getUserAll();
		
		request.setAttribute("list", list);
		
		return "/view/contents/admin/userdelete/deleteForm.jsp";
	}

}