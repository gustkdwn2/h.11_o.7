package edu.kosta.cookcook.controller.user;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.kosta.cookcook.controller.main.CommandAction;
import edu.kosta.cookcook.model.CookCookDAO;
import edu.kosta.cookcook.model.CookCookUserVO;

public class UserInfoUpdateAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		request.setCharacterEncoding("UTF-8");
		
		CookCookUserVO vo = new CookCookUserVO();
		int result = 0;
		
		vo.setId(request.getParameter("id"));
		vo.setPwd(request.getParameter("pwd"));
		vo.setEmail(request.getParameter("email"));
		
		CookCookDAO dao = CookCookDAO.getInstance();
		result = dao.userInfoUpdate(vo);
		
		request.setAttribute("result", result);
		
		return "/view/contents/user/userInfoModifyPro.jsp";
	}

}
