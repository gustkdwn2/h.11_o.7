package edu.kosta.cookcook.controller.login;
import edu.kosta.cookcook.controller.*;
import edu.kosta.cookcook.controller.main.CommandAction;
import edu.kosta.cookcook.model.CookCookDAO;
import edu.kosta.cookcook.model.CookCookVO;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LoginUpdateAction implements CommandAction{
	public String process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String id = request.getParameter("id");
		String pwd = request.getParameter("pwd");
		String pwd1 = request.getParameter("pwd1");
		String email = request.getParameter("email");
		  
		int log = 3;
		
		CookCookDAO dao = CookCookDAO.getInstance();
		
		if(pwd.equals(pwd1)){
			log = dao.loginup(id, pwd1, email);
		}
		
		request.setAttribute("log", log);
		
		return "/view/contents/login/LoginUpdatePro.jsp";
	}
}
