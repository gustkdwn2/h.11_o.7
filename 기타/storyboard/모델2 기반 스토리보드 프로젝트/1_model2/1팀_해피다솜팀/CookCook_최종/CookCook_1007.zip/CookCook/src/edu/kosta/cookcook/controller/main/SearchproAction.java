package edu.kosta.cookcook.controller.main;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.kosta.cookcook.model.CookCookDAO;
import edu.kosta.cookcook.model.CookCookVO;

public class SearchproAction implements CommandAction{
	public String process(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	
		int count = 0;
		int counts = 0;
		String[] str = new String[20];
		String[] sele = new String[3];
		
		for(int i=0; i<str.length; i++){
			String a = "str"+(i+1);
			str[i] = request.getParameter(a);
			if (str[i] != null) {
				counts++;
			}
		}										
		
		for (int i = 0; i <= counts; i++) {
			for (int j = 0; j < str.length; j++) {
				if (str[j] != null) {
					sele[i] = str[j];
					i++;
				}
			}
		}										
		
		CookCookDAO dao = CookCookDAO.getInstance();
		List<CookCookVO> list = dao.getSelectSearch(counts, sele);	
		
			
		count = dao.Selecount(counts, sele);
		
		request.setAttribute("list", list);
		request.setAttribute("count", count);
		
		return "/view/contents/list.jsp";
	}
}