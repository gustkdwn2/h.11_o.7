package edu.kosta.cookcook.controller.login;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import edu.kosta.cookcook.controller.main.CommandAction;

public class LogOutAction implements CommandAction{
	public String process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		HttpSession session = request.getSession();
	    session.invalidate();
		
		return "/view/contents/main_contents.jsp";
	}
}
