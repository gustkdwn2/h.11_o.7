package edu.kosta.cookcook.controller.login;
import edu.kosta.cookcook.controller.*;
import edu.kosta.cookcook.controller.main.CommandAction;
import edu.kosta.cookcook.model.CookCookDAO;
import edu.kosta.cookcook.model.CookCookVO;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class LoginCheckAction  implements CommandAction {
	   public String process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		   		   
		   String id = request.getParameter("id");
		   String pwd = request.getParameter("password");
		   
		   CookCookDAO dao = CookCookDAO.getInstance();
		   
		   int log = dao.login(id, pwd);
		   request.setAttribute("log", log);
		   
		   HttpSession session = request.getSession();
		   
		   if(log == 1){
			   session.setAttribute("sid", id);
		   } else {
			   id = null;
			   session.setAttribute("sid", id);
		   }
		   		   
		   if(log == 4){
			   
			   List<CookCookVO> list = dao.getSelectAll();
			   request.setAttribute("list", list);
			   
			   return "/view/contents/admin/adminPage.jsp";
		   } else {
			   return "/view/contents/login/LoginPro.jsp";
		   }
	   }
}