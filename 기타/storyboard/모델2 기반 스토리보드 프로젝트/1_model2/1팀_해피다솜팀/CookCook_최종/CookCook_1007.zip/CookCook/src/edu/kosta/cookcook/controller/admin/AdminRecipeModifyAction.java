package edu.kosta.cookcook.controller.admin;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.kosta.cookcook.controller.main.CommandAction;
import edu.kosta.cookcook.model.CookCookDAO;
import edu.kosta.cookcook.model.CookCookVO;

public class AdminRecipeModifyAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		String cookid = request.getParameter("cookid");
		
		System.out.println("cookid = "+cookid);
		
		CookCookDAO dao = CookCookDAO.getInstance();
		CookCookVO vo = dao.getSelectCookid(cookid);			
		
		request.setAttribute("list", vo);	
		
		return "/view/contents/admin/recipe/recipemodify.jsp";
	}

}
