package edu.kosta.cookcook.controller.main;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.kosta.cookcook.model.CookCookDAO;
import edu.kosta.cookcook.model.CookCookVO;

public class Searchpro3Action implements CommandAction {
	public String process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String[] a = new String[7];
		int count = 0;
		
		String code = "";
		for(int i = 0; i<7; i++ ){
			String b = "0"+(i+1);
			a[i] = request.getParameter(b);
			if(a[i]!=null){
				code = a[i];
			}
		}
		//System.out.println(b);
		
		CookCookDAO dao = CookCookDAO.getInstance();
		List<CookCookVO> list = dao.getSelectSearch3(code);
		
		count = list.size();
		
		request.setAttribute("list", list);
		request.setAttribute("count", count);
		
		return "/view/contents/list.jsp";
	}
}
