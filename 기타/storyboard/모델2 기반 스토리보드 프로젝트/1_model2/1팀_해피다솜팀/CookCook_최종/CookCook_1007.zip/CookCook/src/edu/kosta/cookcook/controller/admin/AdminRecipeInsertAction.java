package edu.kosta.cookcook.controller.admin;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.kosta.cookcook.controller.main.CommandAction;
import edu.kosta.cookcook.model.CookCookDAO;
import edu.kosta.cookcook.model.CookCookVO;

public class AdminRecipeInsertAction implements CommandAction {
   public String process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	  request.setCharacterEncoding("UTF-8"); 
	  
	  CookCookVO vo = new CookCookVO();	   
      String[] str = new String[20];
      
      int result = 0;

		vo.setCookid(request.getParameter("cookid"));
	    vo.setCookname(request.getParameter("cookname"));
	    vo.setUrl(request.getParameter("url"));
	    vo.setSrc(request.getParameter("src"));
	    vo.setCal(request.getParameter("cal"));
	    vo.setCode(request.getParameter("code"));
      
	    for(int i = 0; i<20; i++){
	       String a = "str"+(i+1);
	       str[i] = request.getParameter(a);
	       
	       if (str[i] != null) 
	          str[i] = "1";
	       else
	          str[i] = "0";
	       }
	    
	    vo.setEgg(str[0]);
	    vo.setCarrot(str[1]);
	    vo.setOnion(str[2]);
	    vo.setPotato(str[3]);
	    vo.setGarlic(str[4]);
	    vo.setMushroom(str[5]);
	    vo.setPepper(str[6]);
	    vo.setDaikon(str[7]);
	    vo.setLettuce(str[8]);
	    vo.setPumpkin(str[9]);
	    vo.setPork(str[10]);
	    vo.setBeef(str[11]);
	    vo.setChicken(str[12]);
	    vo.setSausage(str[13]);
	    vo.setBacon(str[14]);
	    vo.setMackerel(str[15]);
	    vo.setSquid(str[16]);
	    vo.setSaury(str[17]);
	    vo.setMussel(str[18]);
	    vo.setCheese(str[19]);
	    
		CookCookDAO dao = CookCookDAO.getInstance();
		result = dao.recipeInsert(vo);
		
		List<CookCookVO> list = dao.getSelectAll();
		
		int count = list.size();
		
		request.setAttribute("result",result);
		request.setAttribute("list", list);
		request.setAttribute("count", count);
							
		return "/view/contents/admin/recipe/recipeList.jsp";
      }
}