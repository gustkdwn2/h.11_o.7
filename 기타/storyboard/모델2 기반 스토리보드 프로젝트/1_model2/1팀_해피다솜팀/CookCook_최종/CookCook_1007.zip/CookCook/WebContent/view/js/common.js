var overFlag = false;
//var clickFlag = false;
//var oldObj;
		$(document).ready(function() {
			$(".sub_menu").hide();
			
			// 대메뉴 마우스오버 이벤트
			$(".menu>li").hover(function(){
				$(this).children(".sub_menu").stop(true, false, true).slideDown(200);
				$(this).addClass("menu_active");
				$(this).find("span").removeClass("white");
			},function(){
				$(this).removeClass("menu_active");
				$(this).find("span").addClass("white");
				$(this).children(".sub_menu").slideUp(100);
			});

			$(".sub_menu").hover(function(){
				 $(this).show();
			},function(){
				 $(this).slideUp();
			});
			
			/*// 대메뉴 클릭 이벤트
			$(".menu>li").click(function(){
				$(this).children(".sub_menu").slideDown(100);
				$(this).addClass("menu_active");
				$(this).find("span").removeClass("white");
			});

			$(".sub_menu").hover(function(){
				 $(this).show();
			},function(){
				 $(this).slideUp();
				 $(this).parent("li").removeClass("menu_active");
				 $(this).parent("li").find("span").addClass("white");
			});*/
			
			// 서브메뉴 마우스오버 이벤트
			$(".sub_menu_over").hover(function(){
				overFlag = true;
				$(this).find("img").removeClass('gray');
			},function() {
				$(this).find("img").addClass('gray');
			});

		// Checkbox
		$(function () {
			$('.check').on('click', function () {
				// 초기화
				$('.sub_menu>li>a').removeClass('sub_menu_on');
				$('.sub_menu_over>img').addClass('gray');
				$('.choice_result').find('span').remove(); // 선택된 재료 지우기
				
				var obj = this;
				var valThis = $(this).val();
				setTimeout(function() {
					if (!$(obj).prop('checked'))
					{
						$("input:checkbox").each( function(index) {
								var val = $(this).val();
								if (val==valThis) $(this).prop('checked', false);
								//$('.choice_result').removeAttr('span'); // 선택된 재료 지우기
						});
					}
					var checkValues = '';
					$("input:checkbox").each( function(index) {
							var val = $(this).val();
							var getNames = $(this).parent().parent().find(".sub_menu_txt").text();
							var checked = $(this).prop('checked');
							if (checked) {
								checkValues += val + '['+ getNames + ']' + ',';
							}
					});

					$("input:checkbox").each( function(index) {
						var val = $(this).val();
						if (checkValues.indexOf(val)>=0) { 
							$(this).prop('checked', true);
							$(this).parent().parent().find("a").addClass('sub_menu_on');
							$(this).parent().parent().find("img").removeClass('gray');
						} 
					});	
					
					$.each(checkValues.split(','), function( i, codeAndNames) {
						if (codeAndNames=='') return true;	// 공백 스킵
						var _name = codeAndNames.split('[')[1].replace(']','');
						//console.log('/' + checkValues + _name);
						
						if ($(".choice_result_append").html().indexOf(_name)>=0 || _name=='') return true;
						$(".choice_result_append").append("<span class='choice_material'>"+ _name + "</span>");
					});
					checkValues = '';
				}, 100);
			});
			
			// 레시피 URL 페이지 위치지정
			/*$('.includedContent').animate({          //Scroll된 Target
			    //위치값 가져올 Target
			    scrollTop:$(".inner_url").offset().top
			}, 200);*/
			$("#header").hide();
			$("#u_skip").hide();
			$(".cont_utility").hide();
			$("#footer").hide();
			$(".section6").hide();
		});	
	}); // end document.ready()	