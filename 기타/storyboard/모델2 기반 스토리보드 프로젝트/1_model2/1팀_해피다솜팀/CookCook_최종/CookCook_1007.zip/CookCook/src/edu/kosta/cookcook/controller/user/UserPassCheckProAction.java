package edu.kosta.cookcook.controller.user;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.kosta.cookcook.controller.main.CommandAction;
import edu.kosta.cookcook.model.CookCookDAO;
import edu.kosta.cookcook.model.CookCookUserVO;

public class UserPassCheckProAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		String id = request.getParameter("id");
		String password = request.getParameter("password");
		
		System.out.println("UserPassCheckPro's id : "+id);
		
		int result = 0;
		
		CookCookDAO dao = CookCookDAO.getInstance();
		result = dao.userPassWordCheck(id,password);
	
		request.setAttribute("result", result);
		request.setAttribute("id",id);
		
		return "/view/contents/user/userPassCheckPro.jsp";
	}

}
