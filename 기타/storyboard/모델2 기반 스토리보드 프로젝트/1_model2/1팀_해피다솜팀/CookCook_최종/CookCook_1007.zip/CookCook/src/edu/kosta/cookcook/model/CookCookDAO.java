package edu.kosta.cookcook.model;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.InitialContext;
import javax.servlet.http.HttpServletRequest;
import javax.sql.DataSource;

import edu.kosta.cookcook.dbutil.CloseUtil;

public class CookCookDAO { // Controller
	
	private static CookCookDAO instance = new CookCookDAO();

	public static CookCookDAO getInstance() {
		return instance;
	}

	public CookCookDAO() {
	}

	public Connection getConnection() throws Exception {
		Connection conn = null;		
		
		try {
			   Class.forName("com.mysql.jdbc.Driver");
			   conn = DriverManager.getConnection("jdbc:mysql://cookcook.czprhotkwfkj.ap-northeast-2.rds.amazonaws.com:3306/CookCook","admin","qwer1234");
		} catch (Exception e) {
			e.printStackTrace();
			
		} finally {			
			return conn;
		}		
	}
	////////////////////////////
	public int login(String id, String pwd) {
	      Connection conn = null;
	      PreparedStatement pstmt = null;
	      ResultSet rs = null;
	      
	      int log = 0;
	      
	      String admin = "";
	      String sql = "select id from userinfo where id = ? and pwd = ?";

	      try {
	         conn = getConnection();
	         pstmt = conn.prepareStatement(sql);
	         pstmt.setString(1, id);
	         pstmt.setString(2, pwd);
	         rs = pstmt.executeQuery();
	         
	         if (rs.next()){
	            log = 1;
	            admin = rs.getString("id");
	            if(admin.equals("admin")){
	               log = 4;
	            }
	         }
	      } catch (Exception e) {
	         e.printStackTrace();
	      } 
	      finally {
	         CloseUtil.close(conn);
	         CloseUtil.close(rs);
	         CloseUtil.close(pstmt);
	      }

	      return log;
	   }
	
	////////////////////////////////////////
	 public int loginup(String id, String pwd, String email) {
	      Connection conn = null;
	      PreparedStatement pstmt = null;
	      ResultSet rs = null;
	      int log = 0;
	      
	      String sql = "insert into userinfo(id, pwd, email) values(?, ?, ?)";

	      try {
	         conn = getConnection();
	         pstmt = conn.prepareStatement(sql);
	         pstmt.setString(1, id);
	         pstmt.setString(2, pwd);
	         pstmt.setString(3, email);
	         
	         log = pstmt.executeUpdate();

	      } catch (Exception e) {
	         e.printStackTrace();
	      } finally {
	         CloseUtil.close(conn);
	         CloseUtil.close(rs);
	         CloseUtil.close(pstmt);
	      }

	      return log;
	 }	
	 
	public int Selecount(int counts, String sele[]) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int count = 0;
		String sql = "";

		if (counts == 0) {
			sql = "select count(*) from cook";
		} else if (counts == 1) {
			sql = "select count(*) from cook where " + sele[0] + "='1'";
		} else if (counts == 2) {
			sql = "select count(*) from cook where " + sele[0] + "='1' and " + sele[1] + "='1'";
		} else if (counts == 3) {
			sql = "select count(*) from cook where " + sele[0] + "='1' and " + sele[1] + "='1' and " + sele[2] + "='1'";
		} else
			sql = "select count(*) from cook";

		try {
			
			conn = getConnection();

			pstmt = conn.prepareStatement(sql);

			rs = pstmt.executeQuery();

			if (rs.next())
				count = rs.getInt(1);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(conn);
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
		}

		return count;
	}
	
	
	public int Selecount2(String search) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int count = 0;
		String sql = "select count(*) from cook where cookname like ?";

		try {
			conn = getConnection();

			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, "%"+search+"%");
			rs = pstmt.executeQuery();

			if (rs.next())
				count = rs.getInt(1);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(conn);
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
		}

		return count;
	}

	public List<CookCookVO> getSelectSearch(int count, String sele[]) {

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<CookCookVO> list = null;
		String sql = "";

		if (count == 0) {
			sql = "select * from cook";
		} else if (count == 1) {
			sql = "select * from cook where " + sele[0] + "='1'";
		} else if (count == 2) {
			sql = "select * from cook where " + sele[0] + "='1' and " + sele[1] + "='1'";
		} else if (count == 3) {
			sql = "select * from cook where " + sele[0] + "='1' and " + sele[1] + "='1' and " + sele[2]
					+ "='1'";
		} else
			sql = "select * from cook";

		try {
			conn = getConnection();

			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				list = new ArrayList();
				do {
					CookCookVO vo = new CookCookVO();
					
					vo.setCookid(rs.getString("cookid"));
					vo.setCookname(rs.getString("cookname"));
					vo.setUrl(rs.getString("url"));
					vo.setSrc(rs.getString("src"));
					vo.setCal(rs.getString("cal"));
					vo.setLove(rs.getInt("love"));
					
					list.add(vo);

				} while (rs.next());
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(conn);
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
		}

		return list;
	}

	public List<CookCookVO> getSelectSearch2(String search) {

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<CookCookVO> list = null;
		String sql = "select * from cook where cookname like ?";

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, "%"+search+"%");
			rs = pstmt.executeQuery();

			if (rs.next()) {
				list = new ArrayList();

				do {
					CookCookVO vo = new CookCookVO();
					
					vo.setCookid(rs.getString("cookid"));
					vo.setCookname(rs.getString("cookname"));
					vo.setUrl(rs.getString("url"));
					vo.setSrc(rs.getString("src"));
					vo.setCal(rs.getString("cal"));
					vo.setLove(rs.getInt("love"));
					
					list.add(vo);

				} while (rs.next());
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(conn);
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
		}

		return list;
	}	
	   public List<CookCookVO> getSelectSearch3(String code) {

		      Connection conn = null;
		      PreparedStatement pstmt = null;
		      ResultSet rs = null;
		      List<CookCookVO> list = null;
		      String sql = "";

		      if(code.equals("01")){
		         sql = "select * from cook join cook_category on cook.code = cook_category.code where cook.code='01'";
		      } else if(code.equals("02")){
		         sql = "select * from cook join cook_category on cook.code = cook_category.code where cook.code='02'";
		      } else if(code.equals("03")){
		         sql = "select * from cook join cook_category on cook.code = cook_category.code where cook.code='03'";
		      } else if(code.equals("04")){
		         sql = "select * from cook join cook_category on cook.code = cook_category.code where cook.code='04'";
		      } else if(code.equals("05")){
		         sql = "select * from cook join cook_category on cook.code = cook_category.code where cook.code='05'";
		      } else if(code.equals("06")){
		         sql = "select * from cook join cook_category on cook.code = cook_category.code where cook.code='06'";
		      } else if(code.equals("07")){
		         sql = "select * from cook join cook_category on cook.code = cook_category.code where cook.code='07'";
		      }
		         
		      try {
		         conn = getConnection();

		         pstmt = conn.prepareStatement(sql);
		         rs = pstmt.executeQuery();

		         if (rs.next()) {
		            list = new ArrayList();

		            do {
		               CookCookVO vo = new CookCookVO();
		               
		               vo.setCookid(rs.getString("cookid"));
		               vo.setCookname(rs.getString("cookname"));
		               vo.setUrl(rs.getString("url"));
		               vo.setSrc(rs.getString("src"));
		               vo.setCal(rs.getString("cal"));
		               vo.setLove(rs.getInt("love"));
		               
		               list.add(vo);

		            } while (rs.next());
		         }
		      } catch (Exception e) {
		         e.printStackTrace();
		      } finally {
		         CloseUtil.close(conn);
		         CloseUtil.close(rs);
		         CloseUtil.close(pstmt);
		      }

		      return list;
		   }
	   public CookCookVO getSelectCookid(String cookid) {
			
			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			CookCookVO vo = null;
			
			String sql = "select * from cook where cookid = ?";

			try {
				conn = getConnection();

				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, cookid);
				rs = pstmt.executeQuery();

				if (rs.next()) {
					
						vo = new CookCookVO();
						
						vo.setCookid(rs.getString("cookid"));
						vo.setCookname(rs.getString("cookname"));
			            vo.setEgg(rs.getString("egg"));
			            vo.setCarrot(rs.getString("carrot"));
			            vo.setOnion(rs.getString("onion"));
			            vo.setPotato(rs.getString("potato"));
			            vo.setGarlic(rs.getString("garlic"));
			            vo.setMushroom(rs.getString("mushroom"));
			            vo.setPepper(rs.getString("pepper"));
			            vo.setDaikon(rs.getString("daikon"));
			            vo.setLettuce(rs.getString("lettuce"));
			            vo.setPumpkin(rs.getString("pumpkin"));
			            vo.setPork(rs.getString("pork"));
			            vo.setBeef(rs.getString("beef"));
			            vo.setChicken(rs.getString("chicken"));
			            vo.setSausage(rs.getString("sausage"));
			            vo.setBacon(rs.getString("bacon"));
			            vo.setMackerel(rs.getString("mackerel"));
			            vo.setSquid(rs.getString("squid"));
			            vo.setSaury(rs.getString("saury"));
			            vo.setMussel(rs.getString("mussel"));
			            vo.setCheese(rs.getString("cheese"));
			            vo.setUrl(rs.getString("url"));
			            vo.setSrc(rs.getString("src"));
			            vo.setCal(rs.getString("cal"));
			            vo.setCode(rs.getString("code"));				            
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				CloseUtil.close(conn);
				CloseUtil.close(rs);
				CloseUtil.close(pstmt);
			}
			return vo;
		}	   
	   
		public List<CookCookVO> getSelectCookid() {
			
			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			List<CookCookVO> list = null;
			
			String sql = "select * from cook order by love desc LIMIT 15";

			try {
				conn = getConnection();

				pstmt = conn.prepareStatement(sql);
				rs = pstmt.executeQuery();

				if (rs.next()) {
					list = new ArrayList();

					do {
						CookCookVO vo = new CookCookVO();
						
						vo.setCookid(rs.getString("cookid"));
						vo.setCookname(rs.getString("cookname"));
						vo.setUrl(rs.getString("url"));
						vo.setSrc(rs.getString("src"));
						vo.setCal(rs.getString("cal"));
						vo.setLove(rs.getInt("love"));
						
						list.add(vo);

					} while (rs.next());
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				CloseUtil.close(conn);
				CloseUtil.close(rs);
				CloseUtil.close(pstmt);
			}
			return list;
		}
		
		public int getSelectLike(String cookid) {

			Connection conn = null;
			PreparedStatement pstmt = null;
			List<CookCookVO> list = null;
			ResultSet rs = null;
			String sql = "";

			sql = "select love from cook where cookid = ?";
			try {
				conn = getConnection();

				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, cookid);
				rs = pstmt.executeQuery();

				if (rs.next()) {
					return rs.getInt(1);
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				CloseUtil.close(conn);
				CloseUtil.close(rs);
				CloseUtil.close(pstmt);
			}

			return 0;
		}
		
		public int recipeInsert(CookCookVO vo) {
			
		      Connection conn = null;
		      PreparedStatement pstmt = null;
		      String sql = "";		      
		      int result = 0;
		      
		      sql = "insert into cook(cookname, egg, carrot, onion, potato, garlic, mushroom, pepper, daikon, lettuce, pumpkin,"
		      		+ " pork, beef, chicken, sausage, bacon, mackerel, squid, saury, mussel, cheese,"
		      		+ " url, src, cal, code, cookid)"
		      		+ " values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		      
		      try {
		    	  
		         conn = getConnection();		         
		         pstmt = conn.prepareStatement(sql);
					
				 pstmt.setString(1, vo.getCookname());
				 pstmt.setString(2, vo.getEgg());
				 pstmt.setString(3, vo.getCarrot());
				 pstmt.setString(4, vo.getOnion());
				 pstmt.setString(5, vo.getPotato());
				 pstmt.setString(6, vo.getGarlic());
				 pstmt.setString(7, vo.getMushroom());
				 pstmt.setString(8, vo.getPepper());
				 pstmt.setString(9, vo.getDaikon());
				 pstmt.setString(10, vo.getLettuce());
				 pstmt.setString(11, vo.getPumpkin());
				 pstmt.setString(12, vo.getPork());
				 pstmt.setString(13, vo.getBeef());
				 pstmt.setString(14, vo.getChicken());
				 pstmt.setString(15, vo.getSausage());
				 pstmt.setString(16, vo.getBacon());
				 pstmt.setString(17, vo.getMackerel());
				 pstmt.setString(18, vo.getSquid());
				 pstmt.setString(19, vo.getSaury());
				 pstmt.setString(20, vo.getMussel());
				 pstmt.setString(21, vo.getCheese());
				 pstmt.setString(22, vo.getUrl());
				 pstmt.setString(23, vo.getSrc());
				 pstmt.setString(24, vo.getCal());
				 pstmt.setString(25, vo.getCode());
				 pstmt.setString(26, vo.getCookid());		
					
				 result = pstmt.executeUpdate();
		         
		         System.out.println(result);   

		      } catch (Exception e) {
		         e.printStackTrace();
		      } finally {
		         CloseUtil.close(conn);
		         CloseUtil.close(pstmt);
		      }

		      return result;
	   }	

		public int recipeUpdate(CookCookVO vo) {
			
			Connection conn = null;
			PreparedStatement pstmt = null;
			String sql  = null;
			int result = 0;
			
			sql = "update cook set cookname = ?, egg = ?,carrot = ?, onion = ?, potato = ?, garlic = ?"
					+ ", mushroom = ?, pepper = ?, daikon = ?, lettuce = ?, pumpkin = ?, pork = ?"
					+ ", beef = ?, chicken = ?, sausage = ?, bacon = ?, mackerel = ?, squid = ?, saury = ?"
					+ ", mussel = ?, cheese = ?, url = ?, src = ?, cal = ?, code = ?"
					+ " where cookid = ?";
			
			try {
				
				conn = getConnection();
				pstmt = conn.prepareStatement(sql);
				
				pstmt.setString(1, vo.getCookname());
				pstmt.setString(2, vo.getEgg());
				pstmt.setString(3, vo.getCarrot());
				pstmt.setString(4, vo.getOnion());
				pstmt.setString(5, vo.getPotato());
				pstmt.setString(6, vo.getGarlic());
				pstmt.setString(7, vo.getMushroom());
				pstmt.setString(8, vo.getPepper());
				pstmt.setString(9, vo.getDaikon());
				pstmt.setString(10, vo.getLettuce());
				pstmt.setString(11, vo.getPumpkin());
				pstmt.setString(12, vo.getPork());
				pstmt.setString(13, vo.getBeef());
				pstmt.setString(14, vo.getChicken());
				pstmt.setString(15, vo.getSausage());
				pstmt.setString(16, vo.getBacon());
				pstmt.setString(17, vo.getMackerel());
				pstmt.setString(18, vo.getSquid());
				pstmt.setString(19, vo.getSaury());
				pstmt.setString(20, vo.getMussel());
				pstmt.setString(21, vo.getCheese());
				pstmt.setString(22, vo.getUrl());
				pstmt.setString(23, vo.getSrc());
				pstmt.setString(24, vo.getCal());
				pstmt.setString(25, vo.getCode());
				pstmt.setString(26, vo.getCookid());		
				
				result = pstmt.executeUpdate();
				
			} catch(Exception e) {
				e.printStackTrace();
			} finally {
				CloseUtil.close(conn);
				CloseUtil.close(pstmt);
			}			

			return result;
		}

		public List<CookCookVO> getSelectAll() {
			
			Connection conn = null;
			PreparedStatement pstmt = null;
			List<CookCookVO> list = null;
			ResultSet rs = null;
			
			String sql = "select * from cook";
			
			try {
				list = new ArrayList();
			
				conn = getConnection();
				pstmt = conn.prepareStatement(sql);
				rs = pstmt.executeQuery();
			
				if (rs.next()) {

					list = new ArrayList();
					
					do {
						CookCookVO vo = new CookCookVO();
						
						vo.setCookid(rs.getString("cookid"));
						vo.setCookname(rs.getString("cookname"));
						vo.setUrl(rs.getString("url"));
						vo.setSrc(rs.getString("src"));
						vo.setCal(rs.getString("cal"));
						vo.setLove(rs.getInt("love"));
						
						list.add(vo);

					} while (rs.next());
				}					
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				CloseUtil.close(conn);
				CloseUtil.close(rs);
				CloseUtil.close(pstmt);				
			}			
			return list;
		}		
		
		/////////////////////////////////////////////////////////////
		public List<WeeklyMenuVO> getSelectWeeklyMenu(String id) {
		
			Connection conn = null;
			PreparedStatement pstmt = null;
			List<WeeklyMenuVO> menu = null;
			ResultSet rs = null;
			String sql = "";
			
			sql = "select * from userinfo where id = ? ";
			try {
			conn = getConnection();			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				
				menu = new ArrayList();
				WeeklyMenuVO vo = new WeeklyMenuVO();
					
				vo.setId("id");
				vo.setWeek1(rs.getString("week1"));
				vo.setWeek2(rs.getString("week2"));
				vo.setWeek3(rs.getString("week3"));
				vo.setWeek4(rs.getString("week4"));
				vo.setWeek5(rs.getString("week5"));
				vo.setWeek6(rs.getString("week6"));
				vo.setWeek7(rs.getString("week7"));
					
				menu.add(vo);  			
				}
			
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				CloseUtil.close(conn);
				CloseUtil.close(rs);
				CloseUtil.close(pstmt);
		}
			return menu;
	}
		
		public List<CookCookUserVO> getUserAll() {
			
			Connection conn = null;
			PreparedStatement pstmt = null;
			List<CookCookUserVO> list = null;
			ResultSet rs = null;
			
			String sql = "select * from userinfo";
			
			try {
				list = new ArrayList();
			
				conn = getConnection();
				pstmt = conn.prepareStatement(sql);
				rs = pstmt.executeQuery();
			
				if (rs.next()) {

					list = new ArrayList();
					
					do {
						CookCookUserVO vo = new CookCookUserVO();
						
						vo.setId(rs.getString("id"));
						
						list.add(vo);

					} while (rs.next());
				}					
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				CloseUtil.close(conn);
				CloseUtil.close(rs);
				CloseUtil.close(pstmt);				
			}			
			return list;
		}

		public int userDelete(String id, String password) {
			
			Connection conn = null;
			PreparedStatement pstmt = null;
			int result = 0;
			
			String sql = "delete from userinfo where id = ? and pwd = ?";
			
			try {
				conn = getConnection();				
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, id);
				pstmt.setString(2, password);
				
				result = pstmt.executeUpdate();
				
				System.out.println(result);
				
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				CloseUtil.close(conn);
				CloseUtil.close(pstmt);
			}
			return result;
		}
/////////////////////////////////////////////////////

	public List<CookCookUserVO> getUserDelete(String id) {
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		List<CookCookUserVO> list = null;
		ResultSet rs = null;
		
		String sql = "delete from userinfo where id = ?";
		
		try {
			list = new ArrayList();
		
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			pstmt.executeUpdate();
			
			sql = "select * from userinfo";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if (rs.next()) {
	
				list = new ArrayList();
				
				do {
					CookCookUserVO vo = new CookCookUserVO();
					
					vo.setId(rs.getString("id"));
					
					list.add(vo);
	
				} while (rs.next());
			}					
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(conn);
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);				
		}			
		return list;
	}

	public int userPassWordCheck(String id, String password) {
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int result = 0;
		
		String sql = "select * from userinfo where id = ? and pwd = ?";
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			pstmt.setString(2, password);
			
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				result = 1;
			}			
			System.out.println("UserPassCheck : "+ result);
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(conn);
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);		
		}
		
		return result;		
	}

	public CookCookUserVO userInfoModify(String id) {
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		CookCookUserVO vo = null;
		
		String sql = "select * from userinfo where id = ?";
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				vo = new CookCookUserVO();
				vo.setId(rs.getString("id"));
				vo.setPwd(rs.getString("pwd"));
				vo.setEmail(rs.getString("email"));				
			}
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(conn);
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);	
		}
		return vo;
	}

	public int userInfoUpdate(CookCookUserVO vo) {
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql  = null;
		int result = 0;
		
		sql = "update userinfo set pwd = ?, email = ? where id = ?";
		
		try {			
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, vo.getPwd());
			pstmt.setString(2, vo.getEmail());
			pstmt.setString(3, vo.getId());		
			
			result = pstmt.executeUpdate();
			
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(conn);
			CloseUtil.close(pstmt);
		}			

		return result;
	}

	public void userWeeklyMenuDelete(String id, String week) {
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		String sql  = "update userinfo set "+week+" = '-' where id = ? ";
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			
			pstmt.executeUpdate();	
			
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(conn);
			CloseUtil.close(pstmt);
		}		
	}


	public int emailCheck(String id, String email) {
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int result = 0;

		String sql = "select * from userinfo where id = ? and email = ?";
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			pstmt.setString(2, email);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				result = 1;
			}			
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(conn);
			CloseUtil.close(pstmt);
		}		
		return result;
	}
	
	
	public int passwordReset(String id, String pwd, String email) {
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		int result = 0;
		
		String sql  = "update userinfo set pwd = ? where id = ? and email = ?";
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, pwd);
			pstmt.setString(2, id);
			pstmt.setString(3, email);
			
			result = pstmt.executeUpdate();	
			
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(conn);
			CloseUtil.close(pstmt);
		}		
		return result;
	}

	public void updateLike(String cookid) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		List<CookCookVO> list = null;
		ResultSet rs = null;
		String sql = "";

		sql = "update cook set love = love+1 where cookid = ?";
		try {
			conn = getConnection();

			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, cookid);
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(conn);
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
		}
	}

}