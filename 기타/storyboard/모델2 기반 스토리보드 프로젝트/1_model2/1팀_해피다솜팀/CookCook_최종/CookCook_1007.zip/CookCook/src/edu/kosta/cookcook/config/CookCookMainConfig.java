package edu.kosta.cookcook.config;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.kosta.cookcook.controller.main.CommandAction;

public class CookCookMainConfig extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		process(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		process(request, response);
	}

	protected void process(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String view = null;
		CommandAction ca = null;
		
		String url = "edu.kosta.cookcook.controller.main.";
		String url2 = "Action";
		
		String command = "";
		String command2 = "";
		String command3 ="";

		try {
			command = request.getRequestURI();
			
	        if (command.indexOf(request.getContextPath()) == 0)            
	            command = command.substring(request.getContextPath().length()+1);          
			
			command2 = command.substring(0,command.length()-3);
			command2 = command2.substring(0,1).toUpperCase()+command2.substring(1);
			
			command3 = url+command2+url2;
			System.out.println("command3 = "+command3);
						
	        Object commandInstance = Class.forName(command3).newInstance();
	        
			ca = (CommandAction)commandInstance;
			
	        System.out.println("ca = "+ca);
						
			view = ca.process(request, response);

		} catch (Exception e) {
			e.printStackTrace();
		}
		
		request.setAttribute("CONTENT", view);
		
		if (view.startsWith("likeCount")) {
			String count=view.split("-")[1];
			response.getOutputStream().println(count);
			return;
		}
	
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("/view/main.jsp");
		dispatcher.forward(request, response);	
	}
}