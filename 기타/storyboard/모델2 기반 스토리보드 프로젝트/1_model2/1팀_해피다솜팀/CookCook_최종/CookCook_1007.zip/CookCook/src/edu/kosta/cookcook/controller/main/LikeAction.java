package edu.kosta.cookcook.controller.main;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.kosta.cookcook.model.CookCookDAO;
import edu.kosta.cookcook.model.CookCookVO;

public class LikeAction implements CommandAction {
   public String process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      String cookid = request.getParameter("cookid");
      
      CookCookDAO dao = CookCookDAO.getInstance();
      dao.updateLike(cookid);
      int count = dao.getSelectLike(cookid);      
      
      return "likeCount-"+count;
   }
}