package edu.kosta.cookcook.controller.user;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.kosta.cookcook.controller.main.CommandAction;
import edu.kosta.cookcook.model.CookCookDAO;
import edu.kosta.cookcook.model.CookCookUserVO;

public class UserInfoModifyAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		String id = request.getParameter("id");
		
		System.out.println("UserInfoModifyAction id : "+id);
			
		CookCookUserVO vo = new CookCookUserVO();
		CookCookDAO dao = CookCookDAO.getInstance();
		
		vo = dao.userInfoModify(id);
		
		request.setAttribute("list", vo);
		
		return "/view/contents/user/userInfoModifyForm.jsp";
	}

}
