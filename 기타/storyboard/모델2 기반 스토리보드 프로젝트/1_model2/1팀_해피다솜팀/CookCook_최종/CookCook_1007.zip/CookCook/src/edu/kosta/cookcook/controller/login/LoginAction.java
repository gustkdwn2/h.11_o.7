package edu.kosta.cookcook.controller.login;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.kosta.cookcook.controller.main.CommandAction;

public class LoginAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		return "/view/contents/login/LoginForm.jsp";
	}

}
