package edu.kosta.cookcook.controller.user;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import edu.kosta.cookcook.controller.main.CommandAction;
import edu.kosta.cookcook.model.CookCookDAO;

public class UserDeleteProAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		String id = request.getParameter("id");
		String password = request.getParameter("password");
		
		CookCookDAO dao = CookCookDAO.getInstance();
		int result = dao.userDelete(id,password);
	
		request.setAttribute("result", result);
		
		if(result==1) {
			HttpSession session = request.getSession();
		    session.invalidate();	
		}	
				
		return "/view/contents/user/userDeletePro.jsp";
	}

}
