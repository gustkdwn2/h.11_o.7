package edu.kosta.cookcook.controller.main;

import java.io.IOException;
import java.util.List;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.kosta.cookcook.model.CookCookDAO;
import edu.kosta.cookcook.model.CookCookVO;

public class RecommandMenuAction implements CommandAction {
	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int count = 15;

		CookCookDAO dao = CookCookDAO.getInstance();
		List<CookCookVO> list = dao.getSelectCookid();
		
		request.setAttribute("list", list);
		request.setAttribute("count", count);
		
		return "/view/contents/list.jsp";
	}
}
