package edu.kosta.cookcook.controller.user;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import edu.kosta.cookcook.controller.main.CommandAction;
import edu.kosta.cookcook.model.CookCookDAO;
import edu.kosta.cookcook.model.WeeklyMenuVO;

public class UserDeleteWeeklyMenuAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {

		request.setCharacterEncoding("UTF-8");
		
		HttpSession session = request.getSession();		
		
		String id = (String) session.getAttribute("sid");		
		String week = request.getParameter("week");		
		
		CookCookDAO dao = CookCookDAO.getInstance();
		dao.userWeeklyMenuDelete(id, week);		
		
		List<WeeklyMenuVO> menu = dao.getSelectWeeklyMenu(id);
		
		request.setAttribute("menu", menu);
		
		return "/view/contents/user/myPage.jsp";
	}
}