package edu.kosta.cookcook.controller.login;
import edu.kosta.cookcook.controller.*;
import edu.kosta.cookcook.controller.main.CommandAction;
import edu.kosta.cookcook.model.CookCookDAO;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LoginInsertAction  implements CommandAction {
	   public String process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		   
		   return "/view/contents/login/LoginUpdate.jsp";
	   }
}