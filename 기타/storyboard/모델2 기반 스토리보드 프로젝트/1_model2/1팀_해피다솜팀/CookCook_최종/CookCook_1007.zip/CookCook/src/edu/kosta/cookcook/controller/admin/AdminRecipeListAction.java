package edu.kosta.cookcook.controller.admin;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.kosta.cookcook.controller.main.CommandAction;
import edu.kosta.cookcook.model.CookCookDAO;
import edu.kosta.cookcook.model.CookCookVO;

public class AdminRecipeListAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		CookCookVO vo = new CookCookVO();
		
		CookCookDAO dao = CookCookDAO.getInstance();
		List<CookCookVO> list = dao.getSelectAll();
		
		int count = list.size();
		
		request.setAttribute("list", list);		
		request.setAttribute("count", count);
		
		return "/view/contents/admin/recipe/recipeList.jsp";
	}

}
