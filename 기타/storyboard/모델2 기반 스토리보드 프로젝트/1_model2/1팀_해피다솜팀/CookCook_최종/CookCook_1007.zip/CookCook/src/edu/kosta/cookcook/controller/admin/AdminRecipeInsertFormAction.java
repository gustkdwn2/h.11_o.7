package edu.kosta.cookcook.controller.admin;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.kosta.cookcook.controller.main.CommandAction;

public class AdminRecipeInsertFormAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {

		return "/view/contents/admin/recipe/recipeinsert.jsp";
	}

}
