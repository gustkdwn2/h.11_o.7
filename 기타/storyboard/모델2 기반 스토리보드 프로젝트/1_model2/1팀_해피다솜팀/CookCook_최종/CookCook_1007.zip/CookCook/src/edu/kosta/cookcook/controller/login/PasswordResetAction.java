package edu.kosta.cookcook.controller.login;

import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import edu.kosta.cookcook.controller.main.CommandAction;
import edu.kosta.cookcook.model.CookCookDAO;

public class PasswordResetAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
			
		
		String id = request.getParameter("reset_id");
		String email = request.getParameter("reset_email");
		
		int result = 0;
		
		CookCookDAO dao = CookCookDAO.getInstance();
		result = dao.emailCheck(id, email);
		
		System.out.println("emailCheck result : "+result);
		
		if (result==1) {
			Random random = new Random();
			
			int[] num = new int[8];
			char[] alpha = new char[4];
			
			for(int i=0; i<num.length; i++)
				num[i] = random.nextInt(10);	
				
			for(int i=0; i<alpha.length; i++)
				alpha[i] = (char)((random.nextInt(1)+97)+(random.nextInt(24)));
			
			String pwd = "a"+num[0]+num[1]+alpha[0]+num[2]+num[3]+alpha[1]+num[4]+num[5]+alpha[2]+num[6]+num[7]+alpha[3];				
			System.out.println("PasswordResetAction pwd : "+pwd);			
			
			result = dao.passwordReset(id, pwd, email);				
			System.out.println("PasswordResetAction result : "+result);
			
			request.setAttribute("pwd", pwd);
		} 		
		
		request.setAttribute("result", result);		
		return "/view/contents/login/userEmailCheckPro.jsp";
	}

}
