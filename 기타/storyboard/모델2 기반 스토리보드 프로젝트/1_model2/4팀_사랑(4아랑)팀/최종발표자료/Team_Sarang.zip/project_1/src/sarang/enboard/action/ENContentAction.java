package sarang.enboard.action;

import java.util.Collections;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sarang.action.CommandAction;
import sarang.en.ENDAO;
import sarang.en.ENVO;

public class ENContentAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("utf-8");
		int num = Integer.parseInt(request.getParameter("num"));
		String pageNum = request.getParameter("pageNum");
		
		try {
			ENDAO dao = ENDAO.getInstance();
			ENVO vo = dao.getDataDetail(num);
			request.setAttribute("vo", vo);
			request.setAttribute("pageNum", pageNum);

			List list = null;
			int count = dao.ReplyCount(num);  
			
			if( count > 0 ){
				list = dao.getReplyAll(num);  
			} else {
				list=Collections.EMPTY_LIST;
			}			
			request.setAttribute("list", list);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "/EN/ENContent.jsp";
	}
}
