package sarang.member.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import sarang.action.CommandAction;
import sarang.member.MemberDAO;

public class PayMoneyAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("utf-8");
		String id = request.getParameter("id");
		String num = request.getParameter("num");
		String pageNum = request.getParameter("pageNum");
		
		MemberDAO dao = MemberDAO.getInstance();
		int check = dao.PayMoney(id);
		if(check ==1){
			int money = dao.ReturnMoney(id);			
			HttpSession session = request.getSession(); 
			session.setAttribute("money", money);
		}		
		request.setAttribute("num", num);
		request.setAttribute("pageNum", pageNum);
		request.setAttribute("check", check);
		request.setAttribute("id", id);
		
		return "/member/PayMoney.jsp";
	}
}
