package sarang.foodboard.action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sarang.action.CommandAction;
import sarang.survey.SurveyDAO;
import sarang.survey.SurveyVO;

public class FoodSurveyCheckFormAction implements CommandAction {
	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {

		request.setCharacterEncoding("utf-8");
		String ref = request.getParameter("num");
		String pageNum = request.getParameter("pageNum");
		SurveyDAO dao = new SurveyDAO();
		List Qlist = null;
		List Alist = null;
		Qlist = dao.getSurveyQ("FOOD", ref);
		Alist = dao.getSurveyA("FOOD", ref);
		request.setAttribute("ref", ref);
		request.setAttribute("Qlist", Qlist);
		request.setAttribute("Alist", Alist);
		request.setAttribute("pageNum", pageNum);
		return "/FOOD/FoodSurveyCheckForm.jsp";
	}
}
