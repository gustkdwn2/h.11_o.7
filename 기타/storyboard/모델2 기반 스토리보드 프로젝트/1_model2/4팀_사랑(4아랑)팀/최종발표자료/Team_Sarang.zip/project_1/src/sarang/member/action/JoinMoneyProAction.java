package sarang.member.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import sarang.action.CommandAction;
import sarang.member.MemberDAO;

public class JoinMoneyProAction implements CommandAction {
	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("utf-8");
		
		int num = Integer.parseInt(request.getParameter("num"));
		int setmoney = Integer.parseInt(request.getParameter("setmoney"));		
		MemberDAO dao = MemberDAO.getInstance();
		int money = dao.Moneyupdate(num, setmoney);

		HttpSession session = request.getSession();
		
		session.setAttribute("money", money);
		request.setAttribute("check", money);

		return "/member/JoinMoneyPro.jsp";
	}
}