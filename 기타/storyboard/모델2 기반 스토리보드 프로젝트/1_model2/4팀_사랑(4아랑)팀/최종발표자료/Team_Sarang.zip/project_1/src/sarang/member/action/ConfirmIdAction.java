package sarang.member.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sarang.action.CommandAction;
import sarang.member.MemberDAO;

public class ConfirmIdAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("utf-8");
		String id = request.getParameter("id");
		MemberDAO dao = MemberDAO.getInstance();
		int check = dao.confirmID(id);
		request.setAttribute("check", check);
		request.setAttribute("id", id);
		
		return "/member/confirmId.jsp";
	}
}
