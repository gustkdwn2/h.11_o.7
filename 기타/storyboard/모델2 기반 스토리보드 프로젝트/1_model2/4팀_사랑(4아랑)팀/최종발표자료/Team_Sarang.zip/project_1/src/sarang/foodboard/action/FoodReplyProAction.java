package sarang.foodboard.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sarang.action.CommandAction;
import sarang.food.FoodDAO;
import sarang.food.FoodReplyVO;

public class FoodReplyProAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("utf-8");
		FoodReplyVO re_vo = new FoodReplyVO();
		
		re_vo.setRef_num(Integer.parseInt(request.getParameter("ref_num")));		
		re_vo.setReply_writer(request.getParameter("reply_writer"));
		re_vo.setReply_password(request.getParameter("reply_password"));
		re_vo.setReply_content(request.getParameter("reply_content"));
		
		
		FoodDAO dao = new FoodDAO();
		dao.insert(re_vo);
		
		String ref_pageNum = request.getParameter("ref_pageNum");
		System.out.println(ref_pageNum);
		request.setAttribute("re_vo", re_vo);
		request.setAttribute("ref_pageNum", ref_pageNum);

		return "/FOOD/FoodReplyPro.jsp";
	}

}
