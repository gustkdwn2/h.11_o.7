package sarang.enboard.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sarang.action.CommandAction;

public class ENSurveyUpdateFormAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("utf-8");

		int ref = Integer.parseInt(request.getParameter("ref"));
		
		System.out.println("������Ʈ �׼ǿ��� ref : " + ref);
		request.setAttribute("ref", ref);
		return "/EN/ENSurveyUpdateForm.jsp";
	}

}
