package sarang.member.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import sarang.action.CommandAction;
import sarang.member.MemberDAO;
import sarang.member.MemberVO;

public class ModifyFormAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("utf-8");
		int num = 0;
		num = Integer.parseInt(request.getParameter("num"));
		MemberDAO dao = MemberDAO.getInstance();
		MemberVO vo = dao.update(num);

		request.setAttribute("id", vo.getId());
		request.setAttribute("password", vo.getPassword());
		request.setAttribute("name", vo.getName());
		request.setAttribute("phone", vo.getPhone());
		request.setAttribute("jointype", vo.getJointype());
		request.setAttribute("jobnum", vo.getJobnum());
		request.setAttribute("num", new Integer(num));

		return "/member/modifyForm.jsp";

	}

}