package sarang.tipboard.action;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sarang.action.CommandAction;
import sarang.tip.TipDAO;
import sarang.tip.TipVO;

public class TipContentAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("utf-8");
		
		int num = Integer.parseInt(request.getParameter("num"));
		String pageNum = request.getParameter("pageNum");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		try {
			TipDAO dao = TipDAO.getInstance();
			TipVO vo = dao.getDataDetail(num);
			int ref = vo.getRef();
			int re_step = vo.getRe_step();
			int re_level = vo.getRe_level();

			request.setAttribute("num", new Integer(num));
			request.setAttribute("writer", vo.getWriter());
			request.setAttribute("subject", vo.getSubject());
			request.setAttribute("email", vo.getEmail());
			request.setAttribute("readcount", vo.getReadcount());
			request.setAttribute("content", vo.getContent());
			request.setAttribute("password", vo.getPassword());
			request.setAttribute("reg_date", new Timestamp(System.currentTimeMillis()));
			request.setAttribute("ref", new Integer(ref));
			request.setAttribute("re_step", new Integer(re_step));
			request.setAttribute("re_level", new Integer(re_level));
			request.setAttribute("ip", vo.getIp());
			request.setAttribute("pageNum", pageNum);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "/tipboard/TipContent.jsp";
	}
}
