package sarang.member.action;

import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sarang.action.CommandAction;
import sarang.en.ENDAO;
import sarang.en.ENVO;
import sarang.food.FoodDAO;
import sarang.food.FoodVO;
import sarang.it.ITDAO;
import sarang.it.ITVO;
import sarang.tip.TipDAO;

public class MainAction implements CommandAction {
	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("utf-8");

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");

		/* Hot 키워드 */
		// _IT
		ITDAO ITdao = ITDAO.getInstance();
		ITVO ITvo = new ITVO();
		ITvo = ITdao.toprate();
		int ITCount = ITdao.getListAllCount();
		int ITPagenum = (ITCount / 6) + 1;
		if (ITCount > 0) {
			int listnum = ITdao.listnum(ITvo.getNum());
			int currentPage = ITPagenum - (listnum / 6);
			request.setAttribute("currentPage", currentPage);
			request.setAttribute("ITvo", ITvo);
		}
		request.setAttribute("ITCount", ITCount);

		// _FOOD
		FoodDAO fooddao = FoodDAO.getInstance();
		FoodVO foodvo = new FoodVO();
		foodvo = fooddao.toprate();
		int foodCount = fooddao.getListAllCount();
		int foodPagenum = (foodCount / 6) + 1;
		if (foodCount > 0) {
			int listnum = fooddao.listnum(foodvo.getNum());
			int currentPage = foodPagenum - (listnum / 6);
			request.setAttribute("currentPage", currentPage);
			request.setAttribute("foodvo", foodvo);
		}
		request.setAttribute("foodCount", foodCount);

		// _EN
		ENDAO ENdao = ENDAO.getInstance();
		ENVO ENvo = new ENVO();
		ENvo = ENdao.toprate();
		int ENCount = ENdao.getListAllCount();
		int ENPagenum = (ENCount / 6) + 1;
		if (ENCount > 0) {
			int listnum = ENdao.listnum(ENvo.getNum());
			int currentPage = ENPagenum - (listnum / 6);
			request.setAttribute("currentPage", currentPage);
			request.setAttribute("ENvo", ENvo);
		}
		request.setAttribute("ENCount", ENCount);

		// Tip Board 표시
		int startRow = 1;
		int endRow = 5;
		int count = 0, number = 0;

		List tiplist = null;

		TipDAO tipdao = TipDAO.getInstance();
		count = tipdao.getListAllCount();

		if (count > 0) {
			tiplist = tipdao.getSelectAll(startRow, endRow);
		} else {
			tiplist = Collections.EMPTY_LIST;
		}
		number = count;

		request.setAttribute("count", new Integer(count));
		request.setAttribute("number", new Integer(number));
		request.setAttribute("tiplist", tiplist);

		return "/member/main.jsp";
	}
}