package sarang.member.action;

import java.sql.Timestamp;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sarang.action.CommandAction;
import sarang.member.MemberDAO;
import sarang.member.MemberVO;

public class JoinProAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {

		request.setCharacterEncoding("utf-8");
		MemberVO vo = new MemberVO();
		
		vo.setId(request.getParameter("id"));
		vo.setPassword(request.getParameter("password"));
		vo.setName(request.getParameter("name"));
		vo.setPhone(request.getParameter("phone"));
		vo.setJointype(request.getParameter("jointype"));
		vo.setJobnum(request.getParameter("jobnum"));

		MemberDAO dao = MemberDAO.getInstance();   //����
		int check = dao.insert(vo);
		request.setAttribute("name", vo.getName());
		request.setAttribute("check", check);
		
		return "/member/JoinPro.jsp";
	}
}
