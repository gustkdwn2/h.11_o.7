package sarang.controller;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sarang.action.CommandAction;

public class SarangController extends HttpServlet {
	private Map commandMap = new HashMap<>();

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		process(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		process(request, response);
	}

	public void init(ServletConfig config) throws ServletException {
		String props = config.getInitParameter("propertyConfig"); // web.xml
																	// ����
																	// ����
																	// �о����
		Properties pr = new Properties();
		FileInputStream f = null;

		try {
			f = new FileInputStream(props);
			pr.load(f);

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (f != null)
				try {
					f.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
		}
		Iterator keyIter = pr.keySet().iterator();

		while (keyIter.hasNext()) {
			String command = (String) keyIter.next();
			String className = pr.getProperty(command); // value :
														// edu.kosta.boardAction.WriteFormAction
			try {
				Class commandClass = Class.forName(className);
				Object commandInstance = commandClass.newInstance();

				commandMap.put(command, commandInstance);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	protected void process(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String view = null;
		CommandAction ca = null;
		RequestDispatcher dispatcher = null;

		try {
			String command = request.getRequestURI();
			System.out.println("command : " + command); // project_1/*.do
			System.out.println("request.getContextPath()" + request.getContextPath()); // day52_boardMVC
			if (command.indexOf(request.getContextPath()) == 0) {
				command = command.substring(request.getContextPath().length() + 1);
				System.out.println(command);
			}

			ca = (CommandAction) commandMap.get(command);
			System.out.println("ca : " + ca);
			view = ca.process(request, response);
			System.out.println("view : " + view);
		} catch (Exception e) {
			e.printStackTrace();
		}

		request.setAttribute("CONTENT", view);
		if (view.equals("/member/confirmId.jsp")) {
			dispatcher = request.getRequestDispatcher(view);
		} else if (view.equals("/foodboard/SurveyForm.jsp") || view.equals("/foodboard/SurveyPro.jsp")
				|| view.equals("/IT/ITSurveyInsertForm.jsp") || view.equals("/IT/ITSurveyInsertPro.jsp")
				|| view.equals("/IT/ITSurveyUpdateForm.jsp") || view.equals("/IT/ITSurveyUpdatePro.jsp")
				|| view.equals("/EN/ENSurveyInsertForm.jsp") || view.equals("/EN/ENSurveyInsertPro.jsp")
				|| view.equals("/EN/ENSurveyUpdateForm.jsp") || view.equals("/EN/ENSurveyUpdatePro.jsp")
				|| view.equals("/FOOD/FoodSurveyInsertForm.jsp") || view.equals("/FOOD/FoodSurveyInsertPro.jsp")
				|| view.equals("/FOOD/FoodSurveyUpdateForm.jsp") || view.equals("/FOOD/FoodSurveyUpdatePro.jsp")) {
			dispatcher = request.getRequestDispatcher(view);
		} else {
			dispatcher = request.getRequestDispatcher("/template/template.jsp");
		}
		dispatcher.forward(request, response);
	}
}
