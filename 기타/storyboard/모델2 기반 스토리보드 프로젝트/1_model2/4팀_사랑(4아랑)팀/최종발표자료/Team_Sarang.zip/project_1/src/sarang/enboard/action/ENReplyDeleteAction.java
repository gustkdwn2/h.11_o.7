package sarang.enboard.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sarang.action.CommandAction;
import sarang.en.ENDAO;

public class ENReplyDeleteAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("utf-8");
		String num = request.getParameter("num");
		String pageNum = request.getParameter("pageNum");
		String re_num = request.getParameter("re_num");
		String reply_password = request.getParameter("reply_password");
		ENDAO dao = new ENDAO();
		int check = dao.deleteReply(re_num, reply_password);
		
		request.setAttribute("num", num);
		request.setAttribute("pageNum", pageNum);
		
		return "/EN/ENReplyDelete.jsp";
	}

}
