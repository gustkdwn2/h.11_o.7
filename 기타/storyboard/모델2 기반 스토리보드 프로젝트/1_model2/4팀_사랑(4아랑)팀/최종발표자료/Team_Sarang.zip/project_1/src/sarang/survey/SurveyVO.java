package sarang.survey;

public class SurveyVO {
	private int ref, cnt;
	private String Q, A, Qvalue, Avalue;
	
	public int getRef() {
		return ref;
	}
	public void setRef(int ref) {
		this.ref = ref;
	}
	
	public int getCnt() {
		return cnt;
	}
	public void setCnt(int cnt) {
		this.cnt = cnt;
	}
	public String getQ() {
		return Q;
	}
	public void setQ(String q) {
		Q = q;
	}
	public String getA() {
		return A;
	}
	public void setA(String a) {
		A = a;
	}
	public String getQvalue() {
		return Qvalue;
	}
	public void setQvalue(String qvalue) {
		Qvalue = qvalue;
	}
	public String getAvalue() {
		return Avalue;
	}
	public void setAvalue(String avalue) {
		Avalue = avalue;
	}
	
	
	
	
}
