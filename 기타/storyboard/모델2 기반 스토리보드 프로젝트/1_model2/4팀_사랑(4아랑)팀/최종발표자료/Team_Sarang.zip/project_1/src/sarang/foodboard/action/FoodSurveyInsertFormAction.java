package sarang.foodboard.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sarang.action.CommandAction;

public class FoodSurveyInsertFormAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {

		request.setCharacterEncoding("utf-8");
		int ref = Integer.parseInt(request.getParameter("ref"));
		request.setAttribute("ref", ref);
		return "/FOOD/FoodSurveyInsertForm.jsp";
	}

}
