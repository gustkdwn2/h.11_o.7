package sarang.foodboard.action;

import java.util.Collections;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sarang.action.CommandAction;
import sarang.food.FoodDAO;
import sarang.food.FoodVO;

public class FoodContentAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("utf-8");
		int num = Integer.parseInt(request.getParameter("num"));
		String pageNum = request.getParameter("pageNum");

		try {
			FoodDAO dao = FoodDAO.getInstance();
			FoodVO vo = dao.getDataDetail(num);
			request.setAttribute("vo", vo);
			request.setAttribute("pageNum", pageNum);

			List list = null;
			int count = dao.ReplyCount(num); // �ش� ����Ʈ ���ð��� Ȯ��

			if (count > 0) {
				list = dao.getReplyAll(num); // ���ڵ� ��� ����
			} else {
				list = Collections.EMPTY_LIST;
			}
			request.setAttribute("list", list);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return "/FOOD/FoodContent.jsp";
	}
}
