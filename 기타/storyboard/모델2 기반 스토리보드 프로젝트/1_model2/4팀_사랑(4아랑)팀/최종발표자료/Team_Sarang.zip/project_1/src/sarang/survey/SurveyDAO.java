package sarang.survey;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import dbclose.util.CloseUtil;

public class SurveyDAO {
	private static SurveyDAO instance = new SurveyDAO();

	public static SurveyDAO getInstance() {
		return instance;
	}

	public SurveyDAO() {
	}

	public Connection getConnection() throws Exception {

		Context ctx = new InitialContext();
		DataSource ds = (DataSource) ctx.lookup("java:comp/env/jdbc:SarangDB");

		return ds.getConnection();
	} // end getConnection()

	public void saveQ(String category, int ref_num, String var_name, String var_value) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		

		String sql = "INSERT INTO "	+ category + "SURVEY(REF, QUESTION, QVALUE) VALUES(?, ?, ?)";
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, ref_num);
			pstmt.setString(2, var_name);
			pstmt.setString(3, var_value);
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {			
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
	}

	public void saveA(String category, int ref_num, String var_name, String var_value) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String Question = var_name.substring(0, 2);
		String Answer = var_name.substring(2);
		String sql = "INSERT INTO "	+ category + "SURVEY(REF, QUESTION, ANSWER, AVALUE, CNT) VALUES(?, ?, ?, ?, ?)";
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, ref_num);
			pstmt.setString(2, Question);
			pstmt.setString(3, Answer);
			pstmt.setString(4, var_value);
			pstmt.setInt(5, 0);
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {			
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
	}

	public List<SurveyVO> getSurveyQ(String category, String ref) {
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		List Qlist = new ArrayList();
		try {
			conn = getConnection();
			sql = "SELECT * FROM "+ category +"SURVEY WHERE REF = ? and QVALUE is not null";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, ref);
			rs = pstmt.executeQuery();
			while(rs.next()){
				SurveyVO vo = new SurveyVO();
				vo.setRef(Integer.parseInt(ref));
				vo.setQ(rs.getString("question"));
				vo.setA(rs.getString("Answer"));
				vo.setQvalue(rs.getString("Qvalue"));
				vo.setAvalue(rs.getString("Avalue"));
				vo.setCnt(rs.getInt("CNT"));
				Qlist.add(vo);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {			
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		return Qlist;
	}

	public List<SurveyVO> getSurveyA(String category, String ref) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		List Alist = new ArrayList();
		try {
			conn = getConnection();
			sql = "SELECT * FROM "+ category + "SURVEY WHERE REF = ? and AVALUE is not null";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, ref);
			rs = pstmt.executeQuery();
			while(rs.next()){				
				SurveyVO vo = new SurveyVO();
				vo.setRef(Integer.parseInt(ref));
				vo.setQ(rs.getString("question"));
				vo.setA(rs.getString("Answer"));
				vo.setQvalue(rs.getString("Qvalue"));
				vo.setAvalue(rs.getString("Avalue"));
				vo.setCnt(rs.getInt("CNT"));
				Alist.add(vo);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {			
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		return Alist;
	}

	public void countup(String category, String ref, String q_name, String answer) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = null;
		try {
			conn = getConnection();
			
			sql = "UPDATE "+ category +"SURVEY SET CNT= CNT+1 WHERE REF=? AND QUESTION=? AND ANSWER=?";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, ref);
			pstmt.setString(2, q_name);
			pstmt.setString(3, answer);
			pstmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {			
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		
	}

	public void deleteSurvey(String category, String var_value) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = null;
		
		try {
			conn = getConnection();
			
			sql = "delete "+ category +"SURVEY WHERE REF=?";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, Integer.parseInt(var_value));
			pstmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {			
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}		
	}

}
