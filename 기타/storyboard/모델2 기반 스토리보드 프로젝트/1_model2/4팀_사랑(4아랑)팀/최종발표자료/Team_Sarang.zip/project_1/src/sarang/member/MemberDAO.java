package sarang.member;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import dbclose.util.CloseUtil;
import sarang.tip.TipVO;

public class MemberDAO {
	private static MemberDAO instance = new MemberDAO();

	public static MemberDAO getInstance() {
		return instance;
	}

	public MemberDAO() {
	}

	public Connection getConnection() throws Exception {

		Context ctx = new InitialContext();
		DataSource ds = (DataSource) ctx.lookup("java:comp/env/jdbc:SarangDB");

		return ds.getConnection();
	} // end getConnection()

	public int insert(MemberVO vo) throws Exception {
		// ȸ�����Խ� ���ο� ȸ������ DB�� ����
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = null;

		conn = getConnection();

		sql = "INSERT INTO MEMBER(NUM, ID , PASSWORD, NAME, PHONE, JOINTYPE, JOBNUM  ) "
				+ "VALUES(MEMBER_NUM.NEXTVAL, ?, ?, ?, ?, ?, ? )";
		pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, vo.getId());
		pstmt.setString(2, vo.getPassword());
		pstmt.setString(3, vo.getName());
		pstmt.setString(4, vo.getPhone());
		pstmt.setString(5, vo.getJointype());
		pstmt.setString(6, vo.getJobnum());

		int result = pstmt.executeUpdate();
		System.out.println("result = " + result);

		CloseUtil.close(pstmt);
		CloseUtil.close(conn);
		return result;
	} // end insert()

	public int pwdCheck(String id, String pwd) throws Exception {
		int result = -1;
		String dbpwd = "";

		Connection conn = getConnection();
		String sql = "SELECT * FROM MEMBER WHERE ID = ?";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, id);
		ResultSet rs = pstmt.executeQuery();

		if (rs.next()) { // id check
			dbpwd = rs.getString("password");
			if (dbpwd.equals(pwd)) { // ��������...
				result = 1;
			} else
				result = 0;
		}
		CloseUtil.close(rs);
		CloseUtil.close(pstmt);
		CloseUtil.close(conn);
		return result;
	}

	public MemberVO userCheck(String id) throws Exception {
		// Session������ ���� ������ ���� ����
		MemberVO vo = null;
		Connection conn = getConnection();
		String sql = "SELECT * FROM MEMBER WHERE ID = ?";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, id);
		ResultSet rs = pstmt.executeQuery();

		if (rs.next()) { // �α��ο�û�� ȸ������ vo��ü�� ����
			vo = new MemberVO();
			vo.setNum(rs.getInt("num"));
			vo.setId(rs.getString("id"));
			vo.setName(rs.getString("name"));
			vo.setMoney(rs.getString("money"));
		}
		CloseUtil.close(rs);
		CloseUtil.close(pstmt);
		CloseUtil.close(conn);
		return vo;
	}

	public MemberVO update(int num) {
		// ȸ������������ ȸ������ ������ֱ� ���� DB���� ȸ������ �������� �Լ�
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		MemberVO vo = null;

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement("SELECT * FROM MEMBER WHERE NUM=?");
			pstmt.setInt(1, num);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				vo = new MemberVO();
				vo.setNum(rs.getInt("num"));
				vo.setId(rs.getString("id"));
				vo.setPassword(rs.getString("password"));
				vo.setName(rs.getString("name"));
				vo.setPhone(rs.getString("phone"));
				vo.setJointype(rs.getString("jointype"));
				vo.setJobnum(rs.getString("jobnum"));
			} // if end

		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		return vo;

	}// update(num) end

	public int update(MemberVO vo, String newpassword) {
		// ȸ���������������� ���� ������ ȸ������ ����
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		String dbpasswd = null;
		int result = -1;

		try {
			conn = getConnection();
			sql = "SELECT PASSWORD FROM MEMBER WHERE NUM=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, vo.getNum());
			rs = pstmt.executeQuery();
			if (rs.next()) {
				dbpasswd = rs.getString("password");

				if (dbpasswd.equals(vo.getPassword())) {
					sql = "UPDATE MEMBER SET ID=?, PASSWORD=?, NAME=?, PHONE=?, JOINTYPE=?, JOBNUM=? WHERE NUM=? ";
					pstmt = conn.prepareStatement(sql);
					pstmt.setString(1, vo.getId());
					pstmt.setString(2, newpassword);
					pstmt.setString(3, vo.getName());
					pstmt.setString(4, vo.getPhone());
					pstmt.setString(5, vo.getJointype());
					pstmt.setString(6, vo.getJobnum());
					pstmt.setInt(7, vo.getNum());
					pstmt.executeUpdate();
					result = 1; // ������Ʈ ������ 1����
				} else {
					result = 0; // ���Ʋ������
				} // if in end
			} // if out end

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		return result;
	}// update(BoardVO vo) end

	public int delete(int num, String password) throws Exception {
		// ȸ��Ż�� �ϴ� �Լ�
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String dbpasswd = null;
		String sql = null;
		int result = 0;
		try {
			conn = getConnection();
			sql = "SELECT PASSWORD FROM MEMBER WHERE NUM = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, num);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				dbpasswd = rs.getString("password");
				if (dbpasswd.equals(password)) {
					sql = "DELETE FROM MEMBER WHERE NUM=?";
					pstmt = conn.prepareStatement(sql);
					pstmt.setInt(1, num);
					result = pstmt.executeUpdate();
					result = 1; // �ۻ��� ���� <--
				} else
					result = 0; // ��й�ȣ Ʋ�� } <--
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		return result;
	} // delete end

	public int confirmID(String id) {
		// ȸ�����Խ� ȸ�����̵� �ߺ�üũ�Ҷ� ���
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int result = 0;
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement("SELECT * FROM MEMBER WHERE ID = ?");
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();

			if (rs.next())
				result = 1; // �ش� ���̵� ����
			else
				result = 0;

		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		return result;
	}

	public int getListAllCount() {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int count = 0;

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement("SELECT COUNT(*) FROM MEMBER");
			rs = pstmt.executeQuery();

			if (rs.next()) {
				count = rs.getInt(1);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		return count;
	}

	public List getSelectAll(int startRow, int endRow) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List list = null;

		String sql = "";

		try {
			conn = getConnection();
			sql = "SELECT NUM, R, ID, PASSWORD, NAME, PHONE, JOINTYPE, JOBNUM, MONEY FROM "
					+ "(SELECT NUM, ID, PASSWORD, NAME, PHONE, JOINTYPE, JOBNUM, MONEY, ROWNUM R FROM "
					+ "(SELECT NUM, ID, PASSWORD, NAME, PHONE, JOINTYPE, JOBNUM, MONEY FROM "
					+ "MEMBER ORDER  BY NUM DESC) ) WHERE R>=? AND R<=?";

			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, startRow);
			pstmt.setInt(2, endRow);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				list = new ArrayList(endRow);
				do {
					MemberVO vo = new MemberVO();
					vo.setNum(rs.getInt("num"));
					vo.setId(rs.getString("id"));
					vo.setPassword(rs.getString("password"));
					vo.setName(rs.getString("name"));
					vo.setPhone(rs.getString("Phone"));
					vo.setJointype(rs.getString("jointype"));
					vo.setJobnum(rs.getString("jobnum"));
					vo.setMoney(rs.getString("money"));

					list.add(vo);
				} while (rs.next());
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		return list;
	}

	public int Moneyupdate(int num, int setmoney) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		int result = -1;
		int money = 0;

		try {
			conn = getConnection();
			sql = "SELECT MONEY FROM MEMBER WHERE NUM=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, num);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				money = Integer.parseInt(rs.getString(1));

				sql = "UPDATE MEMBER SET MONEY=" + (money + setmoney) + " WHERE NUM=?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, num);
				pstmt.executeUpdate();
				result = money + setmoney;
			} else {
				result = 0;
			} // if in end

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		return result;
	}

	public int PayMoney(String id) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		int result = -1;
		int money = 0;

		try {
			conn = getConnection();
			sql = "SELECT MONEY FROM MEMBER WHERE ID=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				money = Integer.parseInt(rs.getString(1));
				money -= 1000;
				sql = "UPDATE MEMBER SET MONEY=" + money + " WHERE ID=?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, id);
				pstmt.executeUpdate();
				result = 1;
			} else {
				result = 0;
			} // if in end

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		return result;
	}

	public int ReturnMoney(String id) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		int money = 0;

		try {
			conn = getConnection();
			sql = "SELECT MONEY FROM MEMBER WHERE ID=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				money = Integer.parseInt(rs.getString(1));
			} else {
				money = 0;
			} // if in end
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		return money;
	}

	// 관리자가 회원을 강제로 탈퇴시킬 때 사용!!
	public void delete(String id) throws Exception {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = null;
		try {
			conn = getConnection();
			sql = "DELETE FROM MEMBER WHERE id = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			pstmt.executeUpdate();

		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
	}

	// 관리자가 회원정보를 강제로 수정 할 때 사용!! (UpdateAdmin에서)
	public MemberVO update(String id, String jointype) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		MemberVO vo = null;

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement("SELECT * FROM MEMBER WHERE ID=? AND JOINTYPE=?");
			pstmt.setString(1, id);
			pstmt.setString(2, jointype);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				vo = new MemberVO();
				vo.setNum(rs.getInt("num"));
				vo.setId(rs.getString("id"));
				vo.setPassword(rs.getString("password"));
				vo.setName(rs.getString("name"));
				vo.setPhone(rs.getString("phone"));
				vo.setJointype(rs.getString("jointype"));
				vo.setJobnum(rs.getString("jobnum"));
				vo.setMoney(rs.getString("money"));
			} // if end

		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		return vo;
	}

	// 관리자가 회원정보를 강제로 수정 할 때 사용!! (UpdateAdminPro에서)
	public void update(MemberVO vo, String id, String name) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = null;
		
		try {
			conn = getConnection();
			sql = "UPDATE MEMBER SET NUM=?, ID=?, PASSWORD=?, NAME=?, PHONE=?, JOINTYPE=?, JOBNUM=?, MONEY=? WHERE ID=? ";

			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, vo.getNum());
			pstmt.setString(2, vo.getId());
			pstmt.setString(3, vo.getPassword());
			pstmt.setString(4, vo.getName());
			pstmt.setString(5, vo.getPhone());
			pstmt.setString(6, vo.getJointype());
			pstmt.setString(7, vo.getJobnum());
			pstmt.setString(8, vo.getMoney());
			pstmt.setString(9, id);
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
	}
}