package sarang.foodboard.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sarang.action.CommandAction;
import sarang.food.FoodDAO;

public class FoodWriteFormAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("utf-8");
		
		try {
			FoodDAO dao = FoodDAO.getInstance();
			int check_lastnum = dao.check_lastnum();
			request.setAttribute("lastnum", new Integer(check_lastnum));
			System.out.println(check_lastnum);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return "/FOOD/FoodWriteForm.jsp";
	}

}
