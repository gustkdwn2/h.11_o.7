package sarang.itboard.action;

import java.io.File;
import java.sql.Timestamp;
import java.util.Enumeration;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import sarang.action.CommandAction;
import sarang.it.ITDAO;
import sarang.it.ITVO;

public class ITWriteProAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("utf-8");

		String realPath = "";
		String savePath = "upload_IT";
		String encType = "utf-8";
		String name = "";
		String fileName = "";

		int maxSize = 1024 * 1024 * 5; // �ִ� ���ε� ����ũ�� 5M

		realPath = request.getRealPath(savePath + "\\");

		MultipartRequest multi = null;
		// ������ ����� ������Ʈ�� �����ϰ� ������ ����
		multi = new MultipartRequest(request, realPath, maxSize, encType, new DefaultFileRenamePolicy());
		Enumeration files = multi.getFileNames();

		while (files.hasMoreElements()) {
			name = (String) files.nextElement();
			fileName = multi.getFilesystemName(name); // ������ ���
			File file = multi.getFile(name);
		}

		String imagepath = "../project_1/upload_IT/" + fileName;

		ITVO vo = new ITVO();

		vo.setSubject(multi.getParameter("subject"));
		vo.setWriter(multi.getParameter("writer"));
		vo.setImagepath(imagepath);
		vo.setPhone(multi.getParameter("phone"));
		vo.setAddress(multi.getParameter("address"));
		vo.setMin_invest(multi.getParameter("min_invest"));
		vo.setMax_invest(multi.getParameter("max_invest"));
		vo.setContent(multi.getParameter("content"));//
		vo.setPassword(multi.getParameter("password"));//
		vo.setReg_date(new Timestamp(System.currentTimeMillis()));//
		vo.setIp(request.getRemoteAddr());

		ITDAO dao = ITDAO.getInstance();
		dao.insert(vo);

		return "/IT/ITWritePro.jsp";
	}
}
