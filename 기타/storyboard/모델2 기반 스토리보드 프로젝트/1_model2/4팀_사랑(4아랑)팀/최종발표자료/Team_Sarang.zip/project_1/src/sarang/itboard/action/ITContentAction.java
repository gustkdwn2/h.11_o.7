package sarang.itboard.action;

import java.util.Collections;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sarang.action.CommandAction;
import sarang.it.ITDAO;
import sarang.it.ITVO;

public class ITContentAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("utf-8");
		int num = Integer.parseInt(request.getParameter("num"));
		String pageNum = request.getParameter("pageNum");
		
		try {
			ITDAO dao = ITDAO.getInstance();
			ITVO vo = dao.getDataDetail(num);
			request.setAttribute("vo", vo);
			request.setAttribute("pageNum", pageNum);

			List list = null;
			int count = dao.ReplyCount(num);   // �ش� ����Ʈ ���ð��� Ȯ��
			
			if( count > 0 ){
				list = dao.getReplyAll(num);  //���ڵ� ��� ����
			} else {
				list=Collections.EMPTY_LIST;
			}			
			request.setAttribute("list", list);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "/IT/ITContent.jsp";
	}
}
