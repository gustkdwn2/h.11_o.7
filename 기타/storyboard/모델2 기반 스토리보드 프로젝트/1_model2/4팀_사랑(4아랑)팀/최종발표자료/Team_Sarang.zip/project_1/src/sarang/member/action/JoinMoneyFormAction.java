package sarang.member.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sarang.action.CommandAction;
import sarang.member.MemberDAO;
import sarang.member.MemberVO;

public class JoinMoneyFormAction implements CommandAction {
	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("utf-8");
		int num = Integer.parseInt(request.getParameter("num"));
		int money = Integer.parseInt(request.getParameter("money"));
		
		request.setAttribute("num", num);
		request.setAttribute("money", money);
		return "/member/JoinMoneyForm.jsp";
	}
}