package sarang.enboard.action;

import java.io.File;
import java.util.Enumeration;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import sarang.action.CommandAction;
import sarang.en.ENDAO;
import sarang.en.ENVO;

public class ENUpdateProAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("utf-8");
		String pageNum = request.getParameter("pageNum");

		String realPath = "";
		String savePath = "upload";
		String encType = "utf-8";
		String name = "";
		String fileName = "";

		int maxSize = 1024 * 1024 * 5;

		realPath = request.getRealPath(savePath + "\\");
		System.out.println("realPath is : " + realPath);
		MultipartRequest multi = null;

		multi = new MultipartRequest(request, realPath, maxSize, encType, new DefaultFileRenamePolicy());
		Enumeration files = multi.getFileNames();

		while (files.hasMoreElements()) {
			name = (String) files.nextElement();
			fileName = multi.getFilesystemName(name);
			File file = multi.getFile(name);

		}
		String imagepath = "../project_1/upload/" + fileName;

		ENDAO dao = ENDAO.getInstance();
		ENVO vo = new ENVO();

		vo.setNum(Integer.parseInt(multi.getParameter("num")));
		vo.setWriter(multi.getParameter("writer"));
		vo.setSubject(multi.getParameter("subject"));
		vo.setContent(multi.getParameter("content"));
		vo.setPassword(multi.getParameter("password"));
		vo.setImagepath(imagepath);
		
		vo.setPhone(multi.getParameter("phone"));
		vo.setAddress(multi.getParameter("address"));
		vo.setMin_invest(multi.getParameter("min_invest"));		
		vo.setMax_invest(multi.getParameter("max_invest"));

		int check = dao.update(vo);

		request.setAttribute("check", check);
		request.setAttribute("pageNum", pageNum);

		return "/EN/ENUpdatePro.jsp";
	}

}
