package sarang.foodboard.action;

import java.util.Enumeration;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sarang.action.CommandAction;
import sarang.survey.SurveyDAO;

public class FoodSurveyUpdateProAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {

		request.setCharacterEncoding("utf-8");

		SurveyDAO dao = new SurveyDAO();
		Enumeration var = request.getParameterNames();
		String var_name = null;
		String var_value = null;
		int ref_num = 0;
		int i = 0;
		while (var.hasMoreElements()) {
			var_name = (String) var.nextElement();
			var_value = request.getParameter(var_name);

			if (var_name.equals("ref")) {
				dao.deleteSurvey("FOOD", var_value);
				ref_num = Integer.parseInt(var_value);
			}

			if (var_name.substring(1, 2).equals(String.valueOf(i))) {
				if (var_name.length() == 2) {
					dao.saveQ("FOOD", ref_num, var_name, var_value);

				} else if (var_name.length() > 3) {
					dao.saveA("FOOD", ref_num, var_name, var_value);
				}
			}

			else {
				i++;
				if (var_name.substring(1, 2).equals(String.valueOf(i))) {
					if (var_name.length() == 2) {
						dao.saveQ("FOOD", ref_num, var_name, var_value);
					}
				}
			}

			System.out.println("var_name : " + var_name + "\tvar_value" + var_value);
			System.out.println(var_name.substring(1, 2));
			System.out.println(var_name.length());
			System.out.println("i : " + i);
		}

		return "/FOOD/FoodSurveyUpdatePro.jsp";
	}
}