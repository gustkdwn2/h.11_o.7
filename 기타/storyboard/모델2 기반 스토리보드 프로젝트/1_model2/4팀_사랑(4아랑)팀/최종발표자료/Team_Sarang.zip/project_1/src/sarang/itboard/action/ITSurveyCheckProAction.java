package sarang.itboard.action;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sarang.action.CommandAction;
import sarang.survey.SurveyDAO;

public class ITSurveyCheckProAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {

		request.setCharacterEncoding("utf-8");
		SurveyDAO dao = new SurveyDAO();
		String ref = request.getParameter("ref");
		String pageNum = request.getParameter("pageNum");
		int Q_len = Integer.parseInt(request.getParameter("Q"));
		int A_len = Integer.parseInt(request.getParameter("A"));

		String Answer = null;
		for(int i = 1; i<=Q_len; i++){
			String Q_name = "Q";
			Q_name = Q_name+i;
	
			Answer = request.getParameter(Q_name);

			dao.countup("IT", ref, Q_name, Answer);
		}
		request.setAttribute("ref", ref);
		request.setAttribute("pageNum", pageNum);		
		return "/IT/ITSurveyCheckPro.jsp";
	}
}
