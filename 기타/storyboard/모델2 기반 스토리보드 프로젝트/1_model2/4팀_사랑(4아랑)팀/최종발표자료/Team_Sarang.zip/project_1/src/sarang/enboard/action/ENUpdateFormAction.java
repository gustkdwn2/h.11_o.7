package sarang.enboard.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sarang.action.CommandAction;
import sarang.en.ENDAO;
import sarang.en.ENVO;

public class ENUpdateFormAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("utf-8");
		
		int num = 0;

		num = Integer.parseInt(request.getParameter("num"));
		String pageNum = request.getParameter("pageNum");

		System.out.println("������Ʈ�׼� num : " + num);
		System.out.println("������Ʈ�׼� pageNum : " + pageNum);

		try {
			ENDAO dao = ENDAO.getInstance();
			ENVO vo = dao.update(num);
			request.setAttribute("vo", vo);
			request.setAttribute("num", num);
			request.setAttribute("pageNum", pageNum);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return "/EN/ENUpdateForm.jsp";
	}
}