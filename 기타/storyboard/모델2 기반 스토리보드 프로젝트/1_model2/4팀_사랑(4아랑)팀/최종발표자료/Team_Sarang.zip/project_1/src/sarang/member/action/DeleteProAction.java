package sarang.member.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import sarang.action.CommandAction;
import sarang.member.MemberDAO;

public class DeleteProAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("utf-8");
		MemberDAO dao = MemberDAO.getInstance();
		String num = request.getParameter("num");
		String password = request.getParameter("password");
		int check = dao.delete(Integer.parseInt(num), password);
		request.setAttribute("check", check);
		if (check == 1) {
			HttpSession session = request.getSession();
			session.invalidate();
		}
		return "/member/deletePro.jsp";
	}
}
