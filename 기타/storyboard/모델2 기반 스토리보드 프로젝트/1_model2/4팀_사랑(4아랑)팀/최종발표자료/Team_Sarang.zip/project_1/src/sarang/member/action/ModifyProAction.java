package sarang.member.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sarang.action.CommandAction;
import sarang.member.MemberDAO;
import sarang.member.MemberVO;

public class ModifyProAction implements CommandAction {

   @Override
   public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
      
      request.setCharacterEncoding("utf-8");
         int num=Integer.parseInt(request.getParameter("num"));
         String id = request.getParameter("id");
         String password = request.getParameter("password");
         String name = request.getParameter("name");         
         String newpassword = request.getParameter("newpassword");
         String phone = request.getParameter("phone");
         String jointype = request.getParameter("jointype");
         String jobnum = request.getParameter("jobnum");   
         
         MemberDAO dao = MemberDAO.getInstance();
         MemberVO vo = new MemberVO();
         vo.setNum(num);
         vo.setId(id);
         vo.setPassword(password);
         vo.setName(name);
         vo.setPhone(phone);
         vo.setJointype(jointype);
         vo.setJobnum(jobnum);
         
         int check = dao.update(vo, newpassword);

         request.setAttribute("check", check);
      
      return "/member/modifyPro.jsp";
   }

}