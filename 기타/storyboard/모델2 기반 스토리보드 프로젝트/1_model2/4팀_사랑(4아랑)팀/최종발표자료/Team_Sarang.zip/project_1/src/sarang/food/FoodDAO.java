package sarang.food;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import dbclose.util.CloseUtil;

public class FoodDAO {
	private static FoodDAO instance = new FoodDAO();

	public static FoodDAO getInstance() {
		return instance;
	}

	public FoodDAO() {
	}

	public Connection getConnection() throws Exception {

		Context ctx = new InitialContext();
		DataSource ds = (DataSource) ctx.lookup("java:comp/env/jdbc:SarangDB");

		return ds.getConnection();
	} // end getConnection()

	public int getListAllCount() {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int count = 0;

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement("SELECT COUNT(*) FROM FOODBOARD");
			rs = pstmt.executeQuery();

			if (rs.next()) {
				count = rs.getInt(1);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		return count;
	}

	public int ReplyCount(int num) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int count = 0;
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement("SELECT COUNT(*) FROM FOODREPLYBOARD WHERE REF_NUM = ?");
			pstmt.setInt(1, num);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				count = rs.getInt(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		return count;
	}

	public List<FoodVO> getSelectAll(int startRow, int endRow) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List list = null;
		String sql = null;

		try {
			conn = getConnection();
			sql = "SELECT NUM, R, SUBJECT, WRITER, IMAGEPATH, PHONE, ADDRESS, MIN_INVEST, MAX_INVEST, CONTENT, PASSWORD, REG_DATE, IP, READCOUNT FROM "
					+ "(SELECT NUM, SUBJECT, WRITER, IMAGEPATH, PHONE, ADDRESS, MIN_INVEST, MAX_INVEST, CONTENT, PASSWORD, REG_DATE, IP, READCOUNT, ROWNUM R FROM "
					+ "(SELECT NUM, SUBJECT, WRITER, IMAGEPATH, PHONE, ADDRESS, MIN_INVEST, MAX_INVEST, CONTENT, PASSWORD, REG_DATE, IP, READCOUNT FROM "
					+ "FOODBOARD ORDER BY NUM DESC )) WHERE R>=? AND R<=?";

			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, startRow);
			pstmt.setInt(2, endRow);
			rs = pstmt.executeQuery();
			list = new ArrayList();

			while (rs.next()) {
				FoodVO vo = new FoodVO();

				vo.setNum(rs.getInt("num"));
				vo.setSubject(rs.getString("subject"));
				vo.setWriter(rs.getString("writer"));
				vo.setImagepath(rs.getString("imagepath"));
				vo.setPhone(rs.getString("phone"));
				vo.setAddress(rs.getString("address"));
				vo.setMin_invest(rs.getString("min_invest"));
				vo.setMax_invest(rs.getString("max_invest"));
				vo.setContent(rs.getString("content"));
				vo.setPassword(rs.getString("password"));
				vo.setReg_date(rs.getTimestamp("reg_date"));
				vo.setIp(rs.getString("ip"));
				vo.setReadcount(rs.getInt("readcount"));
				list.add(vo);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		return list;
	}

	public List<FoodReplyVO> getReplyAll(int num) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List list = null;
		String sql = null;

		try {
			conn = getConnection();
			sql = "SELECT * FROM FOODREPLYBOARD WHERE REF_NUM =?";

			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, num);

			rs = pstmt.executeQuery();
			list = new ArrayList();

			while (rs.next()) {
				FoodReplyVO re_vo = new FoodReplyVO();
				re_vo.setRef_num(rs.getInt("REF_NUM"));
				re_vo.setReply_writer(rs.getString("REPLY_WRITER"));
				re_vo.setReply_password(rs.getString("REPLY_PASSWORD"));
				re_vo.setReply_content(rs.getString("REPLY_CONTENT"));
				re_vo.setRe_num(rs.getInt("RE_NUM"));
				list.add(re_vo);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		return list;
	}

	public void insert(FoodVO vo) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		String sql = "";

		try {
			conn = getConnection();

			sql = "INSERT INTO FOODBOARD(NUM, SUBJECT, WRITER, IMAGEPATH, PHONE, ADDRESS, MIN_INVEST, MAX_INVEST, CONTENT, PASSWORD, REG_DATE, IP)"
					+ " VALUES(IT_NUM.NEXTVAL, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, vo.getSubject());
			pstmt.setString(2, vo.getWriter());
			pstmt.setString(3, vo.getImagepath());
			pstmt.setString(4, vo.getPhone());
			pstmt.setString(5, vo.getAddress());
			pstmt.setString(6, vo.getMin_invest());
			pstmt.setString(7, vo.getMax_invest());
			pstmt.setString(8, vo.getContent());
			pstmt.setString(9, vo.getPassword());
			pstmt.setTimestamp(10, vo.getReg_date());
			pstmt.setString(11, vo.getIp());
			pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
	}

	public void insert(FoodReplyVO re_vo) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "";
		try {
			conn = getConnection();
			sql = "INSERT INTO FOODREPLYBOARD(RE_NUM, REF_NUM, REPLY_WRITER, REPLY_PASSWORD, REPLY_CONTENT)"
					+ " VALUES(IT_RE_NUM.NEXTVAL, ?, ?, ?, ?)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, re_vo.getRef_num());
			pstmt.setString(2, re_vo.getReply_writer());
			pstmt.setString(3, re_vo.getReply_password());
			pstmt.setString(4, re_vo.getReply_content());
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
	}

	public int check_lastnum() {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int lastnum = 0;
		String sql = "";
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement("select max(num) from FOODBOARD");
			rs = pstmt.executeQuery();
			if (rs.next()) {
				lastnum = rs.getInt(1); // ���� �� ��ȣ(���� �߰���)�� ���� ū��ȣ +
										// 1
			} else
				lastnum = 0;

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		return lastnum;
	}

	public FoodVO getDataDetail(int num) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		FoodVO vo = null;
		String sql = null;

		try {
			sql = "UPDATE FOODBOARD SET READCOUNT = READCOUNT + 1 WHERE NUM = ?";
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, num);
			pstmt.executeUpdate();

			pstmt = conn.prepareStatement("SELECT * FROM FOODBOARD WHERE NUM = ?");
			pstmt.setInt(1, num);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				vo = new FoodVO();

				vo.setNum(rs.getInt("num"));
				vo.setSubject(rs.getString("subject"));
				vo.setWriter(rs.getString("writer"));
				vo.setImagepath(rs.getString("imagepath"));
				vo.setPhone(rs.getString("phone"));
				vo.setAddress(rs.getString("address"));
				vo.setMin_invest(rs.getString("min_invest"));
				vo.setMax_invest(rs.getString("max_invest"));
				vo.setContent(rs.getString("content"));
				vo.setPassword(rs.getString("password"));
				vo.setReg_date(rs.getTimestamp("reg_date"));
				vo.setIp(rs.getString("ip"));
				vo.setReadcount(rs.getInt("readcount"));
			} // if end

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		return vo;
	}

	public FoodVO toprate() {

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		FoodVO vo = null;
		String sql = null;

		try {
			conn = getConnection();
			sql = "SELECT NUM FROM FOODBOARD WHERE READCOUNT = (SELECT MAX(READCOUNT) FROM FOODBOARD)";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			int num = 0;
			if (rs.next())
				num = rs.getInt(1);
			// System.out.println(num);

			sql = "SELECT * FROM FOODBOARD WHERE NUM = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, num);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				vo = new FoodVO();
				vo.setNum(rs.getInt("num"));
				vo.setWriter(rs.getString("writer"));
				vo.setImagepath(rs.getString("imagepath"));
				vo.setSubject(rs.getString("subject"));
				vo.setPassword(rs.getString("password"));
				vo.setReg_date(rs.getTimestamp("reg_date"));
				vo.setReadcount(rs.getInt("readcount"));
				vo.setContent(rs.getString("content"));
				vo.setIp(rs.getString("ip"));
			} // if end

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}

		return vo;
	}

	public FoodVO update(int num) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		FoodVO vo = null;

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement("SELECT * FROM FOODBOARD WHERE NUM = ?");
			pstmt.setInt(1, num);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				vo = new FoodVO();
				vo.setNum(rs.getInt("num"));
				vo.setWriter(rs.getString("writer"));
				vo.setImagepath(rs.getString("imagepath"));
				vo.setSubject(rs.getString("subject"));
				vo.setPassword(rs.getString("password"));
				vo.setReg_date(rs.getTimestamp("reg_date"));
				vo.setReadcount(rs.getInt("readcount"));
				vo.setContent(rs.getString("content"));
				vo.setIp(rs.getString("ip"));
				vo.setAddress(rs.getString("address"));
				vo.setPhone(rs.getString("phone"));
				vo.setMax_invest(rs.getString("max_invest"));
				vo.setMin_invest(rs.getString("min_invest"));
			} // if end
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		return vo;
	}

	public int update(FoodVO vo) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		String dbpasswd = "";
		StringBuffer sb = new StringBuffer();
		int result = -1;

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement("select  password  from FOODBOARD where num = ?");
			pstmt.setInt(1, vo.getNum());
			rs = pstmt.executeQuery();

			if (rs.next()) {
				dbpasswd = rs.getString("password");

				if (dbpasswd.equals(vo.getPassword())) {
					sb.append("update FOODBOARD set writer=?, subject =? , password =? ,");
					sb.append(
							" content=? , imagepath =? , phone=?, address=?, min_invest=?, max_invest=? where num = ? ");
					pstmt = conn.prepareStatement(sb.toString());

					pstmt.setString(1, vo.getWriter());
					pstmt.setString(2, vo.getSubject());
					pstmt.setString(3, vo.getPassword());
					pstmt.setString(4, vo.getContent());
					pstmt.setString(5, vo.getImagepath());
					pstmt.setString(6, vo.getPhone());
					pstmt.setString(7, vo.getAddress());
					pstmt.setString(8, vo.getMin_invest());
					pstmt.setString(9, vo.getMax_invest());
					pstmt.setInt(10, vo.getNum());
					pstmt.executeUpdate(); //
					result = 1;
				} else {
					result = 0;
				} // if in end
			} // if out end
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		return result;
	}

	public int listnum(int num) {

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		int readcount = 0;
		int listnum = 0;
		try {
			conn = getConnection();
			sql = "select max(readcount) from FOODBOARD";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if (rs.next())
				readcount = rs.getInt(1);

			sql = "SELECT NUM, READCOUNT, R FROM (SELECT NUM, READCOUNT, ROWNUM R FROM (SELECT NUM, READCOUNT FROM FOODBOARD ORDER BY NUM DESC)) where READCOUNT = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, readcount);
			rs = pstmt.executeQuery();
			if (rs.next())
				listnum = rs.getInt(3);
			System.out.println(listnum);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		return listnum;
	}

	public int delete(String num, String password) throws Exception {
		String sql = "select password  from FOODBOARD where num = ?";
		String dbpwd = "";
		String subsql = "";
		int result = -1;
		Connection conn = getConnection();
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, num);
		ResultSet rs = pstmt.executeQuery();
		if (rs.next()) {
			dbpwd = rs.getString("password");
			if (dbpwd.equals(password)) {
				sql = "delete from FOODBOARD where num=?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, num);
				pstmt.executeUpdate();

				subsql = "delete from FOODSURVEY where ref=?";
				pstmt = conn.prepareStatement(subsql);
				pstmt.setString(1, num);
				pstmt.executeUpdate();
				result = 1;
			} else
				result = 0;
		} else
			result = 0;
		CloseUtil.close(rs);
		CloseUtil.close(pstmt);
		CloseUtil.close(conn);
		return result;
	}

	public int deleteReply(String re_num, String reply_password) throws Exception {
		String sql = "SELECT REPLY_PASSWORD FROM FOODREPLYBOARD WHERE RE_NUM = ?";
		String dbpwd = "";
		int result = -1;
		Connection conn = getConnection();
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, re_num);
		ResultSet rs = pstmt.executeQuery();
		if (rs.next()) {
			dbpwd = rs.getString("REPLY_PASSWORD");
			if (dbpwd.equals(reply_password)) {
				sql = "DELETE FROM FOODREPLYBOARD WHERE RE_NUM=?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, re_num);
				rs = pstmt.executeQuery();
				result = 1; // ��������...
			} else
				result = 0; // ����� Ʋ����.....
		} else
			result = 0;
		CloseUtil.close(rs);
		CloseUtil.close(pstmt);
		CloseUtil.close(conn);
		return result;
	}
}
