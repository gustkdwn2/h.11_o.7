package sarang.tipboard.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sarang.action.CommandAction;
import sarang.tip.TipDAO;
import sarang.tip.TipVO;

public class TipUpdateProAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("utf-8");
		String pageNum = request.getParameter("pageNum");
		TipDAO dao = TipDAO.getInstance();
		TipVO vo = new TipVO();

		vo.setNum(Integer.parseInt(request.getParameter("num")));
		vo.setWriter(request.getParameter("writer"));
		vo.setSubject(request.getParameter("subject"));
		vo.setEmail(request.getParameter("email"));
		vo.setContent(request.getParameter("content"));
		vo.setPassword(request.getParameter("password"));

		int check = dao.update(vo); // ���� ���� ������ �ݿ��ϴ� �Լ�

		request.setAttribute("check", check);
		request.setAttribute("pageNum", pageNum);

		return "/tipboard/TipUpdatePro.jsp";
	}

}
