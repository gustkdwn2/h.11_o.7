CREATE TABLE TIPBOARD (
	NUM NUMBER(7) NOT NULL,		
	WRITER VARCHAR2(20) NOT NULL,	
	EMAIL VARCHAR2(30) ,		
	SUBJECT VARCHAR2(50) NOT NULL,	
	PASSWORD VARCHAR2(12) NOT NULL,   	 
	REG_DATE DATE NOT NULL, 		
	READCOUNT NUMBER(3) DEFAULT 0,	  
	REF NUMBER  NOT NULL, 	
	RE_STEP NUMBER NOT NULL,		
	RE_LEVEL  NUMBER NOT NULL,	
	CONTENT  NVARCHAR2(2000) NOT NULL,	
	IP VARCHAR2(20)  NOT NULL,   		
	CONSTRAINT  TIP_NUM_PK  PRIMARY KEY(NUM)	
) SEGMENT CREATION IMMEDIATE ;

CREATE SEQUENCE TIP_NUM; 

SELECT num, ref, re_step, re_level, content FROM TIPBOARD 

delete from TIPBOARD where writer = 'anseok'
select * from TIPBOARD

select * from TIPBOARD order by ref desc, re_step asc;

select num, r, writer, email, subject, password, reg_date, ref, re_step, re_level, content, ip, readcount from
	(select num, writer, email, subject, password, reg_date, ref, re_step, re_level, content, ip, readcount, rownum r from	
		(select num, writer, email, subject, password, reg_date, ref, re_step, re_level, content, ip, readcount from TIPBOARD order by ref desc, re_step asc)
	)
where r>=1 and r<=6;

delete from TIPBOARD where re_level>(select re_level from TIPBOARD where num = '42') and ref = ? and 
 select num, ref, re_step, re_level from TIPBOARD where ref ='31' and re_level >= (select re_level from TIPBOARD where num = '42') order by re_step asc