package sarang.tip;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import dbclose.util.CloseUtil;

public class TipDAO {
	private static TipDAO instance = new TipDAO();
	public static TipDAO getInstance() {
		return instance;
	}

	public TipDAO() {
	}

	public Connection getConnection() throws Exception {

		Context ctx = new InitialContext();
		DataSource ds = (DataSource) ctx.lookup("java:comp/env/jdbc:SarangDB");

		return ds.getConnection();
	} // end getConnection()

	public int getListAllCount(){
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int count = 0;
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement("SELECT COUNT(*) FROM TIPBOARD");
			rs = pstmt.executeQuery();
			
			if(rs.next()){
				count = rs.getInt(1);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);	CloseUtil.close(pstmt);	CloseUtil.close(conn);
		}
		return count;
	}
	
	public List<TipVO> getSelectAll(int startRow, int endRow){
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List list = null;
		StringBuffer sb = new StringBuffer();
		String sql = "";
		
		try {
			conn = getConnection();
			sql = "select num, r, writer, email, subject, password, reg_date, ref, re_step, re_level, content, ip, readcount from "
					+ "(select num, writer, email, subject, password, reg_date, ref, re_step, re_level, content, ip, readcount, rownum r from "
					+ "(select num, writer, email, subject, password, reg_date, ref, re_step, re_level, content, ip, readcount from "
					+ "TIPBOARD order by ref desc, re_step asc) ) where r>=? and r<=?";
//			sb.append("select num, writer, email, subject, password, reg_date, ref, re_step, re_level, ");
//			sb.append("content, ip, readcount, r from(select num, writer, email, subject, password, ");
//			sb.append("reg_date, ref, re_step, re_level, content, ip, readcount, rownum r ");
//			sb.append("from(select num, writer, email, subject, password, reg_date, ref, re_step, re_level, ");
//			sb.append("content, ip, readcount from TIPBOARD order by ref desc, re_step asc) ");
//			sb.append("order by ref desc, re_level asc) where r>=? and r<=?");
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, startRow);
			pstmt.setInt(2, endRow);
			rs = pstmt.executeQuery();
			

			if(rs.next()){
				list = new ArrayList(endRow);
				do {
					TipVO vo = new TipVO();
					vo.setNum(rs.getInt("num"));
					vo.setWriter(rs.getString("writer"));
					vo.setEmail(rs.getString("email"));
					vo.setSubject(rs.getString("subject"));
					vo.setPassword(rs.getString("password"));
					vo.setReg_date(rs.getTimestamp("reg_date"));
					vo.setReadcount(rs.getInt("readcount"));
					vo.setRef(rs.getInt("ref"));
					vo.setRe_step(rs.getInt("re_step"));
					vo.setRe_level(rs.getInt("re_level"));
					vo.setContent(rs.getString("content"));
					vo.setIp(rs.getString("ip"));
					
					list.add(vo);
				} while(rs.next());
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);	CloseUtil.close(pstmt);	CloseUtil.close(conn);
		}
		return list;
	}

	public void insert(TipVO vo) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		StringBuffer sb = new StringBuffer();

		// �亯���� �Ϲ�(����) ������ �����ؼ� �Է½����ִ� ����
		int num = vo.getNum();
		int ref = vo.getRef();
		int re_step = vo.getRe_step();
		int re_level = vo.getRe_level();
		int number = 0;
		String sql = "";

		try {
			conn = getConnection();

			// ���� board ���̺� ���ڵ��� ���� �Ǵܰ� �� ��ȣ�� ����;
			pstmt = conn.prepareStatement("select max(num) from TIPBOARD");
			rs = pstmt.executeQuery();

			// ���ڵ尡 �����Ѵٸ�
			if (rs.next()) {
				number = rs.getInt(1) + 1; // ���� �� ��ȣ(���� �߰���)�� ���� ū��ȣ + 1
			} else
				number = 1;

			if (num != 0) {
				sql = "update TIPBOARD set re_step = re_step+1 where ref = ? and re_step > ?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, ref);
				pstmt.setInt(2, re_step);
				pstmt.executeUpdate();
				re_step = re_step+1;
				re_level = re_level+1;
			}else{
				ref = number;				
				re_step = 0;
				re_level = 0;
			}

			sb.append("insert into TIPBOARD(num, writer, subject, email, content, password, ");
			sb.append("reg_date, ref, re_step, re_level, ip) ");
			sb.append("values(TIP_NUM.nextVal, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

			pstmt = conn.prepareStatement(sb.toString());
			pstmt.setString(1, vo.getWriter());
			pstmt.setString(2, vo.getSubject());
			pstmt.setString(3, vo.getEmail());
			pstmt.setString(4, vo.getContent());
			pstmt.setString(5, vo.getPassword());
			pstmt.setTimestamp(6, vo.getReg_date());
			pstmt.setInt(7, ref);
			pstmt.setInt(8, re_step);
			pstmt.setInt(9, re_level);
			pstmt.setString(10, vo.getIp());
			pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			CloseUtil.close(rs);	CloseUtil.close(pstmt);	CloseUtil.close(conn);
		}		
	}

	public TipVO getDataDetail(int num){
		Connection  conn = null;
		PreparedStatement pstmt = null;
		ResultSet  rs = null;
		TipVO  vo = null;
		String sql = null;
		
		try {
			sql = "UPDATE TIPBOARD SET READCOUNT = READCOUNT + 1 WHERE NUM = ?";
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, num);
			pstmt.executeUpdate(); 
			
			pstmt = conn.prepareStatement("SELECT * FROM TIPBOARD WHERE NUM = ?" );
			pstmt.setInt(1, num);
			rs = pstmt.executeQuery();
			
			if( rs.next() ) {
				vo = new TipVO();
				vo.setNum(rs.getInt("num"));
				vo.setWriter(rs.getString("writer"));
				vo.setEmail(rs.getString("email"));
				vo.setSubject(rs.getString("subject"));
				vo.setPassword(rs.getString("password"));
				vo.setReg_date(rs.getTimestamp("reg_date"));
				vo.setReadcount(rs.getInt("readcount"));
				vo.setRef(rs.getInt("ref"));
				vo.setRe_step(rs.getInt("re_step"));
				vo.setRe_level(rs.getInt("re_level"));
				vo.setContent(rs.getString("content"));
				vo.setIp(rs.getString("ip"));
			} // if end
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			 CloseUtil.close(rs);			 CloseUtil.close(pstmt);			 CloseUtil.close(conn);
		}		
		return vo ;
	}

	public TipVO update(int num) {
		Connection  conn = null;
		PreparedStatement pstmt = null;
		ResultSet  rs = null;
		TipVO  vo = null;
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement("SELECT * FROM TIPBOARD WHERE NUM = ?" );
			pstmt.setInt(1, num);
			rs = pstmt.executeQuery();
			
			if( rs.next() ) {
				vo = new TipVO();
				vo.setNum(rs.getInt("num"));
				vo.setWriter(rs.getString("writer"));
				vo.setEmail(rs.getString("email"));
				vo.setSubject(rs.getString("subject"));
				vo.setPassword(rs.getString("password"));
				vo.setReg_date(rs.getTimestamp("reg_date"));
				vo.setReadcount(rs.getInt("readcount"));
				vo.setRef(rs.getInt("ref"));
				vo.setRe_step(rs.getInt("re_step"));
				vo.setRe_level(rs.getInt("re_level"));
				vo.setContent(rs.getString("content"));
				vo.setIp(rs.getString("ip"));
			} // if end			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			 CloseUtil.close(rs);			 CloseUtil.close(pstmt);			 CloseUtil.close(conn);
		}		
		return vo ;
	}

	public int update(TipVO vo) {
		Connection  conn = null;
		PreparedStatement pstmt = null;
		ResultSet  rs = null;
		
		String dbpasswd = "";
		StringBuffer sb = new StringBuffer();
		int result = -1;
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement("select  password  from TIPBOARD where num = ?" );
			pstmt.setInt(1, vo.getNum());
			rs = pstmt.executeQuery();
			
			if( rs.next() ) {
				dbpasswd = rs.getString("password");
				
				if( dbpasswd.equals(vo.getPassword())) {
					sb.append("update TIPBOARD set writer=?, email =? , subject =? , password =? ,");
					sb.append(" content=? where num = ? ");
					pstmt = conn.prepareStatement(sb.toString());
					
					pstmt.setString(1, vo.getWriter());
					pstmt.setString(2, vo.getEmail());
					pstmt.setString(3, vo.getSubject());
					pstmt.setString(4, vo.getPassword());
					pstmt.setString(5, vo.getContent());
					pstmt.setInt(6, vo.getNum());
					
					pstmt.executeUpdate();   //
					
					result = 1;   // ������Ʈ ������ 1 ����...
					
				} else {
					result = 0; // ����� Ʋ������ 
				} // if in end		
			} // if out end
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			 CloseUtil.close(rs);			 CloseUtil.close(pstmt);			 CloseUtil.close(conn);
		}			
		return result;
	}

	public int delete(String num, String pwd)throws Exception {
		String sql = "select password  from TIPBOARD where num = ?";
		String dbpwd = "";
		int result = -1;
		Connection conn = getConnection();
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, num);
		ResultSet rs = pstmt.executeQuery();
		if (rs.next()) {
			dbpwd = rs.getString("password");
			if (dbpwd.equals(pwd)) {
				
				sql = "update TIPBOARD set writer = 'X', subject = '게시물이 삭제되었습니다.', email = 'X', content = 'X', password = 'X', ip='X' where num = ?";
				
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, num);
				rs = pstmt.executeQuery();			
				result = 1; // ��������...
			} else
				result = 0; // ����� Ʋ����.....
		} else
			result = 0;
		CloseUtil.close(rs);
		CloseUtil.close(pstmt);
		CloseUtil.close(conn);
		return result;
	}
}