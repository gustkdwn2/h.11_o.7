package sarang.member.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sarang.action.CommandAction;
import sarang.member.MemberDAO;
import sarang.member.MemberVO;

public class UpdateAdminAction implements CommandAction {
	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("utf-8");

		String id = request.getParameter("id");
		String jointype = request.getParameter("jointype");

		MemberDAO dao = MemberDAO.getInstance();
		MemberVO vo = dao.update(id, jointype);

		request.setAttribute("num", vo.getNum());
		request.setAttribute("id", vo.getId());
		request.setAttribute("password", vo.getPassword());
		request.setAttribute("name", vo.getName());
		request.setAttribute("phone", vo.getPhone());
		request.setAttribute("jointype", vo.getJointype());
		request.setAttribute("jobnum", vo.getJobnum());
		request.setAttribute("money", vo.getMoney());

		return "/member/updateAdmin.jsp";
	}
}