package sarang.itboard.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sarang.action.CommandAction;
import sarang.it.ITDAO;
import sarang.it.ITReplyVO;

public class ITReplyProAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("utf-8");
		ITReplyVO re_vo = new ITReplyVO();
		
		re_vo.setRef_num(Integer.parseInt(request.getParameter("ref_num")));		
		re_vo.setReply_writer(request.getParameter("reply_writer"));
		re_vo.setReply_password(request.getParameter("reply_password"));
		re_vo.setReply_content(request.getParameter("reply_content"));
		
		
		ITDAO dao = new ITDAO();
		dao.insert(re_vo);
		
		String ref_pageNum = request.getParameter("ref_pageNum");
		System.out.println(ref_pageNum);
		request.setAttribute("re_vo", re_vo);
		request.setAttribute("ref_pageNum", ref_pageNum);

		return "/IT/ITReplyPro.jsp";
	}

}
