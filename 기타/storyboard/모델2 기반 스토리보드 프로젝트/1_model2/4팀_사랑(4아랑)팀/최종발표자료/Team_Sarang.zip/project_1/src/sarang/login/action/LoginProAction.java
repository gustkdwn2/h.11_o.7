package sarang.login.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import sarang.action.CommandAction;
import sarang.member.MemberDAO;
import sarang.member.MemberVO;

public class LoginProAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("utf-8");
		String id = request.getParameter("id");
		String pwd = request.getParameter("password");
		int check = 0;

		MemberDAO dao = MemberDAO.getInstance();
		MemberVO vo = new MemberVO();
		check = dao.pwdCheck(id, pwd);
		System.out.println(check);
		if (check == 1) {
			vo = dao.userCheck(id);
			HttpSession session = request.getSession();
			session.setAttribute("num", vo.getNum());
			session.setAttribute("id", id);
			session.setAttribute("name", vo.getName());
			session.setAttribute("money", vo.getMoney());
			request.setAttribute("num", vo.getNum());
		}
		request.setAttribute("check", check);
		return "/login/LoginPro.jsp";
	}

}
