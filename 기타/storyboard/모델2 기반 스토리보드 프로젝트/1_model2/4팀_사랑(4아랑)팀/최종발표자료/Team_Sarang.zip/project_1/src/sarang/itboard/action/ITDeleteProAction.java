package sarang.itboard.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sarang.action.CommandAction;
import sarang.food.FoodDAO;
import sarang.it.ITDAO;
import sarang.it.ITVO;

public class ITDeleteProAction implements CommandAction {
	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("utf-8");
		String password = request.getParameter("password");
		String num = request.getParameter("num");

		ITDAO dao = ITDAO.getInstance();

		int check = dao.delete(num, password);
		request.setAttribute("check", check);

		return "/IT/ITDeletePro.jsp";
	}
}