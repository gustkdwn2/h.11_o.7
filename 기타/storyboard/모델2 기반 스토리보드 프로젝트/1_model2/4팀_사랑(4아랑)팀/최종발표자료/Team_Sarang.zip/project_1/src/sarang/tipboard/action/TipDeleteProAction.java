package sarang.tipboard.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sarang.action.CommandAction;
import sarang.tip.TipDAO;

public class TipDeleteProAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("utf-8");
		String pwd = request.getParameter("password");
		String num = request.getParameter("num");

		TipDAO dao = TipDAO.getInstance();
		int check = dao.delete(num, pwd);
		request.setAttribute("check", check);

		return "/tipboard/TipDeletePro.jsp";
	}
}