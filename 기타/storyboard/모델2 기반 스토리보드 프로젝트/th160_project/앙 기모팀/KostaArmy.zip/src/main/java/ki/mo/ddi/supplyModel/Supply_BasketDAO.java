package ki.mo.ddi.supplyModel;

import java.util.List;
import java.util.Map;

public interface Supply_BasketDAO {
	
	public void insertBasketSupply(Supply_BasketDTO dto);
	
	public List<Supply_BasketDTO> getBasketList(String osupply_group);
	
	public void deleteBasketSupply(Supply_BasketDTO dto);
	
	public void initialization(Map<Object, Object> map);
	
}
