package ki.mo.ddi.managerModel;

public class Manager_FamilyTableDTO {
	private String soldier_number;
	private String famRel1;
	private String famName1;
	private String famAge1;
	private String famJob1;
	private String famPhone1;
	private String famRel2;
	private String famName2;
	private String famAge2;
	private String famJob2;
	private String famPhone2;
	private String famRel3;
	private String famName3;
	public String getSoldier_number() {
		return soldier_number;
	}
	public void setSoldier_number(String soldier_number) {
		this.soldier_number = soldier_number;
	}
	public String getFamRel1() {
		return famRel1;
	}
	public void setFamRel1(String famRel1) {
		this.famRel1 = famRel1;
	}
	public String getFamName1() {
		return famName1;
	}
	public void setFamName1(String famName1) {
		this.famName1 = famName1;
	}
	public String getFamAge1() {
		return famAge1;
	}
	public void setFamAge1(String famAge1) {
		this.famAge1 = famAge1;
	}
	public String getFamJob1() {
		return famJob1;
	}
	public void setFamJob1(String famJob1) {
		this.famJob1 = famJob1;
	}
	public String getFamPhone1() {
		return famPhone1;
	}
	public void setFamPhone1(String famPhone1) {
		this.famPhone1 = famPhone1;
	}
	public String getFamRel2() {
		return famRel2;
	}
	public void setFamRel2(String famRel2) {
		this.famRel2 = famRel2;
	}
	public String getFamName2() {
		return famName2;
	}
	public void setFamName2(String famName2) {
		this.famName2 = famName2;
	}
	public String getFamAge2() {
		return famAge2;
	}
	public void setFamAge2(String famAge2) {
		this.famAge2 = famAge2;
	}
	public String getFamJob2() {
		return famJob2;
	}
	public void setFamJob2(String famJob2) {
		this.famJob2 = famJob2;
	}
	public String getFamPhone2() {
		return famPhone2;
	}
	public void setFamPhone2(String famPhone2) {
		this.famPhone2 = famPhone2;
	}
	public String getFamRel3() {
		return famRel3;
	}
	public void setFamRel3(String famRel3) {
		this.famRel3 = famRel3;
	}
	public String getFamName3() {
		return famName3;
	}
	public void setFamName3(String famName3) {
		this.famName3 = famName3;
	}
	public String getFamAge3() {
		return famAge3;
	}
	public void setFamAge3(String famAge3) {
		this.famAge3 = famAge3;
	}
	public String getFamJob3() {
		return famJob3;
	}
	public void setFamJob3(String famJob3) {
		this.famJob3 = famJob3;
	}
	public String getFamPhone3() {
		return famPhone3;
	}
	public void setFamPhone3(String famPhone3) {
		this.famPhone3 = famPhone3;
	}
	private String famAge3;
	private String famJob3;
	private String famPhone3;
}
