  function change1(obj){
        obj.style.background = '#BECDFF';
        obj.style.color = 'white';
    }
     
    function change2(obj){
        obj.style.background = 'white';
        obj.style.color = 'black';
    }