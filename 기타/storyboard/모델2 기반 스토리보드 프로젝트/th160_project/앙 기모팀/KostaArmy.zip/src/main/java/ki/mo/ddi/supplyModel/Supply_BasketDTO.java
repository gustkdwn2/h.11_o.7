package ki.mo.ddi.supplyModel;

public class Supply_BasketDTO {
	private String osupply_num;
	private String osupply_name;
	private String osupply_order;
	private String osupply_flag;
	private String osupply_group;
	
	private String tableName;
	
	public String getTableName() {
		return tableName;
	}
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	public String getOsupply_group() {
		return osupply_group;
	}
	public void setOsupply_group(String osupply_group) {
		this.osupply_group = osupply_group;
	}
	public String getOsupply_num() {
		return osupply_num;
	}
	public void setOsupply_num(String osupply_num) {
		this.osupply_num = osupply_num;
	}
	public String getOsupply_name() {
		return osupply_name;
	}
	public void setOsupply_name(String osupply_name) {
		this.osupply_name = osupply_name;
	}
	public String getOsupply_order() {
		return osupply_order;
	}
	public void setOsupply_order(String osupply_order) {
		this.osupply_order = osupply_order;
	}
	public String getOsupply_flag() {
		return osupply_flag;
	}
	public void setOsupply_flag(String osupply_flag) {
		this.osupply_flag = osupply_flag;
	}
	
	
}
