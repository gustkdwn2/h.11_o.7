package ki.mo.ddi.supplyModel;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Supply_BasketDAOImpl implements Supply_BasketDAO {

	@Autowired
	private SqlSession sqlSession;
	
	@Override
	public void insertBasketSupply(Supply_BasketDTO dto) {
		// TODO Auto-generated method stub
		Supply_BasketDAO supply_basketDAO = sqlSession.getMapper(Supply_BasketDAO.class);
		supply_basketDAO.insertBasketSupply(dto);
	}

	@Override
	public List<Supply_BasketDTO> getBasketList(String osupply_group) {
		Supply_BasketDAO supply_basketDAO = sqlSession.getMapper(Supply_BasketDAO.class);
		return supply_basketDAO.getBasketList(osupply_group);
	}

	@Override
	public void deleteBasketSupply(Supply_BasketDTO dto) {
		Supply_BasketDAO supply_basketDAO = sqlSession.getMapper(Supply_BasketDAO.class);
		supply_basketDAO.deleteBasketSupply(dto);
	}

	@Override
	public void initialization(Map<Object, Object> map) {
		Supply_BasketDAO supply_basketDAO = sqlSession.getMapper(Supply_BasketDAO.class);
		supply_basketDAO.initialization(map);
	}

}
