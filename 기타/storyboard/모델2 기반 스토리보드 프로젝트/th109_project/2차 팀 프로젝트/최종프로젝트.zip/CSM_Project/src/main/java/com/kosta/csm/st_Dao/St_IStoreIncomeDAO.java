package com.kosta.csm.st_Dao;

import java.util.ArrayList;

import org.apache.ibatis.annotations.Param;

import com.kosta.csm.vo.Criteria;
import com.kosta.csm.vo.StoreincomeVO;

public interface St_IStoreIncomeDAO {
	public StoreincomeVO getSameDateSale(StoreincomeVO storeincomeVO);
	public void insertNewProduct(StoreincomeVO storeincomeVO);
	public void updatePresentProduct(StoreincomeVO storeincomeVO);
	public ArrayList<StoreincomeVO> revenuePerDay(@Param("cri") Criteria cri, @Param("m_Id") String m_Id);
	public ArrayList<StoreincomeVO> revenuePerMonth(@Param("cri") Criteria cri, @Param("m_Id") String m_Id);
	public ArrayList<StoreincomeVO> revenueBetweenDay(@Param("cri") Criteria cri, @Param("m_Id") String m_Id
			,@Param("first")  String first, @Param("last")  String last);
	public int revenuePerDayCount(String m_Id);
	public int revenuePerMonthCount(String m_Id);
	public int revenueBetweenDayCount(@Param("m_Id") String m_Id, @Param("first")  String first, @Param("last")  String last);
}
