package com.kosta.csm.st_Service;

import java.util.List;

import org.springframework.ui.Model;

import com.kosta.csm.vo.Criteria;
import com.kosta.csm.vo.TimeLineVO;

public interface St_ITimeLineService {
	
	public List<TimeLineVO> parentList(Criteria cri, Model model);
	
	public List<TimeLineVO> childList();
	
	public void writeReply(TimeLineVO vo);
	
	public void writeTimeLine(TimeLineVO vo);
	
	public void modifyTimeLine(TimeLineVO vo);
	
	public void deleteTimeLine(int t_Num);
}
