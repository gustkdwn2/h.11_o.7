package com.kosta.csm.hq_Service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.kosta.csm.hq_Dao.Hq_IMemberDAO;
import com.kosta.csm.vo.Criteria;
import com.kosta.csm.vo.CriteriaIndex;
import com.kosta.csm.vo.MemberVO;

@Service
public class Hq_MemberService implements Hq_IMemberService {

	@Autowired
	private SqlSession sqlSession;

	// 회원가입 승인
	@Override
	public List<MemberVO> approvalList(Criteria cri, Model model) {
		Hq_IMemberDAO dao = sqlSession.getMapper(Hq_IMemberDAO.class);
		model.addAttribute("count", dao.approvalListCount());
		return dao.approvalList(cri);
	}

	@Override
	public List<MemberVO> indexApprovalList(CriteriaIndex cri, Model model) {
		Hq_IMemberDAO dao = sqlSession.getMapper(Hq_IMemberDAO.class);
		model.addAttribute("m_Count", dao.indexApprovalListCount());
		return dao.indexApprovalList(cri);
	}

	@Override
	public void updateState(String m_Id, String m_Store) {
		Hq_IMemberDAO dao = sqlSession.getMapper(Hq_IMemberDAO.class);
		
		if(m_Store.equals("본사")){
			dao.updateState(m_Id);
			dao.insertGradeHq(m_Id);
		}else{
			dao.updateState(m_Id);
			dao.insertGrade(m_Id);
		}
	}

	@Override
	public void updateStates(String[] ckb) {
		Hq_IMemberDAO dao = sqlSession.getMapper(Hq_IMemberDAO.class);
		
		for (int i = 0; i < ckb.length; i++) {
			
			if(dao.selectM_Store(ckb[i]).equals("본사")){
				dao.updateState(ckb[i]);
				dao.insertGradeHq(ckb[i]);
			}else{
				dao.updateState(ckb[i]);
				dao.insertGrade(ckb[i]);
			}
		}
	}
	
	@Override
	public void mstateDelete(String[] ckb) {
		Hq_IMemberDAO dao = sqlSession.getMapper(Hq_IMemberDAO.class);
		
		for (int i = 0; i < ckb.length; i++) {
			dao.mstateDelete(ckb[i]);
		}
	}


	// 회원정보 수정

	@Override
	public List<MemberVO> memberList() {
		Hq_IMemberDAO dao = sqlSession.getMapper(Hq_IMemberDAO.class);
		return dao.memberList();
	}

	@Override
	public String modify(String m_Id) {
		Hq_IMemberDAO dao = sqlSession.getMapper(Hq_IMemberDAO.class);
		return dao.modify(m_Id);
	}

	@Override
	public String check(HttpServletRequest request, Model model) {
		System.out.println("Service check");
		Hq_IMemberDAO dao = sqlSession.getMapper(Hq_IMemberDAO.class);
		String pwd = dao.check(request.getParameter("m_Id"));
		String m_Pwd = request.getParameter("m_Pwd");
		if (pwd.equals(m_Pwd)) {
			return "redirect:/hq/member/memberModify";
		} else {
			model.addAttribute("check", 1);
			return "hq_aside.member.modify";
		}

	}

	@Override
	public String memberModify(MemberVO vo) {
		System.out.println("Service memberModify");
		Hq_IMemberDAO dao = sqlSession.getMapper(Hq_IMemberDAO.class);
		dao.memberModify(vo);
		return "redirect:/hq/member/modify";
	}

	@Override
	public String pwdModify(HttpServletRequest request, MemberVO vo) {
		System.out.println("Service pwdModify");
		Hq_IMemberDAO dao = sqlSession.getMapper(Hq_IMemberDAO.class);
		String pwd = dao.check(request.getParameter("m_Id"));
		String m_Pwd = request.getParameter("m_Pwd");
		String m_Pwd1 = request.getParameter("m_Pwd1");
		String m_Pwd2 = request.getParameter("m_Pwd2");

		if (pwd.equals(m_Pwd) && m_Pwd1.equals(m_Pwd2)) {
			if (!pwd.equals(m_Pwd1)) {
				vo.setM_Pwd(m_Pwd1);
				dao.pwdModify(vo);
				return "redirect:/hq/member/modify";
			}
		} else {
			return "hq_aside.member.pwdModify";
		}
		return "hq_aside.member.pwdModify";
	}

	@Override
	public String memberLeave(Model model, HttpServletRequest request, MemberVO vo) {
		System.out.println("Service memberLeave");
		Hq_IMemberDAO dao = sqlSession.getMapper(Hq_IMemberDAO.class);
		String pwd = dao.check(request.getParameter("m_Id"));
		String m_Pwd = request.getParameter("m_Pwd");
		if (pwd.equals(m_Pwd)) {
			dao.memberLeave(vo);
			return "redirect:/logout";
		} else {
			model.addAttribute("check", 1);
			return "hq_aside.member.memberLeave";
		}
	}

	@Override
	public MemberVO searchById() {
		Hq_IMemberDAO dao = sqlSession.getMapper(Hq_IMemberDAO.class);
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String m_Id = (String) auth.getName();
		return dao.searchById(m_Id);
	}

	@Override
	public String check() {
		Hq_IMemberDAO dao = sqlSession.getMapper(Hq_IMemberDAO.class);
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String m_Id = (String) auth.getName();
		return dao.check(m_Id);
	}

	
}
