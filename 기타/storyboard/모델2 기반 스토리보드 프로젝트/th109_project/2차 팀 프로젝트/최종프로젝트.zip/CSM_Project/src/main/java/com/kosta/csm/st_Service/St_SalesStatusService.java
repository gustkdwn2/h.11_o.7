package com.kosta.csm.st_Service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.swing.text.html.HTMLEditorKit.Parser;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.kosta.csm.st_Dao.St_ISalesStatusDAO;
import com.kosta.csm.vo.CategoryStatusVO;
import com.kosta.csm.vo.Criteria;

@Service
public class St_SalesStatusService implements St_ISalesStatusService {

	@Autowired
	private SqlSession sqlSession;
	
	@Override
	public void categoryStatus(Model model, HttpServletRequest request) {
		
		String year = request.getParameter("year");
		String month = request.getParameter("month");
		
		String day=null;
		if(year !=null && month != null){
			day = year + "-" + month;
		}
		
		St_ISalesStatusDAO dao = sqlSession.getMapper(St_ISalesStatusDAO.class);
		
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String user_id = (String)auth.getName();
		
		List<CategoryStatusVO> list;
		
		if(day == null){
			list = dao.categoryStatus(user_id);
		}else{
			list = dao.categoryStatusDay(user_id, day);
			model.addAttribute("year", year);
			model.addAttribute("month", month);
		}
		List<Integer> categoryList = new ArrayList<Integer>(); 
		
		List<String> category = new ArrayList<String>(
				Arrays.asList("간편식사", "즉석조리", "과자류", "아이스크림", "식품", "음료", "생활용품"));
		
		List<List<CategoryStatusVO>> categoryListRank = new ArrayList<List<CategoryStatusVO>>();
		
		
		// 초기화
		for(int i=0; i<7; i++){
			categoryList.add(i, 0);
		}
		
		if(!list.isEmpty()){
			for(int i=0; i<list.size(); i++){
				for(int j=0; j<category.size(); j++){
					if(list.get(i).getHp_Category().equals(category.get(j))){
						categoryList.set(j, list.get(i).getTotalAmount());
					}
				}
			}// for
		}// if
		
		if(day==null){
			for(int i=0; i<category.size(); i++){
				categoryListRank.add(i, dao.categoryStatusRank(user_id, category.get(i)));
			}
		}else{
			for(int i=0; i<category.size(); i++){
				categoryListRank.add(i, dao.categoryStatusRankDay(user_id, category.get(i), day));
			}
		}
		
		
		model.addAttribute("categoryList", categoryList);
		model.addAttribute("categoryListRank", categoryListRank);
	}

	@Override
	public void salesStatusAll(Criteria cri, Model model, HttpServletRequest request) {
		String year = request.getParameter("year");
		String month = request.getParameter("month");
		String category = request.getParameter("category");
		
		String day=null;
		if(year !=null && month != null){
			day = year + "-" + month;
		}
		
		St_ISalesStatusDAO dao = sqlSession.getMapper(St_ISalesStatusDAO.class);
		
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String user_id = (String)auth.getName();
		
		if(day == null){
			if(category == null){
				model.addAttribute("salesStatus", dao.salesStatusAll(cri, user_id));
				model.addAttribute("count", dao.salesStatusAllCount(user_id));
			}else{
				model.addAttribute("salesStatus", dao.salesStatusAllCate(cri, user_id, category));
				model.addAttribute("count", dao.salesStatusAllCountCate(user_id, category));
				model.addAttribute("category", category);
			}
		}else{
			if(category == null){
				model.addAttribute("salesStatus", dao.salesStatusAllDay(cri, user_id, day));
				model.addAttribute("count", dao.salesStatusAllDayCount(user_id, day));
				model.addAttribute("year", year);
				model.addAttribute("month", month);
			}else{
				model.addAttribute("salesStatus", dao.salesStatusAllDayCate(cri, user_id, day, category));
				model.addAttribute("count", dao.salesStatusAllDayCountCate(user_id, day, category));
				model.addAttribute("year", year);
				model.addAttribute("month", month);
				model.addAttribute("category", category);
			}
		}
		
	}

	@Override
	public void monthStatus(Model model, HttpServletRequest request) {
		String chYear = request.getParameter("year");
		
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy");
		String year = dateFormat.format(cal.getTime()).substring(0,4);
		
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String user_id = (String)auth.getName();
		
		St_ISalesStatusDAO dao = sqlSession.getMapper(St_ISalesStatusDAO.class);
		
		List<String> month = new ArrayList<String>(
				Arrays.asList("01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"));
		
		List<Integer> monthList = new ArrayList<Integer>();
		
		
		for(int i=0; i<month.size(); i++){
			if(chYear==null){
				monthList.add(i, dao.monthStatus(user_id, year+"/"+month.get(i)+"%"));
			}else{
				monthList.add(i, dao.monthStatus(user_id, chYear+"/"+month.get(i)+"%"));
				model.addAttribute("year", chYear);
			}
		}
		
		model.addAttribute("status", monthList);
	}

	@Override
	public void yearStatus(Model model) {
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy");
		String thisYear = dateFormat.format(cal.getTime()).substring(0,4);
		
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String user_id = (String)auth.getName();
		
		St_ISalesStatusDAO dao = sqlSession.getMapper(St_ISalesStatusDAO.class);
		
		List<String> year = new ArrayList<String>();
		
		for(int i=0; i<5; i++){
			year.add(i, Integer.toString((Integer.parseInt(thisYear)-(4-i))));
		}
		
		List<Integer> yearList = new ArrayList<Integer>();
		
		
		for(int i=0; i<year.size(); i++){
			yearList.add(i, dao.yearStatus(user_id, year.get(i)+"%"));
		}
		
		model.addAttribute("year", year);
		model.addAttribute("status", yearList);
	}

}
