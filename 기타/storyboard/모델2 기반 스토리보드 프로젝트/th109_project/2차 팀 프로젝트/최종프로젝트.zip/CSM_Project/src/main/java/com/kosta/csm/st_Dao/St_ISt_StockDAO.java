package com.kosta.csm.st_Dao;

import com.kosta.csm.vo.StStockVO;

public interface St_ISt_StockDAO {
	void updateDecrease(StStockVO stStockVO);//input : 감소된 재고수량기록

	StStockVO getRealStock(StStockVO stStockVO);
}
