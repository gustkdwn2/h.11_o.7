package com.kosta.csm.hq_Controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.kosta.csm.hq_Service.Hq_PersonResourceService;
import com.kosta.csm.vo.Criteria;
import com.kosta.csm.vo.EmployeeVO;

@Controller
@RequestMapping("/hq/personResource")
public class Hq_PersonResourceController {

   //////////////급여설정///////////////////////////////
   @Autowired   
   private Hq_PersonResourceService service;
   static List<EmployeeVO> list = new ArrayList<EmployeeVO>();
   ///////////////////급여설정////////////////////////////////
   @RequestMapping(value="/setPay", method=RequestMethod.GET)
   public String setPay( Model model, @RequestParam(value="target", required=false) String target,
		   				Criteria cri){
      System.out.println("/hq/personResource/setPay");
      model.addAttribute("list", service.getEmployee(cri, model));
      model.addAttribute("target", target);
      System.out.println("target:" +target );
      model.addAttribute("cri", cri);
      return "hq_aside.personResource.setPay";
   }
   
   // 급여 검색
   @RequestMapping(value="/setPaySearch")
   public String setPaySearch(Criteria cri, Model model, @RequestParam("searchType") String searchType,
		   												@RequestParam("employee") String employee,
		   												@RequestParam(value="target", required=false) String target){
	   model.addAttribute("list", service.setPaySearch(cri, model, searchType, employee));
	   model.addAttribute("target", target);
	   model.addAttribute("cri", cri);
	   model.addAttribute("searchType", searchType);
	   model.addAttribute("employee", employee);
	   return "hq_aside.personResource.setPay";
   }
   
   //급여 업데이트
   @RequestMapping(value="/setProPay", method=RequestMethod.POST)
   public String setProPay( Model model, @RequestParam(value="e_Num",required = false) Integer e_Num 
         , @RequestParam("e_Pay") Integer e_Pay,
         @RequestParam(value = "e_Position", required = false) String e_Position){
      System.out.println("/hq/personResource/setProPay");
      service.modifyPay(e_Num,e_Pay,e_Position);
      return "redirect:/hq/personResource/setPay";
   }

   /////////////////////////급여계산///////////////////////////////
   //직원급여계산
   @RequestMapping(value="/showPayPerMonth")
   public String showPayPerMonth(Criteria cri, Model model){
      System.out.println("/hq/personResource/showPayPerMonth");
      model.addAttribute("list", service.getPayPerMonth(cri, model));
      model.addAttribute("cri", cri);
      return "hq_aside.personResource.showPayPerMonth";
   }
   
   // 직원급여계산 검색
   @RequestMapping(value="/paySearch")
   public String paySearch(Criteria cri, Model model, @RequestParam("searchType") String searchType,
		   											@RequestParam("search") String search){
	   model.addAttribute("list", service.paySearch(cri, model, searchType, search));
	   model.addAttribute("cri", cri);
	   model.addAttribute("searchType", searchType);
	   model.addAttribute("search", search);
	   return "hq_aside.personResource.showPayPerMonth";
   }
   
   /////////////////////////급여계산///////////////////////////////
   //직원급여계산
   @RequestMapping(value="/showSalaryPerMonth")
   public String showSalaryPerMonth(Criteria cri, Model model){
      System.out.println("/hq/personResource/showSalaryPerMonth");
      model.addAttribute("list", service.getSalaryPerMonth(cri, model));
      model.addAttribute("cri", cri);
   return "hq_aside.personResource.showSalaryPerMonth";
   }
   
   // 직원급여검색
   @RequestMapping(value="/salarySearch")
   public String salarySearch(Criteria cri, Model model, @RequestParam("searchType") String searchType,
		   											@RequestParam("search") String search){
	   model.addAttribute("list", service.salarySearch(cri, model, searchType, search));
	   model.addAttribute("cri", cri);
	   model.addAttribute("searchType", searchType);
	   model.addAttribute("search", search);
	   return "hq_aside.personResource.showSalaryPerMonth";
   }

   /////////////////////직원/////////////////////////////////
   //직원관리
   @RequestMapping(value="/manageEmployee", method=RequestMethod.GET)
   public String manageEmployee(Criteria cri, Model model){
      System.out.println("/hq/personResource/manageEmployee");
      
      model.addAttribute("list", service.getEmployee(cri, model));
      model.addAttribute("cri", cri);
      return "hq_aside.personResource.manageEmployee";
   }  
   
   // 직원관리 - 직원검색
   @RequestMapping(value="/employeeSearch")
   public String employeeSearch(Criteria cri, Model model, @RequestParam("employee") String employee,
															@RequestParam("searchType") String searchType){
	   model.addAttribute("list", service.employeeSearch(cri, model, employee, searchType));
	   model.addAttribute("cri", cri);
	   model.addAttribute("employee", employee);
	   model.addAttribute("searchType", searchType);
	   return "hq_aside.personResource.manageEmployee";
   }
   
   //직원추가뷰로
   @RequestMapping(value="/addEmployee", method=RequestMethod.GET)
   public String addEmployee( Model model){
      System.out.println("/hq/personResource/addEmployee");
      model.addAttribute("list", list);
      model.addAttribute("check", "0");
      return "hq_aside.personResource.addEmployee";
   }

   //직원추가처리
   @RequestMapping(value="/addEndEmployee", method=RequestMethod.POST)
   public String addEndEmployee(@ModelAttribute EmployeeVO vo , Model model ,@RequestParam("month") String month,
          @RequestParam("year") String year , @RequestParam("day") String day){
      System.out.println("/hq/personResource/addEndEmployee");
      System.out.println("컨르롤러에 들어온 값들 : " + year +"/" + day + "/ " +month );
      System.out.println("컨르롤러에 들어온 값들 : " +vo.getE_Account()+ vo.getE_Name()+vo.getE_Num());
      service.addEmployee(year,month,day, list, vo);
      return "redirect:/hq/personResource/addEmployee";
   }

   //직원삭제
   @RequestMapping(value="/removeEmployee", method=RequestMethod.POST)
   public String removeEmployee(@RequestParam(value= "e_Num" ,required = false)Integer e_Num , @RequestParam(value ="targetRemove" ,required = false) Integer[] targetRemove ,Model model){
      System.out.println("/hq/personResource/removeEmployee");
      service.removeEmployee( e_Num , targetRemove);
      return "redirect:/hq/personResource/manageEmployee";
   }

   //직원수정
   @RequestMapping(value="/updateEmployee", method=RequestMethod.GET)
   public String updateEmployee(@RequestParam("e_Num")Integer e_Num, Model model){
      System.out.println("/hq/personResource/updateEmployee");
      EmployeeVO vo = service.getEmployeeOfNum(e_Num);
      model.addAttribute("vo", vo);
      model.addAttribute("year", vo.getE_StartDay().substring(0, 4));
      model.addAttribute("month", vo.getE_StartDay().substring(5, 7));
      model.addAttribute("day",  vo.getE_StartDay().substring(8, 10));
      return "hq_aside.personResource.updateEmployee";
   }

   //직원수정처리
   @RequestMapping(value="/updateProEmployee", method=RequestMethod.POST)
   public String updateProEmployee(@ModelAttribute EmployeeVO vo, Model model,@RequestParam("month") String month,
          @RequestParam("year") String year , @RequestParam("day") String day){
      System.out.println("/hq/personResource/updateProEmployee");
      service.updateEmployee(year,month,day, vo);
      return "redirect:/hq/personResource/manageEmployee";
   }

   
   @RequestMapping(value="checkMember", method=RequestMethod.POST)
   public String checkMember(@ModelAttribute EmployeeVO vo,  Model model, @RequestParam(value = "day" ,required =false) String day
         , @RequestParam(value = "month" ,required =false) String month
         , @RequestParam(value = "year" ,required =false) String year, @RequestParam(value = "fromUri" ,required =false,defaultValue ="0") String fromUri){
      System.out.println("/hq/personResource/checkMember");
      System.out.println("EmployeeVO의 M_ID : " + vo.getM_Id());
      model.addAttribute("vo", vo);   
      model.addAttribute("check", service.checkMember(vo));
      model.addAttribute("year",year);
      model.addAttribute("month", month);
      model.addAttribute("day", day);
      model.addAttribute("list", list);
      System.out.println("들어온경로: "+fromUri);
      if(fromUri.equals("addEmployee"))
         return "hq_aside.personResource.addEmployee";
      else if(fromUri.equals("updateEmployee"))
         return "hq_aside.personResource.updateEmployee";
      return "hq_aside.personResource.addEmployee";
   }

   
   //////////////////////////근무기간/////////////////////////////////////////////////////////////
   //출결관리
   @RequestMapping(value="/showTimePart", method=RequestMethod.GET)
   public String showTimePart(Criteria cri, Model model){
      System.out.println("/hq/personResource/showTimePart");
      model.addAttribute("list",service.getWorkingTime(cri, model));
      model.addAttribute("cri", cri);
      return "hq_aside.personResource.showTimePart";
   }
   
   //출결관리 검색
   @RequestMapping(value="/timePartSearch")
   public String timePartSearch(Criteria cri, Model model, @RequestParam("searchType") String searchType,
															@RequestParam("search") String search){
	   model.addAttribute("list", service.timePartSearch(cri, model, searchType, search));
	   model.addAttribute("cri", cri);
	   model.addAttribute("searchType", searchType);
	   model.addAttribute("search", search);
	   return "hq_aside.personResource.showTimePart";
   }
   
   
}
