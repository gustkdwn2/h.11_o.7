package com.kosta.csm.st_Dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.kosta.csm.vo.Criteria;
import com.kosta.csm.vo.ProductVO;
import com.kosta.csm.vo.St_Stock_ProductVO;

public interface St_ISt_Stock_ProductDAO {
	public int countList(String m_Id);
	public List<St_Stock_ProductVO> list(@Param("cri") Criteria cri, @Param("m_Id") String m_Id);
	public List<ProductVO> stockListDetail(@Param("cri") Criteria cri, @Param("m_Id") String m_Id);
	public void deleteProduct(String hp_Code);
	
	
	// 판매 상품 등록
	public List<ProductVO> productList(Criteria cri);
	public int productListCount();
	public int productFilter(@Param("m_Id") String m_Id, @Param("hp_Code") String hp_Code);
	public void insertStStock(@Param("m_Id") String m_Id, @Param("hp_Code") String hp_Code);
	
	// 판매 상품 검색
	public List<ProductVO> productRegSearch_hp_Code(@Param("cri") Criteria cri, @Param("productSearch") String productSearch);
	public List<ProductVO> productRegSearch_hp_Name(@Param("cri") Criteria cri, @Param("productSearch") String productSearch);
	public int productRegSearchCount_hp_Name(String productSearch);
	public int search_CategoryCount(String category);
	public List<ProductVO> search_Category(@Param("cri") Criteria cri, @Param("category") String category);

	
	// 매장 재고 검색
	public List<St_Stock_ProductVO> productStockSearch_hp_Code(@Param("cri") Criteria cri, @Param("m_Id") String m_Id, @Param("productSearch") String productSearch);
	public List<St_Stock_ProductVO> productStockSearch_hp_Name(@Param("cri") Criteria cri, @Param("m_Id") String m_Id, @Param("productSearch") String productSearch);
	public int productStockSearchCount_hp_Name(@Param("m_Id") String m_Id, @Param("productSearch") String productSearch);
	public Object search_StockCategoryCount(@Param("m_Id") String m_Id, @Param("category") String category);
	public List<St_Stock_ProductVO> search_StockCategory(@Param("cri") Criteria cri, @Param("m_Id") String m_Id, @Param("category") String category);
	public List<ProductVO> productStockSearch_hp_Code_Detail(@Param("cri") Criteria cri, @Param("m_Id") String m_Id, @Param("productSearch") String productSearch);
	public List<ProductVO> productStockSearch_hp_Name_Detail(@Param("cri") Criteria cri, @Param("m_Id") String m_Id, @Param("productSearch") String productSearch);
	public List<ProductVO> search_StockCategory_Detail(@Param("cri") Criteria cri, @Param("m_Id") String m_Id, @Param("category") String category);
	
	
	
	
	
	

	
}
