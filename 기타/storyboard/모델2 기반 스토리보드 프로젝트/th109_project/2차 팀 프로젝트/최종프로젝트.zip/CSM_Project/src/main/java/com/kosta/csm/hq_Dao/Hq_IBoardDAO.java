package com.kosta.csm.hq_Dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.kosta.csm.vo.BoardVO;
import com.kosta.csm.vo.Criteria;

public interface Hq_IBoardDAO {

	public int boardListCount();
	
	public List<BoardVO> boardListPage(Criteria cri);

	public void boardInsert(BoardVO vo);
	
	public List<BoardVO> boardContent(int b_Num);
	
	public void boardModify(BoardVO vo);
	
	public void boardDelete(int b_Num);
	
	public void updateReadCount(int b_Num);
	
	//글번호 검색
	public List<BoardVO> boardSearch1(@Param("cri") Criteria cri, @Param("boardSearch") int boardSearch);
	//글제목 검색
	public List<BoardVO> boardSearch2(@Param("cri") Criteria cri, @Param("boardSearch") String boardSearch);
	public int boardSearch2Count(String boardSearch);
}
