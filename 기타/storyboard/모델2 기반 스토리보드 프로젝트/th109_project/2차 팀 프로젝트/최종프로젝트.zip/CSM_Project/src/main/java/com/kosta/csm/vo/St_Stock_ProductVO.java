package com.kosta.csm.vo;

public class St_Stock_ProductVO {
	private String m_Id;
	private String hp_Code;
	private int st_Amount;
	private String hp_Name;
	private int hp_Mprice;
	private int hp_Cprice;
	private String hp_Path;

	public St_Stock_ProductVO() {
	}

	public St_Stock_ProductVO(String m_Id, String hp_Code, int st_Amount, String hp_Name, int hp_Mprice, int hp_Cprice,
			String hp_Path) {
		this.m_Id = m_Id;
		this.hp_Code = hp_Code;
		this.st_Amount = st_Amount;
		this.hp_Name = hp_Name;
		this.hp_Mprice = hp_Mprice;
		this.hp_Cprice = hp_Cprice;
		this.hp_Path = hp_Path;
	}

	// getter / setter
	public String getM_Id() {
		return m_Id;
	}

	public void setM_Id(String m_Id) {
		this.m_Id = m_Id;
	}

	public String getHp_Code() {
		return hp_Code;
	}

	public void setHp_Code(String hp_Code) {
		this.hp_Code = hp_Code;
	}

	public int getSt_Amount() {
		return st_Amount;
	}

	public void setSt_Amount(int st_Amount) {
		this.st_Amount = st_Amount;
	}

	public String getHp_Name() {
		return hp_Name;
	}

	public void setHp_Name(String hp_Name) {
		this.hp_Name = hp_Name;
	}

	public int getHp_Mprice() {
		return hp_Mprice;
	}

	public void setHp_Mprice(int hp_Mprice) {
		this.hp_Mprice = hp_Mprice;
	}

	public int getHp_Cprice() {
		return hp_Cprice;
	}

	public void setHp_Cprice(int hp_Cprice) {
		this.hp_Cprice = hp_Cprice;
	}

	public String getHp_Path() {
		return hp_Path;
	}

	public void setHp_Path(String hp_Path) {
		this.hp_Path = hp_Path;
	}

}
