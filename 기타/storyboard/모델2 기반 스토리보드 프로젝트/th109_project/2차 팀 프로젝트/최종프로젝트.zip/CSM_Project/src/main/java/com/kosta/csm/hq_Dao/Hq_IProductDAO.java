package com.kosta.csm.hq_Dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.kosta.csm.vo.Criteria;
import com.kosta.csm.vo.ProductVO;

public interface Hq_IProductDAO {
	public List<ProductVO> list(Criteria cri);
	public void insert(ProductVO vo);
	public void insertHq_Stock(String hp_Code);
	
	public List<ProductVO> detail(String hp_Code);
	public void delete(String hp_Code);
	public ProductVO selectAll(String hp_Code);
	public void modify(ProductVO vo);
	public int listCount();
	public int duplicationCheck(String hp_Code);
	public void stateChange_0(String hp_Code);
	public int susListCount();
	public List<ProductVO> susList(Criteria cri);
	public void stateChange_1(String hp_Code);
	
	public List<ProductVO> productListSearch_hp_Code(@Param("cri") Criteria cri, @Param("productSearch") String productSearch);
	
	public List<ProductVO> productListSearch_hp_Name(@Param("cri") Criteria cri, @Param("productSearch") String productSearch);
	public int productListSearchCount_hp_Name(String productSearch);
	
	public int search_CategoryCount(String category);
	public List<ProductVO> search_Category(@Param("cri") Criteria cri, @Param("category") String category);
	
	public List<ProductVO> productSusListSearch_hp_Code(@Param("cri") Criteria cri, @Param("productSearch") String productSearch);
	
	
	public int productSusListSearchCount_hp_Name(String productSearch);
	public List<ProductVO> productSusListSearch_hp_Name(@Param("cri") Criteria cri, @Param("productSearch") String productSearch);
	
	public int searchSus_CategoryCount(String category);
	public List<ProductVO> searchSus_Category(@Param("cri") Criteria cri, @Param("category") String category);
	
	
}
