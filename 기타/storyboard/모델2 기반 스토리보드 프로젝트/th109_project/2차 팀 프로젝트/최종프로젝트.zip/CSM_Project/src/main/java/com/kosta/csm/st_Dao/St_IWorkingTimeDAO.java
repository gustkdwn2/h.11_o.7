package com.kosta.csm.st_Dao;

import org.apache.ibatis.annotations.Param;

import com.kosta.csm.vo.StWorkingEmployee;

public interface St_IWorkingTimeDAO {

	Integer checkFirstWorkingEmployee(@Param("e_Num") Integer e_Num, @Param("m_Id") String m_Id);

	void enrollStartTime(Integer e_Num);


	void enrollLastTime(Integer e_Num);

	StWorkingEmployee checkWorkingEmployee(@Param("e_Num") Integer e_Num, @Param("m_Id") String m_Id);

	StWorkingEmployee checkWorkedEmployee(@Param("e_Num") Integer e_Num, @Param("m_Id") String m_Id);


}
