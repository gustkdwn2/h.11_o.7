package com.kosta.csm.hq_Service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.kosta.csm.hq_Dao.Hq_IHeadExpendDAO;
import com.kosta.csm.hq_Dao.Hq_IIncomeDAO;
import com.kosta.csm.hq_Dao.Hq_IRevenueDAO;
import com.kosta.csm.hq_Dao.Hq_IWorkingTimeDAO;
import com.kosta.csm.vo.Criteria;
import com.kosta.csm.vo.HeadExpendPerMonth;
import com.kosta.csm.vo.HeadExpendVO;
import com.kosta.csm.vo.HqIncome;
import com.kosta.csm.vo.HqIncomeOfMonth;
import com.kosta.csm.vo.HqRevenue;
import com.kosta.csm.vo.HqRevenueMore;
import com.kosta.csm.vo.PayVO;
import com.kosta.csm.vo.WorkingTimeMore;

@Service
public class Hq_AccountingService implements Hq_IAccountingService {

   @Autowired
   private SqlSession sqlSession;

   public List<HeadExpendPerMonth> getExpendPerMonth(Criteria cri, Model model) {
      System.out.println("List<HeadExpendPerMonth> getExpendPerMonth() ");
      Hq_IHeadExpendDAO dao = sqlSession.getMapper(Hq_IHeadExpendDAO.class);
      model.addAttribute("count", dao.HeadExpendPerMonthCount());
      return dao.HeadExpendPerMonth(cri);
   }

   public void removeOfMonth(String yearAndMonth) {
      // TODO Auto-generated method stub
      System.out.println("removeOfMonth(String yearAndMonth)    parameter : " + yearAndMonth);

      Hq_IHeadExpendDAO dao = sqlSession.getMapper(Hq_IHeadExpendDAO.class);
      dao.removeOfMonth(yearAndMonth);
   }

   public List<HeadExpendVO> getExpendOfMonth(Criteria cri, Model model, String he_Date) {
      // TODO Auto-generated method stub
      System.out.println("List<HeadExpendVO> getExpendOfMonth(String he_Date)     parameter :  " + he_Date);
      Hq_IHeadExpendDAO dao = sqlSession.getMapper(Hq_IHeadExpendDAO.class);
      model.addAttribute("count", dao.HeadExpendOfMonthCount(he_Date));
      return dao.HeadExpendOfMonth(cri, he_Date);

   }

   public void removeOfNum(Integer he_Num) {
      // TODO Auto-generated method stub
      System.out.println("removeOfNum(String yearAndMonth)    parameter : " + he_Num);
      Hq_IHeadExpendDAO dao = sqlSession.getMapper(Hq_IHeadExpendDAO.class);
      dao.removeOfNum(he_Num);
   }

   public void addTempExpend(String year, String month, String day, List<HeadExpendVO> list, HeadExpendVO vo) {
      // TODO Auto-generated method stub
      if (vo.getHe_Expend() != 0) {
         if (month.length() == 1)
            month = "0" + month;
         if (day.length() == 1)
            day = "0" + day;
         vo.setHe_Date(year + "/" + month + "/" + day);
         if (vo.getHe_Expend() != 0)
            list.add(vo);

      } else
         System.out.println("값이 0이므로 추가x");
   }

   public void addExpendList(List<HeadExpendVO> list) {
      // TODO Auto-geSnerated method stub
      System.out.println("addExpendList(List<HeadExpendVO> list)    parameter  list.size: " + list.size());

      Hq_IHeadExpendDAO dao = sqlSession.getMapper(Hq_IHeadExpendDAO.class);
      for (int a = 0; a < list.size(); a++)
         dao.addExpend(list.get(a));
      System.out.println("success query!");
      System.out.println("add size" + list.size());
      list.clear();
      System.out.println("size after clear and all add" + list.size());
   }

   public HeadExpendVO getExpendOfNum(Integer he_Num) {
      // TODO Auto-generated method stub
      System.out.println(" getExpendOfNum(Integer he_Num) )    parameter  : " + he_Num);

      Hq_IHeadExpendDAO dao = sqlSession.getMapper(Hq_IHeadExpendDAO.class);
      System.out.println("get expend (content): " + dao.getExpendOfNum(he_Num).getHe_Content());
      return dao.getExpendOfNum(he_Num);
   }

   public void updateExpend(String year, String month, String day, HeadExpendVO vo) {
      // TODO Auto-generated method stub
      System.out.println(" updateExpend(HeadExpendVO vo)  parameter vo읠부(he_num): " + vo.getHe_Num());
      Hq_IHeadExpendDAO dao = sqlSession.getMapper(Hq_IHeadExpendDAO.class);

      if (vo.getHe_Expend() != 0) {
         if (month.length() == 1)
            month = "0" + month;
         if (day.length() == 1)
            day = "0" + day;
         vo.setHe_Date(year + "/" + month + "/" + day);
         dao.updateExpend(vo);
      } else
         System.out.println("값이 0이므로 추가x");

      System.out.println("query success!");
   }

   public HeadExpendPerMonth getExpendPayOfMonth(String he_Date) {
      // TODO Auto-generated method stub
      System.out.println(" List<HeadExpendPerMonth> getExpendPayOfMonth(String he_Date)  parameter :  " + he_Date);
      Hq_IWorkingTimeDAO dao = sqlSession.getMapper(Hq_IWorkingTimeDAO.class);
      return dao.getExpendPayOfMonth(he_Date);
   }

   public List<HqIncome> incomePerMonth(Criteria cri, Model model) {
      // TODO Auto-generated method stub
      System.out.println(" List<HqIncomePerMonth> incomePerMonth()");
      Hq_IIncomeDAO dao = sqlSession.getMapper(Hq_IIncomeDAO.class);
      model.addAttribute("count", dao.incomePerMonthCount());
      return dao.incomePerMonth(cri);
   }

   public List<HqIncomeOfMonth> incomeOfMonthPerStore(Criteria cri, Model model, String income_Date) {
      // TODO Auto-generated method stub
      System.out.println(" List<HqIncome> incomeOfMonthPerStore(String income_Date)   parameter: " + income_Date);
      Hq_IIncomeDAO dao = sqlSession.getMapper(Hq_IIncomeDAO.class);
      model.addAttribute("count", dao.incomeOfMonthPerStoreCount(income_Date));
      return dao.incomeOfMonthPerStore(cri, income_Date);
   }

   // 달별 수익합
   public List<HqIncomeOfMonth> incomeOfMonthPerDay(Criteria cri, Model model, String income_Date) {
      // TODO Auto-generated method stub
      System.out.println(" List<HqIncome> incomeOfMonthPerDay(String income_Date)   parameter: " + income_Date);
      Hq_IIncomeDAO dao = sqlSession.getMapper(Hq_IIncomeDAO.class);
      model.addAttribute("count", dao.incomeOfMonthPerDayCount(income_Date));
      return dao.incomeOfMonthPerDay(cri, income_Date);

   }

   // 매장내 일자별 수익합
   public List<HqIncomeOfMonth> incomePerStoreDetail(Criteria cri, Model model, String m_Id, String income_Date) {
      System.out.println(
            " List<HqIncomeOfMonth> incomePerStoreDetail(String m_Id)   parameter: " + m_Id + "/  " + income_Date);
      Hq_IIncomeDAO dao = sqlSession.getMapper(Hq_IIncomeDAO.class);
      model.addAttribute("count", dao.incomePerStoreDetailCount(m_Id, income_Date));
      return dao.incomePerStoreDetail(cri, m_Id, income_Date);
   }

   // 같은날짜내 매장별 수익합
   public List<HqIncomeOfMonth> incomePerDayDetail(Criteria cri, Model model, String income_Date) {
      // TODO Auto-generated method stub
      System.out
            .println(" List<HqIncomeOfMonth> incomePerDayDetail(String income_Date)    parameter: " + income_Date);
      Hq_IIncomeDAO dao = sqlSession.getMapper(Hq_IIncomeDAO.class);
      model.addAttribute("count", dao.incomePerDayDetailCount(income_Date));
      return dao.incomePerDayDetail(cri, income_Date);
   }

   // 같은날짜내 매장별 모든 수익들
   public List<HqIncomeOfMonth> allOfdayIncome(String income_Date) {
      // TODO Auto-generated method stub
      System.out.println(" List<HqIncomeOfMonth> allOfdayIncome(String income_Date)    parameter: " + income_Date);
      Hq_IIncomeDAO dao = sqlSession.getMapper(Hq_IIncomeDAO.class);
      System.out.println("query end    get size : " + dao.allOfdayIncome(income_Date).size());
      return dao.allOfdayIncome(income_Date);
   }

   // 같은 월과 매장내 모든 수익들
   public List<HqIncomeOfMonth> allOfStoreMonthIncome(String income_Date, String m_Id) {
      System.out.println(
            " List<HqIncomeOfMonth> allOfStoreMonthIncome(String m_Id)   parameter: " + m_Id + "/  " + income_Date);
      Hq_IIncomeDAO dao = sqlSession.getMapper(Hq_IIncomeDAO.class);
      System.out.println("query end    get size : " + dao.allOfStoreMonthIncome(m_Id, income_Date).size());
      return dao.allOfStoreMonthIncome(m_Id, income_Date);
   }

   public List<HqRevenue> getSumRevenuePerMonth(Criteria cri, Model model) {
      // TODO Auto-generated method stub
      System.out.println(" List<HqIncomeOfMonth> getSumRevenuePerMonth()");
      Hq_IRevenueDAO dao = sqlSession.getMapper(Hq_IRevenueDAO.class);
      model.addAttribute("count", dao.getSumRevenuePerMonthCount());
      return dao.getSumRevenuePerMonth(cri);
   }

   public List<HqRevenueMore> getRevenueMore(Criteria cri, Model model) {
      // TODO Auto-generated method stub
      System.out.println(" List<HqRevenueMore> getRevenueMore()");
      Hq_IRevenueDAO dao = sqlSession.getMapper(Hq_IRevenueDAO.class);
      model.addAttribute("count", dao.getRevenueMoreCount());
      return dao.getRevenueMore(cri);
   }

   @Override
   public List<HqRevenue> revenueSearch(Criteria cri, Model model, HttpServletRequest request) {
      Hq_IRevenueDAO dao = sqlSession.getMapper(Hq_IRevenueDAO.class);
      String date = request.getParameter("year") + "/" + request.getParameter("month");
      model.addAttribute("count", dao.revenueSearchCount(date));
      model.addAttribute("year", request.getParameter("year"));
      model.addAttribute("month", request.getParameter("month"));
      return dao.revenueSearch(cri, date);
   }

   @Override
   public List<HqIncome> incomeSearch(Criteria cri, Model model, HttpServletRequest request) {
      Hq_IIncomeDAO dao = sqlSession.getMapper(Hq_IIncomeDAO.class);
      String date = request.getParameter("year") + "/" + request.getParameter("month");
      model.addAttribute("count", dao.incomeSearchCount(date));
      model.addAttribute("year", request.getParameter("year"));
      model.addAttribute("month", request.getParameter("month"));
      return dao.incomeSearch(cri, date);
   }

   @Override
   public List<HeadExpendPerMonth> expendSearch(Criteria cri, Model model, HttpServletRequest request) {
      Hq_IHeadExpendDAO dao = sqlSession.getMapper(Hq_IHeadExpendDAO.class);
      String date = request.getParameter("year") + "/" + request.getParameter("month");
      model.addAttribute("count", dao.expendSearchCount(date));
      model.addAttribute("year", request.getParameter("year"));
      return dao.expendSearch(cri, date);
   }

}