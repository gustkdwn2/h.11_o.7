package com.kosta.csm.hq_Dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.kosta.csm.vo.Criteria;
import com.kosta.csm.vo.HqStockList;
import com.kosta.csm.vo.HqStockVO;
import com.kosta.csm.vo.ProductVO;

public interface Hq_IStockDAO {
	public List<HqStockList> stockList(Criteria cri);
	public List<ProductVO> stockListDetail(Criteria cri);
	public void modify(@Param("hp_Code") String hp_Code, @Param("hp_Amount") int hp_Amount);
	public int stockListCount();
	public List<HqStockList> stockListSearch_hp_Code(@Param("cri") Criteria cri, @Param("productSearch") String productSearch);
	public List<HqStockList> stockListSearch_hp_Name(@Param("cri") Criteria cri, @Param("productSearch") String productSearch);
	public int stockListSearchCount_hp_Name(String productSearch);
	public List<ProductVO> stockListSearchDetail_hp_Code(@Param("cri") Criteria cri, @Param("productSearch") String productSearch);
	public List<ProductVO> stockListSearchDetail_hp_Name(@Param("cri") Criteria cri, @Param("productSearch") String productSearch);
	public HqStockList stockModifyView(String hp_Code);
	
}
