package com.kosta.csm.hq_Dao;

import org.apache.ibatis.annotations.Param;

public interface Hq_ISalesStatusDAO {

	int monthStatus(@Param("user_id") String user_id, @Param("date") String date);

	Integer yearStatus(@Param("user_id") String user_id, @Param("date") String date);

}
