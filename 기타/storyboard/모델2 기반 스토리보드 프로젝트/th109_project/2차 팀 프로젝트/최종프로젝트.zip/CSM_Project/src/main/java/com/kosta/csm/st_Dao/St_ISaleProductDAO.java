package com.kosta.csm.st_Dao;

import com.kosta.csm.vo.SaleProduct;

public interface St_ISaleProductDAO {
	public SaleProduct getSale(SaleProduct saleProductVO);
}
