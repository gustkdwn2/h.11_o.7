package com.kosta.csm.st_Controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.kosta.csm.st_Service.St_ISalesStatusService;
import com.kosta.csm.vo.Criteria;

@Controller
@RequestMapping("/st/salesStatus")
public class St_SalesStatusController {
	
	@Autowired
	private St_ISalesStatusService service;
	
	@RequestMapping(value="/categoryStatus")
	public String categoryStatus(Model model, HttpServletRequest request){
		service.categoryStatus(model, request);
		
		return "st_aside.salesStatus.categoryStatus";
	}
	
	@RequestMapping(value="/salesStatusAll")
	public String salesStatus(Criteria cri, Model model, HttpServletRequest request){
		
		service.salesStatusAll(cri, model, request);
		model.addAttribute("cri", cri);
		
		return "st_aside.salesStatus.salesStatusAll";
	}
	
	@RequestMapping(value="/monthStatus")
	public String monthStatus(Model model, HttpServletRequest request){
		
		service.monthStatus(model, request);
		
		return "st_aside.salesStatus.monthStatus";
	}
	
	@RequestMapping(value="/yearStatus")
	public String yearStatus(Model model){
		
		service.yearStatus(model);
		
		return "st_aside.salesStatus.yearStatus";
	}
}
