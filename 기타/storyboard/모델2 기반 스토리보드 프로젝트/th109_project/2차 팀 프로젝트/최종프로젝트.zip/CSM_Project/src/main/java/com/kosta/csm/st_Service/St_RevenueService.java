package com.kosta.csm.st_Service;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.kosta.csm.st_Dao.St_IAllRevenueDAO;
import com.kosta.csm.st_Dao.St_ISaleAboutPriceDAO;
import com.kosta.csm.st_Dao.St_IStoreExpendDAO;
import com.kosta.csm.st_Dao.St_IStoreIncomeDAO;
import com.kosta.csm.vo.AllRevenue;
import com.kosta.csm.vo.Criteria;
import com.kosta.csm.vo.SaleAboutPrice;
import com.kosta.csm.vo.StoreExpendVO;
import com.kosta.csm.vo.StoreincomeVO;

@Service
public class St_RevenueService implements St_IRevenueService{
	@Autowired
	private SqlSession sqlSession;

	// 판매내역
	public ArrayList<SaleAboutPrice> saleList(Criteria cri, Model model) {
		System.out.println("*St_RevenueService :   ArrayList<SaleAboutPrice> saleList(HttpServletRequest request)");
		St_ISaleAboutPriceDAO st_ISaleAboutPriceDAO = sqlSession.getMapper(St_ISaleAboutPriceDAO.class);
		ArrayList<SaleAboutPrice> list;
		
		//로그인한 id값 구함
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String m_Id = (String)auth.getName();
		
		list = st_ISaleAboutPriceDAO.saleList(cri, m_Id);
		model.addAttribute("count", st_ISaleAboutPriceDAO.saleListCount(m_Id));
		return list;
	}

	// 판매내역 기간별
	public ArrayList<SaleAboutPrice> saleListBetweenDay(Criteria cri, Model model, String First, String Last) {
		System.out.println("*St_RevenueService :  saleListBetweenDay(HttpServletRequest request, String First, String Last)"
				+ "   parameters:" + First +","+ Last );
		St_ISaleAboutPriceDAO st_ISaleAboutPriceDAO = sqlSession.getMapper(St_ISaleAboutPriceDAO.class);
		ArrayList<SaleAboutPrice> list;
		
		//로그인한 id값 구함
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String m_Id = (String)auth.getName();
		
		list = st_ISaleAboutPriceDAO.saleListBetweenDay(cri, m_Id,First, Last);
		model.addAttribute("count", st_ISaleAboutPriceDAO.saleListBetweenDayCount(m_Id, First, Last));
		return list;
	}

	// 판매상세내역
	public ArrayList<SaleAboutPrice> saleDetail(Criteria cri, Model model, Integer s_Group) {
		System.out.println("*St_RevenueService :   ArrayList<SaleAboutPrice> saleDetail(HttpServletRequest request,In"
				+ "teger s_Group)  parameters :  " +s_Group);
		System.out.println("상세정보표시될 s_Group: " + s_Group);
		St_ISaleAboutPriceDAO st_ISaleAboutPriceDAO = sqlSession.getMapper(St_ISaleAboutPriceDAO.class);
		
		//로그인한 id값 구함
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String m_Id = (String)auth.getName();
				
		ArrayList<SaleAboutPrice> list;
		list = st_ISaleAboutPriceDAO.saleDetail(cri, m_Id, s_Group);
		model.addAttribute("count", st_ISaleAboutPriceDAO.saleDetailCount(m_Id, s_Group));
		
		return list;
	}

	// 일별 매장수익
	public ArrayList<StoreincomeVO> Revenue(Criteria cri, Model model) {
		System.out.println("*St_RevenueService :   ArrayList<StoreincomeVO> Revenue(HttpServletRequest request)");
		St_IStoreIncomeDAO st_IStoreIncomeDAO = sqlSession.getMapper(St_IStoreIncomeDAO.class);
		ArrayList<StoreincomeVO> list = new  ArrayList<StoreincomeVO>();
		
		//로그인한 id값 구함
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String m_Id = (String)auth.getName();
		
		list = st_IStoreIncomeDAO.revenuePerDay(cri, m_Id);
		model.addAttribute("count", st_IStoreIncomeDAO.revenuePerDayCount(m_Id));
		return list;
	}

	// 월별 매장수익
	public ArrayList<StoreincomeVO> revenuePerMonth(Criteria cri, Model model) {
		System.out.println("*St_RevenueService :  ArrayList<StoreincomeVO> revenuePerMonth(HttpServletRequest request)");
		St_IStoreIncomeDAO st_IStoreIncomeDAO = sqlSession.getMapper(St_IStoreIncomeDAO.class);
		ArrayList<StoreincomeVO> list = new  ArrayList<StoreincomeVO>();
		
		//로그인한 id값 구함
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String m_Id = (String)auth.getName();

		list = st_IStoreIncomeDAO.revenuePerMonth(cri, m_Id);
		model.addAttribute("count", st_IStoreIncomeDAO.revenuePerMonthCount(m_Id));
		return list;
	}

	// 기간별 매장수익
	public ArrayList<StoreincomeVO> revenueBetweenDay(Criteria cri, Model model, String First, String Last) {
		System.out.println("*St_RevenueService :  revenueBetweenDay(HttpServletRequest reques"
				+ "t, String First, String Last) parameters :" 
				+First+","+Last );
		St_IStoreIncomeDAO st_IStoreIncomeDAO = sqlSession.getMapper(St_IStoreIncomeDAO.class);
		ArrayList<StoreincomeVO> list;
		
		//로그인한 id값 구함
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String m_Id = (String)auth.getName();
		
		
		if(First.length() == 8) 	First =  First.substring(0,4) + "/" + First.substring(4,6) +"/"+ First.substring(6,8); 
		else if(First.length()<8) First="0000/00/00";
		else 						First ="9999/12/32";
		if(Last.length() == 8) 		Last =  Last.substring(0,4) + "/" + Last.substring(4,6) +"/"+ Last.substring(6,8); 
		else if(Last.length()<8)  Last="0000/00/00";
		else 						Last ="9999/12/32";
		System.out.println("db에 맞게 변형된 First:" + First);
		System.out.println("db에 맞게 변형된 Last:" + Last);
		
		list = st_IStoreIncomeDAO.revenueBetweenDay(cri, m_Id, First, Last);
		model.addAttribute("count", st_IStoreIncomeDAO.revenueBetweenDayCount(m_Id, First, Last));
		
		return list;
	}
	
	public void addExpend(HttpServletRequest request,  String year, String month, String day, Integer se_Expend, String se_Content) {
		// TODO Auto-generated method stub
		System.out.println("*St_RevenueService :  addExpend(HttpServletRequest request, String se_Date, Integer se_Expend, String se_Content)"
				+ " parameters :  " + year+ month+day+"," + se_Expend +"," + se_Content );
		St_IStoreExpendDAO st_IStoreIncomeDAO = sqlSession.getMapper(St_IStoreExpendDAO.class);

		if(month.length()==1)
			month = "0" + month;
		if(day.length()==1)
			day = "0" + day;
		String se_Date = year + "/"+ month +"/"+ day;
		System.out.println("날짜 하나로합친 se_Date: " + se_Date);
		
		//로그인 id 획득
		HttpSession session = request.getSession();
		SecurityContext value = (SecurityContext) session.getAttribute("SPRING_SECURITY_CONTEXT");
		Authentication authentication = value.getAuthentication();
		String m_Id = authentication.getName();
		
		//지출내역 설정 
		StoreExpendVO storeExpendVO = new StoreExpendVO();
		storeExpendVO.setM_Id(m_Id);
		storeExpendVO.setSe_Date(se_Date);
		storeExpendVO.setSe_Expend(se_Expend);
		storeExpendVO.setSe_Content(se_Content);
		System.out.println("set end storeExpendVO");
		st_IStoreIncomeDAO.addExpend(storeExpendVO); 
		System.out.println("success query!");
		System.out.println();
	} 

	public List<StoreExpendVO> getStoreExpend(Criteria cri, Model model, List<StoreExpendVO> expendList) {
		// TODO Auto-generated method stub
		System.out.println("*St_RevenueService :  ArrayList<StoreExpendVO> getStoreExpend(HttpServletRequest request)");
		St_IStoreExpendDAO st_IStoreExpendDAO = sqlSession.getMapper(St_IStoreExpendDAO.class);
	
		//로그인 id 획득
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String m_Id = (String)auth.getName();
		
		expendList = st_IStoreExpendDAO.getStoreExpend(cri, m_Id);
		model.addAttribute("count", st_IStoreExpendDAO.getStoreExpendCount(m_Id));
		return expendList;
	}
	

	//삭제후 삭제된결과 가저옴
	public List<StoreExpendVO> removeExpend(Integer se_Num , List<StoreExpendVO> listBeforeRemove) {
		// TODO Auto-generated method stub
		System.out.println("*St_RevenueService : removeExpend(Integer se_num)   pqrameters: " + se_Num);
		St_IStoreExpendDAO st_IStoreExpendDAO = sqlSession.getMapper(St_IStoreExpendDAO.class);
		
		st_IStoreExpendDAO.removeExpend(se_Num);//삭제
		System.out.println("success query" );
		//보여주는 list에서도 삭제된 내용 적용
		for(int a =0; a< listBeforeRemove.size(); a++){
			System.out.println(listBeforeRemove.get(a).getSe_Num());
			if(listBeforeRemove.get(a).getSe_Num() == se_Num)
				listBeforeRemove.remove(a);
		}

		System.out.println();
		return listBeforeRemove;
	}

	public  List<StoreExpendVO> expendBetweenDay(HttpServletRequest request, List<StoreExpendVO> expendList, String First, String Last) {
		System.out.println("*St_RevenueService :  expendBetweenDay(HttpServletRequest reques"
				+ "t, String First, String Last) parameters :" 
				+First+","+Last );
		St_IStoreExpendDAO st_IStoreExpendDAO = sqlSession.getMapper(St_IStoreExpendDAO.class);

		//로그인한 id값 구함
		HttpSession session = request.getSession();
		SecurityContext value = (SecurityContext) session.getAttribute("SPRING_SECURITY_CONTEXT");
		Authentication authentication = value.getAuthentication();
		String m_Id = authentication.getName();
		System.out.println("m_id:" + m_Id);
		System.out.println("First:" + First);
		System.out.println(" Last:" + Last);
		
		//날짜범위 틀리면 최대나 최소값으로
		if(First.length() == 8) 	First =  First.substring(0,4) + "/" + First.substring(4,6) +"/"+ First.substring(6,8); 
		else if(First.length()<8) First="0000/00/00";
		else 						First ="9999/12/32";
		if(Last.length() == 8) 		Last =  Last.substring(0,4) + "/" + Last.substring(4,6) +"/"+ Last.substring(6,8); 
		else if(Last.length()<8)  Last="0000/00/00";
		else 						Last ="9999/12/32";
		System.out.println("db에 맞게 변형된 First:" + First);
		System.out.println("db에 맞게 변형된 Last:" + Last);
		
		expendList = st_IStoreExpendDAO.expendBetweenDay(m_Id, First, Last);
		System.out.println("query success");
		System.out.println("get content num : " + expendList.size());
		System.out.println();
		return expendList;
	}

	public ArrayList<AllRevenue> allRevenue(Criteria cri, Model model) {
		// TODO Auto-generated method stub	
		System.out.println("*St_RevenueService :  allRevenue(HttpServletRequest request)");
		
		St_IAllRevenueDAO st_IAllReavenueDAO = sqlSession.getMapper(St_IAllRevenueDAO.class);
		ArrayList<AllRevenue> list;
		
		//로그인한 id값 구함
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String m_Id = (String)auth.getName();
		
		list = st_IAllReavenueDAO.allRevenue(cri, m_Id);
		model.addAttribute("count", st_IAllReavenueDAO.allRevenueCount(m_Id));
		
		return list;
	}

	public ArrayList<AllRevenue> detailRevenue(Criteria cri, Model model, String s_Date) {
		// TODO Auto-generated method stub
		System.out.println("*St_RevenueService :  detailRevenue(HttpServletRequest request,"
				+ " String s_Date) paremeters : " + s_Date);
		St_IAllRevenueDAO st_IAllReavenueDAO = sqlSession.getMapper(St_IAllRevenueDAO.class);
		ArrayList<AllRevenue> list;
		
		//로그인한 id값 구함
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String m_Id = (String)auth.getName();
		
		list = st_IAllReavenueDAO.detailRevenue(cri, m_Id, s_Date);
		model.addAttribute("count", st_IAllReavenueDAO.detailRevenueCount(m_Id, s_Date));
		return list;
	}

}





