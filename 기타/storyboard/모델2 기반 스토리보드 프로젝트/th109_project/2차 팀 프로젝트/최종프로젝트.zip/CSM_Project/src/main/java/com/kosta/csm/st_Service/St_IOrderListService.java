package com.kosta.csm.st_Service;

import java.util.List;

import org.springframework.ui.Model;

import com.kosta.csm.vo.Criteria;
import com.kosta.csm.vo.OrderListVO;
import com.kosta.csm.vo.OrderList_ProductVO;
import com.kosta.csm.vo.ProductVO;
import com.kosta.csm.vo.St_Stock_ProductVO;

public interface St_IOrderListService {

	public List<OrderList_ProductVO> list(Criteria cri, Model model);
	
	public List<ProductVO> stockDetail_list(Criteria cri);
	
	public List<ProductVO> stockDetail_order(Criteria cri);
	
	public List<ProductVO> stockDetail_complete(Criteria cri);

	public void delete(String o_Num);

	public List<St_Stock_ProductVO> stock(Criteria cri, Model model);

	public void order(OrderListVO vo);

	public List<OrderList_ProductVO> complete(Criteria cri, Model model);

	public List<St_Stock_ProductVO> orderSearch1(Criteria cri, Model model, String searchType, String search);

	public List<St_Stock_ProductVO> orderSearch2(Criteria cri, Model model, String category);


}
