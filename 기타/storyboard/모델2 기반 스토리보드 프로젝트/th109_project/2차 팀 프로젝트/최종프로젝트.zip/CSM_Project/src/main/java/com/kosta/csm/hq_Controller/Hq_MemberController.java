package com.kosta.csm.hq_Controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.kosta.csm.hq_Service.Hq_IMemberService;
import com.kosta.csm.hq_Service.Hq_IOrderListService;
import com.kosta.csm.vo.Criteria;
import com.kosta.csm.vo.CriteriaIndex;
import com.kosta.csm.vo.MemberVO;

@Controller
@RequestMapping("/hq")
public class Hq_MemberController {

	@Autowired
	private Hq_IMemberService service1;

	@Autowired
	private Hq_IOrderListService service2;

	// index Page
	@RequestMapping(value = "/index/adminIndex", method = RequestMethod.GET)
	public String test(HttpServletRequest request, CriteriaIndex cri, Model model) {
		System.out.println("adminIndex!");

		int m_PageNum;
		int o_PageNum;

		if (request.getParameter("m_PageNum") == null) {
			m_PageNum = 1;
		} else {
			m_PageNum = Integer.parseInt(request.getParameter("m_PageNum"));
		}

		if (request.getParameter("o_PageNum") == null) {
			o_PageNum = 1;
		} else {
			o_PageNum = Integer.parseInt(request.getParameter("o_PageNum"));
		}

		System.out.println("m_PageNum : " + m_PageNum);
		System.out.println("o_PageNum : " + o_PageNum);

		cri.setM_PageNum(m_PageNum);
		cri.setO_PageNum(o_PageNum);
		model.addAttribute("list1", service1.indexApprovalList(cri, model));
		model.addAttribute("list2", service2.indexApprovalList(cri, model));
		model.addAttribute("list2Detail", service2.orderApprovalListDetail2(cri));
		// model.addAttribute("stockListDetail", service2.stockListDetail(cri));
		model.addAttribute("cri", cri);
		return "hq.index.adminIndex";
	}

	@RequestMapping(value = "/index/mstateUpdate", method = RequestMethod.GET)
	public String update(HttpServletRequest request, @RequestParam("ckb") String[] ckb) {
		service1.updateStates(ckb);
		return "redirect:/hq/index/adminIndex";
	}

	// 회원가입 승인
	@RequestMapping(value = "/member/memberApproval", method = RequestMethod.GET)
	public String list(Criteria cri, Model model) {
		model.addAttribute("list", service1.approvalList(cri, model));
		model.addAttribute("cri", cri);
		return "hq_aside.store.memberApproval";
	}

	@RequestMapping(value = "/member/mstateUpdate", method = RequestMethod.GET)
	public String updateState(HttpServletRequest request) {
		System.out.println("button update");
		String id = request.getParameter("id");
		String m_Store=request.getParameter("m_Store");
		service1.updateState(id, m_Store);
		return "redirect:/hq/member/memberApproval";
	}

	@RequestMapping(value = "/member/mstateUpdate", method = RequestMethod.POST)
	public String updateStatePost(HttpServletRequest request, @RequestParam("ckb") String[] ckb) {
		System.out.println("post update");
		service1.updateStates(ckb);
		return "redirect:/hq/member/memberApproval";
	}
	
	@RequestMapping(value = "/member/mstateDelete", method = RequestMethod.POST)
	public String mstateDelete(HttpServletRequest request, @RequestParam("ckb") String[] ckb) {
		System.out.println("post update");
		service1.mstateDelete(ckb);
		return "redirect:/hq/member/memberApproval";
	}

	// 회원정보 수정
	@RequestMapping(value = "/member/modify", method = RequestMethod.GET)
	public String modifyGet() {

		return "hq_aside.member.modify";
	}

	@RequestMapping(value = "/member/modify", method = RequestMethod.POST)
	public String modifyPost(HttpServletRequest request, Model model) {

		return service1.check(request, model);
	}

	@RequestMapping(value = "/member/memberModify", method = RequestMethod.GET)
	public String memberModifyGet(Model model) {
		System.out.println("memberModify Get");
		MemberVO vo = service1.searchById();
		String[] m_Emails = vo.getM_Email().split("@");
		model.addAttribute("vo", vo);
		model.addAttribute("m_Emails", m_Emails);
		return "hq_aside.member.memberModify";
	}

	@RequestMapping(value = "/member/memberModify", method = RequestMethod.POST)
	public String memberModifyPost(MemberVO vo, @RequestParam ("m_Email1") String m_Email1, @RequestParam ("m_Email2") String m_Email2) {
		System.out.println("memberModify Post");
		System.out.println(vo.getM_Id());
		vo.setM_Email(m_Email1 + "@" + m_Email2);
		return service1.memberModify(vo);
	}

	@RequestMapping(value = "/member/pwdModify", method = RequestMethod.GET)
	public String pwdModifyGet(Model model) {
		System.out.println("pwdModify Get");
		model.addAttribute("pwd", service1.check());
		return "hq_aside.member.pwdModify";
	}

	@RequestMapping(value = "/member/pwdModify", method = RequestMethod.POST)
	public String pwdModifyPost(HttpServletRequest request, MemberVO vo) {
		System.out.println("pwdModify Post");
		System.out.println(vo.getM_Id());
		System.out.println(vo.getM_Pwd());
		return service1.pwdModify(request, vo);
	}

	@RequestMapping(value = "/member/memberLeave", method = RequestMethod.GET)
	public String memberLeaveGet() {
		System.out.println("memberLeave Get");
		return "hq_aside.member.memberLeave";
	}

	@RequestMapping(value = "/member/memberLeave", method = RequestMethod.POST)
	public String memberLeavePost(Model model, HttpServletRequest request, MemberVO vo) {
		System.out.println("memberLeave Post");
		System.out.println(vo.getM_Id());
		System.out.println(vo.getM_Pwd());
		return service1.memberLeave(model, request, vo);
	}
}
