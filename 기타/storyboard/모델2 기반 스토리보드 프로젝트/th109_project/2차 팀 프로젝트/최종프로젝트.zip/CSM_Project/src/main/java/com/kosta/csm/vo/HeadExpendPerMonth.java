package com.kosta.csm.vo;

public class HeadExpendPerMonth {
	String he_Date; // 지출 날짜 ('년/월' 만  저장)
	long he_Expend; // 지출금
	int count; // 지출건수
	public String getHe_Date() {
		return he_Date;
	}
	public void setHe_Date(String he_Date) {
		this.he_Date = he_Date;
	}
	public long getHe_Expend() {
		return he_Expend;
	}
	public void setHe_Expend(long he_Expend) {
		this.he_Expend = he_Expend;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	
}

