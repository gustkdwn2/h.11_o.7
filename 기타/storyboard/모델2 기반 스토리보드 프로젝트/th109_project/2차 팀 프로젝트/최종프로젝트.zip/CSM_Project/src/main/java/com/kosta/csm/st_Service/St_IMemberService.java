package com.kosta.csm.st_Service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.ui.Model;

import com.kosta.csm.vo.MemberVO;

public interface St_IMemberService {

	List<MemberVO> memberList();

	public String modify(String m_Id);

	String check(HttpServletRequest request, Model model);

	String memberModify(MemberVO vo);

	String pwdModify(HttpServletRequest request, MemberVO vo);

	public MemberVO searchById();

	String check();
}
