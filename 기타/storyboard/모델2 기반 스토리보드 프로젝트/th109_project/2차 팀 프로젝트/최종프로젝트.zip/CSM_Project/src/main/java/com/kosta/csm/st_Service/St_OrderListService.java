package com.kosta.csm.st_Service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.kosta.csm.st_Dao.St_IOrderListDAO;
import com.kosta.csm.vo.Criteria;
import com.kosta.csm.vo.OrderListVO;
import com.kosta.csm.vo.OrderList_ProductVO;
import com.kosta.csm.vo.ProductVO;
import com.kosta.csm.vo.St_Stock_ProductVO;

@Service
public class St_OrderListService implements St_IOrderListService {
	
	@Autowired
	private SqlSession sqlSession;


	@Override
	public List<OrderList_ProductVO> list(Criteria cri, Model model) {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String m_Id = (String)auth.getName();
		
		St_IOrderListDAO dao = sqlSession.getMapper(St_IOrderListDAO.class);
		model.addAttribute("count", dao.orderListCount(m_Id));
		
		//date
		List<OrderList_ProductVO> list=dao.list(cri, m_Id);
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String o_StringDate;
		
		for(int i=0; i<list.size(); i++){
			//orderDate에 list에 들어있는 o_Date를 넣는다.
			Date orderDate=list.get(i).getO_Date();
			//list o_StringDate에 sdf로 포맷 바꾼 orderDate 입력한다.
			o_StringDate=sdf.format(orderDate);
			list.get(i).setO_StringDate(o_StringDate);
			//db에 sdf로 포맷 바꾼 orderDate를 o_StringDate 컬럼에 업데이트한다.
			dao.updateStringDate(o_StringDate, list.get(i).getHp_Code());
		}
		
		return list;
	}


	@Override
	public void delete(String o_Num) {
		St_IOrderListDAO dao = sqlSession.getMapper(St_IOrderListDAO.class);
		
		dao.delete(o_Num);
	}


	@Override
	public List<St_Stock_ProductVO> stock(Criteria cri, Model model) {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String m_Id = (String)auth.getName();
		
		St_IOrderListDAO dao = sqlSession.getMapper(St_IOrderListDAO.class);
		
		model.addAttribute("count", dao.stockCount(m_Id));
		
		List<St_Stock_ProductVO> list = dao.stock(cri, m_Id);
		
		List<Integer> filter = new ArrayList<Integer>();
		
		for(int i=0; i<list.size(); i++){
			filter.add(i, dao.stateFilter(list.get(i).getHp_Code()));
		}
		
		model.addAttribute("filter", filter);
		
		return list;
	}
	
	@Override
	public List<ProductVO> stockDetail_list(Criteria cri) {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String m_Id = (String)auth.getName();
		
		St_IOrderListDAO dao = sqlSession.getMapper(St_IOrderListDAO.class);
		
		return dao.stockDetail_list(cri, m_Id);
	}
	
	
	@Override
	public List<St_Stock_ProductVO> orderSearch1(Criteria cri, Model model, String searchType, String search) {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String m_Id = (String)auth.getName();
		
		St_IOrderListDAO dao = sqlSession.getMapper(St_IOrderListDAO.class);
		
		
		
		List<St_Stock_ProductVO> list = new ArrayList<>();
				
		if(searchType.equals("상품번호")){
			list = dao.orderSearch1stock_Num(cri, m_Id, search);
			model.addAttribute("stockListDetail", dao.orderSearch1Detail_Num(cri, m_Id, search));
		}else if(searchType.equals("상품명")){
			list = dao.orderSearch1stock_Name(cri, m_Id, "%"+search+"%");
			model.addAttribute("count", dao.orderSearch1Count_Name(m_Id, "%"+search+"%"));
			model.addAttribute("stockListDetail", dao.orderSearch1Detail_Name(cri, m_Id, "%"+search+"%"));
		}
		
		
		
		List<Integer> filter = new ArrayList<Integer>();
		
		for(int i=0; i<list.size(); i++){
			filter.add(i, dao.stateFilter(list.get(i).getHp_Code()));
		}
		
		model.addAttribute("filter", filter);
		
		return list;
	}
	
	@Override
	public List<St_Stock_ProductVO> orderSearch2(Criteria cri, Model model, String category) {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String m_Id = (String)auth.getName();
		
		St_IOrderListDAO dao = sqlSession.getMapper(St_IOrderListDAO.class);
		
		
		
		List<St_Stock_ProductVO> list = dao.orderSearch2(cri, m_Id, category);
		model.addAttribute("count", dao.orderSearch2Count(m_Id, category));
		model.addAttribute("stockListDetail", dao.orderSearch2Detail(cri, m_Id, category));
		
		List<Integer> filter = new ArrayList<Integer>();
		
		for(int i=0; i<list.size(); i++){
			filter.add(i, dao.stateFilter(list.get(i).getHp_Code()));
		}
		
		model.addAttribute("filter", filter);
		
		return list;
	}

	
	
	@Override
	public List<ProductVO> stockDetail_order(Criteria cri) {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String m_Id = (String)auth.getName();
		
		St_IOrderListDAO dao = sqlSession.getMapper(St_IOrderListDAO.class);
		
		return dao.stockDetail_order(cri, m_Id);
	}
	
	@Override
	public List<ProductVO> stockDetail_complete(Criteria cri) {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String m_Id = (String)auth.getName();
		
		St_IOrderListDAO dao = sqlSession.getMapper(St_IOrderListDAO.class);
		
		return dao.stockDetail_complete(cri, m_Id);
	}


	@Override
	public void order(OrderListVO vo) {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String user_id = (String)auth.getName();
		
		vo.setM_Id(user_id);
		
		St_IOrderListDAO dao = sqlSession.getMapper(St_IOrderListDAO.class);
		
		dao.order(vo);
	}


	@Override
	public List<OrderList_ProductVO> complete(Criteria cri, Model model) {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String m_Id = (String)auth.getName();
		
		St_IOrderListDAO dao = sqlSession.getMapper(St_IOrderListDAO.class);
		model.addAttribute("count", dao.orderCompleteListCount(m_Id));
		
		/*
		 * 
		 * <td>${list.hp_Code }</td>
				<td>${list.hp_Name }</td>
				<td>${list.hp_Mprice }</td>
				<td>${list.hp_Cprice }</td>
				<td>${list.o_amount }</td>
				<td>${list.o_amount * list.hp_Mprice }</td>
				<td>${list.o_StringDate }</td>
		 */
		
		
		List<OrderList_ProductVO> list = dao.completeList(cri, m_Id);
		
		
		return list;
	}


	


	


	
	
	
}
