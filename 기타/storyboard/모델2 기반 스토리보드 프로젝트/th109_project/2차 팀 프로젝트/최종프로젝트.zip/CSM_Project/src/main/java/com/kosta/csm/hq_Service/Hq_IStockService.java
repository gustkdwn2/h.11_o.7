package com.kosta.csm.hq_Service;

import java.util.List;

import org.springframework.ui.Model;

import com.kosta.csm.vo.Criteria;
import com.kosta.csm.vo.HqStockList;
import com.kosta.csm.vo.ProductVO;

public interface Hq_IStockService {
	public List<HqStockList> stockList(Criteria cri, Model model);
	public List<ProductVO> stockListDetail(Criteria cri);
	public void modify(String[] hp_Code, int[] hp_Amount);
	public List<HqStockList> stockListSearch(Criteria cri, Model model, String productSearch, String searchType);
	public List<ProductVO> stockListDetailSearch(Criteria cri, String productSearch, String searchType);
	public List<HqStockList> stockModifyView(String[] hp_Code);
	
}
