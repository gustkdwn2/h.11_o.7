package com.kosta.csm.vo;

public class HqRevenueMore {
String revenue_Date;
long expend1;
long expend2;
long expend3;
long income1;
public String getRevenue_Date() {
	return revenue_Date;
}
public void setRevenue_Date(String revenue_Date) {
	this.revenue_Date = revenue_Date;
}
public long getExpend1() {
	return expend1;
}
public void setExpend1(long expend1) {
	this.expend1 = expend1;
}
public long getExpend2() {
	return expend2;
}
public void setExpend2(long expend2) {
	this.expend2 = expend2;
}
public long getExpend3() {
	return expend3;
}
public void setExpend3(long expend3) {
	this.expend3 = expend3;
}
public long getIncome1() {
	return income1;
}
public void setIncome1(long income1) {
	this.income1 = income1;
}

}
