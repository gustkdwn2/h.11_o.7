package com.kosta.csm.st_Controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.kosta.csm.st_Service.St_IRevenueService;
import com.kosta.csm.vo.Criteria;
import com.kosta.csm.vo.StoreExpendVO;

@Controller
@RequestMapping("/st")
public class St_RevenueController {
	static List<StoreExpendVO> expendList = new ArrayList<StoreExpendVO>();

	@Autowired
	private St_IRevenueService service;

	// 영업판매내역
	@RequestMapping(value = "/revenue/saleList", method = RequestMethod.GET)
	public String saleList(Criteria cri, Model model) {
		System.out.println("/st/revenue/saleList");
		expendList.clear();
		model.addAttribute("list", service.saleList(cri, model));
		model.addAttribute("cri", cri);
		model.addAttribute("indexBtn", new String("betweenDay"));
		return "st_aside.revenue.saleList";
	}

	// 영업판매상세내역
	@RequestMapping(value = "/revenue/saleDetail", method = RequestMethod.GET)
	public String saleDetail(Criteria cri, Model model,
			@RequestParam(value = "s_Group", required = false) Integer s_Group) {
		System.out.println("/st/revenue/saleDetail");
		model.addAttribute("list", service.saleDetail(cri, model, s_Group));
		model.addAttribute("cri", cri);
		model.addAttribute("s_Group", s_Group);
		return "st_aside.revenue.detailSale";
	}

	// 기간별 영업판매내역
	@RequestMapping(value = "/revenue/saleListBetweenDay")
	public String saleListBetweenDay(Criteria cri, Model model, @RequestParam("first") String first,
			@RequestParam("last") String last) {
		System.out.println("/st/revenue/saleListBetweenDay");
		model.addAttribute("list", service.saleListBetweenDay(cri, model, first, last));
		model.addAttribute("cri", cri);
		model.addAttribute("first", first);
		model.addAttribute("last", last);
		model.addAttribute("indexBtn", new String("perDay"));
		return "st_aside.revenue.saleList";
	}

	// 일별 매장영업수익
	@RequestMapping(value = "/revenue/revenuePerDay", method = RequestMethod.GET)
	public String revenuePerDay(Criteria cri, Model model) {
		System.out.println("/st/revenue/revenuePerDay");
		expendList.clear();
		model.addAttribute("list", service.Revenue(cri, model));
		model.addAttribute("cri", cri);
		model.addAttribute("check", 0);
		return "st_aside.revenue.profitListPerDay";
	}

	// 월별 매장영업수익
	@RequestMapping(value = "/revenue/revenuePerMonth", method = RequestMethod.GET)
	public String revenuePerMonth(Criteria cri, Model model) {
		System.out.println("/st/revenue/revenuePerMonth");
		model.addAttribute("list", service.revenuePerMonth(cri, model));
		model.addAttribute("cri", cri);
		model.addAttribute("check", 1);
		return "st_aside.revenue.profitListPerDay";
	}

	// 기간별 매장 영업수익
	@RequestMapping(value = "/revenue/revenueBetweenDay")
	public String revenueBetweenDay(Criteria cri, Model model, @RequestParam("first") String first,
			@RequestParam("last") String last) {
		System.out.println("/st/revenue/revenueBetweenDay");
		model.addAttribute("list", service.revenueBetweenDay(cri, model, first, last));
		model.addAttribute("cri", cri);
		model.addAttribute("check", 2);
		model.addAttribute("first", first);
		model.addAttribute("last", last);
		return "st_aside.revenue.profitListPerDay";
	}

	// 매장 영업외 지출 추가후 가저오기
	@RequestMapping(value = "/revenue/addAndGetExpend", method = RequestMethod.POST)
	public String addAndGetExpend(Model model, HttpServletRequest request,
			@RequestParam("se_Content") String se_Content, @RequestParam("month") String month,
		    @RequestParam("year") String year , @RequestParam("day") String day,
			@RequestParam("se_Expend") Integer se_Expend) {
		System.out.println("/st/revenue/addAndGetExpend");
		 service.addExpend(request, year,month,day, se_Expend, se_Content);
		model.addAttribute("list", expendList);
		return "redirect:/st/revenue/getExpend";
	}

	// 매장 영업외 지출내역 가저오기
	@RequestMapping(value = "/revenue/getExpend", method = RequestMethod.GET)
	public String getExpend(Criteria cri, Model model) {
		System.out.println("/st/revenue/getExpend");
		expendList =  service.getStoreExpend(cri, model, expendList);
		model.addAttribute("list", expendList);
		model.addAttribute("cri", cri);
		model.addAttribute("indexBtn", new String("betweenDay"));
		return "st_aside.revenue.expendList";			
	}
	
	// 매장 영업외 지출내역 삭제
	@RequestMapping(value = "/revenue/removeExpend", method = RequestMethod.POST)
	public String removeExpend(Model model, HttpServletRequest request, @RequestParam("se_Num") Integer se_Num, @RequestParam("indexBtn") String indexBtn) {
		System.out.println("/st/revenue/removeExpend");
		model.addAttribute("list", service.removeExpend(se_Num, expendList));
		model.addAttribute("indexBtn", indexBtn);
		return "st_aside.revenue.expendList";
	}
	
	//기간별 매장 영업외 지출내역  가져오기
	@RequestMapping(value = "/revenue/expendBetweenDay")
	public String expendBetweenDay(Model model, HttpServletRequest request, @RequestParam("first") String first,
			@RequestParam("last") String last) {
		System.out.println("/st/revenue/expendBetweenDay");
		expendList = service.expendBetweenDay(request, expendList ,first, last);
		model.addAttribute("list", expendList);
		model.addAttribute("indexBtn",new String("perDay"));
		model.addAttribute("first", first);
		model.addAttribute("last", last);
		return "st_aside.revenue.expendList";
	}

	// 기간 종류 분류(1.영업판매내역 2.매장수익내역 3. 매장 지출내역 )
	@RequestMapping(value = "/revenue/divBetweenDay", method = RequestMethod.POST)
	public String divBetweenDay(Model model, @RequestParam("kind") String kind) {
		System.out.println("/st/revenue/divBetweenDay");
		model.addAttribute("kind", kind);
		return "st_aside.revenue.InputBetweenDay";
	}

	//매장총수익
	@RequestMapping(value = "/revenue/allStoreRevenue", method = RequestMethod.GET)
	public String allStoreRevenue(Criteria cri, Model model) {
		System.out.println("/st/revenue/allStoreRevenue");
		model.addAttribute("list", service.allRevenue(cri, model));
		model.addAttribute("cri", cri);
		return "st_aside.revenue.allStoreRevenue";
	}
	
	//매장총수익 같은날내용 상세하게
	@RequestMapping(value = "/revenue/detailRevenue", method = RequestMethod.GET)
	public String detailRevenue(Criteria cri, Model model, @RequestParam("s_Date") String s_Date) {
		System.out.println("/st/revenue/detailRevenue");
		model.addAttribute("list", service.detailRevenue(cri, model , s_Date));
		model.addAttribute("cri", cri);
		model.addAttribute("s_Date", s_Date);
		return "st_aside.revenue.detailRevenue";
	}
	

}










