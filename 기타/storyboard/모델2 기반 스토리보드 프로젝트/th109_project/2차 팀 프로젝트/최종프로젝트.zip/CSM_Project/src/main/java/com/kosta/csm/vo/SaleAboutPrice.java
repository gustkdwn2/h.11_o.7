package com.kosta.csm.vo;

import java.util.Date;

public class SaleAboutPrice {
	private String hp_Code;//상품코드
	private String hp_Name;//상품명
	private int s_Group; //판매그룹번호
	private int s_Amount; //판매수량
	private String s_Date; //판매날짜
	private int hp_Cprice;//판매금액
	
	public String getHp_Code() {
		return hp_Code;
	}
	public void setHp_Code(String hp_Code) {
		this.hp_Code = hp_Code;
	}
	public String getHp_Name() {
		return hp_Name;
	}
	public void setHp_Name(String hp_Name) {
		this.hp_Name = hp_Name;
	}
	public int getS_Group() {
		return s_Group;
	}
	public void setS_Group(int s_Group) {
		this.s_Group = s_Group;
	}
	public int getS_Amount() {
		return s_Amount;
	}
	public void setS_Amount(int s_Amount) {
		this.s_Amount = s_Amount;
	}
	public String getS_Date() {
		return s_Date;
	}
	public void setS_Date(String s_Date) {
		this.s_Date = s_Date;
	}
	public int getHp_Cprice() {
		return hp_Cprice;
	}
	public void setHp_Cprice(int hp_Cprice) {
		this.hp_Cprice = hp_Cprice;
	}
	
}
