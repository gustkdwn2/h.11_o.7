package com.kosta.csm.hq_Controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.kosta.csm.hq_Service.Hq_IAccountingService;
import com.kosta.csm.vo.Criteria;
import com.kosta.csm.vo.HeadExpendVO;

@Controller
@RequestMapping("/hq/accounting")
public class Hq_AccountingController {

	@Autowired   
	private  Hq_IAccountingService service;
	static List<HeadExpendVO> list = new ArrayList<HeadExpendVO>();
	///////////////////////////////수익확인메뉴////////////////////////////
	//본사수익
	@RequestMapping(value="/revenueList", method=RequestMethod.GET)
	public String revenueList(Criteria cri, Model model){
		System.out.println("/hq/accounting/revenueList");
		model.addAttribute("list", service.getSumRevenuePerMonth(cri, model));
		model.addAttribute("cri", cri);

		return "hq_aside.accounting.revenueList";
	} 
	
	//본사수익 자세히
	@RequestMapping(value="/revenueMore")
	public String revenerMore(Criteria cri, Model model){
		System.out.println("/hq/accounting/revenerMore");
		model.addAttribute("list", service.getRevenueMore(cri, model));
		model.addAttribute("cri", cri);
		
		return "hq_aside.accounting.revenueMoreList";
	} 
	
	//본사 급여지출내역상세
	@RequestMapping(value="/showPayPerMonth", method=RequestMethod.GET)
	public String showPayPerMonth( Model model){
		System.out.println("/hq/accounting/showPayPerMonth");
		model.addAttribute("kind", "accounting");
		return "redirect:/hq/personResource/showPayPerMonth";
	} 
	
	//본사 기타지출상세
	@RequestMapping(value="/etcExpend", method=RequestMethod.GET)
	public String etcExpend( Model model){
		System.out.println("/hq/accounting/etcExpend");
		model.addAttribute("kind", "revenue");
		return "redirect:/hq/accounting/expendPerMonth";
	} 
	
	// 본사 수익 월별 검색 ------------ 추가
	@RequestMapping(value = "/revenueSearch")
	public String revenueSearch(Criteria cri, Model model, HttpServletRequest request) {
		System.out.println("/hq/accounting/revenueSearch");
		model.addAttribute("list", service.revenueSearch(cri, model, request));
		model.addAttribute("cri", cri);
		return "hq_aside.accounting.revenueList";
	}

	//////////////////////////////지출관리메뉴////////////////////////////
	//본사 지출(선택한 월 에 대해)
	@RequestMapping(value="/expendList", method=RequestMethod.GET)
	public String list(Criteria cri, Model model, @RequestParam("he_Date") String he_Date){
		System.out.println("/hq/accounting/expendList");
		model.addAttribute("list", service.getExpendOfMonth(cri, model, he_Date));
		model.addAttribute("he_Date", he_Date);
		model.addAttribute("cri", cri);
		return "hq_aside.accounting.expendList";
	}  
	
	//월별 본사 지출
	@RequestMapping(value = "/expendPerMonth" )
	public String expendPerMonth(Criteria cri, Model model, @RequestParam(value ="kind" , required = false ) String kind){
		System.out.println("/hq/accounting/expendPerMonth");
		model.addAttribute("list", service.getExpendPerMonth(cri, model));
		model.addAttribute("cri", cri);
		model.addAttribute("kind", kind);
		return "hq_aside.accounting.expendPerMonth";
	}
	
	//본사지출내역 삭제후 다시출력(월정보로삭제)
	@RequestMapping(value = "/removeAndGetExpend" , method =RequestMethod.POST)
	public String removeAndGetExpend( @RequestParam("yearAndMonth") String yearAndMonth){
		System.out.println("/hq/accounting/removeAndGetExpend");
		service.removeOfMonth(yearAndMonth);
		return "redirect:/hq/accounting/expendPerMonth";
	}

	//본사지출내역 삭제후 다시출력(기본키로삭제)
	@RequestMapping(value = "/removeAndGetExpendInNum" , method =RequestMethod.POST)
	public String removeAndGetExpendInNum( @RequestParam("he_Num") Integer he_Num, @RequestParam("he_Date") String he_Date){
		System.out.println("/hq/accounting/removeAndGetExpendInNum");
		service.removeOfNum(he_Num);
		System.out.println("go to redirect:/hq/accounting/expendList="+he_Date);
		return "redirect:/hq/accounting/expendList?he_Date="+he_Date;
	}
	//본사지출내역 추가창으로
	@RequestMapping(value = "/addExpend" , method =RequestMethod.POST)
	public String addExpend(Criteria cri, @ModelAttribute HeadExpendVO vo,
			Model model ,@RequestParam(value ="year" ,required = false) String year
			,@RequestParam(value ="month" ,required = false) String month
			,@RequestParam(value ="day" ,required = false) String day){
		System.out.println("/hq/accounting/addExpend");
		service.addTempExpend(year,month,day,list,vo);
		model.addAttribute("list", list);
		model.addAttribute("cri", cri);
		return "hq_aside.accounting.addExpend";
	}
	//list임시로 가지고있는 값들 한번에 db에 지출내역추가
	@RequestMapping(value = "/endAddExpend", method =RequestMethod.GET)
	public String endAddExpend( ){
		System.out.println("/hq/accounting/endAddExpend");
		service.addExpendList(list);
		return "redirect:/hq/accounting/expendPerMonth";
	}

	//누른값을 수정하는 뷰로
	@RequestMapping(value = "/updateExpend", method =RequestMethod.POST)
	public String updateExpend(@ModelAttribute HeadExpendVO vo ,  Model model, HttpServletRequest request){
		System.out.println("/hq/accounting/updateExpend");
		model.addAttribute("vo", vo);
		model.addAttribute("year", vo.getHe_Date().substring(0, 4));
		model.addAttribute("month", vo.getHe_Date().substring(5, 7));
		model.addAttribute("day",  vo.getHe_Date().substring(8, 10));
		model.addAttribute("exp_he_Date", request.getParameter("exp_he_Date"));
		System.out.println("before updateExpend return ");
		return "hq_aside.accounting.updateExpend";
	}
	
	//수정처리
	@RequestMapping(value = "/proUpdate", method =RequestMethod.POST)
	public String proUpdate(@ModelAttribute HeadExpendVO vo,Model model, @RequestParam("year") String year
			, @RequestParam("month") String month
			, @RequestParam("day") String day){
		System.out.println("/hq/accounting/proUpdate");
		System.out.println(vo.getHe_Num());
		System.out.println(vo.getHe_Expend());
		service.updateExpend(year,month,day,vo);
		return "redirect:/hq/accounting/expendList?he_Date=" + vo.getHe_Date();
	}
	
	//본사지출내역 추가후 다시출력
	@RequestMapping(value = "/removeAndAddExpend" , method =RequestMethod.GET)
	public String removeAndAddExpend(){
		System.out.println("/hq/accounting/removeAndAddExpend");
		return "hq_aside.accounting.expendList";
	}
	
	// 기타 지출 관리 검색 ------------ 추가
	@RequestMapping(value = "/expendSearch") 
	public String expendSearch(Criteria cri, Model model, HttpServletRequest request) {
		System.out.println("/hq/accounting/expendSearch");
		model.addAttribute("list", service.expendSearch(cri, model, request));
		model.addAttribute("cri", cri);
		return "hq_aside.accounting.expendPerMonth";
	}

	/////////////////////매출 및 영업 이익 확인//////////////////////////////////////////
	@RequestMapping(value="/incomePerMonth")
	public String incomePerMonth(Criteria cri, Model model){
		System.out.println("/hq/accounting/incomePerMonth");
		model.addAttribute("list",service.incomePerMonth(cri, model));
		model.addAttribute("cri", cri);
		return "hq_aside.accounting.incomePerMonth";
	}
	//매장별
	@RequestMapping(value="/incomeOfMonthPerStore")
	public String incomeOfMonthPerStore(Criteria cri, Model model, @RequestParam("income_Date") String income_Date){
		System.out.println("/hq/accounting/incomeOfMonthPerStore");
		model.addAttribute("list",service.incomeOfMonthPerStore(cri, model, income_Date));
		model.addAttribute("income_Date", income_Date);
		model.addAttribute("cri", cri);
		return "hq_aside.accounting.incomeOfMonthPerStore";
	}
	//일자별
	@RequestMapping(value="/incomeOfMonthPerDay")
	public String incomeOfMonthPerDay(Criteria cri, Model model, @RequestParam("income_Date") String income_Date){
		System.out.println("/hq/accounting/incomeOfMonthPerDay");
		model.addAttribute("list",service.incomeOfMonthPerDay(cri, model, income_Date));
		model.addAttribute("income_Date", income_Date);
		model.addAttribute("cri", cri);
		return "hq_aside.accounting.incomeOfMonthPerDay";
	}
	
	//월별  ->매장 수익합 상세
	@RequestMapping(value="/incomePerStoreDetail")
	public String incomePerStoreDetail(Criteria cri, Model model, @RequestParam("m_Id") String m_Id, @RequestParam("income_Date") String income_Date){
		System.out.println("/hq/accounting/incomePerStoreDetail");
		model.addAttribute("list",service.incomePerStoreDetail(cri, model, m_Id,income_Date));
		model.addAttribute("income_Date", income_Date);
		model.addAttribute("m_Id", m_Id);
		model.addAttribute("cri", cri);
		System.out.println("go  incomePerStoreDetail.jsp");
		return "hq_aside.accounting.incomePerStoreDetail";
	}
	
	//월별 ->일별 수익합 상세
	@RequestMapping(value="/incomePerDayDetail")
	public String incomePerDayDetail(Criteria cri, Model model, @RequestParam("income_Date") String income_Date){
		System.out.println("/hq/accounting/incomePerDayDetail");
		model.addAttribute("list",service.incomePerDayDetail(cri, model, income_Date));
		model.addAttribute("income_Date", income_Date);
		model.addAttribute("cri", cri);
		System.out.println("go  incomePerDayDetail.jsp");
		return "hq_aside.accounting.incomePerDayDetail";
	}

	//날짜(년.월.일)를 받아 해당날짜에 대한 모든 수익을 보여줌
	@RequestMapping(value="/allOfdayIncome")
	public String allOfdayIncome( Model model, @RequestParam("income_Date") String income_Date){
		System.out.println("/hq/accounting/allOfdayIncome");
		model.addAttribute("list",service.allOfdayIncome(income_Date));
		model.addAttribute("income_Date", income_Date);
		model.addAttribute("state", "detail");
		System.out.println("go  incomePerDayDetail.jsp");
		return "hq_aside.accounting.incomePerDayDetail";
	}
	
	//월, 매장을 받아 해당 정보에 대한 모든 수익을 보여줌
	@RequestMapping(value="/allOfStoreMonthIncome")
	public String allOfStoreMonthIncome( Model model, @RequestParam("income_Date") String income_Date, 
			@RequestParam("m_Id") String m_Id){
		System.out.println("/hq/accounting/allOfStoreMonthIncome");
		model.addAttribute("list",service.allOfStoreMonthIncome(income_Date,m_Id));
		model.addAttribute("income_Date", income_Date);
		model.addAttribute("state", "detail");
		System.out.println("go  incomePerStoreDetail.jsp");
		return "hq_aside.accounting.incomePerStoreDetail";
	}
	
	// 매출 확인 월별 검색 ------------ 추가
	@RequestMapping(value = "/incomeSearch")
	public String incomeSearch(Criteria cri, Model model, HttpServletRequest request) {
		System.out.println("/hq/accounting/incomeSearch");
		model.addAttribute("list", service.incomeSearch(cri, model, request));
		model.addAttribute("cri", cri);
		return "hq_aside.accounting.incomePerMonth";
	}
	
}
