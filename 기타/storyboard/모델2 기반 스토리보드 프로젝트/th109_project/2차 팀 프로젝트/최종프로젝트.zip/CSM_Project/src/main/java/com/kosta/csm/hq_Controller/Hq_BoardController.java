package com.kosta.csm.hq_Controller;

import java.io.UnsupportedEncodingException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.kosta.csm.hq_Service.Hq_IBoardService;
import com.kosta.csm.vo.BoardVO;
import com.kosta.csm.vo.Criteria;

@Controller
@RequestMapping("/hq/board")
public class Hq_BoardController {

	@Autowired
	private Hq_IBoardService service;
	
	@RequestMapping(value="/list", method=RequestMethod.GET)
	public String list(Criteria cri, Model model){
		System.out.println("list() !");
		
		model.addAttribute("list", service.list(cri, model));
		model.addAttribute("cri", cri);
		
		return "hq.board.list";
	}// list()
	
	@RequestMapping(value="/write", method=RequestMethod.GET)
	public String writeGet(){
		System.out.println("writeGet");
		return "hq.board.write";
	}
	
	@RequestMapping(value="/write", method=RequestMethod.POST)
	public String writePost(BoardVO vo, HttpServletRequest request) throws Exception{
		service.write(request, vo);
		return "redirect:/hq/board/list";
	}
	
	@RequestMapping(value="/content", method=RequestMethod.GET)
	public String contentGet(@RequestParam("b_Num") int b_Num, Model model){
		System.out.println("contentGet");
		service.updateReadCount(b_Num);
		model.addAttribute("contentList", service.content(b_Num));
		return "hq.board.content";
	}
	
	@RequestMapping("/download")
	public String download(@RequestParam("path") String path, @RequestParam("file") String file, 
			HttpServletRequest request, HttpServletResponse response) throws Exception{
		System.out.println("download");
		service.download(path, file, request, response);
		return "redirect:/hq/board/content";
	}
	
	@RequestMapping(value="/modify", method=RequestMethod.GET)
	public String modifyGet(BoardVO vo, Model model, @RequestParam("b_Num") int b_Num){
		System.out.println("modifyGet" +b_Num);
		model.addAttribute("modifyList", service.content(b_Num));
		return "hq.board.modify";
	}
	
	@RequestMapping(value="/modify", method=RequestMethod.POST)
	public String modifyPost(HttpServletRequest request, BoardVO vo) throws Exception{
		System.out.println("modifyPost");
		System.out.println(vo.getB_Num());
		service.modify(request, vo);
		return "redirect:/hq/board/list";
	}
	
	@RequestMapping(value="/delete")
	public String delete(@RequestParam("b_Num") int b_Num){
		System.out.println("delete");
		service.delete(b_Num);
		return "redirect:/hq/board/list";
	}

	@RequestMapping(value="/boardListSearch")
	public String boardListSearch(Criteria cri, Model model, @RequestParam("boardSearch") String boardSearch,
			@RequestParam("searchType") String searchType){
		
		System.out.println("boardListSearch");
		model.addAttribute("list", service.boardSearch(cri, boardSearch, searchType, model));
		model.addAttribute("cri", cri);
		model.addAttribute("search_check", 1);
		model.addAttribute("boardSearch", boardSearch);
		model.addAttribute("searchType", searchType);
		
		return "hq.board.list";
	}

}
