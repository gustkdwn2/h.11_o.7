package com.kosta.csm.st_Controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.kosta.csm.st_Service.St_SaleService;
import com.kosta.csm.vo.SaleProduct;

@Controller
@RequestMapping("/st")
public class St_SaleController {
   static List<SaleProduct> saleList = new ArrayList<SaleProduct>();

   @Autowired
   private St_SaleService service;
   
   //매장의 영어시작 또는 매장관리메뉴 선택창 *******************************************8
   @RequestMapping(value = "/index/userIndex", method = RequestMethod.GET)
   public String test() {
      System.out.println();
      return "fullscreen.st.index.userIndex";
   }
   
   //영업시작화면으로  *******************************************
   @RequestMapping(value = "/sale/sale", method = RequestMethod.GET)
   public String sale(Model model, HttpServletRequest request) {
      System.out.println("/st/sale/sale");
      return "fullscreen.st.sale.sale";
   }
   
   @RequestMapping(value="/sale/addSaleProduct", method=RequestMethod.POST)
   public String addSaleProduct(
         @RequestParam(value = "code" , required = false ) String code,
         @RequestParam(value = "amount"  , required = false) String amount,
         Model model){
      System.out.println("/st/sale/addSaleProduct");
      service.addSaleProduct(saleList, code, amount);
      model.addAttribute("allPrice",service.allPrice(saleList));
      model.addAttribute("saleList",saleList);
      System.out.println();
      return "fullscreen.st.sale.sale";
   }

   @RequestMapping(value="/sale/delSaleProduct", method=RequestMethod.POST)
   public String delSaleProduct(
         @RequestParam(value = "code" , required = false) String code,
         Model model){
      System.out.println("/st/sale/delSaleProduct");
      service.delSaleProduct(saleList, code);
      model.addAttribute("allPrice",service.allPrice(saleList));
      model.addAttribute("saleList",saleList);
      System.out.println();
      return "fullscreen.st.sale.sale";
   }
   
   @RequestMapping(value="/sale/moneyCalculation", method=RequestMethod.POST)
   public String moneyCalculation(@RequestParam(value = "receiveMoney" , required = false) String receiveMoney,
         Model model){
      System.out.println("/st/sale/receiveMoney");
      System.out.println("service.moneyCalculation(saleList, receiveMoney) :" + service.moneyCalculation(saleList, receiveMoney));
      model.addAttribute("sendMoney",service.moneyCalculation(saleList, receiveMoney));
      System.out.println("receiveMoney :" + receiveMoney);
      model.addAttribute("receiveMoney",receiveMoney);
      model.addAttribute("allPrice",service.allPrice(saleList));
      model.addAttribute("saleList",saleList);
      System.out.println();
      return "fullscreen.st.sale.sale";
   }
   @RequestMapping(value="/sale/endPaperMoney", method=RequestMethod.POST)
   public String endPaperMoney(Model model,HttpServletRequest request){
      System.out.println("/st/sale/endPaperMoney");
      service.endPaperMoney(request, saleList);
      System.out.println();
      return "fullscreen.st.sale.sale";
   }

   //영업종료
   @RequestMapping(value="/sale/endSale", method=RequestMethod.GET)
   public String endSale(){
      System.out.println("/st/sale/endSale");
      saleList.clear();
      return "redirect:/logout";
   } 
   
   //매장 영업시작시 출근 직원의 코드입력창    *******************************************8
   @RequestMapping(value = "/sale/startSellerPopUp", method = RequestMethod.GET)
   public String enrollSeller() {
      System.out.println("/st/index/startSellerPopUp");
      return "fullscreen.st.sale.startSellerPopUp";
   }   
   
   //매장 영업직원 퇴근처리하는 폼
   @RequestMapping(value="/sale/endSellerPopUp", method=RequestMethod.GET)
   public String endSellerPopUp(Model model){
      System.out.println("/st/sale/endSellerPopUp");
      return "fullscreen.st.sale.endSellerPopUp";
   }
   //매장 영업직원 퇴근직접처리
   @RequestMapping(value="/sale/EndEmployee", method=RequestMethod.POST)
   public String checkEndEmployee(Model model, @RequestParam("e_Num") Integer e_Num, HttpServletRequest request){
      System.out.println("/st/sale/EndEmployee");
      model.addAttribute("check",service.setEndTime(e_Num,request)); 
      return "fullscreen.st.sale.endSellerPopUp";
   }

   //매장 영업직원 퇴근직접처리
   @RequestMapping(value="/sale/StartEmployee", method=RequestMethod.POST)
   public String StartEmployee(Model model, @RequestParam("e_Num") Integer e_Num, HttpServletRequest request){
      System.out.println("/st/sale/StartEmployee");
      model.addAttribute("check",service.setStartTime(e_Num,request)); 
      return "fullscreen.st.sale.startSellerPopUp";
   }
   //근무중인 직원 보기
   @RequestMapping(value="/sale/showWorkingEmployee", method=RequestMethod.GET)
   public String showWorkingEmployee(Model model, HttpServletRequest request){
      System.out.println("/st/sale/showWorkingEmployee");
      model.addAttribute("list", service.WorkingEmployeeList(request));
      System.out.println("before return showWorkingEmployee.jsp");
      return "fullscreen.st.sale.showWorkingEmployee";
   }
   

   
   
}
