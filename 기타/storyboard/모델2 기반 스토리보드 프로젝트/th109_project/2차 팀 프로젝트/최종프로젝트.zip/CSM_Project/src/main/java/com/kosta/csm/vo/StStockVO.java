package com.kosta.csm.vo;

public class StStockVO {
	private String m_Id;
	private String hp_Code;
	private int st_Amount;
	
	//생성자
	public StStockVO(){
		
	}
		
	public StStockVO(String m_Id, String hp_Code, int st_Amount) {
		super();
		this.m_Id = m_Id;
		this.hp_Code = hp_Code;
		this.st_Amount = st_Amount;
	}

	//getter setter
	public String getM_Id() {
		return m_Id;
	}
	public void setM_Id(String m_Id) {
		this.m_Id = m_Id;
	}
	
	public String getHp_Code() {
		return hp_Code;
	}

	public void setHp_Code(String hp_Code) {
		this.hp_Code = hp_Code;
	}

	public int getSt_Amount() {
		return st_Amount;
	}
	public void setSt_Amount(int st_Amount) {
		this.st_Amount = st_Amount;
	}
	
	
}
