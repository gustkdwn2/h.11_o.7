package com.kosta.csm.st_Service;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.kosta.csm.vo.AllRevenue;
import com.kosta.csm.vo.Criteria;
import com.kosta.csm.vo.SaleAboutPrice;
import com.kosta.csm.vo.StoreExpendVO;
import com.kosta.csm.vo.StoreincomeVO;

   public interface St_IRevenueService {
      // 판매내역
      public ArrayList<SaleAboutPrice> saleList(Criteria cri, Model model);
      // 판매내역 기간별
      public ArrayList<SaleAboutPrice> saleListBetweenDay(Criteria cri, Model model, String First, String Last);
      // 판매상세내역
      public ArrayList<SaleAboutPrice> saleDetail(Criteria cri, Model model,Integer s_Group);
      // 일별 매장수익
      public ArrayList<StoreincomeVO> Revenue(Criteria cri, Model model);
      // 월별 매장수익
      public ArrayList<StoreincomeVO> revenuePerMonth(Criteria cri, Model model);
      // 기간별 매장수익
      public ArrayList<StoreincomeVO> revenueBetweenDay(Criteria cri, Model model, String First, String Last);
      //지출내역 추가
      public void addExpend(HttpServletRequest request,  String year, String month, String day, Integer se_Expend, String se_Content);
      //지출내역을 가저옴
      public List<StoreExpendVO> getStoreExpend(Criteria cri, Model model, List<StoreExpendVO> expendList);
      //삭제후 삭제된결과 가저옴
      public List<StoreExpendVO> removeExpend(Integer se_Num , List<StoreExpendVO> listBeforeRemove);
      //지출내역 기간별로가져옴
      public  List<StoreExpendVO> expendBetweenDay(HttpServletRequest request, List<StoreExpendVO> expendList, String First, String Last);
      //모든 총수익 을 가저옴
      public ArrayList<AllRevenue> allRevenue(Criteria cri, Model model);
      //총수익에대한 상세 수입 지출내역을 가저옴
      ArrayList<AllRevenue> detailRevenue(Criteria cri, Model model, String s_Date);
}