package com.kosta.csm.st_Service;

import javax.servlet.http.HttpServletRequest;

import org.springframework.ui.Model;

import com.kosta.csm.vo.Criteria;

public interface St_ISalesStatusService {

	void categoryStatus(Model model, HttpServletRequest request);

	void salesStatusAll(Criteria cri, Model model, HttpServletRequest request);

	void monthStatus(Model model, HttpServletRequest request);

	void yearStatus(Model model);

}
