package com.kosta.csm.hq_Controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.kosta.csm.hq_Service.Hq_IStoreService;
import com.kosta.csm.vo.Criteria;
import com.kosta.csm.vo.MemberVO;

@Controller
@RequestMapping("/hq/store")
public class Hq_StoreController {
	
	@Autowired
	private Hq_IStoreService service;

	// 매장관리
	@RequestMapping(value = "/storePresentCondition", method = RequestMethod.GET)
	public String storePresentCondition(Criteria cri, Model model) {
		System.out.println("storePresentCondition Get");
		model.addAttribute("list", service.storePresentCondition(cri, model));
		model.addAttribute("cri", cri);
		return "hq_aside.store.storePresentCondition";
	}

	@RequestMapping(value = "/storePresentCondition", method = RequestMethod.POST)
	public String storeSearch(Criteria cri, HttpServletRequest request, MemberVO vo, Model model) {
		System.out.println("storeSearch Post");
		model.addAttribute("list", service.storeSearch(cri, model, request, vo));
		model.addAttribute("cri", cri);
		return "hq_aside.store.storePresentCondition";
	}

	@RequestMapping(value = "/storeDelete", method = RequestMethod.GET)
	public String storeDelete(HttpServletRequest request, MemberVO vo) {
		System.out.println("storeDelete Get");
		return service.storeDelete(request, vo);
	}
	
	@RequestMapping(value="/salesStatus", method=RequestMethod.GET)
	public String salesStatus(Model model, HttpServletRequest request){
		
		service.salesStatus(model, request);
		
		return "hq_aside.store.salesStatus";
	}
	
	@RequestMapping(value="/monthStatus")
	public String monthStatus(Model model, HttpServletRequest request){
		
		service.monthStatus(model, request);
		
		return "hq_aside.store.monthStatus";
	}
	
	@RequestMapping(value="/yearStatus")
	public String yearStatus(Model model, HttpServletRequest request){
		
		service.yearStatus(model, request);
		
		return "hq_aside.store.yearStatus";
	}
}
