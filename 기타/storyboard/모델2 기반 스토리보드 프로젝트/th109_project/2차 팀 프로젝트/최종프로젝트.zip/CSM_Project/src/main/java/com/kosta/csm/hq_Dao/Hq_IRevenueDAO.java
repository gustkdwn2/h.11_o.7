package com.kosta.csm.hq_Dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.kosta.csm.vo.Criteria;
import com.kosta.csm.vo.HqRevenue;
import com.kosta.csm.vo.HqRevenueMore;

public interface Hq_IRevenueDAO {

	List<HqRevenue> getSumRevenuePerMonth(Criteria cri);
	
	int getSumRevenuePerMonthCount();

	List<HqRevenueMore> getRevenueMore(Criteria cri);

	int getRevenueMoreCount();

	int revenueSearchCount(String date);
	
	List<HqRevenue> revenueSearch(@Param("cri") Criteria cri, @Param("date") String date);
	
}
