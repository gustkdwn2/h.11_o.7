package com.kosta.csm.vo;

public class EmployeeVO {
	int e_Num;//  --직원코드
	String e_Name;    //--직원이름
	String e_StartDay;  //--입사일(년/월/일)
	String e_Account;  //--계좌번호
	String e_Phone;   //--연락처
	String e_Position;  //--구분  '점장' or '아르바이트'
	String m_Id;    //--근무하는 매장번호
	int e_Pay;    //--월급 또는 시급
	public int getE_Num() {
		return e_Num;
	}
	public void setE_Num(int e_Num) {
		this.e_Num = e_Num;
	}
	public String getE_Name() {
		return e_Name;
	}
	public void setE_Name(String e_Name) {
		this.e_Name = e_Name;
	}
	public String getE_StartDay() {
		return e_StartDay;
	}
	public void setE_StartDay(String e_StartDay) {
		this.e_StartDay = e_StartDay;
	}
	public String getE_Account() {
		return e_Account;
	}
	public void setE_Account(String e_Account) {
		this.e_Account = e_Account;
	}
	public String getE_Phone() {
		return e_Phone;
	}
	public void setE_Phone(String e_Phone) {
		this.e_Phone = e_Phone;
	}
	public String getE_Position() {
		return e_Position;
	}
	public void setE_Position(String e_Position) {
		this.e_Position = e_Position;
	}
	public String getM_Id() {
		return m_Id;
	}
	public void setM_Id(String m_Id) {
		this.m_Id = m_Id;
	}
	public int getE_Pay() {
		return e_Pay;
	}
	public void setE_Pay(int e_Pay) {
		this.e_Pay = e_Pay;
	}
	
}
