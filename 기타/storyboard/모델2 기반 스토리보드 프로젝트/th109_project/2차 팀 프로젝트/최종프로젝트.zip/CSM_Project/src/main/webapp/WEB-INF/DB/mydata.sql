insert into storeincome values ('gyoungi1', '2016/05/19', 476500, 93600);
insert into storeincome values ('gyoungi1', '2016/05/18', 539860, 87400);
insert into storeincome values ('gyoungi1', '2016/05/17', 442120, 53950);
insert into storeincome values ('gyoungi1', '2016/05/16', 571820, 77040);
insert into storeincome values ('gyoungi1', '2016/05/15', 392090, 47500);
insert into storeincome values ('gyoungi1', '2016/05/14', 558900, 67890);
insert into storeincome values ('gyoungi1', '2016/05/13', 630920, 91020);
insert into storeincome values ('gyoungi1', '2016/05/12', 509040, 45340);
insert into storeincome values ('gyoungi1', '2016/05/11', 533060, 56770);
insert into storeincome values ('gyoungi1', '2016/05/10', 599930, 72220);
insert into storeincome values ('gyoungi1', '2016/05/09', 396900, 63780);
insert into storeincome values ('gyoungi1', '2016/05/08', 642180, 53310);
insert into storeincome values ('gyoungi1', '2016/05/07', 709860, 93320);
insert into storeincome values ('gyoungi1', '2016/05/06', 592170, 53450);
insert into storeincome values ('gyoungi1', '2016/05/05', 621220, 45660);
insert into storeincome values ('gyoungi1', '2016/05/04', 659330, 56330);
insert into storeincome values ('gyoungi1', '2016/05/03', 512450, 56620);
insert into storeincome values ('gyoungi1', '2016/05/02', 493710, 62110);
insert into storeincome values ('gyoungi1', '2016/05/01', 653350, 56890);

insert into storeincome values ('seoul1', '2016/04/18', 16985100, 109400);
insert into storeincome values ('seoul2', '2016/04/17', 16518200, 98700);
insert into storeincome values ('incheon1', '2016/04/16', 14539500, 65800);
insert into storeincome values ('incheon2', '2016/04/15', 14924800, 64200);
insert into storeincome values ('gyoungi2', '2016/04/14', 15605300, 76300);

select * from member where m_Location1 = '경기';

delete from STOREINCOME where m_Id = 'gyoungi2'

update MEMBER set m_location1 = '인천' where m_Location1='충북'


insert into storeincome values ('seoul1', '2016/05/18', 15821300, 109400);
insert into storeincome values ('seoul2', '2016/05/17', 18421200, 98700);
insert into storeincome values ('incheon1', '2016/05/16', 13545600, 65800);
insert into storeincome values ('incheon2', '2016/05/15', 12156700, 64200);
insert into storeincome values ('gyoungi2', '2016/05/14', 16045100, 81200);
insert into storeincome values ('seoul1', '2016/04/18', 16985100, 109400);
insert into storeincome values ('seoul2', '2016/04/17', 16518200, 98700);
insert into storeincome values ('incheon1', '2016/04/16', 14539500, 65800);
insert into storeincome values ('incheon2', '2016/04/15', 14924800, 64200);
insert into storeincome values ('gyoungi2', '2016/04/14', 15605300, 76300);

insert into storeincome values ('gyoungi1', '2016/04/14', 13746780, 89340);
insert into storeincome values ('gyoungi1', '2016/03/14', 14321570, 78920);
insert into storeincome values ('gyoungi1', '2016/02/14', 15438910, 94560);
insert into storeincome values ('gyoungi1', '2016/01/14', 14995620, 69460);

insert into storeincome values ('gyoungi1', '2015/01/14', 13112890, 91490);
insert into storeincome values ('gyoungi1', '2015/02/14', 14193180, 88150);
insert into storeincome values ('gyoungi1', '2015/03/14', 16133290, 79910);
insert into storeincome values ('gyoungi1', '2015/04/14', 12945520, 69190);
insert into storeincome values ('gyoungi1', '2015/05/14', 15321990, 89210);
insert into storeincome values ('gyoungi1', '2015/06/14', 14925890, 77140);
insert into storeincome values ('gyoungi1', '2015/07/14', 11921180, 64590);
insert into storeincome values ('gyoungi1', '2015/08/14', 13698710, 75180);
insert into storeincome values ('gyoungi1', '2015/09/14', 12519420, 81390);
insert into storeincome values ('gyoungi1', '2015/10/14', 14419450, 62490);
insert into storeincome values ('gyoungi1', '2015/11/14', 15193780, 80440);
insert into storeincome values ('gyoungi1', '2015/12/14', 13049710, 71040);

insert into storeincome values ('gyoungi1', '2012/01/14', 105964200, 0);
insert into storeincome values ('gyoungi1', '2013/01/14', 135481000, 0);
insert into storeincome values ('gyoungi1', '2014/01/14', 152076300, 0);