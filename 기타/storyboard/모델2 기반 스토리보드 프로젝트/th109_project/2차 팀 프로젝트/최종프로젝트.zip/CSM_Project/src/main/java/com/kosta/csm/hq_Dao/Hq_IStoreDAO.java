package com.kosta.csm.hq_Dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.kosta.csm.vo.Criteria;
import com.kosta.csm.vo.MemberVO;
import com.kosta.csm.vo.salesStatusRankVO;

public interface Hq_IStoreDAO {
	// 매장관리
	public List<MemberVO> storePresentCondition(Criteria cri);
	
	public int storePresentConditionCount();

	public List<MemberVO> storeSearch(@Param("cri") Criteria cri, @Param("m_Store") String m_Store);
	
	public int storeSearchCount(String m_Store);

	public void storeDelete(MemberVO vo);

	public Integer salesStatus(String location);

	public List<salesStatusRankVO> salesStatusRank(String location);

	public Integer salesStatusDay(@Param("day") String day, @Param("location") String location);

	public List<salesStatusRankVO> salesStatusRankDay(@Param("location") String location, @Param("day") String day);

	

	
}
