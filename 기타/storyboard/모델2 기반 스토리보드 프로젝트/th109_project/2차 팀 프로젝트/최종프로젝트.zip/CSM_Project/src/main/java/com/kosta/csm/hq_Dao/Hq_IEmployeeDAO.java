package com.kosta.csm.hq_Dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.kosta.csm.vo.Criteria;
import com.kosta.csm.vo.EmployeeAboutStoreName;
import com.kosta.csm.vo.EmployeeVO;

public interface Hq_IEmployeeDAO {

	List<EmployeeAboutStoreName> getEmployee(Criteria cri);
	
	int getEmployeeCount();

	void addEmployee(EmployeeVO vo);
	void updateEmployeeOfNum(EmployeeVO vo);

	void updateEmployeeOfPosition(EmployeeVO vo);

	void removeEmployee(Integer e_Num);

	void updateEmployee(EmployeeVO vo);

	EmployeeVO getEmployeeOfNum(Integer e_Num);
	
	Integer maxE_num();

	String getSameM_id(EmployeeVO vo);

	List<EmployeeAboutStoreName> employeeSearch_Num(@Param("cri") Criteria cri, @Param("employee") String employee);

	int employeeSearchCount_Num(String employee);

	List<EmployeeAboutStoreName> employeeSearch_Name(@Param("cri") Criteria cri, @Param("employee") String employee);

	int employeeSearchCount_Name(String employee);

	List<EmployeeAboutStoreName> setPaySearch_Num(@Param("cri") Criteria cri, @Param("employee") String employee);

	int setPaySearchCount_Num(String employee);
	
	List<EmployeeAboutStoreName> setPaySearch_Name(@Param("cri") Criteria cri, @Param("employee") String employee);

	int setPaySearchCount_Name(String employee);

	

}
