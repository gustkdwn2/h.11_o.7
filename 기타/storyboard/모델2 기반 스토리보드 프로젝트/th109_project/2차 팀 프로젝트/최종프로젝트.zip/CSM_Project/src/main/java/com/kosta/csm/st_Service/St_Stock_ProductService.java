package com.kosta.csm.st_Service;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.kosta.csm.st_Dao.St_ISt_Stock_ProductDAO;
import com.kosta.csm.vo.Criteria;
import com.kosta.csm.vo.ProductVO;
import com.kosta.csm.vo.St_Stock_ProductVO;

@Service
public class St_Stock_ProductService implements St_ISt_Stock_ProductService {

	@Autowired
	private SqlSession sqlSession;

	
	@Override
	public List<St_Stock_ProductVO> list(Criteria cri, Model model) {
		St_ISt_Stock_ProductDAO dao = sqlSession.getMapper(St_ISt_Stock_ProductDAO.class);
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String m_Id = (String)auth.getName();
		
		model.addAttribute("count", dao.countList(m_Id));
		
		return dao.list(cri, m_Id);
	}
	
	@Override
	public List<ProductVO> stockListDetail(Criteria cri) {
		St_ISt_Stock_ProductDAO dao = sqlSession.getMapper(St_ISt_Stock_ProductDAO.class);
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String m_Id = (String)auth.getName();
		
		
		return dao.stockListDetail(cri, m_Id);
	}

	@Override
	public void deleteProducts(String[] ckb) {
		St_ISt_Stock_ProductDAO dao = sqlSession.getMapper(St_ISt_Stock_ProductDAO.class);
		for (int i = 0; i < ckb.length; i++) {
			dao.deleteProduct(ckb[i]);
		}
	}

	@Override
	public List<ProductVO> productRegList(Criteria cri, Model model) {
		St_ISt_Stock_ProductDAO dao = sqlSession.getMapper(St_ISt_Stock_ProductDAO.class);
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String m_Id = (String)auth.getName();
		
		model.addAttribute("count", dao.productListCount());
		
		List<ProductVO> list = dao.productList(cri);
		List<Integer> filter = new ArrayList<Integer>();
		
		for(int i=0; i<list.size(); i++){
			filter.add(i, dao.productFilter(m_Id, list.get(i).getHp_Code()));
		}
		
		model.addAttribute("filter", filter);
		
		return list;
	}

	@Override
	public void productReg(String[] ckb) {
		St_ISt_Stock_ProductDAO dao = sqlSession.getMapper(St_ISt_Stock_ProductDAO.class);
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String m_Id = (String)auth.getName();
		
		for (int i = 0; i < ckb.length; i++) {
			dao.insertStStock(m_Id, ckb[i]);
		}
	}

	@Override
	public List<ProductVO> productRegSearch(Criteria cri, Model model, String searchType, String productSearch) {
		St_ISt_Stock_ProductDAO dao = sqlSession.getMapper(St_ISt_Stock_ProductDAO.class);
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String m_Id = (String)auth.getName();
		
		List<ProductVO> list = new ArrayList<ProductVO>();
		
		if (searchType.equals("상품번호")) {
			list = dao.productRegSearch_hp_Code(cri, productSearch);
		} else if (searchType.equals("상품명")) {
			model.addAttribute("count", dao.productRegSearchCount_hp_Name("%" + productSearch + "%"));
			list =  dao.productRegSearch_hp_Name(cri, "%" + productSearch + "%");
		}
		
		List<Integer> filter = new ArrayList<Integer>();
		
		for(int i=0; i<list.size(); i++){
			filter.add(i, dao.productFilter(m_Id, list.get(i).getHp_Code()));
		}
		
		model.addAttribute("filter", filter);
		
		return list;
	}

	@Override
	public List<ProductVO> productRegSearch_Category(Criteria cri, Model model, String category) {
		St_ISt_Stock_ProductDAO dao = sqlSession.getMapper(St_ISt_Stock_ProductDAO.class);
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String m_Id = (String)auth.getName();
		
		List<ProductVO> list = dao.search_Category(cri, category);
		
		List<Integer> filter = new ArrayList<Integer>();
		
		for(int i=0; i<list.size(); i++){
			filter.add(i, dao.productFilter(m_Id, list.get(i).getHp_Code()));
		}
		
		model.addAttribute("filter", filter);
		
		model.addAttribute("count", dao.search_CategoryCount(category));

		return list;
	}
	
	
	
	@Override
	public List<St_Stock_ProductVO> productStockSearch(Criteria cri, Model model, String searchType,
			String productSearch) {
		St_ISt_Stock_ProductDAO dao = sqlSession.getMapper(St_ISt_Stock_ProductDAO.class);
		
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String m_Id = (String)auth.getName();
		
		if(searchType.equals("상품번호")){
			model.addAttribute("stockListDetail", dao.productStockSearch_hp_Code_Detail(cri, m_Id, productSearch));
			return dao.productStockSearch_hp_Code(cri, m_Id, productSearch);
		}else if(searchType.equals("상품명")){
			model.addAttribute("stockListDetail", dao.productStockSearch_hp_Name_Detail(cri, m_Id, "%"+productSearch+"%"));
			model.addAttribute("count", dao.productStockSearchCount_hp_Name(m_Id, "%"+productSearch+"%"));
			return dao.productStockSearch_hp_Name(cri, m_Id, "%"+productSearch+"%");
		}
		return null;
	}
	
	@Override
	public List<St_Stock_ProductVO> productStockSearch_Category(Criteria cri, Model model, String category) {
		St_ISt_Stock_ProductDAO dao = sqlSession.getMapper(St_ISt_Stock_ProductDAO.class);
		
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String m_Id = (String)auth.getName();
		
		model.addAttribute("stockListDetail", dao.search_StockCategory_Detail(cri, m_Id, category));
		model.addAttribute("count", dao.search_StockCategoryCount(m_Id, category));
		
		return dao.search_StockCategory(cri, m_Id, category);
		
	}
	

	

	

}
