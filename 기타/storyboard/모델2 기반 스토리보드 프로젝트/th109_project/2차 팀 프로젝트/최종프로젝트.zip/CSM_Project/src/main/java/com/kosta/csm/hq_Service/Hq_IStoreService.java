package com.kosta.csm.hq_Service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.ui.Model;

import com.kosta.csm.vo.Criteria;
import com.kosta.csm.vo.MemberVO;

public interface Hq_IStoreService {
	// 매장관리
	List<MemberVO> storePresentCondition(Criteria cri, Model model);

	public List<MemberVO> storeSearch(Criteria cri, Model model, HttpServletRequest request, MemberVO vo);

	String storeDelete(HttpServletRequest request, MemberVO vo);

	void salesStatus(Model model, HttpServletRequest request);

	void monthStatus(Model model, HttpServletRequest request);

	void yearStatus(Model model, HttpServletRequest request);

	

}
