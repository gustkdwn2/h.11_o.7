package com.kosta.csm.hq_Service;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.kosta.csm.hq_Dao.Hq_IStockDAO;
import com.kosta.csm.vo.Criteria;
import com.kosta.csm.vo.HqStockList;
import com.kosta.csm.vo.ProductVO;

@Service
public class Hq_StockService implements Hq_IStockService{
	
	@Autowired
	private SqlSession sqlSession;
	
	@Override
	public List<HqStockList> stockList(Criteria cri, Model model) {
		Hq_IStockDAO dao=sqlSession.getMapper(Hq_IStockDAO.class);
		
		model.addAttribute("count", dao.stockListCount());
		
		return dao.stockList(cri);
	}
	
	@Override
	public List<ProductVO> stockListDetail(Criteria cri) {
		
		Hq_IStockDAO dao = sqlSession.getMapper(Hq_IStockDAO.class);
		
		return dao.stockListDetail(cri);
	}

	@Override
	public void modify(String[] hp_Code, int[] hp_Amount) {
		Hq_IStockDAO dao=sqlSession.getMapper(Hq_IStockDAO.class);
		
		for(int i=0; i<hp_Code.length; i++){
			dao.modify(hp_Code[i], hp_Amount[i]);
		}
	}

	@Override
	public List<HqStockList> stockListSearch(Criteria cri, Model model, String productSearch, String searchType) {
		Hq_IStockDAO dao=sqlSession.getMapper(Hq_IStockDAO.class);
		
		
		if(searchType.equals("상품번호")){
			return dao.stockListSearch_hp_Code(cri, productSearch);
		}else if(searchType.equals("상품명")){
			model.addAttribute("count", dao.stockListSearchCount_hp_Name("%"+productSearch+"%"));
			return dao.stockListSearch_hp_Name(cri, "%"+productSearch+"%");
		}
		
		return null;
	}

	@Override
	public List<ProductVO> stockListDetailSearch(Criteria cri, String productSearch, String searchType) {
		Hq_IStockDAO dao = sqlSession.getMapper(Hq_IStockDAO.class);
		
		if(searchType.equals("상품번호")){
			return dao.stockListSearchDetail_hp_Code(cri, productSearch);
		}else if(searchType.equals("상품명")){
			return dao.stockListSearchDetail_hp_Name(cri, "%"+productSearch+"%");
		}
		return null;
	}

	@Override
	public List<HqStockList> stockModifyView(String[] hp_Code) {
		Hq_IStockDAO dao=sqlSession.getMapper(Hq_IStockDAO.class);
		
		List<HqStockList> list = new ArrayList<HqStockList>();
		
		for(int i=0; i<hp_Code.length; i++){
			list.add(i, dao.stockModifyView(hp_Code[i]));
		}
		
		return list;
	}




}
