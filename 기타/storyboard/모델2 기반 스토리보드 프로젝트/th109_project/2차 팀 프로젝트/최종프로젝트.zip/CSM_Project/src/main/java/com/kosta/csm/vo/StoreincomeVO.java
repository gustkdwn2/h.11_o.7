package com.kosta.csm.vo;

// 매장별 수입 테이블
public class StoreincomeVO {
	private String m_Id;		// 아이디
	private String si_Date;		// 날짜
	private int si_Sale;		// 매출액
	private int si_Expend;		// 지출액
	
	// Constructor
	public StoreincomeVO() {
	}

	public StoreincomeVO(String m_Id, String si_Date, int si_Sale, int si_Expend) {
		super();
		this.m_Id = m_Id;
		this.si_Date = si_Date;
		this.si_Sale = si_Sale;
		this.si_Expend = si_Expend;
	}

	// getter / setter
	public String getM_Id() {
		return m_Id;
	}

	public void setM_Id(String m_Id) {
		this.m_Id = m_Id;
	}

	public String getSi_Date() {
		return si_Date;
	}

	public void setSi_Date(String si_Date) {
		this.si_Date = si_Date;
	}

	public int getSi_Sale() {
		return si_Sale;
	}

	public void setSi_Sale(int si_Sale) {
		this.si_Sale = si_Sale;
	}

	public int getSi_Expend() {
		return si_Expend;
	}

	public void setSi_Expend(int si_Expend) {
		this.si_Expend = si_Expend;
	}
	
}
