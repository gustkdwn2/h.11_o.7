package com.kosta.csm.vo;

public class StoreExpendVO {
	   int se_Num;            //지출번호 (자동증가)  (PK)
	   String m_Id;           // 아이디   
	   String  se_Date;       // 지출 날짜   (sale 테이블의 판매날짜에서 '년/월/일' 만 따와서 저장)
	   int se_Expend;         // 지출금
	   String se_Content;     // 지출내역
	public int getSe_Num() {
		return se_Num;
	}
	public void setSe_Num(int se_Num) {
		this.se_Num = se_Num;
	}
	public String getM_Id() {
		return m_Id;
	}
	public void setM_Id(String m_Id) {
		this.m_Id = m_Id;
	}
	public String getSe_Date() {
		return se_Date;
	}
	public void setSe_Date(String se_Date) {
		this.se_Date = se_Date;
	}
	public int getSe_Expend() {
		return se_Expend;
	}
	public void setSe_Expend(int se_Expend) {
		this.se_Expend = se_Expend;
	}
	public String getSe_Content() {
		return se_Content;
	}
	public void setSe_Content(String se_Content) {
		this.se_Content = se_Content;
	}
}
