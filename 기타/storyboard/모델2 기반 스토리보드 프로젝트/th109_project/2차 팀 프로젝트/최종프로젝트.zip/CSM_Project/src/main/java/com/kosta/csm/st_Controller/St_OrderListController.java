package com.kosta.csm.st_Controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.kosta.csm.st_Service.St_IOrderListService;
import com.kosta.csm.vo.Criteria;
import com.kosta.csm.vo.OrderListVO;

@Controller
@RequestMapping("/st/orderList")
public class St_OrderListController {
	
	@Autowired
	private St_IOrderListService service;
	
	@RequestMapping(value="/list", method=RequestMethod.GET)
	public String list(Criteria cri, Model model){
		System.out.println("/st/orderList/list!!");
		
		model.addAttribute("orderList", service.list(cri, model));
		model.addAttribute("stockListDetail", service.stockDetail_list(cri));
		model.addAttribute("cri", cri);
		
		return "st_aside.orderList.list";
	}
	
	@RequestMapping(value="/delete", method=RequestMethod.GET)
	public String delete(HttpServletRequest request){
		System.out.println("/st/orderList/delete!!");
		
		service.delete(request.getParameter("o_Num"));
		
		return "redirect:/st/orderList/list";
	}
	
	@RequestMapping(value="/order", method=RequestMethod.GET)
	public String orderGET(Criteria cri, Model model){
		
		model.addAttribute("stock", service.stock(cri, model));
		model.addAttribute("stockListDetail", service.stockDetail_order(cri));
		model.addAttribute("cri", cri);
		
		return "st_aside.orderList.order";
	}
	
	@RequestMapping(value="/order", method=RequestMethod.POST)
	public String orderPOST(OrderListVO vo){
		System.out.println("/st/orderList/order!!");
		
		service.order(vo);
		
		return "redirect:/st/orderList/list";
	}
	
	@RequestMapping(value="/complete", method=RequestMethod.GET)
	public String orderComplete(Criteria cri, Model model){
		System.out.println("/st/orderList/complete!!");
		
		model.addAttribute("completeList", service.complete(cri, model));
		model.addAttribute("stockListDetail", service.stockDetail_complete(cri));
		model.addAttribute("cri", cri);
		return "st_aside.orderList.complete";
	}
	
	@RequestMapping(value="/orderSearch1")
	public String orderSearch1(Criteria cri, Model model, @RequestParam("searchType") String searchType,
															@RequestParam("search") String search){
		
		model.addAttribute("stock", service.orderSearch1(cri, model, searchType, search));
		model.addAttribute("cri", cri);
		model.addAttribute("searchType", searchType);
		model.addAttribute("search", search);
		model.addAttribute("check", 1);
		
		return "st_aside.orderList.order";
	}
	
	@RequestMapping(value="/orderSearch2")
	public String orderSearch2(Criteria cri, Model model, @RequestParam("category") String category){
		
		model.addAttribute("stock", service.orderSearch2(cri, model, category));
		model.addAttribute("cri", cri);
		model.addAttribute("category", category);
		model.addAttribute("check", 2);
		return "st_aside.orderList.order";
	}
}
