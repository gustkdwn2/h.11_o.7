package com.kosta.csm.vo;

public class EmployeeAboutStoreName {

		int e_Num;//  --직원코드
		String e_Name;    //--직원이름
		String e_StartDay;  //--입사일
		String e_Account;  //--계좌번호
		String e_Phone;   //--연락처
		String e_Position;  //--직급 
		String m_Store;    //--근무하는 매장이름
		int e_Pay;	//--급여 (시급 또는 월급)
		public int getE_Num() {
			return e_Num;
		}
		public void setE_Num(int e_Num) {
			this.e_Num = e_Num;
		}
		public String getE_Name() {
			return e_Name;
		}
		public void setE_Name(String e_Name) {
			this.e_Name = e_Name;
		}
		public String getE_StartDay() {
			return e_StartDay;
		}
		public void setE_StartDay(String e_StartDay) {
			this.e_StartDay = e_StartDay;
		}
		public String getE_Account() {
			return e_Account;
		}
		public void setE_Account(String e_Account) {
			this.e_Account = e_Account;
		}
		public String getE_Phone() {
			return e_Phone;
		}
		public void setE_Phone(String e_Phone) {
			this.e_Phone = e_Phone;
		}
	
		public String getE_Position() {
			return e_Position;
		}
		public void setE_Position(String e_Position) {
			this.e_Position = e_Position;
		}
		public String getM_Store() {
			return m_Store;
		}
		public void setM_Store(String m_Store) {
			this.m_Store = m_Store;
		}
		public int getE_Pay() {
			return e_Pay;
		}
		public void setE_Pay(int e_Pay) {
			this.e_Pay = e_Pay;
		}
		
	
}
