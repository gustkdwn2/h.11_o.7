package com.kosta.csm.vo;

public class HqRevenue {
	long expend;//지출
	long income;//수입
	String revenue_Date;//날짜(년월일)
	String content;//내역
	public long getExpend() {
		return expend;
	}
	public void setExpend(long expend) {
		this.expend = expend;
	}
	public long getIncome() {
		return income;
	}
	public void setIncome(long income) {
		this.income = income;
	}
	public String getRevenue_Date() {
		return revenue_Date;
	}
	public void setRevenue_Date(String revenue_Date) {
		this.revenue_Date = revenue_Date;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
}
