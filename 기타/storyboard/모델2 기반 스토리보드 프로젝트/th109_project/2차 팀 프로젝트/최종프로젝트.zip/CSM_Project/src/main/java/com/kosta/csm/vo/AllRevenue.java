package com.kosta.csm.vo;

public class AllRevenue {
	private String m_Id; // 아이디
	private long se_Expend; // 지출액
	private String se_Content; // 지출내역
	private String s_Date; // 날짜
	private long si_Sale; // 상품매출액
	private long si_Expend; // 상품지출액
	public String getM_Id() {
		return m_Id;
	}
	public void setM_Id(String m_Id) {
		this.m_Id = m_Id;
	}
	public long getSe_Expend() {
		return se_Expend;
	}
	public void setSe_Expend(long se_Expend) {
		this.se_Expend = se_Expend;
	}
	public String getSe_Content() {
		return se_Content;
	}
	public void setSe_Content(String se_Content) {
		this.se_Content = se_Content;
	}
	public String getS_Date() {
		return s_Date;
	}
	public void setS_Date(String s_Date) {
		this.s_Date = s_Date;
	}
	public long getSi_Sale() {
		return si_Sale;
	}
	public void setSi_Sale(long si_Sale) {
		this.si_Sale = si_Sale;
	}
	public long getSi_Expend() {
		return si_Expend;
	}
	public void setSi_Expend(long si_Expend) {
		this.si_Expend = si_Expend;
	}
	
}
