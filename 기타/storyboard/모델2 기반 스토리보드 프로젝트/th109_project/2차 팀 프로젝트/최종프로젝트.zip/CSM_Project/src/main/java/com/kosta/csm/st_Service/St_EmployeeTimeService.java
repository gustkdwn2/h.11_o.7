package com.kosta.csm.st_Service;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.kosta.csm.st_Dao.St_IEmployeeDAO;
import com.kosta.csm.vo.Criteria;
import com.kosta.csm.vo.EmployeeVO;
import com.kosta.csm.vo.StWorkingEmployee;

@Service
public class St_EmployeeTimeService implements  St_IEmployeeTimeService{

	@Autowired
	private SqlSession sqlSession;

	public List<StWorkingEmployee> timeList(Criteria cri, Model model) {
		System.out.println(" List<StWorkingEmployee> timeList(HttpServletRequest request)");
		//로그인한 id값 구함
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String m_Id = (String)auth.getName();
		System.out.println("m_Id: " + m_Id);

		St_IEmployeeDAO dao = sqlSession.getMapper(St_IEmployeeDAO.class);
		
		model.addAttribute("count", dao.getTimeListCount(m_Id));
		
		List<StWorkingEmployee> list = new ArrayList<StWorkingEmployee>();
		list = dao.getTimeList(cri, m_Id);
		
		
		List<EmployeeVO> detail = new ArrayList<EmployeeVO>();
		for(int i=0; i<list.size(); i++){
			detail.add(i, dao.getTimeListDetail(list.get(i).getE_Num()));
		}
		
		model.addAttribute("detail", detail);
		return list;
	}
	
	
	public List<StWorkingEmployee> employeeSearch(Criteria cri, Model model, String searchType, String employee) {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String m_Id = (String)auth.getName();
		
		St_IEmployeeDAO dao = sqlSession.getMapper(St_IEmployeeDAO.class);
		
		
		List<StWorkingEmployee> list = new ArrayList<StWorkingEmployee>();
		
		
		if(searchType.equals("직원코드")){
			list = dao.employeeSearch_Num(cri, m_Id, employee);
			model.addAttribute("count", dao.employeeSearchCount_Num(m_Id, employee));
		}else if(searchType.equals("직원명")){
			list = dao.employeeSearch_Name(cri, m_Id, "%"+employee+"%");
			model.addAttribute("count", dao.employeeSearchCount_Name(m_Id, "%"+employee+"%"));
		}
		
		
		List<EmployeeVO> detail = new ArrayList<EmployeeVO>();
		for(int i=0; i<list.size(); i++){
			detail.add(i, dao.getTimeListDetail(list.get(i).getE_Num()));
		}
		
		model.addAttribute("detail", detail);
		return list;
	}

	public void proModifyTime(StWorkingEmployee vo, HttpServletRequest request) throws ParseException {

		System.out.println("  proModifyTime(StWorkingEmployee vo)");
		System.out.println(vo.getE_Name());
		System.out.println(vo.getWt_Num());
		System.out.println(vo.getWt_EndTime());
		System.out.println(vo.getWt_StartTime());
		System.out.println(vo.getE_Num());
		St_IEmployeeDAO st_IEmployeeDAO = sqlSession.getMapper(St_IEmployeeDAO.class);
		System.out.println("update end ");
	
		String yyyy1 =  request.getParameter("yyyy1");
		String mm1 =  request.getParameter("mm1");
		String dd1 =  request.getParameter("dd1");
		String hh1 =  request.getParameter("hh1");
		String mi1 =  request.getParameter("mi1");
		String ss1 =  request.getParameter("ss1");
		String yyyy2 =  request.getParameter("yyyy2");
		String mm2 =  request.getParameter("mm2");
		String dd2 =  request.getParameter("dd2");
		String hh2 =  request.getParameter("hh2");
		String mi2 =  request.getParameter("mi2");
		String ss2 =  request.getParameter("ss2");
		
		String from1 = yyyy1 +"-"+mm1+"-"+dd1+" "+hh1+":"+mi1+":"+ss1;
		String from2 = yyyy2 +"-"+mm2+"-"+dd2+" "+hh2+":"+mi2+":"+ss2;
		SimpleDateFormat transFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date to1 = transFormat.parse(from1);
		Date to2 = transFormat.parse(from2);
		System.out.println(to1);
		System.out.println(to2);
		st_IEmployeeDAO.proModifyTime(vo.getWt_Num(),vo.getE_Num(),to1,to2);
	}

	

}
