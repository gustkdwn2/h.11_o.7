package com.kosta.csm.vo;

public class HqStockList {
	private String hp_Code;
	private String hp_Name;
	private int hp_Oprice;
	private int hp_Mprice;
	private int hp_Cprice;
	private int hp_Amount;
	private String hp_Path;
	

	public HqStockList(){
		
	}
	
	public HqStockList(String hp_Code, String hp_Name, int hp_Oprice, int hp_Mprice, int hp_Cprice, int hp_Amount) {
		this.hp_Code = hp_Code;
		this.hp_Name = hp_Name;
		this.hp_Oprice = hp_Oprice;
		this.hp_Mprice = hp_Mprice;
		this.hp_Cprice = hp_Cprice;
		this.hp_Amount = hp_Amount;
	}

	public String getHp_Code() {
		return hp_Code;
	}
	public void setHp_Code(String hp_Code) {
		this.hp_Code = hp_Code;
	}
	public String getHp_Name() {
		return hp_Name;
	}
	public void setHp_Name(String hp_Name) {
		this.hp_Name = hp_Name;
	}
	public int getHp_Oprice() {
		return hp_Oprice;
	}
	public void setHp_Oprice(int hp_Oprice) {
		this.hp_Oprice = hp_Oprice;
	}
	public int getHp_Mprice() {
		return hp_Mprice;
	}
	public void setHp_Mprice(int hp_Mprice) {
		this.hp_Mprice = hp_Mprice;
	}
	public int getHp_Cprice() {
		return hp_Cprice;
	}
	public void setHp_Cprice(int hp_Cprice) {
		this.hp_Cprice = hp_Cprice;
	}
	public int getHp_Amount() {
		return hp_Amount;
	}
	public void setHp_Amount(int hp_Amount) {
		this.hp_Amount = hp_Amount;
	}
	public String getHp_Path() {
		return hp_Path;
	}
	public void setHp_Path(String hp_Path) {
		this.hp_Path = hp_Path;
	}
	
}
