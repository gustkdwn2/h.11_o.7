package com.kosta.csm.hq_Dao;

import java.util.List;

import com.kosta.csm.vo.Criteria;
import com.kosta.csm.vo.CriteriaIndex;
import com.kosta.csm.vo.MemberVO;

public interface Hq_IMemberDAO {
	
	// 회원가입 승인
	public List<MemberVO> approvalList(Criteria cri);
	
	public int approvalListCount();
	
	public List<MemberVO> indexApprovalList(CriteriaIndex cri);

	public int indexApprovalListCount();

	public void updateState(String m_Id);
	
	public void insertGrade(String m_Id);
	
	public void insertGradeHq(String m_Id);
	
	public String selectM_Store(String m_Id);
	
	
	// 회원정보 수정
	public List<MemberVO> memberList();

	public String modify(String m_Id);

	public String check(String parameter);

	public void memberModify(MemberVO vo);
	
	public void pwdModify(MemberVO vo);
	
	public void memberLeave(MemberVO vo);

	public MemberVO searchById(String m_Id);

	public void mstateDelete(String m_Id);
}
