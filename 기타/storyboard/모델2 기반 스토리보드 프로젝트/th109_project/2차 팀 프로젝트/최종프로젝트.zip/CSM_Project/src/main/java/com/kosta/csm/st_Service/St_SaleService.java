package com.kosta.csm.st_Service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.stereotype.Service;

import com.kosta.csm.st_Dao.St_IEmployeeDAO;
import com.kosta.csm.st_Dao.St_IProductDAO;
import com.kosta.csm.st_Dao.St_ISaleDAO;
import com.kosta.csm.st_Dao.St_ISaleProductDAO;
import com.kosta.csm.st_Dao.St_ISt_StockDAO;
import com.kosta.csm.st_Dao.St_IStoreIncomeDAO;
import com.kosta.csm.st_Dao.St_IWorkingTimeDAO;
import com.kosta.csm.vo.SaleProduct;
import com.kosta.csm.vo.SaleVO;
import com.kosta.csm.vo.StStockVO;
import com.kosta.csm.vo.StWorkingEmployee;
import com.kosta.csm.vo.StoreincomeVO;

@Service
public class St_SaleService implements St_ISaleService {

   @Autowired
   private SqlSession sqlSession;

   @Override
   public void addSaleProduct(List<SaleProduct> saleList, String code, String amount) {
      // TODO Auto-generated method stub
      System.out.println("St_SaleService  addSaleProduct(List<SaleProductVO> "
            + "saleList, String code, int amount)");
      if (saleList == null) {
         System.out.println("saleList == null");
         saleList = new ArrayList<SaleProduct>();
      }
      int IAmount = 0;// 수량
      try {
         IAmount = Integer.parseInt(amount);// 문자로 받아온 수량값 형변환
      } catch (Exception e) {
         System.out.println("수량에 글자입력시 처리 안함  (amount: " + amount + ")");
         return;
      }
      if (IAmount <= 0 || code.length() == 0) {
         System.out.println("수량 또는 상품코드를 받아오지 못핟거나 수량(IAmount) 0개 이하");
         return;
      }
      System.out.println("code :" + code + "// IAmount : " 
            + IAmount + " => 두 값으로 상품(product)db에서  실제 상품 하나 가져옴");
      St_ISaleProductDAO dao = sqlSession.getMapper(St_ISaleProductDAO.class);
      SaleProduct vo = new SaleProduct();
      vo.setHp_Code(code);
      vo.setS_Amount(IAmount);
      try {
         System.out.println("send some information vo");
         vo = dao.getSale(vo);
         System.out.println("success get full information vo :" + dao.getSale(vo).getHp_Code() + "/"
               + dao.getSale(vo).getHp_Name());
      } catch (Exception e) {
         System.out.println("fail get full information vo");
         return;
      }
      // 상품이중복되면 양만증가시킨다.
      int originalAmount = 0;
      int currenAmount = 0;
      int resultAmount = 0;
      for (int a = 0; a < saleList.size(); a++) {
         if (saleList.get(a).getHp_Code().equals(vo.getHp_Code())) {
            System.out.println("중복되므로 양만증가");
            // 기존수량에 수를 더함
            originalAmount = saleList.get(a).getS_Amount();// 이미 등록된 상품의 수량
            currenAmount = vo.getS_Amount();// 현제 입력한 상품의수량
            resultAmount = originalAmount + currenAmount;
            saleList.get(a).setS_Amount(resultAmount);//기존 올라온 상품의 수량을 재셋팅
            return;// 같은 코드의 상품을 찾으면 더이상 찾지않음
         }
      }
      // 중복된게 아니었으면 리스트에 희망제품 추가
      saleList.add(vo);
      System.out.println("중복안되었으므로 구매 희망 상품을 리스트에 추가");
      System.out.println("dao.getSale(vo) success \n");
      return;// 같은 코드의 상품을 찾으면 더이상 찾지않음
   }

   @Override
   public void delSaleProduct(List<SaleProduct> saleList, String code) {
      // TODO Auto-generated method stub
      System.out.println("St_SaleService  delSaleProduct(List<SaleProductVO> saleList, String code)");
      for (int a = 0; a < saleList.size(); a++) {
         if (saleList.get(a).getHp_Code().equals(code)) {
            saleList.remove(a);
            System.out.println("삭제 성공 !   삭제한 상품코드 : " + code + "\n");
            return;
         }
      }
      System.out.println();
      return;
   }

   @Override
   public int allPrice(List<SaleProduct> saleList) {
      System.out.println("St_SaleService  allPrice(List<SaleProductVO> saleList)");
      int sum = 0;
      // 포스기에 찍혀있는 상품들의 총액 계산
      for (int a = 0; a < saleList.size(); a++)
         sum += (saleList.get(a).getHp_Cprice() * saleList.get(a).getS_Amount());
      System.out.println(sum + "를 반환");
      return sum;
   }

   @Override
   public int moneyCalculation(List<SaleProduct> saleList, String receiveMoney) {
      System.out.println("St_SaleService  moneyCalculation(List<SaleProductVO> saleList, String receiveMoney)");
      int IReceiveMoney = 0;
      try {
         IReceiveMoney = Integer.parseInt(receiveMoney);
      } catch (Exception e) {
         return 0;
      }
      System.out.println(IReceiveMoney + "-" + allPrice(saleList) + "를 반환");
      return IReceiveMoney - allPrice(saleList);
   }

   @Override
   public void endPaperMoney(HttpServletRequest request, List<SaleProduct> saleList) {
      System.out.println("St_SaleService  endPaperMoney(HttpRequest request,List<SaleProductVO> saleList)");

      // dao생성 다음의 table3개 접근필요
      St_ISaleDAO st_ISaleDAO = sqlSession.getMapper(St_ISaleDAO.class);
      St_ISt_StockDAO st_ISt_StockDAO = sqlSession.getMapper(St_ISt_StockDAO.class);
      
      //로그인한 id값 구함
      HttpSession session = request.getSession();
      SecurityContext value = (SecurityContext) session.getAttribute("SPRING_SECURITY_CONTEXT");
      Authentication authentication = value.getAuthentication();
      String m_Id = authentication.getName();
      System.out.println("-");
      //db연결dao, 판매될 상품정보리스트, 로그인한 id를 통해 판매와 관련된 테이블정보 수정
      if(saleList.size() > 0){//판매할 상품이 목록에 존재하면
         System.out.println("1-");
         increaseStoreIncome(saleList, m_Id);//매장의 수익내역증가
         System.out.println("2-");
         increaseSale(st_ISaleDAO, saleList, m_Id);//판매내역 증가
         System.out.println("3-");
         decreaseStock(st_ISt_StockDAO, saleList, m_Id);//재고량 감소
         System.out.println("4-");
         saleList.clear();//판매할 상품이 목록들 비우기
      }
   }

   private void increaseSale(St_ISaleDAO st_ISaleDAO, List<SaleProduct> saleList, String m_Id) {
      System.out.println("increaseSale(St_ISaleDAO st_ISaleDAO, List<SaleProductVO> saleList, String m_Id)");
      int s_Group;// number not null, -- s_Group : 구매그룹번호
      int s_Amount;// number not null, -- s_Amount : 판매수량
      String hp_Code;//  상품코드   (FK : product)
      SaleVO saleVO = new SaleVO();

      //m_id , s_Group 를 가져옴
      System.out.println("m_Id: "+ m_Id);
      s_Group = st_ISaleDAO.getMaxGroupNum(m_Id) + 1;//그룹번호 하나 증가시켜 묶어서 추가
      System.out.println("s_Group: " + s_Group);
      //하나의 그룹번호내 상품들을 각각 모두 추가
      for(int a =0; a< saleList.size(); a++){
         //한번구매할때의 등록되는 상품들의 s_Amount, hp_Code 를 가져옴
         hp_Code = saleList.get(a).getHp_Code();
         System.out.println("hp_Code: " + hp_Code);
         s_Amount = saleList.get(a).getS_Amount();
         System.out.println("s_Amount: " + s_Amount);
         //판매내역 정보 설정
         saleVO.setHp_Code(hp_Code);
         saleVO.setM_Id(m_Id);
         saleVO.setS_Amount(s_Amount);
         saleVO.setS_Group(s_Group);
         //판매내역 정보 추가
         st_ISaleDAO.insert(saleVO);
         System.out.println(m_Id + "매장의  "+ s_Group + "번째 구매한 사람의 "+ a  + "번째 판매상품 추가 완료");
      }
      System.out.println(saleList.size() + "개 판매내역 insert 성공 \n");
   }

   private void decreaseStock(St_ISt_StockDAO st_ISt_StockDAO, List<SaleProduct> saleList, String m_Id) {
      System.out.println("St_SaleService  decreaseStock(St_ISt_StockDAO st_ISt_StockDAO, List<SaleProductVO> saleList, String m_Id)");
      String hp_Code;// 상품코드(바코드) (PK) (FK : product)
      int st_Amount;//  재고 수량
      StStockVO stStockVO = new StStockVO();
      for(int a=0; a < saleList.size(); a++){
         //m_id, hp_Code, st_Amount 획득
         System.out.println(a);
         System.out.println("M_Id:" + m_Id);
         stStockVO.setM_Id(m_Id);
         System.out.println(saleList.get(1).getHp_Code());
         hp_Code = saleList.get(a).getHp_Code();
         stStockVO.setHp_Code(hp_Code);
         System.out.println("hp_Code:" + hp_Code);
         stStockVO = st_ISt_StockDAO.getRealStock(stStockVO);
         System.out.println("가저온 vo : " + stStockVO);
         if(stStockVO != null){//재고에 등록돼있지동않는 상품이면
            System.out.println("get st_stock  is not null");
            st_Amount = stStockVO.getSt_Amount();//기존 재고량 
            System.out.println("기존 St_Amount(재고량):" +st_Amount);
            st_Amount -= saleList.get(a).getS_Amount();//판매량만큼 재고량 감소
            stStockVO.setSt_Amount(st_Amount);//감소적용
            System.out.println("변경되는 St_Amount:" +st_Amount);
            //획득한 정보로 업데이트(재고량 감소)
            st_ISt_StockDAO.updateDecrease(stStockVO);//감소적용한vo로 update
         }else{
            stStockVO = new StStockVO();
         }
         System.out.println("적용완료!");
      }
      System.out.println(saleList.size() + "개 종류의 상품재고 업데이트 \n");
   }

   private void increaseStoreIncome(List<SaleProduct> saleList, String m_Id) {
      System.out.println("St_SaleService  increaseStoreIncome(List<SaleProductVO> saleList, String m_Id)");
      String si_Date;// si_Date : 날짜 (PK)(sale 테이블의 판매날짜에서 '년/월/일' 만 저장)
      St_IStoreIncomeDAO st_IStoreIncomeDAO = sqlSession.getMapper(St_IStoreIncomeDAO.class);
      
      //m_Id, si_Date 획득
      System.out.println("m_Id: " + m_Id);
      SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
      si_Date = dateFormat.format(Calendar.getInstance().getTime());
      System.out.println("si_Date: " + si_Date);
      StoreincomeVO storeincomeVO = new StoreincomeVO();
      
      //m_Id, si_Date로 실제 레코드 가저옴
      storeincomeVO.setM_Id(m_Id);
      storeincomeVO.setSi_Date(si_Date);
      StoreincomeVO searchedVO = null;
      searchedVO = st_IStoreIncomeDAO.getSameDateSale(storeincomeVO);
      if(searchedVO != null){//매출지출 기록이 있으면
         increaseOriginalIncome(saleList, storeincomeVO);//같은날 등록되있던 지출 매출액에 매출 지출액 더함
      }else{//매출지출 기록이 없으면
         increaseFirstIncome(saleList, storeincomeVO);//같은날 등록된 매출지출내역이없으면 새로 추가
      }
   }
   public void increaseOriginalIncome(List<SaleProduct> saleList, StoreincomeVO storeincomeVO){
      System.out.println("increaseOriginalIncome(List<SaleProductVO> saleList,"
            + "St_ISt_StockDAO st_ISt_StockDAO, StoreincomeVO storeincomeVO) ");

      String hp_Code;
      int si_Sale=0;// number default 0, -- si_Sale : 매출액 
      int si_Expend=0;// number default 0, -- si_Expend : 지출액
      St_IProductDAO st_IProductDAO = sqlSession.getMapper(St_IProductDAO.class);
      St_IStoreIncomeDAO st_IStoreIncomeDAO = sqlSession.getMapper(St_IStoreIncomeDAO.class);
      
      //m_Id 와 si_Date로  ->  si_Sale와 si_Expend 획득
      storeincomeVO = st_IStoreIncomeDAO.getSameDateSale(storeincomeVO);
      System.out.println("매장에서 같은날 판매한적있음 (일별 매출 지출 수정)");
      si_Sale = storeincomeVO.getSi_Sale();
      System.out.println("기존 si_Sale: " + si_Sale);
      si_Expend = storeincomeVO.getSi_Expend();
      System.out.println("기존 si_Expend: " + si_Expend);

      //지출 매출액 새롭게 계산 하여 수정
      for(int a =0; a< saleList.size(); a++){
         //수정할 매출액과 지출액 계산
         si_Sale +=  saleList.get(a).getHp_Cprice() * 
               saleList.get(a).getS_Amount();//매출에  어떤상품수량*판매가를 더함
         hp_Code = saleList.get(a).getHp_Code();
         si_Expend += st_IProductDAO.getVo(hp_Code).getHp_Mprice()
               * saleList.get(a).getS_Amount();//지출에 어떤상품수량*중간값을 더함
         System.out.println("hp_Code: " + hp_Code );
         System.out.println(a + "번째 등록된 상품  매출 가격 " + saleList.get(a).getHp_Cprice() * 
               saleList.get(a).getS_Amount() );
         System.out.println(a + "번째 등록된 상품  지출 가격 " + st_IProductDAO.getVo(hp_Code).getHp_Mprice()
               * saleList.get(a).getS_Amount() );
      }
      
      //계산된 정보들로 매장수익내역 추가
      storeincomeVO.setSi_Expend(si_Expend);
      storeincomeVO.setSi_Sale(si_Sale);
      System.out.println("수정될 최종 si_Sale: " + si_Sale);
      System.out.println("수정될 최종 si_Expend: " + si_Expend);
      st_IStoreIncomeDAO.updatePresentProduct(storeincomeVO);
      System.out.println("매장수익 매출액 지출액 업데이트완료\n");
   }
   public void increaseFirstIncome(List<SaleProduct> saleList, StoreincomeVO storeincomeVO){
      System.out.println("increaseFirstIncome(List<SaleProductVO> saleList,St_ISt_StockDAO "
            + "st_ISt_StockDAO, StoreincomeVO storeincomeVO)");
      
      System.out.println("매장에서  첫판매 (해당매장 해당날짜(일별 단위)로 새롭게 저장)");
      System.out.println("기존 si_Sale: 가저온 레코드없음");
      System.out.println("기존 si_Expend:가저온 레코드없음");
      int si_Sale=0;// number default 0, -- si_Sale : 매출액 
      int si_Expend=0;// number default 0, -- si_Expend : 지출액
      String hp_Code;
      St_IProductDAO st_IProductDAO = sqlSession.getMapper(St_IProductDAO.class);
      St_IStoreIncomeDAO st_IStoreIncomeDAO = sqlSession.getMapper(St_IStoreIncomeDAO.class);
      
      System.out.println(saleList.size() );
      for(int a =0; a< saleList.size(); a++){
         //수정할 매출액과 지출액 계산
         si_Sale +=  saleList.get(a).getHp_Cprice() * 
               saleList.get(a).getS_Amount();//매출에  어떤상품수량*판매가를 더함
         hp_Code = saleList.get(a).getHp_Code();
         si_Expend += st_IProductDAO.getVo(hp_Code).getHp_Mprice()
               * saleList.get(a).getS_Amount();//지출에 어떤상품수량*중간값을 더함
         System.out.println("hp_Code: " + hp_Code );
         System.out.println(a + "번째 등록된 상품  매출 가격 " + saleList.get(a).getHp_Cprice() * 
               saleList.get(a).getS_Amount() );
         System.out.println(a + "번째 등록된 상품  지출 가격 " + st_IProductDAO.getVo(hp_Code).getHp_Mprice()
               * saleList.get(a).getS_Amount() );
      }
      storeincomeVO.setSi_Expend(si_Expend);
      storeincomeVO.setSi_Sale(si_Sale);
      System.out.println("새로추가하는 si_Sale: " + si_Sale);
      System.out.println("새로추가하는 si_Expend: " + si_Expend);
      st_IStoreIncomeDAO.insertNewProduct(storeincomeVO);
      System.out.println("매장수익 매출액 지출액 새롭게 추가완료\n");
      return;
   }

   public boolean setEndTime(Integer e_Num,HttpServletRequest request) {
      System.out.println("EndEmployee(Integer e_Num)  parameter : " +e_Num );
      St_IWorkingTimeDAO st_IWorkingTimeDAO = sqlSession.getMapper(St_IWorkingTimeDAO.class);
      HttpSession session = request.getSession();
      SecurityContext value = (SecurityContext) session.getAttribute("SPRING_SECURITY_CONTEXT");
      Authentication authentication = value.getAuthentication();
      String m_Id = authentication.getName();
      System.out.println("m_Id: " + m_Id);
      
      if(st_IWorkingTimeDAO.checkWorkingEmployee(e_Num,m_Id) != null){
         System.out.println("근무중인 번호이면(시작=끝   =>초기출근값을뜻함)     퇴근기록 ");
         st_IWorkingTimeDAO.enrollLastTime(e_Num);
         return true;
      }else{
         System.out.println("근무중에 있는 번호가아니면(시작!= 끝시간)       퇴근기록못함");
         return false;
      }
   }

   public  boolean setStartTime (Integer e_Num,HttpServletRequest request) {
      System.out.println("setStartTime(Integer e_Num)  parameter : " +e_Num );
      St_IWorkingTimeDAO st_IWorkingTimeDAO = sqlSession.getMapper(St_IWorkingTimeDAO.class);
      St_IEmployeeDAO st_IEmployeeDAO = sqlSession.getMapper(St_IEmployeeDAO.class);
      
      HttpSession session = request.getSession();
      SecurityContext value = (SecurityContext) session.getAttribute("SPRING_SECURITY_CONTEXT");
      Authentication authentication = value.getAuthentication();
      String m_Id = authentication.getName();
      System.out.println("m_Id: " + m_Id);
      System.out.println("e_num: " + e_Num);
      
      System.out.println("count :"+ st_IWorkingTimeDAO.checkFirstWorkingEmployee(e_Num,m_Id) );
      System.out.println(st_IWorkingTimeDAO.checkWorkedEmployee(e_Num,m_Id));
      System.out.println(st_IEmployeeDAO.checkExistEmployee(e_Num,m_Id));
      if(st_IWorkingTimeDAO.checkWorkedEmployee(e_Num,m_Id) != null ){//새로시작할수있는직원임
         System.out.println("근무끝난(퇴근처리된) 번호이면(시작!=끝   =>퇴근처리값 을뜻함)  출근기록 ");
         st_IWorkingTimeDAO.enrollStartTime(e_Num);
         return true;
      }else if(st_IWorkingTimeDAO.checkFirstWorkingEmployee(e_Num,m_Id) == 0 && st_IEmployeeDAO.checkExistEmployee(e_Num,m_Id) != 0){
         System.out.println("처음 일하는 직원이면   출근기록이없음    출근기록");
         st_IWorkingTimeDAO.enrollStartTime(e_Num);
         return true;
      }else{
         System.out.println("근무끝나지않는(퇴근미처리)번호이면(시작== 끝시간)    출근기록못함");
         return false;
      }
   }
   public List<StWorkingEmployee> WorkingEmployeeList(HttpServletRequest request) {
      System.out.println("List<StWorkingEmployee> WorkingEmployeeList()");
      //로그인한 id값 구함
      HttpSession session = request.getSession();
      SecurityContext value = (SecurityContext) session.getAttribute("SPRING_SECURITY_CONTEXT");
      Authentication authentication = value.getAuthentication();
      String m_Id = authentication.getName();
      System.out.println("m_Id: " + m_Id);
      
      St_IEmployeeDAO st_IEmployeeDAO = sqlSession.getMapper(St_IEmployeeDAO.class);
      System.out.println("querry get size : " +  st_IEmployeeDAO.getWorkingEmployee(m_Id));
      return st_IEmployeeDAO.getWorkingEmployee(m_Id);
   }


   

   
   
   
   
}