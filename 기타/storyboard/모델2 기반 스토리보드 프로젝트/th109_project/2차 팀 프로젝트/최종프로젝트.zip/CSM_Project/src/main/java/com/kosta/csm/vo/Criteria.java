package com.kosta.csm.vo;

// 페이징 처리
public class Criteria {
	private int pageNum;
	private int pageSize = 10;
	private int currentPage;
	
	
	public Criteria(){
		this.pageNum = 1;
		this.pageSize = 10;
	}
	
	
	public void setPageNum(int pageNum){
		if(pageNum <= 0){
			this.pageNum = 1;
			return;
		}// if
		
		this.pageNum = pageNum;
	}
	
	public int getPageStart(){
		currentPage = pageNum;
		if(pageSize==10){
			return (currentPage * pageSize) -9;
		}else if(pageSize==12){
			return (currentPage * pageSize) -11;
		}
		return (currentPage * pageSize) -9;
	}
	
	public int getPageEnd(){
		currentPage = pageNum;
		return (currentPage * pageSize);
	}


	public int getPageNum() {
		return pageNum;
	}

	public void setPageSize(int pageSize){
		this.pageSize = pageSize;
	}
	public int getPageSize() {
		return pageSize;
	}


	public int getCurrentPage() {
		return currentPage;
	}
	
	
	
}
