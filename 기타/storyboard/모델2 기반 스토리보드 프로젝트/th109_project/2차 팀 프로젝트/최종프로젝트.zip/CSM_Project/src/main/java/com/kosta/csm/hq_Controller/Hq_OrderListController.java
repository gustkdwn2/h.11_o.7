package com.kosta.csm.hq_Controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.kosta.csm.hq_Service.Hq_IOrderListService;
import com.kosta.csm.vo.Criteria;

@Controller
@RequestMapping("/hq")
public class Hq_OrderListController {

	@Autowired
	private Hq_IOrderListService service;

	@RequestMapping(value = "/index/ostateUpdate", method = RequestMethod.GET)
	public String update(HttpServletRequest request, @RequestParam("ckb2") String[] ckb) {
		service.updateStates(ckb);
		return "redirect:/hq/index/adminIndex";
	}
	
	// 발주 요청
	@RequestMapping(value = "/order/orderApproval", method = RequestMethod.GET)
	public String orderlist(Criteria cri, Model model) {
		System.out.println("orderApproval");
		
		model.addAttribute("list", service.orderApprovalList(cri, model));
		model.addAttribute("listDetail", service.orderApprovalListDetail(cri));
		model.addAttribute("cri", cri);
		return "hq_aside.order.orderApproval";
	}

	@RequestMapping(value = "/order/ostateUpdate", method = RequestMethod.POST)
	public String updateStatePost(HttpServletRequest request, @RequestParam("ckb") String[] ckb) {
		service.updateStates(ckb);
		return "redirect:/hq/order/orderApproval";
	}
	
	@RequestMapping(value="/order/orderDelete")
	public String orderDelete(@RequestParam("ckb") String[] ckb){
		service.orderDelete(ckb);
		return "redirect:/hq/order/orderApproval";
	}
	
	
	// 발주 승인
	@RequestMapping(value = "/order/compList", method = RequestMethod.GET)
	public String complist(Criteria cri, Model model) {
		
		model.addAttribute("list", service.orderCompleteList(cri, model));
		model.addAttribute("listDetail", service.orderCompleteListDetail(cri));
		model.addAttribute("cri", cri);
		return "hq_aside.order.orderComplete";
	}

	@RequestMapping(value = "/order/ostateCancel", method = RequestMethod.POST)
	public String cancelStatePost(HttpServletRequest request, @RequestParam("ckb") String[] ckb) {
		service.cancelStates(ckb);
		return "redirect:/hq/order/compList";
	}
	
	// 발주 완료
	@RequestMapping(value="/order/orderFinish")
	public String finish(Criteria cri, Model model){
		model.addAttribute("list", service.orderFinishList(cri, model));
		model.addAttribute("listDetail", service.orderFinishListDetail(cri));
		model.addAttribute("cri", cri);
		return "hq_aside.order.orderFinish";
	}
	
	// orderComplete -> orderFinish
	
	@RequestMapping(value="/order/ostateFinish")
	public String ostateFinish(@RequestParam("ckb") String[] ckb){
		System.out.println("ostateFinish!!");
		service.ostateFinish(ckb);
		return "redirect:/hq/order/compList";
	}
	
	// orderComplete -> orderApproval
	@RequestMapping(value="/order/ostateApproval")
	public String ostateApproval(@RequestParam("ckb") String[] ckb){
		service.ostateApproval(ckb);
		return "redirect:/hq/order/compList";
	}
}
