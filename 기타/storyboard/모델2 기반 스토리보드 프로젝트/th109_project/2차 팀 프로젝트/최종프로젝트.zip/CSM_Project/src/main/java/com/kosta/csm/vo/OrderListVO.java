package com.kosta.csm.vo;

import java.util.Date;

public class OrderListVO {
	private int o_Num;
	private String hp_Code;
	private String m_Id;
	private int o_Amount;
	private Date o_Date;
	private int o_State;
	
	//생성자
	public OrderListVO(){
		
	}
	
	public OrderListVO(int o_Num, String hp_Code, String m_Id, int o_Amount, int o_State) {
		this.o_Num = o_Num;
		this.hp_Code = hp_Code;
		this.m_Id = m_Id;
		this.o_Amount = o_Amount;
		this.o_State = o_State;
	}

	//getter setter
	public int getO_Num() {
		return o_Num;
	}
	public void setO_Num(int o_Num) {
		this.o_Num = o_Num;
	}
	public String getHp_Code() {
		return hp_Code;
	}
	public void setHp_Code(String hp_Code) {
		this.hp_Code = hp_Code;
	}
	public String getM_Id() {
		return m_Id;
	}
	public void setM_Id(String m_Id) {
		this.m_Id = m_Id;
	}
	public int getO_Amount() {
		return o_Amount;
	}
	public void setO_Amount(int o_Amount) {
		this.o_Amount = o_Amount;
	}
	public Date getO_Date() {
		return o_Date;
	}
	public void setO_Date(Date o_Date) {
		this.o_Date = o_Date;
	}
	public int getO_State() {
		return o_State;
	}
	public void setO_State(int o_State) {
		this.o_State = o_State;
	}
	
	
}
