package com.kosta.csm.st_Dao;

import java.util.Date;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.kosta.csm.vo.Criteria;
import com.kosta.csm.vo.EmployeeVO;
import com.kosta.csm.vo.StWorkingEmployee;

public interface St_IEmployeeDAO {
	public Integer checkExistEmployee(@Param("e_Num") Integer e_Num, @Param("m_Id") String m_Id  );
	
	public List<StWorkingEmployee> getWorkingEmployee(String m_Id);

	public List<StWorkingEmployee>  getTimeList(@Param("cri") Criteria cri, @Param("m_Id") String m_Id);

	public void proModifyTime(@Param("wt_Num") Integer wt_Num,
			@Param("e_Num") Integer Integer,
			@Param("to1") Date to1, @Param("to2") Date to2);

	public int getTimeListCount(String m_Id);

	public EmployeeVO getTimeListDetail(int e_Num);

	public List<StWorkingEmployee> employeeSearch_Num(@Param("cri") Criteria cri, @Param("m_Id") String m_Id, @Param("employee") String employee);

	public List<StWorkingEmployee> employeeSearch_Name(@Param("cri") Criteria cri, @Param("m_Id") String m_Id, @Param("employee") String employee);

	public int employeeSearchCount_Name(@Param("m_Id") String m_Id, @Param("employee") String employee);

	public int employeeSearchCount_Num(@Param("m_Id") String m_Id, @Param("employee") String employee);
}
