package com.kosta.csm.hq_Service;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.kosta.csm.hq_Dao.Hq_IOrderListDAO;
import com.kosta.csm.vo.Criteria;
import com.kosta.csm.vo.CriteriaIndex;
import com.kosta.csm.vo.OrderListVO;
import com.kosta.csm.vo.OrderList_MemberVO;
import com.kosta.csm.vo.OrderList_ProductVO_2;
import com.kosta.csm.vo.StStockVO;

@Service
public class Hq_OrderListService implements Hq_IOrderListService {

	@Autowired
	private SqlSession sqlSession;

	@Override
	public List<OrderList_MemberVO> indexApprovalList(CriteriaIndex cri, Model model) {
		Hq_IOrderListDAO dao = sqlSession.getMapper(Hq_IOrderListDAO.class);
		model.addAttribute("o_Count", dao.indexApprovalListCount());
		
		return dao.indexApprovalList(cri);
	}
	
	@Override
	public List<List<OrderList_ProductVO_2>> orderApprovalListDetail2(CriteriaIndex cri) {
		Hq_IOrderListDAO dao = sqlSession.getMapper(Hq_IOrderListDAO.class);
		
		List<OrderList_MemberVO> list=dao.indexApprovalList(cri);
		
		OrderList_ProductVO_2 vo=new OrderList_ProductVO_2();
		
		List<List<OrderList_ProductVO_2>> list2=new ArrayList();
		
		for(int i=0; i<list.size(); i++){
			list2.add(dao.orderApprovalDetail(list.get(i).getM_Id(), list.get(i).getO_Date()));
		}

		return list2;
	}

	@Override
	public void updateStates(String[] ckb) {
		Hq_IOrderListDAO dao = sqlSession.getMapper(Hq_IOrderListDAO.class);
		
		for(int i=0; i<ckb.length; i++){
			// search state 0
			List<OrderListVO> stock = dao.getCodeAmount(ckb[i].split(" ")[0], ckb[i].split(" ")[1]);
			for(int j=0; j<stock.size(); j++){
				// state set 1
				dao.updateStates(stock.get(j).getO_Num());
			}
		}
	}
	
	@Override
	public void orderDelete(String[] ckb) {
		Hq_IOrderListDAO dao = sqlSession.getMapper(Hq_IOrderListDAO.class);
		
		for(int i=0; i<ckb.length; i++){
			// search state 0
			List<OrderListVO> stock = dao.getCodeAmount(ckb[i].split(" ")[0], ckb[i].split(" ")[1]);
			// delete
			for(int j=0; j<stock.size(); j++){
				dao.orderDelete(stock.get(j).getO_Num());
			}
		}
	}


	@Override
	public void cancelStates(String[] ckb) {
		Hq_IOrderListDAO dao = sqlSession.getMapper(Hq_IOrderListDAO.class);
		
		for(int i=0; i<ckb.length; i++){
			dao.cancelStates(ckb[i].split(" ")[0], ckb[i].split(" ")[1]);
		}
	}

	@Override
	public List<OrderList_MemberVO> orderApprovalList(Criteria cri, Model model) {
		Hq_IOrderListDAO dao = sqlSession.getMapper(Hq_IOrderListDAO.class);
		
		model.addAttribute("count", dao.indexApprovalListCount());
		
		return dao.orderApprovalList(cri);
	}

	@Override
	public List<List<OrderList_ProductVO_2>> orderApprovalListDetail(Criteria cri) {
		Hq_IOrderListDAO dao = sqlSession.getMapper(Hq_IOrderListDAO.class);
		
		List<OrderList_MemberVO> list=dao.orderApprovalList(cri);
		
		OrderList_ProductVO_2 vo=new OrderList_ProductVO_2();
		
		List<List<OrderList_ProductVO_2>> list2=new ArrayList();
		
		for(int i=0; i<list.size(); i++){
			list2.add(dao.orderApprovalDetail(list.get(i).getM_Id(), list.get(i).getO_Date()));
		}

		return list2;
	}

	@Override
	public List<OrderList_MemberVO> orderCompleteList(Criteria cri, Model model) {
		Hq_IOrderListDAO dao = sqlSession.getMapper(Hq_IOrderListDAO.class);
		model.addAttribute("count", dao.orderCompleteListCount());
		return dao.orderCompleteList(cri);
	}

	@Override
	public List<List<OrderList_ProductVO_2>> orderCompleteListDetail(Criteria cri) {
		Hq_IOrderListDAO dao = sqlSession.getMapper(Hq_IOrderListDAO.class);
		
		List<OrderList_MemberVO> list=dao.orderCompleteList(cri);

		OrderList_ProductVO_2 vo=new OrderList_ProductVO_2();
		
		List<List<OrderList_ProductVO_2>> list2=new ArrayList();
		
		for(int i=0; i<list.size(); i++){
			list2.add(dao.orderCompleteDetail(list.get(i).getM_Id(), list.get(i).getO_Date()));
		}
		
		return list2;
	}

	@Override
	public List<OrderList_MemberVO> orderFinishList(Criteria cri, Model model) {
		Hq_IOrderListDAO dao = sqlSession.getMapper(Hq_IOrderListDAO.class);
		model.addAttribute("count", dao.orderFinishListCount());
		return dao.orderFinishList(cri);
	}

	@Override
	public List<List<OrderList_ProductVO_2>> orderFinishListDetail(Criteria cri) {
		Hq_IOrderListDAO dao = sqlSession.getMapper(Hq_IOrderListDAO.class);
		
		List<OrderList_MemberVO> list=dao.orderFinishList(cri);

		OrderList_ProductVO_2 vo=new OrderList_ProductVO_2();
		
		List<List<OrderList_ProductVO_2>> list2=new ArrayList();
		
		for(int i=0; i<list.size(); i++){
			list2.add(dao.orderFinishListDetail(list.get(i).getM_Id(), list.get(i).getO_Date()));
		}
		
		return list2;
	}

	@Override
	public void ostateFinish(String[] ckb) {
		Hq_IOrderListDAO dao = sqlSession.getMapper(Hq_IOrderListDAO.class);
		
		for(int i=0; i<ckb.length; i++){
			// search state 1
			List<StStockVO> stock = dao.getCodeAmount2(ckb[i].split(" ")[0], ckb[i].split(" ")[1]);
			// search state 1
			List<OrderListVO> vo = dao.getCodeHp_Code(ckb[i].split(" ")[0], ckb[i].split(" ")[1]);
			for(int j=0; j<stock.size(); j++){
				System.out.println(stock.get(j).getHp_Code() + ", " + stock.get(j).getM_Id() + ", " + stock.get(j).getSt_Amount());
				dao.finishStStock(stock.get(j));
				dao.finishHqStock(stock.get(j));
				// set state 2
				dao.ostateFinish(vo.get(j).getO_Num());
			}
			
		}
		
	}

	@Override
	public void ostateApproval(String[] ckb) {
		Hq_IOrderListDAO dao = sqlSession.getMapper(Hq_IOrderListDAO.class);
		
		for(int i=0; i<ckb.length; i++){
			// search state 1
			List<OrderListVO> stock = dao.getCodeHp_Code(ckb[i].split(" ")[0], ckb[i].split(" ")[1]);
			for(int j=0; j<stock.size(); j++){
				dao.ostateApproval(stock.get(j).getO_Num());
			}
		}
		
	}


}
