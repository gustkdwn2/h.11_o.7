package com.kosta.csm.hq_Service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.ui.Model;

import com.kosta.csm.vo.Criteria;
import com.kosta.csm.vo.CriteriaIndex;
import com.kosta.csm.vo.MemberVO;

public interface Hq_IMemberService {
	
	// 회원가입 승인
	public List<MemberVO> approvalList(Criteria cri, Model model);
	
	public List<MemberVO> indexApprovalList(CriteriaIndex cri, Model model);
	
	public void updateState(String m_Id, String m_Store);
	
	public void updateStates(String[] ckb);
	
	// 회원정보 수정
	List<MemberVO> memberList();

	public String modify(String m_Id);

	String check(HttpServletRequest request, Model model);

	String memberModify(MemberVO vo);

	String pwdModify(HttpServletRequest request, MemberVO vo);

	String memberLeave(Model model, HttpServletRequest request, MemberVO vo);

	MemberVO searchById();
	
	String check();

	public void mstateDelete(String[] ckb);
}
