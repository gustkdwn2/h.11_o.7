package com.kosta.csm.hq_Service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.ibatis.annotations.Param;
import org.springframework.ui.Model;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.kosta.csm.vo.BoardVO;
import com.kosta.csm.vo.Criteria;

public interface Hq_IBoardService {

	public List<BoardVO> list(Criteria cri, Model model);

	public void write(HttpServletRequest request, BoardVO vo) throws Exception;

	public List<BoardVO> content(int b_Num);
	
	public void download(String path, String file, HttpServletRequest request, HttpServletResponse response) throws Exception;
	
	public void modify(HttpServletRequest request, BoardVO vo) throws Exception;
	
	public void delete(int b_Num);
	
	public void updateReadCount(int b_Num);
	
	//검색
	public List<BoardVO> boardSearch(Criteria cri, String boardSearch, String searchType, Model model);


}
