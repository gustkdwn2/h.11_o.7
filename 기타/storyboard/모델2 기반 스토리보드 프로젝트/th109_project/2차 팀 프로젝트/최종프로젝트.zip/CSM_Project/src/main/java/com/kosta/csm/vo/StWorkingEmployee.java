package com.kosta.csm.vo;

import java.sql.Date;

public class StWorkingEmployee {
	private String e_Name;
	private int e_Num;
	private String  wt_StartTime;
	private String  wt_EndTime;
	private int  wt_Num;
	public String getE_Name() {
		return e_Name;
	}
	public void setE_Name(String e_Name) {
		this.e_Name = e_Name;
	}
	public int getE_Num() {
		return e_Num;
	}
	public void setE_Num(int e_Num) {
		this.e_Num = e_Num;
	}
	public String getWt_StartTime() {
		return wt_StartTime;
	}
	public void setWt_StartTime(String wt_StartTime) {
		this.wt_StartTime = wt_StartTime;
	}
	public String getWt_EndTime() {
		return wt_EndTime;
	}
	public void setWt_EndTime(String wt_EndTime) {
		this.wt_EndTime = wt_EndTime;
	}
	public int getWt_Num() {
		return wt_Num;
	}
	public void setWt_Num(int wt_Num) {
		this.wt_Num = wt_Num;
	}
	
}
