package com.kosta.csm.vo;

public class TimeLineVO {
	private int t_Num;
	private String m_Id;
	private String t_Content;
	private String t_Date;
	private int t_Group;
	private int  t_reply;
	
	public TimeLineVO(){
		
	}
	public TimeLineVO(int t_Num, String m_Id, String t_Content, String t_Date, int t_Group, int t_reply) {
		this.t_Num = t_Num;
		this.m_Id = m_Id;
		this.t_Content = t_Content;
		this.t_Date = t_Date;
		this.t_Group = t_Group;
		this.t_reply = t_reply;
	}


	public int getT_Num() {
		return t_Num;
	}
	public void setT_Num(int t_Num) {
		this.t_Num = t_Num;
	}
	public String getM_Id() {
		return m_Id;
	}
	public void setM_Id(String m_Id) {
		this.m_Id = m_Id;
	}
	public String getT_Content() {
		return t_Content;
	}
	public void setT_Content(String t_Content) {
		this.t_Content = t_Content;
	}
	public String getT_Date() {
		return t_Date;
	}
	public void setT_Date(String t_Date) {
		this.t_Date = t_Date;
	}
	public int getT_Group() {
		return t_Group;
	}
	public void setT_Group(int t_Group) {
		this.t_Group = t_Group;
	}
	public int getT_reply() {
		return t_reply;
	}
	public void setT_reply(int t_reply) {
		this.t_reply = t_reply;
	}
	
	
}
