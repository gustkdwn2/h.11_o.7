package com.kosta.csm.st_Dao;

import com.kosta.csm.vo.ProductVO;

public interface St_IProductDAO {
	public ProductVO getVo(String hp_Code);
}
