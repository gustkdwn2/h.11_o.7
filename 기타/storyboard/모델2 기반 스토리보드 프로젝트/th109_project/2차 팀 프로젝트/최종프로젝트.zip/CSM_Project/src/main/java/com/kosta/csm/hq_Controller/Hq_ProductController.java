package com.kosta.csm.hq_Controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.kosta.csm.hq_Service.Hq_IProductService;
import com.kosta.csm.hq_Service.Hq_IStockService;
import com.kosta.csm.vo.Criteria;
import com.kosta.csm.vo.ProductVO;

@Controller
@RequestMapping("/hq/product")
public class Hq_ProductController {
	
	@Autowired
	private Hq_IProductService service;
	
	@RequestMapping(value="/productList", method=RequestMethod.GET)
	public String productList(Criteria cri, Model model){
		System.out.println("procutList");
		model.addAttribute("productList", service.list(cri, model));
		model.addAttribute("cri", cri);
		return "hq_aside.product.productList";
	}
	
	@RequestMapping(value="/productInsert", method=RequestMethod.POST)
	public String productInsert(@RequestParam("file") MultipartFile file, Model model, HttpServletRequest request, ProductVO vo)
	throws Exception{
		System.out.println("productInsert");
		service.insert(file, model, vo, request);
		System.out.println("vo.getHp_Code(): " +vo.getHp_Code());
		return "redirect:/hq/product/productList";
	}
	
	@RequestMapping("/productDetail")
	public String productDetail(Model model, HttpServletRequest request){
		System.out.println("productDetail");
		model.addAttribute("productDetail", service.detail(request.getParameter("hp_Code")));
		return "hq_aside.product.productDetail";
	}
	
	@RequestMapping(value="/productModify", method=RequestMethod.GET)
	public String productModifyView(Model model, HttpServletRequest request){		
		System.out.println("productModifyView");
		model.addAttribute("listForModify", service.detail(request.getParameter("hp_Code")));
		return "hq_aside.product.productModify";
	}

	@RequestMapping(value="/productModify", method=RequestMethod.POST)
	public String productModify(@RequestParam("file") MultipartFile file, @RequestParam("old_hp_Category") String old_hp_Category, Model model, HttpServletRequest request, 
			ProductVO vo) throws Exception{
		if(vo.getHp_Category().equals("카테고리 선택")){
			vo.setHp_Category(old_hp_Category);
		}
		
		System.out.println("productModify");
		service.moidfy(file, model, vo, request);
		return "redirect:/hq/product/productList";
	}
	
	
	// 검색처리
	// 검색
	@RequestMapping(value="/productListSearch1")
	public String productListSearch1(Criteria cri, Model model, @RequestParam("productSearch") String productSearch,
																@RequestParam("searchType") String searchType){
		System.out.println("productSearch : " + productSearch);
		model.addAttribute("productList", service.productListSearch(cri, model, searchType, productSearch));
		model.addAttribute("cri", cri);
		model.addAttribute("search_check", 1);
		model.addAttribute("productSearch", productSearch);
		model.addAttribute("searchType", searchType);
		
		return "hq_aside.product.productList";
	}
	
	@RequestMapping(value="/productSusListSearch1")
	public String productSusListSearch1(Criteria cri, Model model, @RequestParam("productSearch") String productSearch,
																@RequestParam("searchType") String searchType){
		System.out.println("productSearch : " + productSearch);
		model.addAttribute("productList", service.productSusListSearch(cri, model, searchType, productSearch));
		model.addAttribute("cri", cri);
		model.addAttribute("search_check", 1);
		model.addAttribute("productSearch", productSearch);
		model.addAttribute("searchType", searchType);
		
		return "hq_aside.product.productSusList";
	}
	
	// 카테고리 검색
	@RequestMapping(value="/productListSearch2")
	public String productListSearch2(Criteria cri, Model model, @RequestParam("category") String category){
		
		model.addAttribute("productList", service.productListSearch_Category(cri, model, category));
		model.addAttribute("cri", cri);
		model.addAttribute("search_check", 2);
		model.addAttribute("category", category);
		
		return "hq_aside.product.productList";
	}
	
	@RequestMapping(value="/productSusListSearch2")
	public String productSusListSearch2(Criteria cri, Model model, @RequestParam("category") String category){
		
		model.addAttribute("productList", service.productSusListSearch_Category(cri, model, category));
		model.addAttribute("cri", cri);
		model.addAttribute("search_check", 2);
		model.addAttribute("category", category);
		
		return "hq_aside.product.productSusList";
	}
	
	// 삭제 사용하기
	@RequestMapping(value="/productDelete")
	public String productDelete(HttpServletRequest request,  @RequestParam("chk") String[] hp_Code){
		System.out.println("productDelete");
		
		service.fileDelete(service.selectFileList(hp_Code), request);
		System.out.println("Requested hp_Code: " +hp_Code);
		
		service.delete(hp_Code);
		System.out.println("productDelete End");
		return "redirect:/hq/product/productSusList";
	}
	
	@RequestMapping(value="/duplicationCheck")
	public String duplicationCheck(HttpServletRequest request, Model model){
		System.out.println("duplicationCheck");
		
		service.duplicationCheck(request, model);
		
		return "fullscreen.hq.product.duplicationCheck";
	}
	
	@RequestMapping(value="/productState")
	public String productState_0(@RequestParam("chk") String[] hp_Code){
		System.out.println("productState");
		
		service.stateChange_0(hp_Code);
		
		return "redirect:/hq/product/productSusList";
	}
	
	@RequestMapping(value="/productSusList")
	public String productSusList(Criteria cri, Model model){
		System.out.println("productSusList");
		model.addAttribute("productList", service.susList(cri, model));
		model.addAttribute("cri", cri);
		return "hq_aside.product.productSusList";
	}
	
	@RequestMapping(value="/productResume")
	public String productResume(@RequestParam("chk") String[] hp_Code){
		System.out.println("productResume");
		
		service.productResume(hp_Code);
		return "redirect:/hq/product/productList";
	}
}
