package com.kosta.csm.st_Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.kosta.csm.st_Service.St_ISt_Stock_ProductService;
import com.kosta.csm.vo.Criteria;

@Controller
@RequestMapping("/st/product")
public class St_ProductController {

	@Autowired
	St_ISt_Stock_ProductService service;

	@RequestMapping("/productList")
	public String productList(Criteria cri, Model model) {
		cri.setPageSize(12);
		model.addAttribute("productList", service.list(cri, model));
		model.addAttribute("stockListDetail", service.stockListDetail(cri));
		model.addAttribute("cri", cri);
		return "st_aside.product.productList";
	}
	
	@RequestMapping("/productDelete")
	public String productDelete(@RequestParam ("ckb") String[] ckb) {
		service.deleteProducts(ckb);
		return "redirect:/st/product/productList";
	}
	
	@RequestMapping(value="/productReg", method=RequestMethod.GET)
	public String productRegGET(Criteria cri, Model model){
		model.addAttribute("productList", service.productRegList(cri, model));
		model.addAttribute("cri", cri);
		return "st_aside.product.productReg";
	}
	
	@RequestMapping(value="/productRegPOST")
	public String productRegPOST(@RequestParam ("ckb") String[] ckb, Model model){
		service.productReg(ckb);
		return "redirect:/st/product/productReg";
	}

	
	@RequestMapping(value = "/productRegSearch1")
	public String productRegSearch1(Criteria cri, Model model, @RequestParam("productSearch") String productSearch,
			@RequestParam("searchType") String searchType) {
		model.addAttribute("productList", service.productRegSearch(cri, model, searchType, productSearch));
		model.addAttribute("cri", cri);
		model.addAttribute("search_check", 1);
		model.addAttribute("productSearch", productSearch);
		model.addAttribute("searchType", searchType);
		return "st_aside.product.productReg";
	}
	
	@RequestMapping(value = "/productRegSearch2")
	public String productRegSearch2(Criteria cri, Model model, @RequestParam("category") String category) {
		model.addAttribute("productList", service.productRegSearch_Category(cri, model, category));
		model.addAttribute("cri", cri);
		model.addAttribute("search_check", 2);
		model.addAttribute("category", category);
		
		return "st_aside.product.productReg";
	}
	
	
	@RequestMapping(value="/productStockSearch")
	public String productStockSearch(Criteria cri, Model model, @RequestParam("productSearch") String productSearch,
									@RequestParam("searchType") String searchType){
		cri.setPageSize(12);
		model.addAttribute("productList", service.productStockSearch(cri, model, searchType, productSearch));
		model.addAttribute("cri", cri);
		model.addAttribute("search_check", 1);
		model.addAttribute("productSearch", productSearch);
		model.addAttribute("searchType", searchType);
		
		return "st_aside.product.productList";
	}
	
	@RequestMapping(value="/productStockSearch2")
	public String productStockSearch2(Criteria cri, Model model, @RequestParam("category") String category){
		cri.setPageSize(12);
		model.addAttribute("productList", service.productStockSearch_Category(cri, model, category));
		model.addAttribute("cri", cri);
		model.addAttribute("search_check", 2);
		model.addAttribute("category", category);
		
		return "st_aside.product.productList";
	}
	
	
}
