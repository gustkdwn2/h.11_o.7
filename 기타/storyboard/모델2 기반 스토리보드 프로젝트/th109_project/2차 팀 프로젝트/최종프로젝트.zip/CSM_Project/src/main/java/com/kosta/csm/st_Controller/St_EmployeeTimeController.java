package com.kosta.csm.st_Controller;

import java.text.ParseException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.kosta.csm.st_Service.St_IEmployeeTimeService;
import com.kosta.csm.vo.Criteria;
import com.kosta.csm.vo.StWorkingEmployee;

@Controller
@RequestMapping("/st/employee")
public class St_EmployeeTimeController {

	@Autowired
	private St_IEmployeeTimeService service;

	@RequestMapping(value = "/timeList", method = RequestMethod.GET)
	public String timeList(Criteria cri, Model model) {
		System.out.println("/st/employee/timeList");
		model.addAttribute("list", service.timeList(cri, model));
		model.addAttribute("cri", cri);
		System.out.println("before go to st_aside.employeeTime.employeeTimeList");
		return "st.employeeTime.employeeTimeList";
	}
	
	@RequestMapping(value = "/modifyTime", method = RequestMethod.POST)
	public String modifyTime(@ModelAttribute StWorkingEmployee vo, Model model, HttpServletRequest request){
		System.out.println("/st/employee/modifyTime");
		System.out.println("vo정보 :"+ vo.getWt_EndTime());
		//System.out.println("get size : " + service.timeList(request).get(0).getWt_Num());
		model.addAttribute("vo", vo);
		System.out.println(vo.getWt_StartTime());
		System.out.println( String.valueOf(vo.getWt_StartTime()).substring(0, 4));
		model.addAttribute("yyyy1", String.valueOf(vo.getWt_StartTime()).substring(0, 4));
		model.addAttribute("mm1", String.valueOf(vo.getWt_StartTime()).substring(5, 7));
		model.addAttribute("dd1", String.valueOf(vo.getWt_StartTime()).substring(8, 10));
		model.addAttribute("hh1", String.valueOf(vo.getWt_StartTime()).substring(11, 13));
		model.addAttribute("mi1", String.valueOf(vo.getWt_StartTime()).substring(14, 16));
		model.addAttribute("ss1", String.valueOf(vo.getWt_StartTime()).substring(17, 19));
		model.addAttribute("yyyy2", String.valueOf(vo.getWt_EndTime()).substring(0, 4));
		model.addAttribute("mm2", String.valueOf(vo.getWt_EndTime()).substring(5, 7));
		model.addAttribute("dd2", String.valueOf(vo.getWt_EndTime()).substring(8, 10));
		model.addAttribute("hh2", String.valueOf(vo.getWt_EndTime()).substring(11, 13));
		model.addAttribute("mi2", String.valueOf(vo.getWt_EndTime()).substring(14, 16));
		model.addAttribute("ss2",String.valueOf( vo.getWt_EndTime()).substring(17, 19));
		return "st.employeeTime.modifyTime";
	}
	
	@RequestMapping(value = "/proModifyTime", method = RequestMethod.POST)
	public String proModifyTime(@ModelAttribute StWorkingEmployee vo,Model model, HttpServletRequest request) throws ParseException {
		System.out.println("/st/employee/proModifyTime");
		service.proModifyTime(vo,request);
		
		return "redirect:/st/employee/timeList";
	}
	
	@RequestMapping(value="/employeeSearch")
	public String employeeSearch(Criteria cri, Model model, @RequestParam("searchType") String searchType,
															@RequestParam("employee") String employee){
		
		model.addAttribute("list", service.employeeSearch(cri, model, searchType, employee));
		model.addAttribute("cri", cri);
		model.addAttribute("searchType", searchType);
		model.addAttribute("employee", employee);
		
		return "st.employeeTime.employeeTimeList";
	}
}
	