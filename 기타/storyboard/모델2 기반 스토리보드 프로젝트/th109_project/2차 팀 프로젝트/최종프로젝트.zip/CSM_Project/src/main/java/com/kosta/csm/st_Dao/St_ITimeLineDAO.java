package com.kosta.csm.st_Dao;

import java.util.List;

import com.kosta.csm.vo.Criteria;
import com.kosta.csm.vo.TimeLineVO;

public interface St_ITimeLineDAO {
	public List<TimeLineVO> parentList(Criteria cri);
	
	public List<TimeLineVO> childList();
	
	public void writeReply(TimeLineVO vo);
	
	public void writeTimeLine(TimeLineVO vo);
	
	public void firstWriteTimeLine(TimeLineVO vo);
	
	public void modifyTimeLine(TimeLineVO vo);
	
	public void deleteTimeLine(int t_Num);
	
	public int timeLineCount();
}
