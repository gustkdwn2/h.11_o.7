package com.kosta.csm.hq_Service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.kosta.csm.hq_Dao.Hq_ISalesStatusDAO;
import com.kosta.csm.hq_Dao.Hq_IStoreDAO;
import com.kosta.csm.st_Dao.St_ISalesStatusDAO;
import com.kosta.csm.vo.Criteria;
import com.kosta.csm.vo.MemberVO;
import com.kosta.csm.vo.salesStatusRankVO;

@Service
public class Hq_StoreService implements Hq_IStoreService {

	@Autowired
	private SqlSession sqlSession;
	
	// 매장관리
	@Override
	public List<MemberVO> storePresentCondition(Criteria cri, Model model) {
		System.out.println("Service storePresentCondition");
		Hq_IStoreDAO dao = sqlSession.getMapper(Hq_IStoreDAO.class);
		model.addAttribute("count", dao.storePresentConditionCount());
		return dao.storePresentCondition(cri);
	}

	@Override
	public List<MemberVO> storeSearch(Criteria cri, Model model, HttpServletRequest request, MemberVO vo) {
		System.out.println("Service storeSearch");
		Hq_IStoreDAO dao = sqlSession.getMapper(Hq_IStoreDAO.class);
		String m_Store = '%' + request.getParameter("storeSearch") + '%';
		vo.setM_Store(m_Store);
		model.addAttribute("count", dao.storeSearchCount(m_Store));
		return dao.storeSearch(cri, m_Store);
	}

	@Override
	public String storeDelete(HttpServletRequest request, MemberVO vo) {
		System.out.println("Service storeDelete");
		Hq_IStoreDAO dao = sqlSession.getMapper(Hq_IStoreDAO.class);
		String m_Id = request.getParameter("m_Id");
		vo.setM_Id(m_Id);
		dao.storeDelete(vo);
		return "redirect:/hq/store/storePresentCondition";
	}

	@Override
	public void salesStatus(Model model, HttpServletRequest request) {
		Hq_IStoreDAO dao = sqlSession.getMapper(Hq_IStoreDAO.class);
		
		String year = request.getParameter("year");
		String month = request.getParameter("month");
		
		String day=null;
		if(year !=null && month != null){
			day = year + "/" + month + "%";
		}
		
		List<String> location = new ArrayList<String>(
				Arrays.asList("서울", "경기", "인천"));
		
		
		List<Integer> status = new ArrayList<Integer>();
		for(int i=0; i<location.size(); i++){
			status.add(i, 0);
		}
		
		
		if(day == null){
			for(int i=0; i<location.size(); i++){
				if(dao.salesStatus(location.get(i))!=null){
					status.set(i, dao.salesStatus(location.get(i)));
				}// if
			}// for
			model.addAttribute("status", status);
		}else{
			for(int i=0; i<location.size(); i++){
				if(dao.salesStatusDay(day, location.get(i))!=null){
					status.set(i, dao.salesStatusDay(day, location.get(i)));
				}// if
			}// for
			model.addAttribute("status", status);
			model.addAttribute("year", year);
			model.addAttribute("month", month);
		}
		
		List<List<salesStatusRankVO>> rank = new ArrayList<List<salesStatusRankVO>>();
		
		
		if(day == null){
			for(int i=0; i<location.size(); i++){
				rank.add(dao.salesStatusRank(location.get(i)));
			}// for
		}else{
			for(int i=0; i<location.size(); i++){
				rank.add(dao.salesStatusRankDay(location.get(i), day));
			}// for
		}
		
		model.addAttribute("rank", rank);
		
	}

	@Override
	public void monthStatus(Model model, HttpServletRequest request) {
		String chYear = request.getParameter("year");
		
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy");
		String year = dateFormat.format(cal.getTime()).substring(0,4);
		
		String user_id = request.getParameter("m_Id");
		
		Hq_ISalesStatusDAO dao = sqlSession.getMapper(Hq_ISalesStatusDAO.class);
		
		List<String> month = new ArrayList<String>(
				Arrays.asList("01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"));
		
		List<Integer> monthList = new ArrayList<Integer>();
		
		
		for(int i=0; i<month.size(); i++){
			if(chYear==null){
				monthList.add(i, dao.monthStatus(user_id, year+"/"+month.get(i)+"%"));
			}else{
				monthList.add(i, dao.monthStatus(user_id, chYear+"/"+month.get(i)+"%"));
				model.addAttribute("year", chYear);
			}
		}
		
		model.addAttribute("status", monthList);
		model.addAttribute("m_Id", user_id);
		
	}

	@Override
	public void yearStatus(Model model, HttpServletRequest request) {
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy");
		String thisYear = dateFormat.format(cal.getTime()).substring(0,4);
		
		
		String user_id = request.getParameter("m_Id");
		
		Hq_ISalesStatusDAO dao = sqlSession.getMapper(Hq_ISalesStatusDAO.class);
		
		List<String> year = new ArrayList<String>();
		
		for(int i=0; i<5; i++){
			year.add(i, Integer.toString((Integer.parseInt(thisYear)-(4-i))));
		}
		
		List<Integer> yearList = new ArrayList<Integer>();
		
		
		for(int i=0; i<year.size(); i++){
			yearList.add(i, dao.yearStatus(user_id, year.get(i)+"%"));
		}
		
		model.addAttribute("year", year);
		model.addAttribute("status", yearList);
		model.addAttribute("m_Id", user_id);
		
	}
}
