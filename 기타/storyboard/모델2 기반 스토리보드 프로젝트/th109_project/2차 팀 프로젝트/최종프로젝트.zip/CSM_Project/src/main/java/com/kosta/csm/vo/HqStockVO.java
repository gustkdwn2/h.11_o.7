package com.kosta.csm.vo;

public class HqStockVO {
	private String hp_Code;
	private int hp_Amount;
	
	//생성자
	public HqStockVO(){
		
	}
	
	public HqStockVO(String hp_Code, int hp_Amount) {
		this.hp_Code = hp_Code;
		this.hp_Amount = hp_Amount;
	}

	//getter setter
	public String getHp_Code() {
		return hp_Code;
	}
	public void setHp_Code(String hp_Code) {
		this.hp_Code = hp_Code;
	}
	public int getHp_Amount() {
		return hp_Amount;
	}
	public void setHp_Amount(int hp_Amount) {
		this.hp_Amount = hp_Amount;
	}
}
