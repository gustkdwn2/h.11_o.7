package com.kosta.csm.hq_Dao;

import java.util.List;

import com.kosta.csm.vo.EmployeeVO;
import com.kosta.csm.vo.PayVO;

public interface Hq_IPayDAO {
	void addPay(EmployeeVO vo);
	
	//직원번호로찾아  pay테이블 pay값 업데이트
	void updatePayOfE_Num(EmployeeVO vo);
	//직업군으(점장/알바)로찾아  pay테이블 pay값 업데이트
	void updatePayOfE_Position(EmployeeVO vo);
	//직업종류에해당하는 직원들의 pay값가져옴
	List<PayVO> getPayOfE_Position(EmployeeVO vo);
	
	PayVO getPayOfE_Num(EmployeeVO vo);

	void insertPay(PayVO vo);
}