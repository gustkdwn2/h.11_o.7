package com.kosta.csm.hq_Service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.kosta.csm.hq_Dao.Hq_IBoardDAO;
import com.kosta.csm.vo.BoardVO;
import com.kosta.csm.vo.Criteria;

@Service
public class Hq_BoardService implements Hq_IBoardService {

	@Autowired
	private SqlSession sqlSession;

	@Override
	public List<BoardVO> list(Criteria cri, Model model) {
		System.out.println("listService() !");

		System.out.println("startPage : " + cri.getPageStart());
		System.out.println("endPage : " + cri.getPageEnd());

		Hq_IBoardDAO dao = sqlSession.getMapper(Hq_IBoardDAO.class);

		model.addAttribute("count", dao.boardListCount());

		return dao.boardListPage(cri);
	}

	@Override
	public List<BoardVO> content(int b_Num) {
		Hq_IBoardDAO dao = sqlSession.getMapper(Hq_IBoardDAO.class);
		return dao.boardContent(b_Num);
	}

	@Override
	public void write(HttpServletRequest request, BoardVO vo) throws Exception {
		System.out.println("실제 글 등록 처리");
		System.out.println(vo.getB_Title());
		System.out.println(vo.getB_Content());
		System.out.println(vo.getFiles().get(0).getName()); // 첨부
															// 파일(CommonsMultipartFile
															// > file)
		System.out.println(vo.getFiles().get(1).getName());

		List<CommonsMultipartFile> files = vo.getFiles();
		List<String> filenames = new ArrayList<String>(); // 파일명만 추출

		if (files != null && files.size() > 0) { // 업로드한 파일이 하나라도 있다면

			for (CommonsMultipartFile multipartfile : files) {

				String fname = multipartfile.getOriginalFilename(); // 파일명 얻기
				String path = request.getSession().getServletContext().getRealPath("/upload");
				String fullpath = path + "\\" + fname;

				System.out.println(fname + " / " + path + " / " + fullpath);

				if (!fname.equals("")) {
					// 서버에 파일 쓰기 작업
					FileOutputStream fs = new FileOutputStream(fullpath);
					fs.write(multipartfile.getBytes());
					fs.close();
				}
				filenames.add(fname); // 실 DB Insert 작업시 .. 파일명
			}

		}

		// DB저장작업
		// DB 저장할 파일 명
		vo.setB_Path1(filenames.get(0));
		vo.setB_Path2(filenames.get(1));

		Hq_IBoardDAO dao = sqlSession.getMapper(Hq_IBoardDAO.class);
		dao.boardInsert(vo);
	}

	@Override
	public void download(String path, String file, HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		String fname = new String(file.getBytes("utf-8"), "8859_1");
		System.out.println(fname);

		response.setHeader("Content-Disposition", "attachment;filename=" + fname + ";");

		// 파일명 전송
		// 파일 내용전송
		String fullpath = request.getSession().getServletContext().getRealPath(path + "/" + file);
		System.out.println(fullpath);
		FileInputStream fin = new FileInputStream(fullpath);

		ServletOutputStream sout = response.getOutputStream();
		byte[] buf = new byte[1024]; // 전체를 다읽지 않고 1204byte씩 읽어서
		int size = 0;
		
		while ((size = fin.read(buf, 0, buf.length)) != -1) // buffer 에 1024byte 담고
		{ // 마지막 남아있는 byte 담고 그다음 없으면 탈출
			sout.write(buf, 0, size); // 1kbyte씩 출력
		}
		fin.close();
		sout.close();

	}

	@Override
	public void modify(HttpServletRequest request, BoardVO vo) throws Exception {
		
		List<CommonsMultipartFile> files = vo.getFiles();
		List<String> filenames = new ArrayList<String>(); // 파일명만 추출

		if (files != null && files.size() > 0) { // 업로드한 파일이 하나라도 있다면

			for (CommonsMultipartFile multipartfile : files) {

				String fname = multipartfile.getOriginalFilename(); // 파일명 얻기
				String path = request.getSession().getServletContext().getRealPath("/upload");
				String fullpath = path + "\\" + fname;

				System.out.println(fname + " / " + path + " / " + fullpath);

				if (!fname.equals("")) {
					// 서버에 파일 쓰기 작업
					FileOutputStream fs = new FileOutputStream(fullpath);
					fs.write(multipartfile.getBytes());
					fs.close();
				}
				filenames.add(fname); // 실 DB Insert 작업시 .. 파일명
			}

		}

		// DB저장작업
		// DB 저장할 파일 명
		vo.setB_Path1(filenames.get(0));
		vo.setB_Path2(filenames.get(1));
		
		Hq_IBoardDAO dao = sqlSession.getMapper(Hq_IBoardDAO.class);
		dao.boardModify(vo);
	}

	@Override
	public void delete(int b_Num) {
		Hq_IBoardDAO dao = sqlSession.getMapper(Hq_IBoardDAO.class);
		dao.boardDelete(b_Num);
	}

	@Override
	public void updateReadCount(int b_Num) {
		Hq_IBoardDAO dao = sqlSession.getMapper(Hq_IBoardDAO.class);
		dao.updateReadCount(b_Num);
	}

	@Override
	public List<BoardVO> boardSearch(Criteria cri, String boardSearch, String searchType, Model model) {
		Hq_IBoardDAO dao = sqlSession.getMapper(Hq_IBoardDAO.class);
		
		if(searchType.equals("글번호")){
			return dao.boardSearch1(cri, Integer.parseInt(boardSearch));
			
		}else if(searchType.equals("글제목")){
			model.addAttribute("count", dao.boardSearch2Count("%"+boardSearch+"%"));
			return dao.boardSearch2(cri, "%"+boardSearch+"%");
		}
		return null;
	}

	

}
