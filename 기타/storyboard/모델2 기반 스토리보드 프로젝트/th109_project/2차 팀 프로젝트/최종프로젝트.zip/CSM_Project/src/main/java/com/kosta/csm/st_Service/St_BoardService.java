package com.kosta.csm.st_Service;

import java.io.FileInputStream;
import java.util.List;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.kosta.csm.hq_Dao.Hq_IBoardDAO;
import com.kosta.csm.st_Dao.St_IBoardDAO;
import com.kosta.csm.vo.BoardVO;
import com.kosta.csm.vo.Criteria;

@Service
public class St_BoardService implements St_IBoardService {

	@Autowired
	private SqlSession sqlSession;

	@Override
	public List<BoardVO> list(Criteria cri, Model model) {
		System.out.println("listService() !");

		System.out.println("startPage : " + cri.getPageStart());
		System.out.println("endPage : " + cri.getPageEnd());

		St_IBoardDAO dao = sqlSession.getMapper(St_IBoardDAO.class);

		model.addAttribute("count", dao.boardListCount());

		return dao.boardListPage(cri);
	}

	@Override
	public List<BoardVO> content(int b_Num) {
		Hq_IBoardDAO dao = sqlSession.getMapper(Hq_IBoardDAO.class);
		return dao.boardContent(b_Num);
	}

	@Override
	public void download(String path, String file, HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		String fname = new String(file.getBytes("utf-8"), "8859_1");
		System.out.println(fname);

		response.setHeader("Content-Disposition", "attachment;filename=" + fname + ";");

		// 파일명 전송
		// 파일 내용전송
		String fullpath = request.getSession().getServletContext().getRealPath(path + "/" + file);
		System.out.println(fullpath);
		FileInputStream fin = new FileInputStream(fullpath);

		ServletOutputStream sout = response.getOutputStream();
		byte[] buf = new byte[1024]; // 전체를 다읽지 않고 1204byte씩 읽어서
		int size = 0;
		
		while ((size = fin.read(buf, 0, buf.length)) != -1) // buffer 에 1024byte 담고
		{ // 마지막 남아있는 byte 담고 그다음 없으면 탈출
			sout.write(buf, 0, size); // 1kbyte씩 출력
		}
		fin.close();
		sout.close();

	}
	
	@Override
	public void updateReadCount(int b_Num) {
		Hq_IBoardDAO dao = sqlSession.getMapper(Hq_IBoardDAO.class);
		dao.updateReadCount(b_Num);
	}

	@Override
	public List<BoardVO> boardSearch(Criteria cri, String boardSearch, String searchType, Model model) {
		Hq_IBoardDAO dao = sqlSession.getMapper(Hq_IBoardDAO.class);
		
		if(searchType.equals("글번호")){
			return dao.boardSearch1(cri, Integer.parseInt(boardSearch));
			
		}else if(searchType.equals("글제목")){
			model.addAttribute("count", dao.boardSearch2Count("%"+boardSearch+"%"));
			return dao.boardSearch2(cri, "%"+boardSearch+"%");
		}
		return null;
	}

}
