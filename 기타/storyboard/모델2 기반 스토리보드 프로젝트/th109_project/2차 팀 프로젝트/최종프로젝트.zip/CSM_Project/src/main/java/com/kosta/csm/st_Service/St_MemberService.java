package com.kosta.csm.st_Service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.kosta.csm.hq_Dao.Hq_IMemberDAO;
import com.kosta.csm.st_Dao.St_IMemberDAO;
import com.kosta.csm.vo.MemberVO;

@Service
public class St_MemberService implements St_IMemberService {

	@Autowired
	private SqlSession sqlSession;

	@Override
	public List<MemberVO> memberList() {
		St_IMemberDAO dao = sqlSession.getMapper(St_IMemberDAO.class);
		return dao.memberList();
	}

	@Override
	public String modify(String m_Id) {
		St_IMemberDAO dao = sqlSession.getMapper(St_IMemberDAO.class);
		return dao.modify(m_Id);
	}

	@Override
	public String check(HttpServletRequest request, Model model) {
		System.out.println("Service check");
		St_IMemberDAO dao = sqlSession.getMapper(St_IMemberDAO.class);
		String pwd = dao.check(request.getParameter("m_Id"));
		String m_Pwd = request.getParameter("m_Pwd");
		if (pwd.equals(m_Pwd)) {
			return "redirect:/st/member/memberModify";
		} else {
			return "st_aside.member.modify";
		}

	}

	@Override
	public String memberModify(MemberVO vo) {
		System.out.println("Service memberModify");
		St_IMemberDAO dao = sqlSession.getMapper(St_IMemberDAO.class);
		dao.memberModify(vo);
		return "redirect:/st/member/modify";
	}

	@Override
	public String pwdModify(HttpServletRequest request, MemberVO vo) {
		System.out.println("Service pwdModify");
		St_IMemberDAO dao = sqlSession.getMapper(St_IMemberDAO.class);
		String pwd = dao.check(request.getParameter("m_Id"));
		String m_Pwd = request.getParameter("m_Pwd");
		String m_Pwd1 = request.getParameter("m_Pwd1");
		String m_Pwd2 = request.getParameter("m_Pwd2");

		if (pwd.equals(m_Pwd) && m_Pwd1.equals(m_Pwd2)) {
			if (!pwd.equals(m_Pwd1)) {
				vo.setM_Pwd(m_Pwd1);
				dao.pwdModify(vo);
				return "redirect:/st/member/modify";
			}
		} else {
			return "st_aside.member.pwdModify";
		}
		return "st_aside.member.pwdModify";
	}

	@Override
	public MemberVO searchById() {
		Hq_IMemberDAO dao = sqlSession.getMapper(Hq_IMemberDAO.class);
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String m_Id = (String) auth.getName();
		return dao.searchById(m_Id);
	}

	@Override
	public String check() {
		Hq_IMemberDAO dao = sqlSession.getMapper(Hq_IMemberDAO.class);
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String m_Id = (String) auth.getName();
		return dao.check(m_Id);
	}

}