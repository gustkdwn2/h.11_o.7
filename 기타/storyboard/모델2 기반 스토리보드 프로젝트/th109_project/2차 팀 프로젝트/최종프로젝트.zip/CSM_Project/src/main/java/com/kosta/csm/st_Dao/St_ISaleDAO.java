package com.kosta.csm.st_Dao;

import java.util.ArrayList;

import com.kosta.csm.vo.SaleVO;

public interface St_ISaleDAO {

	Integer getMaxGroupNum( String m_Id);
	void insert(SaleVO saleVO);
	ArrayList<SaleVO> getAllSale();
}
