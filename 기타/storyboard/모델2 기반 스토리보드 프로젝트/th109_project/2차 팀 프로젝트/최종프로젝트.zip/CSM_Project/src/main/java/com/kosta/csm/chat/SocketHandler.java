package com.kosta.csm.chat;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.socket.CloseStatus;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;

public class SocketHandler extends TextWebSocketHandler implements InitializingBean {
      
    private final Logger logger = LogManager.getLogger(getClass());
    private Set<WebSocketSession> sessionSet = new HashSet<WebSocketSession>();
    public static List<String> users = new ArrayList<>();
   
    public SocketHandler (){
          super();
          this.logger.info("create SocketHandler instance!");
    }

    @Override
    public void afterConnectionClosed(WebSocketSession session,
                 CloseStatus status) throws Exception {
          super.afterConnectionClosed(session, status);

          sessionSet.remove(session);
          this.logger.info("remove session!");
    }

    @Override
    public void afterConnectionEstablished(WebSocketSession session)
                 throws Exception {
          super.afterConnectionEstablished(session);
          sessionSet.add(session);
          this.logger.info("add session!");
    }

    @Override
    public void handleMessage(WebSocketSession session,
                 WebSocketMessage<?> message) throws Exception {
          super.handleMessage(session, message);
         
          this.logger.info("receive message:"+message.toString());
    }

    @Override
    public void handleTransportError(WebSocketSession session,
                 Throwable exception) throws Exception {
          this.logger.error("web socket error!", exception);
    }

    @Override
    public boolean supportsPartialMessages() {
    	
    	
          this.logger.info("call method!");
         
          return super.supportsPartialMessages();
    }
   
    public void sendMessage (TextMessage textMessage){
          for (WebSocketSession session: this.sessionSet){
                 if (session.isOpen()){
                        try{
                        	String[] resultarray = textMessage.getPayload().split("/");
                        	System.out.println(resultarray[0]);
                        	if(resultarray[0].equals("userrequest")){
                        		String newsend = "userrequest/";
                        		if(users.isEmpty()){
                        			users.add(resultarray[1]);
                        		}else{
	                        		for(int i=0; i<users.size(); i++){
	                        			if(users.get(i).equals(resultarray[1])){
	                        				for(int j=0; j<users.size(); j++){
	                                			newsend += users.get(j) + "/";
	                                		}
	                                		session.sendMessage(new TextMessage(newsend));
	                                		return;
	                        			}
	                        		}// for
	                        		users.add(resultarray[1]);
                        		}// else
                        		
                        		System.out.println(resultarray[1]);
                        		for(int i=0; i<users.size(); i++){
                        			newsend += users.get(i) + "/";
                        		}
                        		session.sendMessage(new TextMessage(newsend));
                        	}else if(resultarray[0].equals("remove")){
                        		String newsend = "userrequest/";
                        		for(int i=0; i<users.size(); i++){
                        			if(users.get(i).equals(resultarray[1])){
                        				users.remove(i);
                        			}
                        		}
                        		for(int i=0; i<users.size(); i++){
                        			newsend += users.get(i) + "/";
                        		}
                        		session.sendMessage(new TextMessage(newsend));
                        	}else{
                              session.sendMessage(new TextMessage(textMessage.getPayload()));
                        	}
                        }catch (Exception ignored){
                              this.logger.error("fail to send message!", ignored);
                        }
                 }
          }
    }

    @Override
    public void afterPropertiesSet() throws Exception {
    		
          /*Thread thread = new Thread(){

                 int i=0;
                 @Override
                 public void run() {
                        while (true){

                              try {
                                     sendMessage ("send message index "+i++);
                                     Thread.sleep(1000);
                              } catch (InterruptedException e) {
                                     e.printStackTrace();
                                     break;
                              }
                        }
                 }

          };

          thread.start();*/
    }
    
    @Override
    protected void handleTextMessage(WebSocketSession session, TextMessage message) throws Exception {
    	
    	sendMessage(new TextMessage(message.getPayload()));
    }

}