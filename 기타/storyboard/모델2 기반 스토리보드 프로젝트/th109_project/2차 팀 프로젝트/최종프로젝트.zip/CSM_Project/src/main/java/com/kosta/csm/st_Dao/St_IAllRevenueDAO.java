package com.kosta.csm.st_Dao;

import java.util.ArrayList;

import org.apache.ibatis.annotations.Param;

import com.kosta.csm.vo.AllRevenue;
import com.kosta.csm.vo.Criteria;

public interface St_IAllRevenueDAO {
	ArrayList<AllRevenue> allRevenue(@Param("cri") Criteria cri, @Param("m_Id") String m_Id);
	int allRevenueCount(String m_Id);
	ArrayList<AllRevenue> detailRevenue(@Param("cri") Criteria cri, @Param("m_Id") String m_Id,@Param("s_Date") String s_Date);
	int detailRevenueCount(@Param("m_Id") String m_Id,@Param("s_Date") String s_Date);
	
}

