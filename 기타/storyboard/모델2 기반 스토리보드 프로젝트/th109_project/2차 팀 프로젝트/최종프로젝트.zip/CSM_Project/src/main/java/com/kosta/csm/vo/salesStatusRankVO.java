package com.kosta.csm.vo;

public class salesStatusRankVO {
	private String m_Store;
	private int si_Sale;
	
	public String getM_Store() {
		return m_Store;
	}
	public void setM_Store(String m_Store) {
		this.m_Store = m_Store;
	}
	public int getSi_Sale() {
		return si_Sale;
	}
	public void setSi_Sale(int si_Sale) {
		this.si_Sale = si_Sale;
	}
	
}
