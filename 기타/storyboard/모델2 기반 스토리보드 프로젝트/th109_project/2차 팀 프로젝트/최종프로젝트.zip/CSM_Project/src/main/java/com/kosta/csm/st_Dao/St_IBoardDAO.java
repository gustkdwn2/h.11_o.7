package com.kosta.csm.st_Dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.kosta.csm.vo.BoardVO;
import com.kosta.csm.vo.Criteria;

public interface St_IBoardDAO {

	public int boardListCount();
	
	public List<BoardVO> boardListPage(Criteria cri);
	
	public List<BoardVO> boardContent(int b_Num);
	
	public void updateReadCount(int b_Num);
	
}
