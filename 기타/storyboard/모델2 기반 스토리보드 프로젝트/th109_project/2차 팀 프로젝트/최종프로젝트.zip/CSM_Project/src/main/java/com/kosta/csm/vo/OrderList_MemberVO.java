package com.kosta.csm.vo;

public class OrderList_MemberVO {
	private String m_Id;
	private String m_Store;
	private String o_Date;
	
	public OrderList_MemberVO(){
		
	}
	public OrderList_MemberVO(String m_Id, String m_Store, String o_Date) {
		this.m_Id = m_Id;
		this.m_Store = m_Store;
		this.o_Date = o_Date;
	}
	public String getM_Id() {
		return m_Id;
	}
	public void setM_Id(String m_Id) {
		this.m_Id = m_Id;
	}
	public String getM_Store() {
		return m_Store;
	}
	public void setM_Store(String m_Store) {
		this.m_Store = m_Store;
	}
	public String getO_Date() {
		return o_Date;
	}
	public void setO_Date(String o_Date) {
		this.o_Date = o_Date;
	}

	@Override
	public String toString() {
		return "OrderList_MemberVO [m_Id=" + m_Id + ", m_Store=" + m_Store + ", o_Date=" + o_Date + "]";
	}
}
