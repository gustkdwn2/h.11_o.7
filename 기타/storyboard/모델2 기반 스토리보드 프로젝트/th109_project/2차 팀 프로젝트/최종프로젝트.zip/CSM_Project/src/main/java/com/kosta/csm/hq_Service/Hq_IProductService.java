package com.kosta.csm.hq_Service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.ui.Model;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.kosta.csm.vo.Criteria;
import com.kosta.csm.vo.ProductVO;

public interface Hq_IProductService {
	public List<ProductVO> list(Criteria cri, Model model);
	public void insert(MultipartFile file, Model model, ProductVO vo, HttpServletRequest request) throws Exception;
	public List<ProductVO> detail(String hp_Code);
	public void delete(String[] hp_CodeArray);
	public List<ProductVO> selectFileList(String[] hp_Code);
	public void fileDelete(List<ProductVO> allFileList, HttpServletRequest request);
	public void moidfy(MultipartFile file, Model model, ProductVO vo, HttpServletRequest request) throws Exception;
	public void duplicationCheck(HttpServletRequest request, Model model);
	public void stateChange_0(String[] hp_Code);
	public List<ProductVO> susList(Criteria cri, Model model);
	public void productResume(String[] hp_Code);
	
	// 검색
	public List<ProductVO> productListSearch(Criteria cri, Model model, String searchType, String productSearch);
	public List<ProductVO> productListSearch_Category(Criteria cri, Model model, String category);
	
	public List<ProductVO> productSusListSearch(Criteria cri, Model model, String searchType, String productSearch);
	public List<ProductVO> productSusListSearch_Category(Criteria cri, Model model, String category);
}
