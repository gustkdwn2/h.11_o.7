package com.kosta.csm.hq_Dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.kosta.csm.vo.Criteria;
import com.kosta.csm.vo.HeadExpendPerMonth;
import com.kosta.csm.vo.HeadExpendVO;
public interface Hq_IHeadExpendDAO {

	public List<HeadExpendPerMonth> HeadExpendPerMonth(Criteria cri);

	public void removeOfMonth(String yearAndMonth);

	public List<HeadExpendVO> HeadExpendOfMonth(@Param("cri") Criteria cri, @Param("he_Date") String he_Date);

	public void removeOfNum(Integer he_Num);

	public void addExpend(HeadExpendVO headExpendVO);

	public HeadExpendVO getExpendOfNum(Integer he_Num);

	public void updateExpend(HeadExpendVO vo);

	public int HeadExpendPerMonthCount();

	public int HeadExpendOfMonthCount(String he_Date);
	
	public List<HeadExpendPerMonth> expendSearch(@Param("cri") Criteria cri, @Param ("date") String date);

	public int expendSearchCount(String date);
}
