package com.kosta.csm.vo;

// 페이징 처리
public class CriteriaIndex {
	private int m_PageNum;
	private int o_PageNum;
	private int pageSize = 10;
	private int m_CurrentPage;
	private int o_CurrentPage;
	
	
	public CriteriaIndex(){
		this.m_PageNum = 1;
		this.o_PageNum = 1;
		this.pageSize = 10;
	}
	
	
	public int getO_PageNum() {
		return o_PageNum;
	}
	public void setO_PageNum(int o_PageNum) {
		if(o_PageNum <= 0){
			this.o_PageNum = 1;
			return;
		}// if
		
		this.o_PageNum = o_PageNum;
	}


	public int getM_PageNum() {
		return m_PageNum;
	}
	public void setM_PageNum(int m_PageNum){
		if(m_PageNum <= 0){
			this.m_PageNum = 1;
			return;
		}// if
		
		this.m_PageNum = m_PageNum;
	}
	
	public int getM_PageStart(){
		m_CurrentPage = m_PageNum;
		return (m_CurrentPage * pageSize) -9;
	}
	
	public int getM_PageEnd(){
		m_CurrentPage = m_PageNum;
		return (m_CurrentPage * pageSize);
	}
	
	
	public int getO_PageStart(){
		o_CurrentPage = o_PageNum;
		return (o_CurrentPage * pageSize) -9;
	}
	public int getO_PageEnd(){
		o_CurrentPage = o_PageNum;
		return (o_CurrentPage * pageSize);
	}




	public int getPageSize() {
		return pageSize;
	}


	public int getM_CurrentPage() {
		return m_CurrentPage;
	}


	public int getO_CurrentPage() {
		return o_CurrentPage;
	}

	
	
	
}
