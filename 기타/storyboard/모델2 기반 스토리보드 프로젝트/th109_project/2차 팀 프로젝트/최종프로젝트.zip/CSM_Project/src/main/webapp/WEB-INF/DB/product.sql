
-----------------------------------------------------------간편식사-----------------------------------------------------------
insert into product values('em001', '초코바나나크림샌드', 'em001.jpg', 1100, 1400, 1900, '간편식사', 'CU', '2016/6/30', '110g', 1);

insert into product values('em002', '짜장폭탄주먹밥', 'em002.jpg', 900, 1000, 1300, '간편식사', 'CU', '2016/6/30', '155g', 1);

insert into product values('em003', '매콤햄김치볶음밥', 'em003.jpg', 500, 700, 900, '간편식사', 'CU', '2016/6/30', '155g', 1);

insert into product values('em004', '뉴소고기고추장', 'em004.jpg', 500, 600, 800, '간편식사', 'CU', '2016/6/30', '115g', 1);

insert into product values('em005', '할라피뇨떡갈비버거', 'em005.jpg', 1500, 1900, 2200, '간편식사', 'CU', '2016/6/30', '155g', 1);

insert into product values('em006', '블루베리크림샌드위치', 'em006.jpg', 1750, 1800, 2000, '간편식사', 'CU', '2016/6/30', '1105g', 1);

insert into product values('em007', '오므라이스롤', 'em007.jpg', 800, 1000, 1500, '간편식사', 'CU', '2016/6/30', '160g', 1);

insert into product values('em008', '맛있는핫도그오리지날', 'em008.jpg', 1000, 1300, 1800, '간편식사', 'CU', '2016/6/30', '120g', 1);

insert into product values('em009', '생선까스갈비산적', 'em009.jpg', 2500, 2700, 3000, '간편식사', 'CU', '2016/6/30', '430g', 1);

insert into product values('em010', '9첩반상', 'em010.jpg', 3500, 3700, 3900, '간편식사', 'CU', '2016/6/30', '420g', 1);

insert into product values('em011', '제주매콤돈가스소시지', 'em011.jpg', 2500, 2700, 3000, '간편식사', 'CU', '2016/6/30', '420g', 1);

insert into product values('em012', '뉴불고기버거', 'em012.jpg', 750, 800, 1000, '간편식사', 'CU', '2016/6/30', '110g', 1);

insert into product values('em013', '7첩반상', 'em013.jpg', 3500, 3700, 3900, '간편식사', 'CU', '2016/6/30', '415g', 1);

insert into product values('em014', '깔끔한참치샌드위치', 'em014.jpg', 1000, 1300, 1800, '간편식사', 'CU', '2016/6/30', '110g', 1);

insert into product values('em015', '깔끔한에그샌드위치', 'em015.jpg', 1000, 1300, 1800, '간편식사', 'CU', '2016/6/30', '110g', 1);

insert into product values('em016', '숯불맛불고기', 'em016.jpg', 800, 1000, 1500, '간편식사', 'CU', '2016/6/30', '193g', 1);

insert into product values('em017', '제주왕돈까스김밥', 'em017.jpg', 1750, 1860, 2100, '간편식사', 'CU', '2016/6/30', '245g', 1);

insert into product values('em018', '라면에말아먹는흰쌀밥', 'em018.jpg', 400, 500, 700, '간편식사', 'CU', '2016/6/30', '125g', 1);

insert into product values('em019', '모짜렐라해쉬버거', 'em019.jpg', 1900, 2000, 2300, '간편식사', 'CU', '2016/6/30', '145g', 1);

insert into product values('em020', '백종원부대찌개', 'em020.jpg', 3200, 3400, 3800, '간편식사', 'CU', '2016/6/30', '430g', 1);

insert into product values('em021', '소시지볼튀김참치마요', 'em021.jpg', 900, 1100, 1600, '간편식사', 'CU', '2016/6/30', '135g', 1);

insert into product values('em022', 'NEW핫크리스피통살치킨', 'em022.jpg', 500, 700, 900, '간편식사', 'CU', '2016/6/30', '150g', 1);

insert into product values('em023', '매콤순살치킨빅밥바', 'em023.jpg', 1750, 1800, 2000, '간편식사', 'CU', '2016/6/30', '225g', 1);

insert into product values('em024', '순대국밥정식', 'em024.jpg', 3000, 3300, 3800, '간편식사', 'CU', '2016/6/30', '400g', 1);

insert into product values('em025', '맵닭달닭반반김밥', 'em025.jpg', 1000, 1300, 1800, '간편식사', 'CU', '2016/6/30', '220g', 1);

insert into product values('em026', '엄마표빵속등심돈까스', 'em026.jpg', 1500, 2000, 2500, '간편식사', 'CU', '2016/6/30', '190g', 1);

insert into product values('em027', '멜팅치즈불고기샌드', 'em027.jpg', 1750, 1800, 2000, '간편식사', 'CU', '2016/6/30', '130g', 1);

insert into product values('em028', '쉬림프치즈버거', 'em028.jpg', 1900, 2000, 2300, '간편식사', 'CU', '2016/6/30', '145g', 1);

insert into product values('em029', '제주소불고기덮밥', 'em029.jpg', 3000, 3200, 3500, '간편식사', 'CU', '2016/6/30', '290g', 1);

insert into product values('em030', '제주치킨마요덮밥', 'em030.jpg', 3000, 3200, 3500, '간편식사', 'CU', '2016/6/30', '345g', 1);



-----------------------------------------------------------즉석조리-----------------------------------------------------------
insert into product values('in001', '웨지감자튀김500', 'in001.jpg', 3100, 3300, 3600, '즉석조리', 'CU', '2016/6/30', '500g', 1);

insert into product values('in002', '웨지감자튀김250', 'in002.jpg', 1000, 1300, 1800, '즉석조리', 'CU', '2016/6/30', '250g', 1);

insert into product values('in003', '달콤망고잼가득빵', 'in003.jpg', 800, 900, 1200, '즉석조리', 'CU', '2016/6/30', '50g', 1);

insert into product values('in004', '진한초코가득빵', 'in004.jpg', 800, 900, 1200, '즉석조리', 'CU', '2016/6/30', '50g', 1);

insert into product values('in005', '더블치즈가득빵', 'in005.jpg', 800, 1000, 1300, '즉석조리', 'CU', '2016/6/30', '50g', 1);

insert into product values('in006', '망고잼페스츄리', 'in006.jpg', 800, 1000, 1300, '즉석조리', 'CU', '2016/6/30', '60g', 1);

insert into product values('in007', '망고벌집파이', 'in007.jpg', 900, 1100, 1400, '즉석조리', 'CU', '2016/6/30', '60g', 1);

insert into product values('in008', '콘파이', 'in008.jpg', 800, 900, 1200, '즉석조리', 'CU', '2016/6/30', '50g', 1);

insert into product values('in009', '오레오튀김', 'in009.jpg', 400, 450, 600, '즉석조리', 'CU', '2016/6/30', '20g', 1);

insert into product values('in010', '바나나파이', 'in010.jpg', 900, 1300, 1500, '즉석조리', 'CU', '2016/6/30', '50g', 1);

insert into product values('in011', '해물스틱바', 'in011.jpg', 800, 900, 1200, '즉석조리', 'CU', '2016/6/30', '60g', 1);

insert into product values('in012', '매콤새우맛바', 'in012.jpg', 800, 1000, 1300, '즉석조리', 'CU', '2016/6/30', '65g', 1);

insert into product values('in013', '컵속에치즈쿠키', 'in013.jpg', 900, 1300, 1500, '즉석조리', 'CU', '2016/6/30', '70g', 1);

insert into product values('in014', '컵속에초코칩쿠키', 'in014.jpg', 900, 1300, 1500, '즉석조리', 'CU', '2016/6/30', '70g', 1);

insert into product values('in015', '애플크라운', 'in015.jpg', 800, 900, 1200, '즉석조리', 'CU', '2016/6/30', '50g', 1);

insert into product values('in016', '아몬드크로와상', 'in016.jpg', 800, 900, 1200, '즉석조리', 'CU', '2016/6/30', '50g', 1);

insert into product values('in017', '찹쌀떡패스트리', 'in017.jpg', 800, 900, 1200, '즉석조리', 'CU', '2016/6/30', '50g', 1);

insert into product values('in018', '추억의한입붕어빵', 'in018.jpg', 200, 300, 400, '즉석조리', 'CU', '2016/6/30', '10g', 1);

insert into product values('in019', '추억의갓소시지빵', 'in019.jpg', 1000, 1300, 1800, '즉석조리', 'CU', '2016/6/30', '70g', 1);

insert into product values('in020', '추억햄에그고로케', 'in020.jpg', 900, 1100, 1400, '즉석조리', 'CU', '2016/6/30', '50g', 1);

insert into product values('in021', '추억의갓단팥빵', 'in021.jpg', 800, 900, 1200, '즉석조리', 'CU', '2016/6/30', '50g', 1);

insert into product values('in022', '초코마카롱도넛', 'in022.jpg', 800, 850, 1000, '즉석조리', 'CU', '2016/6/30', '40g', 1);

insert into product values('in023', '딸기마카롱도넛', 'in023.jpg', 800, 850, 1000, '즉석조리', 'CU', '2016/6/30', '40g', 1);

insert into product values('in024', '추억의갓꽈배기', 'in024.jpg', 800, 900, 1100, '즉석조리', 'CU', '2016/6/30', '50g', 1);

insert into product values('in025', '추억의찹쌀도넛2입', 'in025.jpg', 900, 1100, 1400, '즉석조리', 'CU', '2016/6/30', '60g', 1);

insert into product values('in026', '추억의갓케익도넛', 'in026.jpg', 800, 900, 1100, '즉석조리', 'CU', '2016/6/30', '40g', 1);

insert into product values('in027', '추억의갓링도넛', 'in027.jpg', 800, 900, 1100, '즉석조리', 'CU', '2016/6/30', '40g', 1);

insert into product values('in028', '찐한치즈머핀', 'in028.jpg', 1000, 1300, 1800, '즉석조리', 'CU', '2016/6/30', '60g', 1);

insert into product values('in029', '상큼블루베리머핀', 'in029.jpg', 1000, 1300, 1800, '즉석조리', 'CU', '2016/6/30', '60g', 1);

insert into product values('in030', '감자빵', 'in030.jpg', 800, 900, 1200, '즉석조리', 'CU', '2016/6/30', '50g', 1);



-----------------------------------------------------------과자류-----------------------------------------------------------
insert into product values('sn001', '허니버터칩', 'sn001.jpg', 900, 1300, 1500, '과자류', '해태', '2017/01/11', '60g', 1);

insert into product values('sn002', '새우깡', 'sn002.jpg', 600, 750, 1100, '과자류', '농심', '2017/06/28', '90g', 1);

insert into product values('sn003', '프링글스오리지날', 'sn003.jpg', 2000, 2500, 3300, '과자류', '한국프링글스', '2016/12/30', '149g', 1);

insert into product values('sn004', '양파링', 'sn004.jpg', 900, 950, 1300, '과자류', '농심', '2016/12/30', '84g', 1);

insert into product values('sn005', '오징어땅콩', 'sn005.jpg', 900, 1000, 1500, '과자류', '오리온', '2016/12/30', '98g', 1);

insert into product values('sn006', '에끌레어', 'sn006.jpg', 1000, 1300, 1800, '과자류', '삼립', '2016/12/30', '55g', 1);

insert into product values('sn007', '에이스', 'sn007.jpg', 900, 950, 1400, '과자류', '해태', '2016/12/30', '121g', 1);

insert into product values('sn008', '키커바', 'sn008.jpg', 800, 850, 1000, '과자류', 'CROWN', '2016/12/30', '90g', 1);

insert into product values('sn009', '에어칩스치즈', 'sn009.jpg', 900, 950, 1500, '과자류', 'HEYROO', '2016/12/30', '63g', 1);

insert into product values('sn010', '에어칩스어니언', 'sn010.jpg', 900, 950, 1500, '과자류', 'HEYROO', '2016/12/30', '63g', 1);

insert into product values('sn011', '향긋한아베크까망베르치즈쿠키', 'sn011.jpg', 800, 900, 1000, '과자류', 'HEYROO', '2016/12/30', '63g', 1);

insert into product values('sn012', '카라멜맛팝콘', 'sn012.jpg', 800, 900, 1000, '과자류', 'HEYROO', '2016/12/30', '60g', 1);

insert into product values('sn013', '펀스톤초코렛', 'sn013.jpg', 800, 900, 1000, '과자류', 'HEYROO', '2016/12/30', '50g', 1);

insert into product values('sn014', '해씨초코볼', 'sn014.jpg', 800, 900, 1000, '과자류', 'HEYROO', '2016/12/30', '50g', 1);

insert into product values('sn015', '야채칩', 'sn015.jpg', 900, 950, 1500, '과자류', 'HEYROO', '2016/12/30', '28g', 1);

insert into product values('sn016', '새콤달콤키위', 'sn016.jpg', 300, 350, 500, '과자류', 'CROWN', '2016/12/30', '29g', 1);

insert into product values('sn017', '키커바바나나', 'sn017.jpg', 800, 850, 1000, '과자류', 'CROWN', '2016/12/30', '90g', 1);

insert into product values('sn018', '달고나팝콘', 'sn018.jpg', 800, 950, 1500, '과자류', '해태', '2016/12/30', '80g', 1);

insert into product values('sn019', '콘칩발사믹', 'sn019.jpg', 800, 950, 1500, '과자류', '크라운', '2016/12/30', '70g', 1);

insert into product values('sn020', '스노우치즈케익', 'sn020.jpg', 1000, 1500, 2500, '과자류', '삼립', '2016/12/30', '58g', 1);

insert into product values('sn021', '빅슈에바나나', 'sn021.jpg', 1000, 1300, 1800, '과자류', '삼립', '2016/12/30', '85g', 1);

insert into product values('sn022', '초코슈크림빵', 'sn022.jpg', 800, 900, 1100, '과자류', '롯데', '2016/12/30', '80g', 1);

insert into product values('sn023', '프링글스버터카라멜', 'sn023.jpg', 1800, 2000, 3300, '과자류', '한국프링글스', '2016/12/30', '110g', 1);

insert into product values('sn024', '오예스바나나', 'sn024.jpg', 2800, 3900, 4800, '과자류', '롯데', '2016/12/30', '336g', 1);

insert into product values('sn025', '에끌레어클래식', 'sn025.jpg', 800, 1300, 1900, '과자류', 'CJ', '2016/12/30', '48g', 1);

insert into product values('sn026', '에끌레어라즈베리', 'sn026.jpg', 800, 1300, 1900, '과자류', 'CJ', '2016/12/30', '48g', 1);

insert into product values('sn027', '바나나크림빵', 'sn027.jpg', 600, 800, 900, '과자류', '삼립', '2016/12/30', '70g', 1);

insert into product values('sn028', '바나나보름달', 'sn028.jpg', 600, 800, 1000, '과자류', '삼립', '2016/12/30', '70g', 1);

insert into product values('sn029', '아몬드빼빼로', 'sn029.jpg', 800, 900, 1200, '과자류', '롯데', '2016/12/30', '32g', 1);

insert into product values('sn030', '초코빼빼로', 'sn030.jpg', 800, 900, 1200, '과자류', '롯데', '2016/12/30', '32g', 1);



-----------------------------------------------------------아이스크림-----------------------------------------------------------
insert into product values('ic001', '메로나', 'ic001.jpg', 750, 800, 1000, '아이스크림', '빙그레', '2017/6/30', '80ml', 1);

insert into product values('ic002', '월드콘', 'ic002.jpg', 1000, 1200, 1500, '아이스크림', '롯데', '2017/6/30', '170ml', 1);

insert into product values('ic003', '스크류바', 'ic003.jpg', 750, 800, 1000, '아이스크림', '롯데', '2017/6/30', '75ml', 1);

insert into product values('ic004', '더블쭈쭈바초코', 'ic004.jpg', 750, 800, 1000, '아이스크림', 'HEYROO', '2017/6/30', '130ml', 1);

insert into product values('ic005', '눈의정원', 'ic005.jpg', 2600, 3400, 3900, '아이스크림', '롯데', '2017/6/30', '660ml', 1);

insert into product values('ic006', '와플통팥', 'ic006.jpg', 900, 1000, 1500, '아이스크림', '롯데', '2017/6/30', '140ml', 1);

insert into product values('ic007', '1000콘딸기', 'ic007.jpg', 750, 800, 1000, '아이스크림', 'CU', '2017/6/30', '170ml', 1);

insert into product values('ic008', '구구크러스터', 'ic008.jpg', 4700, 5000, 6000, '아이스크림', '롯데', '2017/6/30', '660ml', 1);

insert into product values('ic009', '보석바바나나', 'ic009.jpg', 750, 800, 1000, '아이스크림', '롯데', '2017/6/30', '80ml', 1);

insert into product values('ic010', '라베스트초코콘', 'ic010.jpg', 1750, 1800, 2000, '아이스크림', '롯데', '2017/6/30', '160ml', 1);

insert into product values('ic011', '커피아몬드바', 'ic011.jpg', 2600, 3400, 3900, '아이스크림', '하겐', '2017/6/30', '240ml', 1);

insert into product values('ic012', '아시나요', 'ic012.jpg', 800, 1000, 1500, '아이스크림', '삼립', '2017/6/30', '180ml', 1);

insert into product values('ic013', '쿠키오치즈샌드', 'ic013.jpg', 800, 1000, 1500, '아이스크림', '롯데', '2017/6/30', '130ml', 1);

insert into product values('ic014', '녹차바', 'ic014.jpg', 2500, 3000, 3500, '아이스크림', '나뚜루', '2017/6/30', '90ml', 1);

insert into product values('ic015', '그릭요거트콘', 'ic015.jpg', 1000, 1300, 1800, '아이스크림', '롯데', '2017/6/30', '160ml', 1);

insert into product values('ic016', '팔라쪼체리바', 'ic016.jpg', 1000, 1300, 1800, '아이스크림', '해태', '2017/6/30', '160ml', 1);

insert into product values('ic017', '우유쿠키빙수', 'ic017.jpg', 1500, 2000, 2500, '아이스크림', 'HEYROO', '2017/6/30', '300ml', 1);

insert into product values('ic018', '탱크보이', 'ic018.jpg', 800, 900, 1200, '아이스크림', '롯데', '2017/6/30', '100ml', 1);

insert into product values('ic019', '바밤바골드', 'ic019.jpg', 750, 800, 1000, '아이스크림', '해태', '2017/6/30', '70ml', 1);

insert into product values('ic020', '프라페오렌지망고', 'ic020.jpg', 1750, 1800, 2000, '아이스크림', '롯데', '2017/6/30', '300ml', 1);

insert into product values('ic021', '슬라이스팝키위', 'ic021.jpg', 1500, 2000, 2500, '아이스크림', '빙그레', '2017/6/30', '90ml', 1);

insert into product values('ic022', '슬라이스팝블루', 'ic022.jpg', 1500, 2000, 2500, '아이스크림', '빙그레', '2017/6/30', '90ml', 1);

insert into product values('ic023', '허니아이스', 'ic023.jpg', 750, 800, 1000, '아이스크림', '해태', '2017/6/30', '75ml', 1);

insert into product values('ic024', '미스파인애플바', 'ic024.jpg', 800, 900, 1200, '아이스크림', 'CU', '2017/6/30', '60ml', 1);

insert into product values('ic025', '미스망고바', 'ic025.jpg', 800, 900, 1200, '아이스크림', 'CU', '2017/6/30', '60ml', 1);

insert into product values('ic026', '빅구슬아이스망고', 'ic026.jpg', 800, 1000, 1500, '아이스크림', '동학', '2017/6/30', '62ml', 1);

insert into product values('ic027', '아이스께끼오렌지', 'ic027.jpg', 350, 400, 500, '아이스크림', 'HEYROO', '2017/6/30', '100ml', 1);

insert into product values('ic028', '아이스께끼파인애플', 'ic028.jpg', 350, 400, 500, '아이스크림', 'HEYROO', '2017/6/30', '100ml', 1);

insert into product values('ic029', '더블비얀코', 'ic029.jpg', 1000, 1300, 1800, '아이스크림', '롯데', '2017/6/30', '210ml', 1);

insert into product values('ic030', '누가바', 'ic030.jpg', 750, 800, 1000, '아이스크림', '해태', '2017/6/30', '80ml', 1);



-----------------------------------------------------------식품-----------------------------------------------------------
insert into product values('fo001', '통단팥죽', 'fo001.jpg', 2600, 2900, 3200, '식품', '오뚜기', '2016/6/30', '285g', 1);

insert into product values('fo002', '전복죽', 'fo002.jpg', 2500, 3000, 3500, '식품', '오뚜기', '2016/6/30', '285g', 1);

insert into product values('fo003', '둥지비빔냉면', 'fo003.jpg', 900, 1300, 1500, '식품', '농심', '2016/6/30', '162g', 1);

insert into product values('fo004', '둥지물김치냉면', 'fo004.jpg', 900, 1300, 1500, '식품', '농심', '2016/6/30', '162g', 1);

insert into product values('fo005', '양반전통김', 'fo005.jpg', 800, 1000, 1300, '식품', '동원', '2016/6/30', '5g', 1);

insert into product values('fo006', '네모피자그릴치킨', 'fo006.jpg', 2500, 2700, 3000, '식품', '풀무원', '2016/6/30', '90g', 1);

insert into product values('fo007', '네모피자그릴함박', 'fo007.jpg', 2500, 2700, 3000, '식품', '풀무원', '2016/6/30', '90g', 1);

insert into product values('fo008', '콘스프', 'fo008.jpg', 2900, 3100, 3400, '식품', 'HEYROO', '2016/6/30', '185g', 1);

insert into product values('fo009', '안심치킨매콤닭강정', 'fo009.jpg', 2400, 2600, 2900, '식품', '대림', '2016/6/30', '130g', 1);

insert into product values('fo010', '컵반옐로우커리덮밥', 'fo010.jpg', 2600, 3000, 3300, '식품', 'CJ', '2016/6/30', '280g', 1);

insert into product values('fo011', '볶음진짬뽕컵', 'fo011.jpg', 900, 1100, 1600, '식품', '오뚜기', '2016/6/30', '110g', 1);

insert into product values('fo012', '리코타샐러드', 'fo012.jpg', 2500, 3000, 3500, '식품', 'Nette', '2016/6/30', '160g', 1);

insert into product values('fo013', '닭가슴살샐러드', 'fo013.jpg', 2500, 3000, 3500, '식품', 'Nette', '2016/6/30', '160g', 1);

insert into product values('fo014', '스노우부어스트', 'fo014.jpg', 2600, 2900, 3200, '식품', '진주', '2016/6/30', '70g', 1);

insert into product values('fo015', '밥말라계란콩나물', 'fo015.jpg', 1500, 1700, 2000, '식품', 'HEYROO', '2016/6/30', '118.5g', 1);

insert into product values('fo016', '사골국밥', 'fo016.jpg', 2600, 3000, 3300, '식품', 'HEYROO', '2016/6/30', '250g', 1);

insert into product values('fo017', '미역국밥', 'fo017.jpg', 2600, 3000, 3300, '식품', 'HEYROO', '2016/6/30', '250g', 1);

insert into product values('fo018', '스파이시비엔나', 'fo018.jpg', 800, 1300, 1900, '식품', 'CJ', '2016/6/30', '70g', 1);

insert into product values('fo019', '세부파인애플', 'fo019.jpg', 3500, 3700, 4000, '식품', '미션', '2016/6/30', '100g', 1);

insert into product values('fo020', '세부망고', 'fo020.jpg', 4500, 4700, 5000, '식품', '미션', '2016/6/30', '100g', 1);

insert into product values('fo021', '팔도비빔면컵', 'fo021.jpg', 650, 800, 1050, '식품', '팔도', '2016/6/30', '108g', 1);

insert into product values('fo022', '사골떡국', 'fo022.jpg', 2500, 2700, 3000, '식품', 'HEYROO', '2016/6/30', '253g', 1);

insert into product values('fo023', '밥말라부대찌개라면', 'fo023.jpg', 1000, 1300, 1800, '식품', 'HEYROO', '2016/6/30', '146g', 1);

insert into product values('fo024', '갓비빔면', 'fo024.jpg', 900, 1300, 1500, '식품', '삼양', '2016/6/30', '135g', 1);

insert into product values('fo025', '진짬뽕소컵', 'fo025.jpg', 800, 900, 1200, '식품', '오뚜기', '2016/6/30', '75g', 1);

insert into product values('fo026', '치킨프랑크', 'fo026.jpg', 900, 1100, 1600, '식품', '롯데', '2016/6/30', '70g', 1);

insert into product values('fo027', '의성마을비엔나', 'fo027.jpg', 2500, 3000, 3500, '식품', '롯데', '2016/6/30', '136g', 1);

insert into product values('fo028', '떡갈비꼬치', 'fo028.jpg', 1500, 2000, 2500, '식품', '롯데', '2016/6/30', '90g', 1);

insert into product values('fo029', '치즈불닭볶음면컵', 'fo029.jpg', 600, 1200, 1500, '식품', '삼양', '2016/6/30', '105g', 1);

insert into product values('fo030', 'XXL스트링치즈라이트', 'fo030.jpg', 800, 1300, 1900, '식품', 'CNP', '2016/6/30', '40g', 1);



-----------------------------------------------------------음료-----------------------------------------------------------
insert into product values('dr001', '포카리스웨트캔', 'dr001.jpg', 350, 400, 1000, '음료', '동아오츠카', '2017/6/30', '245ml', 1);

insert into product values('dr002', '코카콜라캔', 'dr002.jpg', 850, 1000, 1300, '음료', '코카콜라', '2017/6/30', '250ml', 1);

insert into product values('dr003', '칠성사이다캔', 'dr003.jpg', 850, 1000, 1300, '음료', '롯데칠성음료', '2017/6/30', '250ml', 1);

insert into product values('dr004', '우유속에코코아', 'dr004.jpg', 550, 800, 1500, '음료', '매일', '2017/6/30', '310ml', 1);

insert into product values('dr005', '썬업과일야채녹황', 'dr005.jpg', 850, 1000, 1300, '음료', '매일', '2017/6/30', '190ml', 1);

insert into product values('dr006', '토레타', 'dr006.jpg', 1000, 1300, 1800, '음료', '코카콜라', '2017/6/30', '500ml', 1);

insert into product values('dr007', '바리스타블랙컵', 'dr007.jpg', 1450, 1640, 2500, '음료', '매일', '2017/6/30', '325ml', 1);

insert into product values('dr008', '바리스타드립라떼', 'dr008.jpg', 1450, 1640, 2500, '음료', '매일', '2017/6/30', '325ml', 1);

insert into product values('dr009', '예쁘다파인', 'dr009.jpg', 2450, 2640, 3000, '음료', '올가니카', '2017/6/30', '190ml', 1);

insert into product values('dr010', '힘나다샤인', 'dr010.jpg', 2450, 2640, 3000, '음료', '올가니카', '2017/6/30', '190ml', 1);

insert into product values('dr011', '가볍다그린', 'dr011.jpg', 2450, 2640, 3000, '음료', '올가니카', '2017/6/30', '190ml', 1);

insert into product values('dr012', '수박우유', 'dr012.jpg', 850, 1000, 1300, '음료', '서울우유', '2017/6/30', '260ml', 1);

insert into product values('dr013', '초코바나나에몽', 'dr013.jpg', 800, 900, 1200, '음료', '남양', '2017/6/30', '250ml', 1);

insert into product values('dr014', '17차홍차', 'dr014.jpg', 800, 900, 1200, '음료', '남양', '2017/6/30', '340ml', 1);

insert into product values('dr015', '리얼브루에스프', 'dr015.jpg', 950, 1640, 1900, '음료', '푸르밀', '2017/6/30', '250ml', 1);

insert into product values('dr016', '리얼브루라떼컵', 'dr016.jpg', 950, 1640, 1900, '음료', '푸르밀', '2017/6/30', '250ml', 1);

insert into product values('dr017', '몬스터울트라에너지', 'dr017.jpg', 950, 1640, 1900, '음료', '코카콜라', '2017/6/30', '355ml', 1);

insert into product values('dr018', '스프라이트P', 'dr018.jpg', 1450, 2000, 2800, '음료', '코카콜라', '2017/6/30', '1.5L', 1);

insert into product values('dr019', '옥수수수염P', 'dr019.jpg', 850, 1040, 1300, '음료', '롯데칠성음료', '2017/6/30', '1L', 1);

insert into product values('dr020', '황금라떼', 'dr020.jpg', 1450, 1640, 1900, '음료', '빽다방', '2017/6/30', '300ml', 1);

insert into product values('dr021', '빽메리카노', 'dr021.jpg', 1450, 1640, 1900, '음료', '빽다방', '2017/6/30', '300ml', 1);

insert into product values('dr022', '바이오드링킹망고', 'dr022.jpg', 450, 640, 1700, '음료', '매일', '2017/6/30', '250ml', 1);

insert into product values('dr023', '애플망고두유아이스', 'dr023.jpg', 450, 640, 1100, '음료', '베지밀', '2017/6/30', '190ml', 1);

insert into product values('dr024', '야왕차', 'dr024.jpg', 1450, 1640, 2000, '음료', '광동', '2017/6/30', '500ml', 1);

insert into product values('dr025', '청사과탄산수', 'dr025.jpg', 450, 640, 1000, '음료', 'HEYROO', '2017/6/30', '350ml', 1);

insert into product values('dr026', '커피우유', 'dr026.jpg', 1450, 1640, 2400, '음료', 'HEYROO', '2017/6/30', '1L', 1);

insert into product values('dr027', '요플레포미블루베리', 'dr027.jpg', 800, 900, 1200, '음료', '빙그레', '2017/6/30', '110ml', 1);

insert into product values('dr028', '요플레포미복숭아', 'dr028.jpg', 800, 900, 1200, '음료', '빙그레', '2017/6/30', '110ml', 1);

insert into product values('dr029', '울트라라떼컵', 'dr029.jpg', 1450, 1640, 2000, '음료', 'GET', '2017/6/30', '250ml', 1);

insert into product values('dr030', '티오피마스터라떼', 'dr030.jpg', 2450, 2640, 2900, '음료', '동서', '2017/6/30', '380ml', 1);



-----------------------------------------------------------생활용품-----------------------------------------------------------
insert into product values('ds001', '발효초샴푸', 'ds001.jpg', 8000, 9000, 9900, '생활용품', '오가니스트', '2017/6/30', '380ml', 1);

insert into product values('ds002', '스파이킹왁스', 'ds002.jpg', 9000, 11000, 13000, '생활용품', '갓투비', '2017/6/30', '57g', 1);

insert into product values('ds003', '힐링선크림', 'ds003.jpg', 11000, 13000, 16000, '생활용품', '더퓨어', '2017/6/30', '80ml', 1);

insert into product values('ds004', '에프킬라킨', 'ds004.jpg', 4000, 4900, 5200, '생활용품', '한국존슨', '2017/6/30', '500ml', 1);

insert into product values('ds005', '아물디S', 'ds005.jpg', 3300, 3600, 4000, '생활용품', '알로에베라코리아', '2017/6/30', '50ml', 1);

insert into product values('ds006', '클레이왁스', 'ds006.jpg', 7500, 8000, 8900, '생활용품', '엘라스틴', '2017/6/30', '80g', 1);

insert into product values('ds007', '하드왁스', 'ds007.jpg', 7500, 8000, 8900, '생활용품', '엘라스틴', '2017/6/30', '80g', 1);

insert into product values('ds008', '스프레이', 'ds008.jpg', 5500, 6000, 6500, '생활용품', '엘라스틴', '2017/6/30', '200ml', 1);

insert into product values('ds009', '페이스트왁스', 'ds009.jpg', 7500, 8000, 8900, '생활용품', '엘라스틴', '2017/6/30', '80g', 1);

insert into product values('ds010', '헤어스프레이', 'ds010.jpg', 4500, 5000, 5500, '생활용품', '미쟝센', '2017/6/30', '200ml', 1);

insert into product values('ds011', '스파이키왁스', 'ds011.jpg', 2800, 3000, 3200, '생활용품', '갸스비', '2017/6/30', '15g', 1);

insert into product values('ds012', '가그린제로', 'ds012.jpg', 1300, 1500, 1700, '생활용품', '동아제약', '2017/6/30', '100ml', 1);

insert into product values('ds013', '구론산D병', 'ds013.jpg', 500, 600, 800, '생활용품', '삼성', '2017/6/30', '100ml', 1);

insert into product values('ds014', '까스명수골드', 'ds014.jpg', 500, 600, 800, '생활용품', '농심', '2017/6/30', '75ml', 1);

insert into product values('ds015', '함빛샴푸', 'ds015.jpg', 10000, 11000, 12500, '생활용품', '려', '2017/6/30', '400g', 1);

insert into product values('ds016', '함빛린스', 'ds016.jpg', 10000, 11000, 12500, '생활용품', '려', '2017/6/30', '400g', 1);

insert into product values('ds017', '가그린뉴레귤러', 'ds017.jpg', 3500, 4000, 4500, '생활용품', '동아제약', '2017/6/30', '380ml', 1);

insert into product values('ds018', '가그린뉴레귤러100', 'ds018.jpg', 1300, 1500, 1700, '생활용품', '동아제약', '2017/6/30', '100ml', 1);

insert into product values('ds019', '가그린레귤러', 'ds019.jpg', 3000, 3100, 3600, '생활용품', '동아제약', '2017/6/30', '380ml', 1);

insert into product values('ds020', '액츠데오일반', 'ds020.jpg', 8000, 9000, 9900, '생활용품', '피죤', '2017/6/30', '1.4L', 1);

insert into product values('ds021', '워터포마드', 'ds021.jpg', 8200, 9200, 10000, '생활용품', '미쟝센', '2017/6/30', '75g', 1);

insert into product values('ds022', '매트파워왁스', 'ds022.jpg', 8200, 9200, 10000, '생활용품', '미쟝센', '2017/6/30', '110ml', 1);

insert into product values('ds023', '헤어잼타이트', 'ds023.jpg', 8200, 9200, 10000, '생활용품', '갸스비', '2017/6/30', '120ml', 1);

insert into product values('ds024', '헤어잼엣지', 'ds024.jpg', 8200, 9200, 10000, '생활용품', '갸스비', '2017/6/30', '120ml', 1);

insert into product values('ds025', '헤어잼스마트', 'ds025.jpg', 8200, 9200, 10000, '생활용품', '갸스비', '2017/6/30', '120ml', 1);

insert into product values('ds026', '퍼퓸블라썸', 'ds026.jpg', 5500, 6000, 6500, '생활용품', '샤프란', '2017/6/30', '410ml', 1);

insert into product values('ds027', '퍼퓸그린코튼', 'ds027.jpg', 5500, 6000, 6500, '생활용품', '샤프란', '2017/6/30', '410ml', 1);

insert into product values('ds028', '오프에어졸', 'ds028.jpg', 6000, 6500, 7000, '생활용품', 'SC존슨', '2017/6/30', '150ml', 1);

insert into product values('ds029', '생크림폼', 'ds029.jpg', 900, 950, 1400, '생활용품', '아임유어', '2017/6/30', '30ml', 1);

insert into product values('ds030', '리스테린쿨민트', 'ds030.jpg', 1300, 1500, 1700, '생활용품', '존슨앤존슨', '2017/6/30', '100ml', 1);