package com.kosta.csm.hq_Service;

import java.util.List;

import org.springframework.ui.Model;

import com.kosta.csm.hq_Dao.Hq_IEmployeeDAO;
import com.kosta.csm.hq_Dao.Hq_IPayDAO;
import com.kosta.csm.hq_Dao.Hq_IWorkingTimeDAO;
import com.kosta.csm.vo.Criteria;
import com.kosta.csm.vo.EmployeeAboutStoreName;
import com.kosta.csm.vo.EmployeeVO;
import com.kosta.csm.vo.PayVO;
import com.kosta.csm.vo.WorkingTimeMore;
import com.kosta.csm.vo.WorkingTimePerMonth;

public interface Hq_IPersonResourceService {
	public List<EmployeeAboutStoreName> getEmployee(Criteria cri, Model model);

	public void addEmployee(String year, String month, String day, List<EmployeeVO> list, EmployeeVO vo);

	public void modifyPay(Integer e_Num, Integer e_Pay, String e_Position);

	public void removeEmployee(Integer e_Num, Integer[] targetRemove);

	public void updateEmployee(String year, String month, String day, EmployeeVO vo);
	
	public EmployeeVO getEmployeeOfNum(Integer e_Num);

	public List<WorkingTimeMore> getWorkingTime(Criteria cri, Model model);

	public List<WorkingTimePerMonth> getPayPerMonth(Criteria cri, Model model);

	public Object getSalaryPerMonth(Criteria cri, Model model);

	public String checkMember( EmployeeVO vo);
	
	public List<EmployeeAboutStoreName> employeeSearch(Criteria cri, Model model, String employee, String searchType);

	public List<EmployeeAboutStoreName> setPaySearch(Criteria cri, Model model, String searchType, String employee);

	public List<WorkingTimePerMonth> paySearch(Criteria cri, Model model, String searchType, String search);

	public List<WorkingTimePerMonth> salarySearch(Criteria cri, Model model, String searchType, String search);

	public List<WorkingTimeMore> timePartSearch(Criteria cri, Model model, String searchType, String search);
}
