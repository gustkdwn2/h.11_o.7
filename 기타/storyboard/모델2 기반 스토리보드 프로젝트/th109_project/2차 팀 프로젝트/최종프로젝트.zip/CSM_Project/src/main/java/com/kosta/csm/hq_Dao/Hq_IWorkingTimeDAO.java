package com.kosta.csm.hq_Dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.kosta.csm.vo.Criteria;
import com.kosta.csm.vo.HeadExpendPerMonth;
import com.kosta.csm.vo.WorkingTimeMore;
import com.kosta.csm.vo.WorkingTimePerMonth;

public interface Hq_IWorkingTimeDAO {

	List<WorkingTimeMore> getWorkingTime(Criteria cri);
	int getWorkingTimeCount();

	List<WorkingTimePerMonth> getPayPerMonth(Criteria cri);
	int getPayPerMonthCount();
	
	List<WorkingTimePerMonth> getSalaryPerMonth(Criteria cri);
	int getSalaryPerMonthCount();
	
	HeadExpendPerMonth getExpendPayOfMonth(String he_Date);
	HeadExpendPerMonth getManagePayOfMonth(String he_Date);
	List<WorkingTimeMore> getTimeOfMonth(@Param("he_Date") String he_Date, @Param("e_Position") String e_Position);
	
	List<WorkingTimePerMonth> paySearch_Num(@Param("cri") Criteria cri, @Param("search") String search);
	int paySearchCount_Num(String search);
	
	List<WorkingTimePerMonth> paySearch_Id(@Param("cri") Criteria cri, @Param("search") String search);
	int paySearchCount_Id(String search);
	
	List<WorkingTimePerMonth> paySearch_Name(@Param("cri") Criteria cri, @Param("search") String search);
	int paySearchCount_Name(String search);
	
	List<WorkingTimePerMonth> salarySearch_Num(@Param("cri") Criteria cri, @Param("search") String search);
	int salarySearchCount_Num(String search);
	
	List<WorkingTimePerMonth> salarySearch_Id(@Param("cri") Criteria cri, @Param("search") String search);
	int salarySearchCount_Id(String search);
	
	List<WorkingTimePerMonth> salarySearch_Name(@Param("cri") Criteria cri, @Param("search") String search);
	int salarySearchCount_Name(String search);
	
	List<WorkingTimeMore> timePartSearch_Num(@Param("cri") Criteria cri, @Param("search") String search);
	int timePartSearchCount_Num(String search);
	
	List<WorkingTimeMore> timePartSearch_Id(@Param("cri") Criteria cri, @Param("search") String search);
	int timePartSearchCount_Id(String search);
	
	List<WorkingTimeMore> timePartSearch_Name(@Param("cri") Criteria cri, @Param("search") String search);
	int timePartSearchCount_Name(String search);

}
