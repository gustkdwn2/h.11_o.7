package com.kosta.csm.st_Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/st/chat")
public class St_ChatController {
	
	@RequestMapping("/chat")
	public String chatView(){
		return "st.chat.chat";
	}
}
