package com.kosta.csm.vo;

public class SaleProduct {
	private String hp_Code;
	private String hp_Name;
	private int hp_Cprice;
	private int s_Amount;
	public String getHp_Code() {
		return hp_Code;
	}
	public void setHp_Code(String hp_Code) {
		this.hp_Code = hp_Code;
	}
	public String getHp_Name() {
		return hp_Name;
	}
	public void setHp_Name(String hp_Name) {
		this.hp_Name = hp_Name;
	}
	public int getHp_Cprice() {
		return hp_Cprice;
	}
	public void setHp_Cprice(int hp_Cprice) {
		this.hp_Cprice = hp_Cprice;
	}
	public int getS_Amount() {
		return s_Amount;
	}
	public void setS_Amount(int s_Amount) {
		this.s_Amount = s_Amount;
	}
}
