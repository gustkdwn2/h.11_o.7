package com.kosta.csm.vo;

public class WorkingTimePerMonth {
	String month; // 년/월
	int e_Num; // 직원번호
	String ct; // 달별 근무횟수
	String m_Id; // 근무매장번호
	int workMinuteSum; // 달별 총근무시간(분단위)
	double workHourSum; // 달별 총근무시간(시단위)
	String e_Position;//구분 (점장/아르바이트)
	String m_Store; // 근무매장이름
	int e_Pay;// 급여

	public String getE_Position() {
		return e_Position;
	}

	public void setE_Position(String e_Position) {
		this.e_Position = e_Position;
	}

	public double getWorkHourSum() {
		return workHourSum;
	}

	public void setWorkHourSum(double workHourSum) {
		this.workHourSum = workHourSum;
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public int getE_Num() {
		return e_Num;
	}

	public void setE_Num(int e_Num) {
		this.e_Num = e_Num;
	}

	public String getCt() {
		return ct;
	}

	public void setCt(String ct) {
		this.ct = ct;
	}

	public String getM_Id() {
		return m_Id;
	}

	public void setM_Id(String m_Id) {
		this.m_Id = m_Id;
	}

	public int getWorkMinuteSum() {
		return workMinuteSum;
	}

	public void setWorkMinuteSum(int workMinuteSum) {
		this.workMinuteSum = workMinuteSum;
	}

	public String getM_Store() {
		return m_Store;
	}

	public void setM_Store(String m_Store) {
		this.m_Store = m_Store;
	}

	public int getE_Pay() {
		return e_Pay;
	}

	public void setE_Pay(int e_Pay) {
		this.e_Pay = e_Pay;
	}

}
