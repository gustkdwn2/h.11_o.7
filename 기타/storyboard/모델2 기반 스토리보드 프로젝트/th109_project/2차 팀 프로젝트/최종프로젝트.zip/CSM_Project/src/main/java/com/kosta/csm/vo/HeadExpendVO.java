package com.kosta.csm.vo;

public class HeadExpendVO {
	int he_Num;  //지출번호
	String he_Date; // 지출 날짜 ('년/월/일' 만  저장)
	int he_Expend; // 지출금
	String he_Content; //지출내역
	String he_ExpendDirector; //지출수행자
	public int getHe_Num() {
		return he_Num;
	}
	public void setHe_Num(int he_Num) {
		this.he_Num = he_Num;
	}
	public String getHe_Date() {
		return he_Date;
	}
	public void setHe_Date(String he_Date) {
		this.he_Date = he_Date;
	}
	public int getHe_Expend() {
		return he_Expend;
	}
	public void setHe_Expend(int he_Expend) {
		this.he_Expend = he_Expend;
	}
	public String getHe_Content() {
		return he_Content;
	}
	public void setHe_Content(String he_Content) {
		this.he_Content = he_Content;
	}
	public String getHe_ExpendDirector() {
		return he_ExpendDirector;
	}
	public void setHe_ExpendDirector(String he_ExpendDirector) {
		this.he_ExpendDirector = he_ExpendDirector;
	}
	
}

