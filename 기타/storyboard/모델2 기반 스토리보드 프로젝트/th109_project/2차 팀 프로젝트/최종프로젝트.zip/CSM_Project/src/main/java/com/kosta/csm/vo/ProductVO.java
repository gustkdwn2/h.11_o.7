package com.kosta.csm.vo;

public class ProductVO {
	private String hp_Code;
	private String hp_Name;
	private String hp_Path;
	private int hp_Oprice;
	private int hp_Mprice;
	private int hp_Cprice;
	//private String hp_FileName;//추가!!!!
	private String hp_Category;
	private String hp_Manufacturer;
	private String hp_ExpirationDate;
	private String hp_Weight;
	private int hp_State;
	private int s_Amount;
	

	

	//생성자
	public ProductVO(){
		
	}
	
	public ProductVO(String hp_Code, String hp_Name, String hp_Path, int hp_Oprice, int hp_Mprice, int hp_Cprice, String hp_Category) {
		this.hp_Code = hp_Code;
		this.hp_Name = hp_Name;
		this.hp_Path = hp_Path;
		this.hp_Oprice = hp_Oprice;
		this.hp_Mprice = hp_Mprice;
		this.hp_Cprice = hp_Cprice;
		this.hp_Category = hp_Category;
	}
	
	//getter setter
	public String getHp_Code() {
		return hp_Code;
	}
	public void setHp_Code(String hp_Code) {
		this.hp_Code = hp_Code;
	}
	public String getHp_Name() {
		return hp_Name;
	}
	public void setHp_Name(String hp_Name) {
		this.hp_Name = hp_Name;
	}
	public String getHp_Path() {
		return hp_Path;
	}
	public void setHp_Path(String hp_Path) {
		this.hp_Path = hp_Path;
	}
	public int getHp_Oprice() {
		return hp_Oprice;
	}
	public void setHp_Oprice(int hp_Oprice) {
		this.hp_Oprice = hp_Oprice;
	}
	public int getHp_Mprice() {
		return hp_Mprice;
	}
	public void setHp_Mprice(int hp_Mprice) {
		this.hp_Mprice = hp_Mprice;
	}
	public int getHp_Cprice() {
		return hp_Cprice;
	}
	public void setHp_Cprice(int hp_Cprice) {
		this.hp_Cprice = hp_Cprice;
	}
	public String getHp_Category() {
		return hp_Category;
	}
	public void setHp_Category(String hp_Category) {
		this.hp_Category = hp_Category;
	}
	public String getHp_Manufacturer() {
		return hp_Manufacturer;
	}
	public void setHp_Manufacturer(String hp_Manufacturer) {
		this.hp_Manufacturer = hp_Manufacturer;
	}
	public String getHp_ExpirationDate() {
		return hp_ExpirationDate;
	}
	public void setHp_ExpirationDate(String hp_ExpirationDate) {
		this.hp_ExpirationDate = hp_ExpirationDate;
	}
	public String getHp_Weight() {
		return hp_Weight;
	}
	public void setHp_Weight(String hp_Weight) {
		this.hp_Weight = hp_Weight;
	}
	public int getHp_State() {
		return hp_State;
	}
	public void setHp_State(int hp_State) {
		this.hp_State = hp_State;
	}
	public int getS_Amount() {
		return s_Amount;
	}
	public void setS_Amount(int s_Amount) {
		this.s_Amount = s_Amount;
	}

}
