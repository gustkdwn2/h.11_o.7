-- table drop
drop table member;
drop table grade;
drop table board;
drop table storeincome;
drop table product;
drop table hq_stock;
drop table st_stock;
drop table order_list;
drop table sale;
drop table storeExpend;
drop table timeLine;
drop table workingTime;
drop table HeadExpend;
drop table employee;
drop table pay;


drop sequence board_seq_num;
drop sequence order_list_seq_num;
drop sequence sale_seq_num;
drop sequence storeExpend_seq_num;
drop sequence timeLine_seq_num;
drop sequence workingTime_seq_num;
drop sequence HeadExpend_seq_num;
drop sequence employee_seq_num;
drop sequence pay_seq_num;


-- table create
create table member(                  -- 회원 테이블
   m_Id varchar2(50) primary key,         -- m_Id       : 아이디 (PK)
   m_Pwd varchar2(50) not null,         -- m_Pwd    : 비밀번호
   m_Store varchar2(50) default '본사',      -- m_Store    : 매장->매장명 / 본사->"본사" 
   m_Phone1 varchar2(50) not null,         -- m_Phone1    : 매장번호     / 본사->"주 번호"
   m_Phone2 varchar2(50) not null,         -- m_Phone2  : 점주번호     / 본사->"부 번호"
   m_Email varchar2(100) not null,         -- m_Email : 지점 이메일
   m_Location1 varchar2(50) not null,      -- m_Location1 : 지점지역   / 본사->"본사지역"
   m_Location2 varchar2(200) not null,      -- m_Location2 : 지점상세주소 / 본사->"본사상세주소"
   m_State number default 0      -- m_Staet      : 회원가입 승인 요청상태    / 1:승인 / 0:요청상태
);

create table grade(                     -- 계정 권한 테이블
   m_Id varchar2(50) primary key,         -- m_Id      : 아이디 (PK) (FK : member)
   role_Name varchar2(50) not null         -- role_Name : 권한
);
alter table grade add constraint fk_member foreign key (m_Id) references member(m_Id) on delete cascade;

create table board(                     -- 게시판 테이블
   b_Num number primary key,            -- b_Num   : 게시글 번호 (자동증가) (PK)
   m_Id varchar2(50) not null,            -- m_Id      : 글쓴이 ID   (FK : member)
   b_Title varchar2(200) not null,         -- b_Title   : 글제목
   b_Content varchar2(1000) not null,      -- b_Content: 글내용
   b_Path1 varchar2(200),               -- b_Path1   : 파일명(사진명)1
   b_Path2 varchar2(200),               -- b_Path2   : 파일명(사진명)2
   b_Date date default sysdate,         -- b_Date   : 작성날짜
   b_Hit number default 0,               -- b_Hit   : 조회수
   b_Important number not null            -- b_Important : (1:전체공지, 0:일반)
);
create sequence board_seq_num;


create table storeincome(               -- 매장별 수입 테이블
   m_Id varchar2(50),         -- m_Id      : 아이디   (PK) (FK : number)
   si_Date varchar2(50),      -- si_Date   : 날짜     (PK) (sale 테이블의 판매날짜에서 '년/월/일' 만 따와서 저장)
   si_Sale number default 0,            -- si_Sale   : 매출액 (일별매출, sale 테이블이 insert될 때마다 update)
   si_Expend number default 0,            -- si_Expend : 지출액
   constraint si_PK primary key(m_Id, si_Date)
);

create table product(                   -- 상품 테이블
  hp_Code varchar2(50) primary key,     -- hp_Code : 상품코드(바코드)  (PK)
  hp_Name varchar2(50) not null,        -- hp_Name : 상품명
  hp_Path varchar2(200),                -- hp_Path : 파일명(사진명)
  hp_Oprice number not null,            -- hp_Oprice : 원가           (*지점 공개 X)
  hp_Mprice number not null,            -- hp_Mprice : 지점 유통가격
  hp_Cprice number not null,            -- hp_Cprice : 소비자 가격
  hp_Category varchar2(100) not null,   -- hp_Category : 카테고리
  hp_Manufacturer varchar2(100),		-- hp_Manufacturer : 제조원
  hp_ExpirationDate varchar2(50),		-- hp_ExpirationDate : 유통기한
  hp_Weight varchar2(50),				-- hp_Weight : 중량
  hp_State number default 1				-- hp_State : 상품 판매상태 (1:판매중, 0:판매중지)
);

create table hq_stock(                  -- 본사 재고 테이블
  hp_Code varchar2(50) primary key,     -- hp_Code : 상품코드(바코드)  (PK) (FK : product)
  hp_Amount number not null             -- hp_Amount : 재고 수량
);

create table st_stock(                  -- 매장 재고 테이블
  m_Id varchar2(50),                    -- m_Id : 아이디             (PK) (FK : member)
  hp_Code varchar2(50),                 -- hp_Code : 상품코드(바코드) (PK) (FK : product)
  st_Amount number not null,             -- st_Amount : 재고 수량
  constraint st_PK primary key(m_Id, hp_Code)
);

create table order_List(                -- 발주 테이블
  o_Num number primary key,             -- o_Num : 발주번호 (자동증가) (PK)
  hp_Code varchar2(50) not null,        -- hp_Code : 상품코드   (FK : product)
  m_Id varchar2(50) not null,           -- m_Id : 매장ID    (FK : member)
  o_Amount number not null,             -- o_amount : 주문 수량
  o_Date date default sysdate,          -- o_Date : 발주날짜
  o_State number not null,               -- o_State : 발주상태  (0:요청상태, 1:요청승인,배송준비, 2:배송완료) / 승인취소시 1->0 / 0일때만 레코드 삭제 가능 / 1->2 일때 본사재고 삭제, 매장재고 추가
  o_StringDate varchar2(50)
);
create sequence order_list_seq_num;

create table sale(                      -- 매장 판매 테이블
  s_Num number primary key,             -- s_Num : 판매번호 (자동증가)  (PK)
  m_Id varchar2(50) not null,           -- m_Id : 매장ID  (FK : member)
  hp_Code varchar2(50) not null,        -- hp_Code : 상품코드   (FK : product)
  s_Group number not null,              -- s_Group : 구매그룹번호
  s_Amount number not null,             -- s_Amount : 판매수량
  s_Date date default sysdate           -- s_Date : 판매날짜
);
create sequence sale_seq_num;


create table storeExpend(         -- 매장별 지출 테이블
   se_num number primary key,     -- s_Num : 지출번호 (자동증가)  (PK)
   m_Id varchar2(50) not null,             -- m_Id      : 아이디 (FK : number)
   se_Date varchar2(50) not null,          -- si_Date   : 지출 날짜 (sale 테이블의 판매날짜에서 '년/월/일' 만 따와서 저장)
   se_Expend number default 0,    -- se_Expend : 지출금
   se_Content varchar2(50) not null        -- se_Content: 지출내역
);
create sequence storeExpend_seq_num;


-- table 추가
create table timeLine(	
	t_Num number primary key,			-- 타임라인 번호 (자동증가) (PK)
	m_Id varchar2(50) not null,			-- 매장 아이디 (FK : number)
	t_Content varchar2(1000) not null,	-- 타임라인 내용
	t_Date date default sysdate,		-- 타임라인 등록 날짜
	t_Group number not null,			-- 부모글과 덧글 그룹 번호
	t_reply number not null				-- 부모글인지 덧글인지 여부 확인 번호 0 --> 부모글 / 1 --> 덧글
);
create sequence timeLine_seq_num;

create table workingTime(
	wt_Num number primary key, --근무번호
	e_Num number, 				--근무직원 번호
	wt_StartTime date, --date  출글
	wt_EndTime date   --date   퇴근
);
create sequence  workingTime_seq_num;

create table HeadExpend (
  he_Num number primary key,   -- he_num : 지출번호 (자동증가)  (PK)
  he_Date varchar2(50) not null,   -- he_Date 년/월/일  2016/02/28
    he_Expend number default 0,  -- he_Expend : 지출금
  he_Content varchar2(50) not null,   -- he_Content: 지출내역
  he_ExpendDirector varchar2(50)    -- he_ExpendDirector: 지출책임자
);
create sequence  HeadExpend_seq_num;

create table employee(
	e_Num number primary key,  --직원코드  
	e_Name varchar2(50),    --직원이름
	e_StartDay varchar2(50),  --입사일(년/월/일)
	e_Account varchar2(50),  --계좌번호 
	e_Phone varchar2(50),  --연락처 
	e_Position varchar2(50),  --'점장' or '아르바이트' 
	m_Id varchar2(50),   --근무하는 매장아이디   **************** 
	e_Pay number default 0 --월급 또는 시급
);
create sequence  employee_seq_num;

create table pay(
	p_Num number primary key,  --급여번호
	e_Num number,      --직원번호   ****
	p_Pay number,   --급여(시/월급)
	p_date varchar2(50) --급여날짜
)
create sequence  Pay_seq_num;

--바로 추가

--나중에 추가
alter table st_stock add constraint fk_st_stock_m_ID foreign key (m_Id) references member(m_Id) on delete cascade;