package com.kosta.csm.st_Dao;

import java.util.ArrayList;

import org.apache.ibatis.annotations.Param;

import com.kosta.csm.vo.Criteria;
import com.kosta.csm.vo.SaleAboutPrice;

public interface St_ISaleAboutPriceDAO {

	ArrayList<SaleAboutPrice> saleListBetweenDay(@Param("cri") Criteria cri, @Param("m_Id") String m_Id, @Param("first") String first, 
			@Param("last") String last);
	ArrayList<SaleAboutPrice> saleList(@Param("cri") Criteria cri, @Param("m_Id") String m_Id);
	ArrayList<SaleAboutPrice> saleDetail(@Param("cri") Criteria cri, @Param("m_Id") String m_Id, @Param("s_Group") Integer s_Group);
	int saleListCount(String m_Id);
	int saleDetailCount(@Param("m_Id") String m_Id, @Param("s_Group") Integer s_Group);
	Object saleListBetweenDayCount(@Param("m_Id") String m_Id, @Param("first") String first, 
			@Param("last") String last);
}
