package com.kosta.csm;

import java.util.Properties;

import javax.mail.Address;
import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.kosta.csm.dao.CommonDAO;
import com.kosta.csm.vo.MemberVO;

@Controller
public class CommonController {

	@Autowired
	private SqlSession sqlSession;

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String login() {
		System.out.println("login()");

		return "home.login";
	}

	@RequestMapping(value = "/loginFilter", method = RequestMethod.GET)
	public String loginFilter() {
		return "home.loginFilter";
	}
	
	@RequestMapping(value="/joinFilter")
	public String joinFilter(){
		return "home.joinFilter";
	}
	
	@RequestMapping(value="/joinHq", method = RequestMethod.GET)
	public String joinHq(){
		return "home.joinHq";
	}

	@RequestMapping(value = "/join", method = RequestMethod.GET)
	public String joinGet() {
		System.out.println("joinGet()");
		return "home.join";
	}// joinGet()

	@RequestMapping(value = "/join", method = RequestMethod.POST)
	public String joinPost(MemberVO vo, @RequestParam("m_Email1") String m_Email1,
			@RequestParam("m_Email2") String m_Email2, @RequestParam("zipCode") String zipCode, 
			@RequestParam("newAddress") String newAddress, @RequestParam("oldAddress") String oldAddress) {
		System.out.println("joinPost()");
		vo.setM_Email(m_Email1 + "@" + m_Email2);
		vo.setM_Location2(zipCode +"	" +newAddress +"( " +oldAddress +" )");
		CommonDAO dao = sqlSession.getMapper(CommonDAO.class);
		dao.join(vo);

		return "redirect:/";
	}// joinGet()

	@RequestMapping(value = "/idSearch", method = RequestMethod.POST)
	public String idSearchGet(MemberVO vo, Model model) throws Exception {
		boolean a = false;
		CommonDAO dao = sqlSession.getMapper(CommonDAO.class);
		System.out.println("idSearch Get()");
		System.out.println(vo.getM_Email());
		System.out.println(vo.getM_Store());
		System.out.println(vo.getM_Phone2());
		String store = vo.getM_Store();
		String phone2 = vo.getM_Phone2();
		MemberVO vo2 = dao.idSearch(vo);

		if (vo2 == null) {
			model.addAttribute("a", a);
			return "home.login";
		}

		if (store.equals(vo2.getM_Store()) && phone2.equals(vo2.getM_Phone2())) {
			model.addAttribute("m_Id", vo2.getM_Id());
			model.addAttribute("m_Email", vo2.getM_Email());

			String from = "csmproject109@gmail.com";
			String to = vo2.getM_Email();
			String subject = vo2.getM_Store() + "매장 아이디 찾기 메일입니다.";
			String content = "아이디는 '" + vo2.getM_Id() + "' 입니다.";
			Properties p = new Properties(); // 정보를 담을 객체

			p.put("mail.smtp.host", "smtp.gmail.com"); // gmail SMTP

			p.put("mail.smtp.port", "465");
			p.put("mail.smtp.starttls.enable", "true");
			p.put("mail.smtp.auth", "true");
			p.put("mail.smtp.debug", "true");
			p.put("mail.smtp.socketFactory.port", "465");
			p.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
			p.put("mail.smtp.socketFactory.fallback", "false");
			// SMTP 서버에 접속하기 위한 정보들

			try {
				javax.mail.Authenticator auth = new SMTPAuthenticatior();
				Session ses = Session.getInstance(p, auth);

				ses.setDebug(true);

				MimeMessage msg = new MimeMessage(ses); // 메일의 내용을 담을 객체
				msg.setSubject(subject); // 제목

				Address fromAddr = new InternetAddress(from);
				msg.setFrom(fromAddr); // 보내는 사람

				Address toAddr = new InternetAddress(to);
				msg.addRecipient(Message.RecipientType.TO, toAddr); // 받는 사람

				msg.setContent(content, "text/html;charset=UTF-8"); // 내용과 인코딩

				Transport.send(msg); // 전송
			} catch (Exception e) {
				e.printStackTrace();
				model.addAttribute("a", a);
				return "home.login";
			}
			a = true;
			model.addAttribute("a", a);
			return "home.login"; // 전송
		}
		model.addAttribute("a", a);
		return "home.login";
	}

	@RequestMapping(value = "/pwdSearch", method = RequestMethod.POST)
	public String pwdSearchGet(MemberVO vo, Model model) throws Exception {
		CommonDAO dao = sqlSession.getMapper(CommonDAO.class);
		System.out.println("pwdSearch()get");
		boolean a = false;
		String id = vo.getM_Id();
		String store = vo.getM_Store();
		String phone2 = vo.getM_Phone2();
		MemberVO vo2 = dao.pwdSearch(vo);

		if (vo2 == null) { // vo2가 null일 경우 에러가 나므로 vo2가 타입이 맞는지 먼저
			model.addAttribute("a", a);
			return "home.login";
		}
		if (id.equals(vo2.getM_Id()) && store.equals(vo2.getM_Store()) && phone2.equals(vo2.getM_Phone2())) {
			model.addAttribute("m_Pwd", vo2.getM_Pwd());
			model.addAttribute("m_Email", vo2.getM_Email());

			String from = "csmproject109@gmail.com";
			String to = vo2.getM_Email();
			String subject = vo2.getM_Id() + "님 비밀번호 찾기 메일입니다.";
			String content = "비밀번호는 '" + vo2.getM_Pwd() + "' 입니다.";

			Properties p = new Properties();

			p.put("mail.smtp.host", "smtp.gmail.com");

			p.put("mail.smtp.port", "465");
			p.put("mail.smtp.starttls.enable", "true");
			p.put("mail.smtp.auth", "true");
			p.put("mail.smtp.debug", "true");
			p.put("mail.smtp.socketFactory.port", "465");
			p.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
			p.put("mail.smtp.socketFactory.fallback", "false");

			try {
				javax.mail.Authenticator auth = new SMTPAuthenticatior();
				Session ses = Session.getInstance(p, auth);

				ses.setDebug(true);

				MimeMessage msg = new MimeMessage(ses); // 메일의 내용을 담을 객체
				msg.setSubject(subject); // 제목

				Address fromAddr = new InternetAddress(from);
				msg.setFrom(fromAddr); // 보내는 사람

				Address toAddr = new InternetAddress(to);
				msg.addRecipient(Message.RecipientType.TO, toAddr); // 받는 사람

				msg.setContent(content, "text/html;charset=UTF-8"); // 내용과 인코딩

				Transport.send(msg); // 전송
			} catch (Exception e) {
				e.printStackTrace();
				model.addAttribute("a", a);
				return "home.login";
			}
			a = true;
			model.addAttribute("a", a);
			return "home.login"; // 전송
		}
		model.addAttribute("a", a);
		return "home.login";
	}

	// id 중복확인
	@RequestMapping(value = "/idCheck")
	public String idCheck(HttpServletRequest request, Model model) {

		CommonDAO dao = sqlSession.getMapper(CommonDAO.class);

		String m_Id = request.getParameter("m_Id");

		model.addAttribute("m_Id", m_Id);
		model.addAttribute("check", dao.idCheck(m_Id));

		return "home.IdCheck";
	}
	
	@RequestMapping(value="/ch")
	public String ch(){
		return "home.chat";
	}
}
