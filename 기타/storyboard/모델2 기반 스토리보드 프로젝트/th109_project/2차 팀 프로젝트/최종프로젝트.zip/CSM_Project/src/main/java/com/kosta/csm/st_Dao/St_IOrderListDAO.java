package com.kosta.csm.st_Dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.kosta.csm.vo.Criteria;
import com.kosta.csm.vo.OrderListVO;
import com.kosta.csm.vo.OrderList_ProductVO;
import com.kosta.csm.vo.ProductVO;
import com.kosta.csm.vo.St_Stock_ProductVO;

public interface St_IOrderListDAO {

	public List<OrderList_ProductVO> list(@Param("cri") Criteria cri, @Param("m_Id") String m_Id);

	public int orderListCount(String m_Id);

	public void delete(String o_Num);

	public int stockCount(String m_Id);

	public List<St_Stock_ProductVO> stock(@Param("cri") Criteria cri, @Param("m_Id") String m_Id);

	public void order(OrderListVO vo);
	
	public void updateStringDate(@Param("o_StringDate") String o_StringDate, @Param("hp_Code") String hp_Code);

	public int orderCompleteListCount(String m_Id);

	public List<OrderList_ProductVO> completeList(@Param("cri") Criteria cri, @Param("m_Id") String m_Id);

	public List<ProductVO> stockDetail_list(@Param("cri") Criteria cri, @Param("m_Id") String m_Id);
	public List<ProductVO> stockDetail_order(@Param("cri") Criteria cri, @Param("m_Id") String m_Id);
	public List<ProductVO> stockDetail_complete(@Param("cri") Criteria cri, @Param("m_Id") String m_Id);

	public Integer stateFilter(String hp_Code);

	public List<St_Stock_ProductVO> orderSearch1stock_Num(@Param("cri") Criteria cri, @Param("m_Id") String m_Id, @Param("search") String search);

	public List<ProductVO> orderSearch1Detail_Num(@Param("cri") Criteria cri, @Param("m_Id") String m_Id, @Param("search") String search);

	public List<St_Stock_ProductVO> orderSearch1stock_Name(@Param("cri") Criteria cri, @Param("m_Id") String m_Id, @Param("search") String search);

	public int orderSearch1Count_Name(@Param("m_Id") String m_Id, @Param("search") String search);

	public List<ProductVO> orderSearch1Detail_Name(@Param("cri") Criteria cri, @Param("m_Id") String m_Id, @Param("search") String search);

	public List<St_Stock_ProductVO> orderSearch2(@Param("cri") Criteria cri, @Param("m_Id") String m_Id, @Param("category") String category);

	public int orderSearch2Count(@Param("m_Id") String m_Id, @Param("category") String category);

	public List<ProductVO> orderSearch2Detail(@Param("cri") Criteria cri, @Param("m_Id") String m_Id, @Param("category") String category);

}
