package com.kosta.csm.vo;

public class HqIncomeOfMonth {
	String m_Id; //매장번호
	String m_Store; // 매장이름
	int ct;//거래건수 달별중 매장별
	long hp_Oprice;//원가
	long hp_Mprice;//본사->매장   납품가
	long income;//순수익
	String income_Date;//날짜(년/월/일)
	public String getM_Id() {
		return m_Id;
	}
	public void setM_Id(String m_Id) {
		this.m_Id = m_Id;
	}
	public String getM_Store() {
		return m_Store;
	}
	public void setM_Store(String m_Store) {
		this.m_Store = m_Store;
	}
	public int getCt() {
		return ct;
	}
	public void setCt(int ct) {
		this.ct = ct;
	}
	public long getHp_Oprice() {
		return hp_Oprice;
	}
	public void setHp_Oprice(long hp_Oprice) {
		this.hp_Oprice = hp_Oprice;
	}
	public long getHp_Mprice() {
		return hp_Mprice;
	}
	public void setHp_Mprice(long hp_Mprice) {
		this.hp_Mprice = hp_Mprice;
	}
	public long getIncome() {
		return income;
	}
	public void setIncome(long income) {
		this.income = income;
	}
	public String getIncome_Date() {
		return income_Date;
	}
	public void setIncome_Date(String income_Date) {
		this.income_Date = income_Date;
	}
	
	
}
