package com.kosta.csm.vo;

// 회원 테이블
public class MemberVO {
	private String m_Id;			// 아이디
	private String m_Pwd;			// 비밀번호
	private String m_Store;			// 매장명
	private String m_Phone1;		// 매장 전화번호
	private String m_Phone2;		// 점주 전화번호
	private String m_Email;			// 지점 이메일
	private String m_Location1;		// 지점 지역
	private String m_Location2;		// 지점 상세주소
	
	
	// Constructor
	public MemberVO() {
	}
	public MemberVO(String m_Id, String m_Pwd, String m_Store, String m_Phone1, String m_Phone2, String m_Email,
			String m_Location1, String m_Location2) {
		this.m_Id = m_Id;
		this.m_Pwd = m_Pwd;
		this.m_Store = m_Store;
		this.m_Phone1 = m_Phone1;
		this.m_Phone2 = m_Phone2;
		this.m_Email = m_Email;
		this.m_Location1 = m_Location1;
		this.m_Location2 = m_Location2;
	}
	
	
	
	// getter / setter
	public String getM_Id() {
		return m_Id;
	}
	public void setM_Id(String m_Id) {
		this.m_Id = m_Id;
	}
	public String getM_Pwd() {
		return m_Pwd;
	}
	public void setM_Pwd(String m_Pwd) {
		this.m_Pwd = m_Pwd;
	}
	public String getM_Store() {
		return m_Store;
	}
	public void setM_Store(String m_Store) {
		this.m_Store = m_Store;
	}
	public String getM_Phone1() {
		return m_Phone1;
	}
	public void setM_Phone1(String m_Phone1) {
		this.m_Phone1 = m_Phone1;
	}
	public String getM_Phone2() {
		return m_Phone2;
	}
	public void setM_Phone2(String m_Phone2) {
		this.m_Phone2 = m_Phone2;
	}
	public String getM_Email() {
		return m_Email;
	}
	public void setM_Email(String m_Email) {
		this.m_Email = m_Email;
	}
	public String getM_Location1() {
		return m_Location1;
	}
	public void setM_Location1(String m_Location1) {
		this.m_Location1 = m_Location1;
	}
	public String getM_Location2() {
		return m_Location2;
	}
	public void setM_Location2(String m_Location2) {
		this.m_Location2 = m_Location2;
	}
	
	
}
