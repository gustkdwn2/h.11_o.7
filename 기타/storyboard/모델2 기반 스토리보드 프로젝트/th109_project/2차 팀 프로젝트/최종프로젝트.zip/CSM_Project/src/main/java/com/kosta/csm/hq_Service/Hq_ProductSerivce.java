package com.kosta.csm.hq_Service;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.multipart.MultipartFile;

import com.kosta.csm.hq_Dao.Hq_IProductDAO;
import com.kosta.csm.vo.Criteria;
import com.kosta.csm.vo.ProductVO;

@Service
public class Hq_ProductSerivce implements Hq_IProductService{
	
	@Autowired
	private SqlSession sqlSession;

	@Override
	public List<ProductVO> list(Criteria cri, Model model) {
		Hq_IProductDAO dao=sqlSession.getMapper(Hq_IProductDAO.class);
		model.addAttribute("count", dao.listCount());
		return dao.list(cri);
	}

	@Override
	public void insert(MultipartFile file, Model model, ProductVO vo, HttpServletRequest request) throws Exception {		
		
		String uploadPath=request.getSession().getServletContext().getRealPath("/upload");
		
		FileCopyUtils.copy(file.getInputStream(), new FileOutputStream(uploadPath+"/"+file.getOriginalFilename()));
		
		vo.setHp_Path(file.getOriginalFilename());
		
		Hq_IProductDAO dao=sqlSession.getMapper(Hq_IProductDAO.class);
		dao.insert(vo);
		dao.insertHq_Stock(vo.getHp_Code());
			
	}

	@Override
	public List<ProductVO> detail(String hp_Code) {
		Hq_IProductDAO dao=sqlSession.getMapper(Hq_IProductDAO.class);
		return dao.detail(hp_Code);
	}

	@Override
	public void delete(String[] hp_CodeArray) {
		Hq_IProductDAO dao=sqlSession.getMapper(Hq_IProductDAO.class);
		
		for(int i=0; i<hp_CodeArray.length; i++){
			dao.delete(hp_CodeArray[i]);
		}
	}

	@Override
	public void fileDelete(List<ProductVO> allFileList, HttpServletRequest request) {
		
		for(int i=0; i<allFileList.size(); i++){
			String fileName=allFileList.get(i).getHp_Path();
			String path=request.getSession().getServletContext().getRealPath("/upload");
			String fullPath=path +"\\" +fileName;
			
			File file=new File(fullPath);
			
			if(file.exists()==true){
				file.delete();
			}
		}
	}

	@Override
	public List<ProductVO> selectFileList(String[] hp_Code) {
		Hq_IProductDAO dao=sqlSession.getMapper(Hq_IProductDAO.class);
		List<ProductVO> allFileList=new ArrayList<ProductVO>();
		
		System.out.println("hp_Code length: "+hp_Code.length);
		
		for(int i=0; i<hp_Code.length; i++){
			allFileList.add(dao.selectAll(hp_Code[i]));
		}
		
		System.out.println("allFileList Size: " +allFileList.size());
		
		return allFileList;
	}

	@Override
	public void moidfy(MultipartFile file, Model model, ProductVO vo, HttpServletRequest request) throws Exception {
		Hq_IProductDAO dao=sqlSession.getMapper(Hq_IProductDAO.class);
		
		if(!file.isEmpty()){
			String uploadPath=request.getSession().getServletContext().getRealPath("/upload");
			System.out.println("uploadPath: " +uploadPath);
			
			FileCopyUtils.copy(file.getInputStream(), new FileOutputStream(uploadPath+"/"+file.getOriginalFilename()));
			System.out.println(uploadPath +file.getOriginalFilename());
			vo.setHp_Path(file.getOriginalFilename());
			dao.modify(vo);
		}
		else{
			System.out.println("file 재업로드 안 함");
			dao.modify(vo);
		}
	}

	@Override
	public void duplicationCheck(HttpServletRequest request, Model model) {
		Hq_IProductDAO dao=sqlSession.getMapper(Hq_IProductDAO.class);
		
		String hp_Code = request.getParameter("hp_Code");
		
		model.addAttribute("hp_Code", hp_Code);
		model.addAttribute("check", dao.duplicationCheck(hp_Code));
		
	}

	@Override
	public void stateChange_0(String[] hp_CodeArray) {
		Hq_IProductDAO dao=sqlSession.getMapper(Hq_IProductDAO.class);
		
		for(int i=0; i<hp_CodeArray.length; i++){
			dao.stateChange_0(hp_CodeArray[i]);
		}// for
	}

	@Override
	public List<ProductVO> susList(Criteria cri, Model model) {
		Hq_IProductDAO dao=sqlSession.getMapper(Hq_IProductDAO.class);
		model.addAttribute("count", dao.susListCount());
		return dao.susList(cri);
	}

	@Override
	public void productResume(String[] hp_CodeArray) {
		Hq_IProductDAO dao=sqlSession.getMapper(Hq_IProductDAO.class);
		
		for(int i=0; i<hp_CodeArray.length; i++){
			dao.stateChange_1(hp_CodeArray[i]);
		}// for
	}

	@Override
	public List<ProductVO> productListSearch(Criteria cri, Model model, String searchType, String productSearch) {
		Hq_IProductDAO dao=sqlSession.getMapper(Hq_IProductDAO.class);		
		
		if(searchType.equals("상품번호")){
			return dao.productListSearch_hp_Code(cri, productSearch);
		}else if(searchType.equals("상품명")){
			model.addAttribute("count", dao.productListSearchCount_hp_Name("%"+productSearch+"%"));
			return dao.productListSearch_hp_Name(cri, "%"+productSearch+"%");
		}
		return null;
	}

	@Override
	public List<ProductVO> productListSearch_Category(Criteria cri, Model model, String category) {
		Hq_IProductDAO dao=sqlSession.getMapper(Hq_IProductDAO.class);
		
		model.addAttribute("count", dao.search_CategoryCount(category));
		
		return dao.search_Category(cri, category);
	}

	@Override
	public List<ProductVO> productSusListSearch(Criteria cri, Model model, String searchType, String productSearch) {
		Hq_IProductDAO dao=sqlSession.getMapper(Hq_IProductDAO.class);
		
		if(searchType.equals("상품번호")){
			return dao.productSusListSearch_hp_Code(cri, productSearch);
		}else if(searchType.equals("상품명")){
			model.addAttribute("count", dao.productSusListSearchCount_hp_Name("%"+productSearch+"%"));
			return dao.productSusListSearch_hp_Name(cri, "%"+productSearch+"%");
		}
		return null;
	}

	@Override
	public List<ProductVO> productSusListSearch_Category(Criteria cri, Model model, String category) {
		Hq_IProductDAO dao=sqlSession.getMapper(Hq_IProductDAO.class);
		
		model.addAttribute("count", dao.searchSus_CategoryCount(category));
		
		return dao.searchSus_Category(cri, category);
	}

}
