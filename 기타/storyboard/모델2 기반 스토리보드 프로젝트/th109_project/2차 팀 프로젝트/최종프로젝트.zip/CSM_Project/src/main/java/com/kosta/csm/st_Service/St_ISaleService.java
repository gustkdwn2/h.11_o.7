package com.kosta.csm.st_Service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.kosta.csm.vo.SaleProduct;

public interface St_ISaleService {
   void addSaleProduct(List<SaleProduct> saleList, String code, String amount);//포스기 화면에 코드및 수량 등 상품정보 하나추가
   void delSaleProduct(List<SaleProduct> saleList, String code);//포스기 희망구매 상품 삭제
   int allPrice(List<SaleProduct> saleList);//희망구매목록의 모든 상품들에대한 가격
   int moneyCalculation(List<SaleProduct> saleList, String receiveMoney);//리스트에 있는 price값들을 수량에맞게 계산하여 더함
   void endPaperMoney(HttpServletRequest request,List<SaleProduct> saleList);//재고테이블 판매내역테이블 매장별수입테이블에 상품정보 변경(구매처리완료시킴)
}