package com.kosta.csm.vo;

public class PayVO {
	int p_Num; //--급여번호
	int e_Num; //  --직원번호
	int p_Pay;//--급여(시/월급)
	String p_Date; //) --급여날짜(년/월)
	public int getP_Num() {
		return p_Num;
	}
	public void setP_Num(int p_Num) {
		this.p_Num = p_Num;
	}
	public int getE_Num() {
		return e_Num;
	}
	public void setE_Num(int e_Num) {
		this.e_Num = e_Num;
	}
	public int getP_Pay() {
		return p_Pay;
	}
	public void setP_Pay(int p_Pay) {
		this.p_Pay = p_Pay;
	}
	public String getP_Date() {
		return p_Date;
	}
	public void setP_Date(String p_Date) {
		this.p_Date = p_Date;
	}
	
}
