package com.kosta.csm.hq_Dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.kosta.csm.vo.Criteria;
import com.kosta.csm.vo.HeadExpendPerMonth;
import com.kosta.csm.vo.HqIncome;
import com.kosta.csm.vo.HqIncomeOfMonth;

public interface Hq_IIncomeDAO {

	List<HqIncome> incomePerMonth(Criteria cri);
	int incomePerMonthCount();
	List<HqIncome> incomeSearch(@Param("cri") Criteria cri, @Param("date") String date);
	int incomeSearchCount(String date);
	
	List<HqIncomeOfMonth> incomeOfMonthPerStore(@Param("cri") Criteria cri, @Param("o_Date") String o_Date);
	int incomeOfMonthPerStoreCount(String o_Date);
	List<HqIncomeOfMonth> incomeOfMonthPerDay(@Param("cri") Criteria cri, @Param("o_Date") String o_Date);
	int incomeOfMonthPerDayCount(String income_Date);

	List<HqIncomeOfMonth> incomePerStoreDetail(@Param("cri") Criteria cri, @Param("m_Id") String m_Id,@Param("income_Date")  String income_Date);
	int incomePerStoreDetailCount(@Param("m_Id") String m_Id,@Param("income_Date")  String income_Date);
	List<HqIncomeOfMonth> incomePerDayDetail(@Param("cri") Criteria cri, @Param("income_Date") String income_Date);
	int incomePerDayDetailCount(String income_Date);
	
	List<HqIncomeOfMonth> allOfdayIncome(String income_Date);
	List<HqIncomeOfMonth> allOfStoreMonthIncome(@Param("m_Id") String m_Id,@Param("income_Date")  String income_Date);
	
	
	

	
}
