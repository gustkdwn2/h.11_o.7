package com.kosta.csm.st_Dao;

import java.util.ArrayList;

import org.apache.ibatis.annotations.Param;

import com.kosta.csm.vo.Criteria;
import com.kosta.csm.vo.StoreExpendVO;

public interface St_IStoreExpendDAO {
	void addExpend(StoreExpendVO storeExpendVO);
	ArrayList<StoreExpendVO> getStoreExpend(@Param("cri") Criteria cri, @Param("m_Id") String m_Id); 
	StoreExpendVO getAExpend(Integer se_Num);
	void removeExpend(Integer se_Num);
	ArrayList<StoreExpendVO> expendBetweenDay(@Param("m_Id") String m_Id
			,@Param("first")  String first, @Param("last")  String last);
	int getStoreExpendCount(String m_Id);
}
