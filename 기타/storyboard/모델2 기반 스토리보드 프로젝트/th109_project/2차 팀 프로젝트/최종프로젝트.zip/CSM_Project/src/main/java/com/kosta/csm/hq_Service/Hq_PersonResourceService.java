package com.kosta.csm.hq_Service;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.kosta.csm.hq_Dao.Hq_IEmployeeDAO;
import com.kosta.csm.hq_Dao.Hq_IPayDAO;
import com.kosta.csm.hq_Dao.Hq_IWorkingTimeDAO;
import com.kosta.csm.vo.Criteria;
import com.kosta.csm.vo.EmployeeAboutStoreName;
import com.kosta.csm.vo.EmployeeVO;
import com.kosta.csm.vo.PayVO;
import com.kosta.csm.vo.WorkingTimeMore;
import com.kosta.csm.vo.WorkingTimePerMonth;

@Service
public class Hq_PersonResourceService implements Hq_IPersonResourceService {

	@Autowired
	private SqlSession sqlSession;

	///////////////////////// 직원관리///////////////////////
	public List<EmployeeAboutStoreName> getEmployee(Criteria cri, Model model) {
		// TODO Auto-generated method stub
		System.out.println(" getEmployee()");
		
		Hq_IEmployeeDAO dao = sqlSession.getMapper(Hq_IEmployeeDAO.class);
		System.out.println("end query      get size : " + dao.getEmployee(cri).size());
		
		model.addAttribute("count", dao.getEmployeeCount());
		return dao.getEmployee(cri);
	}

	public synchronized void addEmployee(String year, String month, String day, List<EmployeeVO> list, EmployeeVO vo) {
		// TODO Auto-generated method stub
		System.out.println("synchronized void addEmployee(EmployeeVO vo)  parameter  vo일부: " + vo.getE_Position());
		Hq_IEmployeeDAO dao = sqlSession.getMapper(Hq_IEmployeeDAO.class);
		System.out.println("1"+vo.getE_Account());
		System.out.println("1"+vo.getE_Name());
		System.out.println("1"+vo.getE_Num());
		System.out.println("1"+vo.getE_Pay());
		System.out.println("1"+vo.getE_Phone());
		System.out.println("1"+vo.getE_Position());
		System.out.println("1"+vo.getE_StartDay());
		System.out.println("1"+vo.getM_Id());
		System.out.println("list"+list.size());
		System.out.println("month"+month);
		System.out.println("day"+day);
		System.out.println("year"+year);
		
		//날짜 셋팅
		if(month.length() ==1)
			month = "0" + month;
		System.out.println("month 의결과" + month);
		if(day.length() ==1)
			day = "0" + day;
		System.out.println("day 의결과" + day);
		vo.setE_StartDay(year+"/"+month+"/"+day);
		System.out.println("vo.gete_startdate 결과" +vo.getE_StartDay());
		
		//직원 삽입 처리
		dao.addEmployee(vo);
		System.out.println("add success");
				
		//삽입된직원번호 가저옴
		int num = dao.maxE_num();
		System.out.println("int num" + num);
		
		//pay기록에 입사일을 기준으로 급여를 새로기록함
		Hq_IPayDAO dao1 = sqlSession.getMapper(Hq_IPayDAO.class);
		vo.setE_Num(num);

		vo.setE_StartDay(year+"/"+month);
		System.out.println("삽입날짜 년월형식:" +vo.getE_StartDay() );
		//직원 급여에관한정보삽입
		dao1.addPay(vo);
		System.out.println("pay테이블에 삽입성공 번호는 " + num);
		
		//보여주기 리스트에 삽입( 년월일모든정보 )
		vo.setE_StartDay(year+"/"+month+"/"+day);
		// 가장오래된 기록 지우기
		if (list.size() == 5)
			list.remove(0);
		list.add(vo);
		System.out.println("vo추가   날짜형식 년.월까지만바꿔서 삽입");
	}

	public void modifyPay(Integer e_Num, Integer e_Pay, String e_Position) {
		// TODO Auto-generated method stub
		System.out.println(" modifyPay(Integer e_Num, Integer e_Pay, String e_Position)  parameter  e_Num: " + e_Num
				+ ", e_Pay :" + e_Pay + " e_Position : " + e_Position);
		Hq_IEmployeeDAO dao = sqlSession.getMapper(Hq_IEmployeeDAO.class);
		Hq_IPayDAO pDao = sqlSession.getMapper(Hq_IPayDAO.class);

		PayVO pVo;
		String currentDate = new java.text.SimpleDateFormat("yyyy/MM").format(new java.util.Date());

		EmployeeVO vo = new EmployeeVO();
		vo.setE_Pay(e_Pay);// 새로운급여설정
		if (e_Position == null) {// 직책을 선택한적이없으면
			vo.setE_Num(e_Num);// 새로운급여설정
			System.out.println("한사람 enum으로 pay설정");
			vo.setE_Num(e_Num);
			dao.updateEmployeeOfNum(vo);
			// 기존존재하는 날짜이면 업데이트완료
			System.out.println("pay등록값 pay관리테이블에서바꿈 직원한명만 ");
			System.out.println("업데이트할정보 vo:  " + vo.getE_Num()+"/"+ vo.getE_Pay());
			pDao.updatePayOfE_Num(vo);

			pVo = pDao.getPayOfE_Num(vo);
			System.out.println("가저온 date : " + pVo.getP_Date().substring(0,7));
			System.out.println("현재 date : " + currentDate.substring(0,7));
			if (!currentDate.substring(0,7).equals(pVo.getP_Date().substring(0,7))) {// 현제날짜와 같지않음(최신으로
														// 추가할필요있음)
				System.out.println("같은년월로 pay등록이돼있지 않으면");
				// 같은날짜로 등록된 pay없으면 추가하고등록
				pVo = new PayVO();
				pVo.setE_Num(e_Num);
				pVo.setP_Date(currentDate);
				pVo.setP_Pay(e_Pay);
				System.out.println("pay해당 년월로 삽입시작");
				pDao.insertPay(pVo);

			}else{
				System.out.println("이미 한사람의 pay가 같은년월로 등록");
			}
		} else {// 직책 선택후 수정하러왔으면
			System.out.println("직책으로 pay 수정");
			vo.setE_Position(e_Position);
			System.out.println("employee값바꿈");
			dao.updateEmployeeOfPosition(vo);
			System.out.println("pay등록값 pay관리테이블에서바꿈 ");
			System.out.println("업데이트할정보 vo:  " + vo.getE_Position() +"/"+ vo.getE_Pay());
			pDao.updatePayOfE_Position(vo);

			// 존재하지않는 날짜들 새로 직원번호로 추가
			List<PayVO> list = pDao.getPayOfE_Position(vo);

			System.out.println("현제날짜 : " + currentDate);
			for (int a = 0; a < list.size(); a++) {
				System.out.println("\n가저온 date : " + list.get(a).getP_Date() +"/ e_num:" + list.get(a).getE_Num());
				System.out.println("현재 date : " + currentDate);
				if (!currentDate.substring(0,7).equals(list.get(a).getP_Date().substring(0,7))) {// 현제날짜와
																	// 같지않음(최신으로
																	// 추가할필요있음)
					System.out.println("같지않으므로 현제년월로 추가");
					pVo = new PayVO();
					pVo.setE_Num(list.get(a).getE_Num());
					pVo.setP_Date(currentDate);
					pVo.setP_Pay(e_Pay);
					pDao.insertPay(pVo);
				} else {
					System.out.println("같은경우는 패스! 이미업데이트되었음");
				}
			}
		}
	}

	public void removeEmployee(Integer e_Num, Integer[] targetRemove) {
		// TODO Auto-generated method stub
		System.out.println(
				" removeEmployee(Integer e_Num, String[] targetRemove) parameter : " + e_Num + "  /" + targetRemove);
		Hq_IEmployeeDAO dao = sqlSession.getMapper(Hq_IEmployeeDAO.class);
		if (e_Num != null) {
			System.out.println("e_Num != null ");
			dao.removeEmployee(e_Num);
		} else {
			System.out.println("targetRemove != null ");
			for (int a = 0; a < targetRemove.length; a++)
				dao.removeEmployee(targetRemove[a]);
		}
	}

	public void updateEmployee(String year, String month, String day, EmployeeVO vo) {
		// TODO Auto-generated method stub
		System.out.println(" updateEmployee(String year, String month, String day, EmployeeVO vo) 일부(e_num) : " + vo.getE_Num());
		//날짜 셋팅
		if(month.length() ==1)
			month = "0" + month;
		if(day.length() ==1)
			day = "0" + day;
		vo.setE_StartDay(year+"/"+month+"/"+day);
		System.out.println("업데이트할 vo정보들중  pay : " + vo.getE_Pay());
		System.out.println("직원수정");
		Hq_IEmployeeDAO dao = sqlSession.getMapper(Hq_IEmployeeDAO.class);
		dao.updateEmployee(vo);
		System.out.println("직원pay기록 수정");
		Hq_IPayDAO hq_IPayDAO = sqlSession.getMapper(Hq_IPayDAO.class);
		hq_IPayDAO.updatePayOfE_Num(vo);
	}

	public EmployeeVO getEmployeeOfNum(Integer e_Num) {
		// TODO Auto-generated method stub
		System.out.println(" EmployeeVO getEmployeeOfNum(Integer e_Num)     parameter: " + e_Num);
		Hq_IEmployeeDAO dao = sqlSession.getMapper(Hq_IEmployeeDAO.class);
		return dao.getEmployeeOfNum(e_Num);
	}

	public List<WorkingTimeMore> getWorkingTime(Criteria cri, Model model) {
		// TODO Auto-generated method stub
		System.out.println(" List<WorkingTimeAboutEName> getWorkingTime()");
		Hq_IWorkingTimeDAO dao = sqlSession.getMapper(Hq_IWorkingTimeDAO.class);
		model.addAttribute("count", dao.getWorkingTimeCount());
		return dao.getWorkingTime(cri);
	}

	public List<WorkingTimePerMonth> getPayPerMonth(Criteria cri, Model model) {
		// TODO Auto-generated method stub
		System.out.println(" WorkingTimePerMonth getPayPerMonth()");
		
		Hq_IWorkingTimeDAO dao = sqlSession.getMapper(Hq_IWorkingTimeDAO.class);
		model.addAttribute("count", dao.getPayPerMonthCount());
		return dao.getPayPerMonth(cri);
	}

	public Object getSalaryPerMonth(Criteria cri, Model model) {
		// TODO Auto-generated method stub
		System.out.println(" WorkingTimePerMonth getSalaryPerMonth()");
		
		Hq_IWorkingTimeDAO dao = sqlSession.getMapper(Hq_IWorkingTimeDAO.class);
		model.addAttribute("count", dao.getSalaryPerMonthCount());
		return dao.getSalaryPerMonth(cri);
	}

	public String checkMember( EmployeeVO vo) {
		// TODO Auto-generated method stub
		System.out.println(" checkMember(EmployeeVO vo)  parameter  :  vo중(m_id)일부값   " + vo.getM_Id());
		Hq_IEmployeeDAO dao = sqlSession.getMapper(Hq_IEmployeeDAO.class);
		System.out.println("dao.getSameM_id()" + dao.getSameM_id(vo));
	
		if(dao.getSameM_id(vo) == null)
			return "2";
		return "1";
	}

	public List<EmployeeAboutStoreName> employeeSearch(Criteria cri, Model model, String employee, String searchType) {
		Hq_IEmployeeDAO dao = sqlSession.getMapper(Hq_IEmployeeDAO.class);
		
		if(searchType.equals("직원코드")){
			model.addAttribute("count", dao.employeeSearchCount_Num(employee));
			return dao.employeeSearch_Num(cri, employee);
		}else if(searchType.equals("직원명")){
			model.addAttribute("count", dao.employeeSearchCount_Name("%"+employee+"%"));
			return dao.employeeSearch_Name(cri, "%"+employee+"%");
		}
		
		return null;
	}

	public List<EmployeeAboutStoreName> setPaySearch(Criteria cri, Model model, String searchType, String employee) {
		Hq_IEmployeeDAO dao = sqlSession.getMapper(Hq_IEmployeeDAO.class);
		
		if(searchType.equals("직원코드")){
			model.addAttribute("count", dao.setPaySearchCount_Num(employee));
			return dao.setPaySearch_Num(cri, employee);
		}else if(searchType.equals("직원명")){
			model.addAttribute("count", dao.setPaySearchCount_Name("%"+employee+"%"));
			return dao.setPaySearch_Name(cri, "%"+employee+"%");
		}
		
		return null;
	}

	public List<WorkingTimePerMonth> paySearch(Criteria cri, Model model, String searchType, String search) {
		
		Hq_IWorkingTimeDAO dao = sqlSession.getMapper(Hq_IWorkingTimeDAO.class);
		
		if(searchType.equals("직원코드")){
			model.addAttribute("count", dao.paySearchCount_Num(search));
			return dao.paySearch_Num(cri, search);
		}else if(searchType.equals("매장아이디")){
			model.addAttribute("count", dao.paySearchCount_Id(search));
			return dao.paySearch_Id(cri, search);
		}else if(searchType.equals("매장이름")){
			model.addAttribute("count", dao.paySearchCount_Name("%"+search+"%"));
			return dao.paySearch_Name(cri, "%"+search+"%");
		}
		
		return null;
	}

	public List<WorkingTimePerMonth> salarySearch(Criteria cri, Model model, String searchType, String search) {
		Hq_IWorkingTimeDAO dao = sqlSession.getMapper(Hq_IWorkingTimeDAO.class);
		
		if(searchType.equals("직원코드")){
			model.addAttribute("count", dao.salarySearchCount_Num(search));
			return dao.salarySearch_Num(cri, search);
		}else if(searchType.equals("매장아이디")){
			model.addAttribute("count", dao.salarySearchCount_Id(search));
			return dao.salarySearch_Id(cri, search);
		}else if(searchType.equals("매장이름")){
			model.addAttribute("count", dao.salarySearchCount_Name("%"+search+"%"));
			return dao.salarySearch_Name(cri, "%"+search+"%");
		}
		
		return null;
	}

	public List<WorkingTimeMore> timePartSearch(Criteria cri, Model model, String searchType, String search) {
		Hq_IWorkingTimeDAO dao = sqlSession.getMapper(Hq_IWorkingTimeDAO.class);
		
		if(searchType.equals("직원코드")){
			model.addAttribute("count", dao.timePartSearchCount_Num(search));
			return dao.timePartSearch_Num(cri, search);
		}else if(searchType.equals("매장아이디")){
			model.addAttribute("count", dao.timePartSearchCount_Id(search));
			return dao.timePartSearch_Id(cri, search);
		}else if(searchType.equals("매장이름")){
			model.addAttribute("count", dao.timePartSearchCount_Name("%"+search+"%"));
			return dao.timePartSearch_Name(cri, "%"+search+"%");
		}
		
		return null;
	}
}
