package com.kosta.csm.hq_Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.kosta.csm.hq_Service.Hq_IStockService;
import com.kosta.csm.vo.Criteria;
import com.kosta.csm.vo.HqStockList;
import com.kosta.csm.vo.HqStockVO;

@Controller
@RequestMapping("/hq/stock")
public class Hq_StockController {
	
	@Autowired
	private Hq_IStockService service;
	
	@RequestMapping("/stockList")
	public String stockList(Criteria cri, Model model){
		System.out.println("stockList");
		model.addAttribute("stockList", service.stockList(cri, model));
		model.addAttribute("stockListDetail", service.stockListDetail(cri));
		model.addAttribute("cri", cri);
		return "hq.stock.stockList";
	}
	
	@RequestMapping(value="/stockModify", method=RequestMethod.GET)
	public String stcokModifyView(Criteria cri, Model model, @RequestParam("hp_Code") String[] hp_Code){
		System.out.println("stockModifyView");
		//model.addAttribute("stockList", service.stockList(cri, model));
		model.addAttribute("stockList", service.stockModifyView(hp_Code));
		//model.addAttribute("cri", cri);
		return "hq.stock.stockModify";
	}
	
	@RequestMapping(value="/stockModify", method=RequestMethod.POST)
	public String stcokModify(Model model, @RequestParam("hp_Code") String[] hp_Code, @RequestParam("hp_Amount") int[] hp_Amount){
		System.out.println("stockModify");
		System.out.println("hp_Code[] length: " +hp_Code.length);
		System.out.println("hp_Amount[] length: " +hp_Amount.length);
		
		service.modify(hp_Code, hp_Amount);
		return "redirect:/hq/stock/stockList";
	}
	
	@RequestMapping(value="/stockListSearch")
	public String productListSearch(Criteria cri, Model model, @RequestParam("stockSearch") String stockSearch,
																@RequestParam("searchType") String searchType){
		
		model.addAttribute("stockList", service.stockListSearch(cri, model, stockSearch, searchType));
		model.addAttribute("stockListDetail", service.stockListDetailSearch(cri, stockSearch, searchType));
		model.addAttribute("search_check", 1);
		model.addAttribute("stockSearch", stockSearch);
		model.addAttribute("searchType", searchType);
		model.addAttribute("cri", cri);
		return "hq.stock.stockList";
	}
}
