package com.kosta.csm.hq_Service;

import java.util.List;

import org.springframework.ui.Model;

import com.kosta.csm.vo.Criteria;
import com.kosta.csm.vo.CriteriaIndex;
import com.kosta.csm.vo.OrderListVO;
import com.kosta.csm.vo.OrderList_MemberVO;
import com.kosta.csm.vo.OrderList_ProductVO_2;

public interface Hq_IOrderListService {
	
	public List<OrderList_MemberVO> indexApprovalList(CriteriaIndex cri, Model model);
	
	public List<List<OrderList_ProductVO_2>> orderApprovalListDetail2(CriteriaIndex cri);
	
	/////////////////////////////////////////////////////////////////////////////
	public void updateStates(String[] ckb);
	
	public void cancelStates(String[] ckb);

	public List<OrderList_MemberVO> orderApprovalList(Criteria cri, Model model);
	
	public List<List<OrderList_ProductVO_2>> orderApprovalListDetail(Criteria cri);
	
	public List<OrderList_MemberVO> orderCompleteList(Criteria cri, Model model);
	
	public List<List<OrderList_ProductVO_2>> orderCompleteListDetail(Criteria cri);

	public void orderDelete(String[] ckb);

	/////////////////////////////////////////////////////////////////////////////
	public List<OrderList_MemberVO> orderFinishList(Criteria cri, Model model);

	public List<List<OrderList_ProductVO_2>> orderFinishListDetail(Criteria cri);

	public void ostateFinish(String[] ckb);

	public void ostateApproval(String[] ckb);

	
}
