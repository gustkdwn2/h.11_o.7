package com.kosta.csm.vo;

public class HqIncome {
	long income; //수입금액
	String income_Date;//수익 날짜
	public long getIncome() {
		return income;
	}
	public void setIncome(long income) {
		this.income = income;
	}
	public String getIncome_Date() {
		return income_Date;
	}
	public void setIncome_Date(String income_Date) {
		this.income_Date = income_Date;
	}
}
