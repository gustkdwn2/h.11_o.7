package com.kosta.csm.vo;

import java.util.Date;

// 발주내역 확인 테이블
public class OrderList_ProductVO {
	
	private int o_Num;
	private String hp_Code;
	private String hp_Name;
	private String o_amount;
	private String hp_Mprice;
	private String hp_Cprice;
	private Date o_Date;
	private String o_StringDate;
	private int o_State;
	
	

	@Override
	public String toString() {
		return "OrderList_ProductVO [hp_Code=" + hp_Code + ", hp_Name=" + hp_Name + ", o_amount=" + o_amount
				+ ", hp_Mprice=" + hp_Mprice + ", hp_Cprice=" + hp_Cprice + "]";
	}

	public OrderList_ProductVO() {
	}
	
	public OrderList_ProductVO(String hp_Code, String hp_Name, String o_amount, String hp_Mprice, String hp_Cprice) {
		this.hp_Code = hp_Code;
		this.hp_Name = hp_Name;
		this.o_amount = o_amount;
		this.hp_Mprice = hp_Mprice;
		this.hp_Cprice = hp_Cprice;
	}


	// getter / setter
	public int getO_Num() {
		return o_Num;
	}
	public void setO_Num(int o_Num) {
		this.o_Num = o_Num;
	}
	public String getHp_Code() {
		return hp_Code;
	}
	public void setHp_Code(String hp_Code) {
		this.hp_Code = hp_Code;
	}
	public String getHp_Name() {
		return hp_Name;
	}
	public void setHp_Name(String hp_Name) {
		this.hp_Name = hp_Name;
	}
	public String getO_amount() {
		return o_amount;
	}
	public void setO_amount(String o_amount) {
		this.o_amount = o_amount;
	}
	public String getHp_Mprice() {
		return hp_Mprice;
	}
	public void setHp_Mprice(String hp_Mprice) {
		this.hp_Mprice = hp_Mprice;
	}
	public String getHp_Cprice() {
		return hp_Cprice;
	}
	public void setHp_Cprice(String hp_Cprice) {
		this.hp_Cprice = hp_Cprice;
	}
	public Date getO_Date() {
		return o_Date;
	}
	public void setO_Date(Date o_Date) {
		this.o_Date = o_Date;
	}
	public String getO_StringDate() {
		return o_StringDate;
	}
	public void setO_StringDate(String o_StringDate) {
		this.o_StringDate = o_StringDate;
	}
	public int getO_State() {
		return o_State;
	}
	public void setO_State(int o_State) {
		this.o_State = o_State;
	}
}
