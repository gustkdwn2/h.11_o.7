package com.kosta.csm.st_Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.kosta.csm.st_Service.St_ITimeLineService;
import com.kosta.csm.vo.Criteria;
import com.kosta.csm.vo.TimeLineVO;

@Controller
@RequestMapping("/st/timeLine")
public class St_TimeLineController {
	
	@Autowired
	private St_ITimeLineService service;
	
	@RequestMapping(value="/list")
	public String listGet(Model model, Criteria cri){
		model.addAttribute("parentList", service.parentList(cri, model));
		model.addAttribute("childList", service.childList());
		model.addAttribute("cri", cri);
		return "st.timeLine.list";
	}
	
	@RequestMapping(value="/writeReply", method=RequestMethod.POST)
	public String writeReply(TimeLineVO vo){
		service.writeReply(vo);
		return "redirect:/st/timeLine/list";
	}
	
	@RequestMapping(value="/writeTimeLine", method=RequestMethod.POST)
	public String writeTimeLine(TimeLineVO vo){
		service.writeTimeLine(vo);
		return "redirect:/st/timeLine/list";
	}
	
	@RequestMapping(value="/modifyTimeLine", method=RequestMethod.POST)
	public String modifyTimeLine(TimeLineVO vo){
		service.modifyTimeLine(vo);
		return "redirect:/st/timeLine/list";
	}
	
	@RequestMapping(value="/deleteTimeLine")
	public String deleteTimeLine(@RequestParam("t_Num") int t_Num){
		service.deleteTimeLine(t_Num);
		return "redirect:/st/timeLine/list";
	}

}
