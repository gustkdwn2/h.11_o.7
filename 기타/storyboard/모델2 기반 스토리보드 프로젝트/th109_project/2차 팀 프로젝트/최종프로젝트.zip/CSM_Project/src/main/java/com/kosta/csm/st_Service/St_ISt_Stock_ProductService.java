package com.kosta.csm.st_Service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.kosta.csm.vo.Criteria;
import com.kosta.csm.vo.ProductVO;
import com.kosta.csm.vo.St_Stock_ProductVO;

public interface St_ISt_Stock_ProductService {
	public List<St_Stock_ProductVO> list(Criteria cri, Model model);
	public void deleteProducts(String[] ckb);
	public List<ProductVO> stockListDetail(Criteria cri);
	
	// 판매 상품 등록
	public List<ProductVO> productRegList(Criteria cri, Model model);
	public void productReg(String[] ckb);
	
	// 판매 상품 검색
	public List<ProductVO> productRegSearch(Criteria cri, Model model, String searchType, String productSearch);
	public List<ProductVO> productRegSearch_Category(Criteria cri, Model model, String category);
	
	// 매장 재고 검색
	public List<St_Stock_ProductVO> productStockSearch(Criteria cri, Model model, String searchType, String productSearch);
	public List<St_Stock_ProductVO> productStockSearch_Category(Criteria cri, Model model, String category);
	
	

}
