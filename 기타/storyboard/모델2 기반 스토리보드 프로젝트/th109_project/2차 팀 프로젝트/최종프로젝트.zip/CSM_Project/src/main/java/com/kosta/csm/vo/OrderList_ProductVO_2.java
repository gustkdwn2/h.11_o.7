package com.kosta.csm.vo;

public class OrderList_ProductVO_2 {
	private int o_Num;
	private String hp_Code;
	private String m_Id;
	private int o_Amount;
	private String o_Date;
	private int o_State;
	private String hp_Name;
	private int hp_Oprice;
	private int hp_Mprice;
	private int hp_Cprice;
	
	public OrderList_ProductVO_2(){
		
	}
	public OrderList_ProductVO_2(int o_Num, String hp_Code, String m_Id, int o_Amount, String o_Date, int o_State,
			String hp_Name, int hp_Oprice, int hp_Mprice, int hp_Cprice) {
		this.o_Num = o_Num;
		this.hp_Code = hp_Code;
		this.m_Id = m_Id;
		this.o_Amount = o_Amount;
		this.o_Date = o_Date;
		this.o_State = o_State;
		this.hp_Name = hp_Name;
		this.hp_Oprice = hp_Oprice;
		this.hp_Mprice = hp_Mprice;
		this.hp_Cprice = hp_Cprice;
	}


	public int getO_Num() {
		return o_Num;
	}
	public void setO_Num(int o_Num) {
		this.o_Num = o_Num;
	}
	public String getHp_Code() {
		return hp_Code;
	}
	public void setHp_Code(String hp_Code) {
		this.hp_Code = hp_Code;
	}
	public String getM_Id() {
		return m_Id;
	}
	public void setM_Id(String m_Id) {
		this.m_Id = m_Id;
	}
	public int getO_Amount() {
		return o_Amount;
	}
	public void setO_Amount(int o_Amount) {
		this.o_Amount = o_Amount;
	}
	public String getO_Date() {
		return o_Date;
	}
	public void setO_Date(String o_Date) {
		this.o_Date = o_Date;
	}
	public int getO_State() {
		return o_State;
	}
	public void setO_State(int o_State) {
		this.o_State = o_State;
	}
	public String getHp_Name() {
		return hp_Name;
	}
	public void setHp_Name(String hp_Name) {
		this.hp_Name = hp_Name;
	}
	public int getHp_Oprice() {
		return hp_Oprice;
	}
	public void setHp_Oprice(int hp_Oprice) {
		this.hp_Oprice = hp_Oprice;
	}
	public int getHp_Mprice() {
		return hp_Mprice;
	}
	public void setHp_Mprice(int hp_Mprice) {
		this.hp_Mprice = hp_Mprice;
	}
	public int getHp_Cprice() {
		return hp_Cprice;
	}
	public void setHp_Cprice(int hp_Cprice) {
		this.hp_Cprice = hp_Cprice;
	}
	
	@Override
	public String toString() {
		return "OrderList_ProductVO_2 [o_Num=" + o_Num + ", hp_Code=" + hp_Code + ", m_Id=" + m_Id + ", o_Amount="
				+ o_Amount + ", o_Date=" + o_Date + ", o_State=" + o_State + ", hp_Name=" + hp_Name + ", hp_Oprice="
				+ hp_Oprice + ", hp_Mprice=" + hp_Mprice + ", hp_Cprice=" + hp_Cprice + "]";
	}
	
}
