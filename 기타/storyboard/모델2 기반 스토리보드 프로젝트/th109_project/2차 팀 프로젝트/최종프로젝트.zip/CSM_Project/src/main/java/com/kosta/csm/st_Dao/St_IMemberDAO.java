package com.kosta.csm.st_Dao;

import java.util.List;

import com.kosta.csm.vo.MemberVO;

public interface St_IMemberDAO {

	public List<MemberVO> memberList();

	public String modify(String m_Id);

	public String check(String parameter);

	public void memberModify(MemberVO vo);
	
	public void pwdModify(MemberVO vo);
	
	public MemberVO searchById(String m_Id);

}
