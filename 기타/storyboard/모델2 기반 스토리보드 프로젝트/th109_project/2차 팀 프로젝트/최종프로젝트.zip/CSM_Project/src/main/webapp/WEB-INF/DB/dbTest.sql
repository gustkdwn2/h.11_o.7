create table workingTime(
	wt_Num number primary key, --근무번호
	e_Num number, 				--근무직원 번호
	wt_StartTime date, --date  출글
	wt_EndTime date   --date   퇴근
);

update member set m_Pwd='123123' where m_Id = 'gyoungi1'

update member set m_pwd = '123123' where m_id = 'admin'

-- 점장은 한달에 하나만 있어도 된다
-- 아르바이트생은 넣기.. 제대로

insert into WORKINGTIME values(workingTime_seq_num.nextval, 22, 
						to_date('2016-06-15-00-00-00', 'yyyy-dd-mm-hh24-mi-ss'),
						to_date('2016-06-15-04-00-00', 'yyyy-dd-mm-hh24-mi-ss'));

						
insert into workingTime values 
(workingTime_seq_num.nextval, 9, to_date('2016-06-11-09-00-12', 'yyyy-mm-dd-hh24-mi-ss'), 
to_date('2016-06-11-19-01-20', 'yyyy-mm-dd-hh24-mi-ss'));

insert into workingTime values 
(workingTime_seq_num.nextval, 9, to_date('2016-03-11-23-01-12', 'yyyy-mm-dd-hh24-mi-ss'), 
to_date('2016-03-12-01-01-12', 'yyyy-mm-dd-hh24-mi-ss'));

insert into workingTime values 
(workingTime_seq_num.nextval, 7, to_date('2016-06-11-09-00-12', 'yyyy-mm-dd-hh24-mi-ss'), 
to_date('2016-06-11-19-01-20', 'yyyy-mm-dd-hh24-mi-ss'));

insert into workingTime values 
(workingTime_seq_num.nextval, 7, to_date('2016-03-11-23-01-12', 'yyyy-mm-dd-hh24-mi-ss'), 
to_date('2016-03-12-01-01-12', 'yyyy-mm-dd-hh24-mi-ss'));

insert into workingTime values 
(workingTime_seq_num.nextval, 2, to_date('2016-06-07-18-11-22', 'yyyy-mm-dd-hh24-mi-ss'), 
to_date('2016-04-06-19-01-22', 'yyyy-mm-dd-hh24-mi-ss'));

insert into workingTime values 
(workingTime_seq_num.nextval, 2, to_date('2016-03-11-09-11-12', 'yyyy-mm-dd-hh24-mi-ss'), 
to_date('2016-03-11-20-11-20', 'yyyy-mm-dd-hh24-mi-ss'));




insert into workingTime values 
(workingTime_seq_num.nextval, 25, to_date('2016-05-31-08-00-00', 'yyyy-mm-dd-hh24-mi-ss'), 
                         to_date('2016-05-31-16-00-00', 'yyyy-mm-dd-hh24-mi-ss'));

insert into workingTime values 
(workingTime_seq_num.nextval, 24, to_date('2016-05-31-16-00-00', 'yyyy-mm-dd-hh24-mi-ss'), 
                         to_date('2016-05-31-23-00-00', 'yyyy-mm-dd-hh24-mi-ss'));

insert into workingTime values 
(workingTime_seq_num.nextval, 25, to_date('2016-05-30-08-00-00', 'yyyy-mm-dd-hh24-mi-ss'), 
                         to_date('2016-05-30-16-00-00', 'yyyy-mm-dd-hh24-mi-ss'));

insert into workingTime values 
(workingTime_seq_num.nextval, 24, to_date('2016-05-30-16-00-00', 'yyyy-mm-dd-hh24-mi-ss'), 
                         to_date('2016-05-30-23-00-00', 'yyyy-mm-dd-hh24-mi-ss'));

insert into workingTime values 
(workingTime_seq_num.nextval, 23, to_date('2016-05-31-08-00-00', 'yyyy-mm-dd-hh24-mi-ss'), 
                         to_date('2016-05-31-16-00-00', 'yyyy-mm-dd-hh24-mi-ss'));

insert into workingTime values 
(workingTime_seq_num.nextval, 21, to_date('2016-05-31-16-00-00', 'yyyy-mm-dd-hh24-mi-ss'), 
                         to_date('2016-05-31-23-00-00', 'yyyy-mm-dd-hh24-mi-ss'));

insert into workingTime values 
(workingTime_seq_num.nextval, 23, to_date('2016-05-30-08-00-00', 'yyyy-mm-dd-hh24-mi-ss'), 
                         to_date('2016-05-30-16-00-00', 'yyyy-mm-dd-hh24-mi-ss'));

insert into workingTime values 
(workingTime_seq_num.nextval, 21, to_date('2016-05-30-16-00-00', 'yyyy-mm-dd-hh24-mi-ss'), 
                         to_date('2016-05-30-23-00-00', 'yyyy-mm-dd-hh24-mi-ss'));   
                         
insert into workingTime values 
(workingTime_seq_num.nextval, 20, to_date('2016-05-31-08-00-00', 'yyyy-mm-dd-hh24-mi-ss'), 
                         to_date('2016-05-31-16-00-00', 'yyyy-mm-dd-hh24-mi-ss'));

insert into workingTime values 
(workingTime_seq_num.nextval, 18, to_date('2016-05-31-16-00-00', 'yyyy-mm-dd-hh24-mi-ss'), 
                         to_date('2016-05-31-23-00-00', 'yyyy-mm-dd-hh24-mi-ss'));

insert into workingTime values 
(workingTime_seq_num.nextval, 20, to_date('2016-05-30-08-00-00', 'yyyy-mm-dd-hh24-mi-ss'), 
                         to_date('2016-05-30-16-00-00', 'yyyy-mm-dd-hh24-mi-ss'));

insert into workingTime values 
(workingTime_seq_num.nextval, 18, to_date('2016-05-30-16-00-00', 'yyyy-mm-dd-hh24-mi-ss'), 
                         to_date('2016-05-30-23-00-00', 'yyyy-mm-dd-hh24-mi-ss'));   

insert into workingTime values 
(workingTime_seq_num.nextval, 10, to_date('2016-06-10-23-00-00', 'yyyy-mm-dd-hh24-mi-ss'), 
                         to_date('2016-06-11-01-00-00', 'yyyy-mm-dd-hh24-mi-ss'));   

insert into workingTime values 
(workingTime_seq_num.nextval, 18, to_date('2016-06-11-23-00-00', 'yyyy-mm-dd-hh24-mi-ss'), 
                         to_date('2016-06-12-02-30-00', 'yyyy-mm-dd-hh24-mi-ss'));   

  insert into order_list values(order_list_seq_num.nextval, 'sn022', 'seoul1', 1000000, to_date('2016-05-01-16-00-00', 'yyyy-mm-dd-hh24-mi-ss'), 2, '');
insert into order_list values(order_list_seq_num.nextval, 'sn022', 'seoul1', 1500000, to_date('2016-04-01-16-00-00', 'yyyy-mm-dd-hh24-mi-ss'), 2, '');
insert into order_list values(order_list_seq_num.nextval, 'sn022', 'seoul1', 2700000, to_date('2016-03-01-16-00-00', 'yyyy-mm-dd-hh24-mi-ss'), 2, '');
insert into order_list values(order_list_seq_num.nextval, 'sn022', 'seoul1', 1900000, to_date('2016-01-01-16-00-00', 'yyyy-mm-dd-hh24-mi-ss'), 2, '');                       

insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/03/16',8000,'전자회로구매','손상민');
insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/02/03',2000,'전기세납부','신성림');
insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/01/19',4500,'사무용품','김신진');
insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/02/30',4000,'전기세납부','나상림');
insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/04/30',3000,'청소용품','서민진');
insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/05/30',4500,'부서비','박성림');
insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/04/17',1200,'부서비','장상진');
insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/02/19',5000,'it신제품 지원금','신신훈');
insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/02/10',2300,'우수부서 지원금','손문금');
insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/05/15',15000,'의약품구매','박상훈');
insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/04/30',5000,'전자회로구매','최상현');
insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/05/19',2000,'청소용품','서상원');
insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/03/21',1400,'부서비','김문훈');
insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/02/01',4500,'부서비','박문민');
insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/04/13',2300,'청소용품','장문훈');
insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/05/30',5400,'컴퓨터구매','서문훈');
insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/05/11',5000,'부서비','유상훈');
insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/03/28',4500,'전자회로구매','박신주');
insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/01/30',4500,'의약품구매','하예연');
insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/02/09',400000,'부서비','김혜훈');
insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/01/30',2000,'우수부서 지원금','하혜주');
insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/03/24',7000,'사무용품','장문금');
insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/01/15',2000,'팀회식','하종현');
insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/02/30',2000,'부서비','신예민');
insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/04/21',4000,'건물세납부','최신덕');
insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/05/30',2300,'의약품구매','박성환');
insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/01/29',400000,'건물세납부','나상환');
insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/01/27',5400,'팀회식','민신재');
insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/01/12',5400,'컴퓨터구매','민신현');
insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/01/08',4000,'사무용품','이성훈');
insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/04/22',4500,'컴퓨터구매','서종덕');
insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/04/03',4000,'팀회식','이예주');
insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/01/24',5000,'가스비납부','하민현');
insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/05/30',1400,'부서비','박예훈');
insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/01/10',3000,'사무용품','장상민');
insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/05/16',3000,'전자회로구매','김문주');
insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/02/18',50000,'우수부서 지원금','최문환');
insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/05/30',2300,'건물세납부','장예훈');
insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/04/02',4000,'설날선물구매','손문현');
insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/04/17',4500,'부서비','장민환');
insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/03/30',2400,'수도세납부','나상재');
insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/01/01',5000,'it신제품 지원금','신예환');
insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/01/16',5000,'사무용품','신성환');
insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/04/30',4000,'사무용품','박문주');
insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/05/14',1400,'부서비','손상주');
insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/01/07',4500,'부서비','하혜환');
insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/05/30',2300,'사무용품','장상금');
insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/02/12',4500,'팀회식','민신훈');
insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/04/30',5400,'it신제품 지원금','이성연');
insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/04/05',4500,'팀회식','민문연');
insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/02/30',4500,'부서비','최혜원');
insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/03/30',4000,'팀회식','나미덕');
insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/03/08',7000,'전자회로구매','서민현');
insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/05/05',8000,'청소용품','장미주');
insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/03/30',1400,'청소용품','신종림');
insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/01/24',4500,'팀회식','손종민');
insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/01/30',7000,'청소용품','장미연');
insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/04/03',4000,'가스비납부','손종현');
insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/05/12',5000,'it신제품 지원금','나신금');
insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/05/19',7000,'사무용품','유문연');
insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/05/26',1200,'팀회식','김예원');
insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/03/05',400000,'설날선물구매','신예림');
insert into HeadExpend  values(HeadExpend_seq_num.nextval,'2016/04/30',8000,'컴퓨터구매','하신진');


create table HeadExpend (
  he_Num number primary key,   -- he_num : 지출번호 (자동증가)  (PK)
  he_Date varchar2(50) not null,   -- he_Date 년/월/일  2016/02/28
    he_Expend number default 0,  -- he_Expend : 지출금
  he_Content varchar2(50) not null,   -- he_Content: 지출내역
  he_ExpendDirector varchar2(50)    -- he_ExpendDirector: 지출책임자
);

delete from headExpend where he_date like '2016-0%'

insert into member values ('admin', 'admin', '관리자', '000-0000-0000', '000-0000-0000', 'sijin.k91@gmail.com', '관리자', '관리자', 1)

insert into grade values ('admin', 'ROLE_ADMIN')

select * from (select * from board order by b_Num desc) where rownum >=1 and rownum <= 5;

select B.* from (select C.*, rownum R from (select p.* from st_stock s, PRODUCT p where s.hp_Code = p.hp_Code and s.m_Id = 'gyoungi1' and p.hp_Name like #{search} order by s.hp_Code desc) C where rownum <= #{cri.pageEnd}) B where R >= #{cri.pageStart}

select B.* from (select C.*, rownum R from 
		(SELECT DISTINCT o.m_Id, m.m_Store, TO_CHAR(o.o_Date, 'YYYY-MM-DD') as o_Date 
		FROM order_List o, member m where m.m_id=o.m_id and o.o_state=0 order by o_Date asc) 
		C where rownum <= 5) B where R >= 1


select B.* from (select C.*, rownum R from (
		select e.e_Name as e_Name,  e.e_Num as e_Num, to_char(wt_StartTime,'yyyy/mm/dd/hh24/mi/ss') as wt_StartTime,   to_char(wt_EndTime,'yyyy/mm/dd/hh24/mi/ss') as wt_EndTime,  wt_Num 
		from member m, employee e, workingtime  w 
 		  where  m.m_id = e.m_id and w.e_num = e.e_num 
 		   and e.m_id = 'b'
 		   ) C where rownum <= 5) B where R >= 1
 		   
 		   select * from employee where e_Num = 62

insert into WORKINGTIME values(workingTime_seq_num.nextval, 63, '2016/06/06', '2016/06/07');
select * from WORKINGTIME
select B.* from (select C.*, rownum R from 
		(select e_Num, e_Name ,e_StartDay, e_Account ,e_Phone, e_Position, m_Store, e_Pay FROM Employee e, member m 
			where e.m_Id = m.m_Id order by e.e_Num desc) 
		C where rownum <= 5) B where R >= 1

insert into member values('a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 1);
insert into member values('b', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 1);
insert into grade values('a', 'ROLE_ADMIN');
insert into grade values('b', 'ROLE_USER');
insert into grade values('c', 'ROLE_USER');


select * from grade;
select * from workingtime;
select * from member;
select * from employee;
select * from board;
select * from STOREINCOME;
select * from product;
select * from hq_stock;
select * from ST_STOCK;
select * from order_list;
select * from STOREEXPEND;
select * from sale;
select * from timeline;
select * from workingtime;
select * from headexpend;
select * from pay;

insert into workingTime values(workingTime_seq_num.nextval, 41, '2016/06/12', '2016/06/13');


delete from member where m_id = 'c';
insert into grade values('c', 'ROLE_USER');

select s.m_Id, s.hp_Code, o.o_amount as st_Amount from st_stock s, order_List o where s.m_Id=o.m_Id and s.hp_Code = o.hp_Code and o.o_state = 1 and o.m_Id = 'b' and TO_CHAR(o.o_Date, 'YYYY-MM-DD')='2016-06-04'

select * from member;
select * from grade;

update hq_STOCK set hp_Amount = 0
update st_stock set st_amount = 0

select * from order_List

select B.* from (select C.*, rownum R from (select o.o_Num, p.hp_Code, p.hp_Name, o.o_amount, p.hp_Mprice, p.hp_Cprice, o.o_Date, o.o_State from (select * from ORDER_LIST where o_State = 0 or o_State = 1) o, PRODUCT p where p.hp_Code = o.hp_Code and o.m_Id='b' order by o.o_Num desc) C where rownum <= 10) B where R >= 0
select * from ORDER_LIST where o_State = 0 or o_State = 1

select count(*) from (select * from ORDER_LIST where o_State = 0 or o_State = 1) o, PRODUCT p where p.hp_Code = o.hp_Code and o.m_Id='b'

insert into member values ('admin', 'admin', '관리자', '000-0000-0000', '000-0000-0000', 'sijin.k91@gmail.com', '관리자', '관리자', 1)
insert into grade values ('admin', 'ROLE_USER')
insert into grade values ('admin', 'ROLE_ADMIN')
delete from grade where m_Id='admin'

select * from member;

select * from product;

delete from product where hp_Code='1'

insert into product values('1', '바나나', '바나나사진.jsp', 100, 200, 300, '과자류', '아프리카', '2016/08/11', '100g', 1);
insert into product values('2', '킹콩바나나노', '바나나사진.jsp', 100, 200, 300, '과자류', '아프리카', '2016/08/11', '100g', 1);
insert into product values('3', '바나나맛우유', '바나나사진.jsp', 100, 200, 300, '과자류', '아프리카', '2016/08/11', '100g', 1);
insert into product values('4', '초코바나나', '바나나사진.jsp', 100, 200, 300, '과자류', '아프리카', '2016/08/11', '100g', 1);
insert into product values('5', '초코초코초코', '바나나사진.jsp', 100, 200, 300, '과자류', '아프리카', '2016/08/11', '100g', 1);
insert into product values('6', '초코는맛있다', '바나나사진.jsp', 100, 200, 300, '과자류', '아프리카', '2016/08/11', '100g', 1);
insert into product values('7', '꼬르륵', '바나나사진.jsp', 100, 200, 300, '과자류', '아프리카', '2016/08/11', '100g', 1);
insert into product values('8', '바나나', '바나나사진.jsp', 100, 200, 300, '과자류', '아프리카', '2016/08/11', '100g', 1);
insert into product values('9', '바나나', '바나나사진.jsp', 100, 200, 300, '과자류', '아프리카', '2016/08/11', '100g', 1);
insert into product values('10', '바나나', '바나나사진.jsp', 100, 200, 300, '과자류', '아프리카', '2016/08/11', '100g', 1);
insert into product values('11', '바나나', '바나나사진.jsp', 100, 200, 300, '과자류', '아프리카', '2016/08/11', '100g', 1);
insert into product values('12', '바나나', '바나나사진.jsp', 100, 200, 300, '과자류', '아프리카', '2016/08/11', '100g', 1);
insert into product values('13', '바나나', '바나나사진.jsp', 100, 200, 300, '과자류', '아프리카', '2016/08/11', '100g', 1);
insert into product values('14', '바나나', '바나나사진.jsp', 100, 200, 300, '과자류', '아프리카', '2016/08/11', '100g', 1);
insert into product values('15', '바나나', '바나나사진.jsp', 100, 200, 300, '과자류', '아프리카', '2016/08/11', '100g', 1);

select * from product where hp_Name like '%바나나%'
select count(*) from product where hp_Name like '%바나나%'

select * from product where hp_Category = '과자류'

select count(*) from product where hp_Name like 'b' and hp_State = 1

select B.* from (select C.*, rownum R from (select * from product where hp_Name like '%바나나%' order by hp_Code desc) C where rownum <= 5) B where R >= 1
select * from board;

insert into BOARD values(board_seq_num.nextval, 'a', 'a', 'a', 'a', 'a', '2016/05/27', 0, '0');
insert into BOARD values(board_seq_num.nextval, 'a', 'a', 'a', 'a', 'a', '2016/05/27', 0, '0');
insert into BOARD values(board_seq_num.nextval, 'a', 'a', 'a', 'a', 'a', '2016/05/27', 0, '0');
insert into BOARD values(board_seq_num.nextval, 'a', 'a', 'a', 'a', 'a', '2016/05/27', 0, '0');
insert into BOARD values(board_seq_num.nextval, 'a', 'a', 'a', 'a', 'a', '2016/05/27', 0, '0');
insert into BOARD values(board_seq_num.nextval, 'a', 'a', 'a', 'a', 'a', '2016/05/27', 0, '0');
insert into BOARD values(board_seq_num.nextval, 'a', 'a', 'a', 'a', 'a', '2016/05/27', 0, '0');
insert into BOARD values(board_seq_num.nextval, 'a', 'a', 'a', 'a', 'a', '2016/05/27', 0, '0');
insert into BOARD values(board_seq_num.nextval, 'a', 'a', 'a', 'a', 'a', '2016/05/27', 0, '0');
insert into BOARD values(board_seq_num.nextval, 'a', 'a', 'a', 'a', 'a', '2016/05/27', 0, '0');
insert into BOARD values(board_seq_num.nextval, 'a', 'a', 'a', 'a', 'a', '2016/05/27', 0, '0');
insert into BOARD values(board_seq_num.nextval, 'a', 'a', 'a', 'a', 'a', '2016/05/27', 0, '0');
insert into BOARD values(board_seq_num.nextval, 'a', 'a', 'a', 'a', 'a', '2016/05/27', 0, '0');
insert into BOARD values(board_seq_num.nextval, 'a', 'a', 'a', 'a', 'a', '2016/05/27', 0, '0');
insert into BOARD values(board_seq_num.nextval, 'a', 'a', 'a', 'a', 'a', '2016/05/27', 0, '0');
insert into BOARD values(board_seq_num.nextval, 'a', 'a', 'a', 'a', 'a', '2016/05/27', 0, '0');
insert into BOARD values(board_seq_num.nextval, 'a', 'a', 'a', 'a', 'a', '2016/05/27', 0, '0');
insert into BOARD values(board_seq_num.nextval, 'a', 'a', 'a', 'a', 'a', '2016/05/27', 0, '0');
insert into BOARD values(board_seq_num.nextval, 'a', 'a', 'a', 'a', 'a', '2016/05/27', 0, '0');
insert into BOARD values(board_seq_num.nextval, 'a', 'a', 'a', 'a', 'a', '2016/05/27', 0, '0');
insert into BOARD values(board_seq_num.nextval, 'a', 'a', 'a', 'a', 'a', '2016/05/27', 0, '0');
insert into BOARD values(board_seq_num.nextval, 'a', 'a', 'a', 'a', 'a', '2016/05/27', 0, '0');
insert into BOARD values(board_seq_num.nextval, 'a', 'a', 'a', 'a', 'a', '2016/05/27', 0, '0');
insert into BOARD values(board_seq_num.nextval, 'a', 'a', 'a', 'a', 'a', '2016/05/27', 0, '0');
insert into BOARD values(board_seq_num.nextval, 'a', 'a', 'a', 'a', 'a', '2016/05/27', 0, '0');
insert into BOARD values(board_seq_num.nextval, 'a', 'a', 'a', 'a', 'a', '2016/05/27', 0, '0');
insert into BOARD values(board_seq_num.nextval, 'a', 'a', 'a', 'a', 'a', '2016/05/27', 0, '0');
insert into BOARD values(board_seq_num.nextval, 'a', 'a', 'a', 'a', 'a', '2016/05/27', 0, '0');
insert into BOARD values(board_seq_num.nextval, 'a', 'a', 'a', 'a', 'a', '2016/05/27', 0, '0');
insert into BOARD values(board_seq_num.nextval, 'a', 'a', 'a', 'a', 'a', '2016/05/27', 0, '0');
insert into BOARD values(board_seq_num.nextval, 'a', 'a', 'a', 'a', 'a', '2016/05/27', 0, '0');
insert into BOARD values(board_seq_num.nextval, 'a', 'a', 'a', 'a', 'a', '2016/05/27', 0, '0');



select B.* from (select C.*, rownum R from (select to_char(b_date,'YYYYMMDD') from board order by b_Num desc) C where rownum <= 20) B where R >= 11


select B.* from (select C.*, rownum R from (select b_Num, m_Id, b_Title, b_Content, b_Path1, b_Path2, to_date(b_date,'YYYYMMDD'), b_Hit, b_Important from board order by b_Num desc) C where rownum <= 5) B where R >= 1




select * from HQ_STOCK;


select * from PRODUCT
s
insert into order_List values(order_list_seq_num.nextval, '1', 'b', 5, '2016/05/27', 0);
insert into product values('1', '바나나', '바나나사진.jsp', 100, 200, 300, '과일', '아프리카', '2016/08/11', '100g');


insert into order_List values(order_list_seq_num.nextval, '2', 'b', 2, '2016/05/28', 0);
insert into product values('2', '초퀄릿', '바나나사진.jsp', 1000, 2000, 3000, '과자', '아프리카', '2016/08/11', '100g');

insert into order_List values(order_list_seq_num.nextval, '3', 'b', 3, '2016/05/29', 0);
insert into product values('3', '칫솔', '바나나사진.jsp', 500, 600, 700, '생활용품', '아프리카', '2016/08/11', '100g');
insert into product values('4', '집가고싶어', '바나나사진.jsp', 5000, 6000, 7000, '집가고싶어', '집!!!', '2016/08/11', '100g');

insert into st_stock values('b', '123', 10);
insert into st_stock values('b', '2', 1);
insert into st_stock values('b', '3', 2);

select * from st_stock
insert into st_stock values('c', '2', 1);

insert into hq_stock values('1', 1);
insert into hq_stock values('2', 2);
insert into hq_stock values('3', 3);

select * from ST_STOCK;
select * from sale;

select * from product

select * from order_List;

select B.* from (select C.*, rownum R from (select p.hp_Code, p.hp_Name, o.o_amount, p.hp_Mprice, p.hp_Cprice from order_List o, PRODUCT p where p.hp_Code = o.hp_Code and o.o_State = 0 and o.m_Id='b' order by o.o_Num desc) C where rownum <= 5) B where R >= 1

select count(*) from order_List o, PRODUCT p where p.hp_Code = o.hp_Code and o.o_State = 0 and o.m_Id='b' order by o.o_Num desc



select B.* from (select C.*, rownum R from (select s.m_Id, s.hp_Code, s.st_Amount, p.hp_Name, p.hp_Mprice, p.hp_Cprice from st_stock s, PRODUCT p where s.hp_Code = p.hp_Code and s.m_Id = 'b' order by s.hp_Code desc) C where rownum <= 5) B where R >= 1
select count(*) from st_stock s, product p where s.hp_Code = p.hp_Code and s.m_Id = 'b'




drop table order_List;

create table order_List(                -- 발주 테이블
  o_Num number primary key,             -- o_Num : 발주번호 (자동증가) (PK)
  hp_Code varchar2(50) not null,        -- hp_Code : 상품코드   (FK : product)
  m_Id varchar2(50) not null,           -- m_Id : 매장ID    (FK : member)
  o_amount number not null,             -- o_amount : 주문 수량
  o_Date date default sysdate,          -- o_Date : 발주날짜
  o_State number not null               -- o_State : 발주상태  (0:요청상태, 1:승인상태) / 승인취소시 1->0 / 0일때만 레코드 삭제 가능
);

create table order_List(                -- 발주 테이블
  o_Num number primary key,             -- o_Num : 발주번호 (자동증가) (PK)
  hp_Code varchar2(50) not null,        -- hp_Code : 상품코드   (FK : product)
  m_Id varchar2(50) not null,           -- m_Id : 매장ID    (FK : member)
  o_amount number not null,             -- o_amount : 주문 수량
  o_Date date default sysdate,          -- o_Date : 발주날짜
  o_State number not null,               -- o_State : 발주상태  (0:요청상태, 1:승인상태) / 승인취소시 1->0 / 0일때만 레코드 삭제 가능
  o_StringDate varchar2(50)
);

select * from order_List;
insert into order_List values(order_list_seq_num.nextval, '1', 'b', 5, '2016/05/27', 0);
insert into order_List values(order_list_seq_num.nextval, '1', 'b', 100, '2016/05/27', 0);
insert into order_List values(order_list_seq_num.nextval, '2', 'b', 2, '2016/05/28', 0);
insert into order_List values(order_list_seq_num.nextval, '3', 'b', 3, '2016/05/29', 0);

insert into order_List values(order_list_seq_num.nextval, '1', 'c', 5, '2016/05/27', 0);
insert into order_List values(order_list_seq_num.nextval, '1', 'c', 100, '2016/05/27', 0);
insert into order_List values(order_list_seq_num.nextval, '2', 'c', 2, '2016/05/28', 0);
insert into order_List values(order_list_seq_num.nextval, '3', 'c', 3, '2016/05/29', 0);

-- 성공!
SELECT DISTINCT m_Id, TO_CHAR(o_Date, 'YYYY-MM-DD HH:mm') FROM order_List order by m_Id;

-- 성공!
select * from order_List where m_id = 'b' and TO_CHAR(o_date,'YYYY-MM-DD') = '2016-05-27'




select * from order_List where m_id='b' and o_State=1;

select count(*) from order_List where m_id='b' and o_State=1;

select B.* from (select C.*, rownum R from (select o.o_Num, p.hp_Code, p.hp_Name, o.o_amount, p.hp_Mprice, p.hp_Cprice, TO_CHAR(o_Date, 'YYYY-MM-DD HH:mm') as o_StringDate from order_List o, PRODUCT p where p.hp_Code = o.hp_Code and o.o_State = 1 and o.m_Id='b' order by o.o_Num desc) C where rownum <= 5) B where R >= 1


select B.* from (select C.*, rownum R from (select p.* from product p, hq_stock s where s.hp_Code=p.hp_Code order by p.hp_Code desc) C where rownum <= 5) B where R >= 1

select * from product

select B.* from (select C.*, rownum R from (select p.* from st_stock s, PRODUCT p where s.hp_Code = p.hp_Code and s.m_Id = 'b' order by s.hp_Code desc) C where rownum <= 5) B where R >= 1

select B.* from (select C.*, rownum R from (select p.* from order_list o, product p where p.hp_Code = o.hp_Code and o_state = 0 order by o_Num desc) C where rownum <= 5) B where R >= 1

select * from order_List

select B.* from (select C.*, rownum R from (select * from member order by m_Id desc) C where rownum <= 5) B where R >= 1

select count(*) from member

SELECT DISTINCT o.m_Id, m.m_Store, TO_CHAR(o.o_Date, 'YYYY-MM-DD') as o_Date 
			FROM order_List o, member m where m.m_id=o.m_id and o.o_state=1 order by o.m_Id
			
			SELECT DISTINCT count(DISTINCT o.m_Id)
			FROM order_List o, member m where m.m_id=o.m_id and o.o_state=1 order by o.m_Id
			
select * from st_stock;
select * from order_List;
select s.m_Id, s.hp_Code, o.o_amount as st_Amount from st_stock s, order_List o where s.m_Id=o.m_Id and s.hp_Code = o.hp_Code and o.o_state = 0 and o.m_Id = 'b' and TO_CHAR(o.o_Date, 'YYYY-MM-DD')='2016-06-01'


update st_stock set st_Amount = st_Amount+4 where m_Id='b' and hp_Code='2'

select * from grade;

select m.* from member m, grade g where m.m_Id = g.m_Id and g.role_Name = 'ROLE_USER' order by m.m_Id desc

select count(*) from member m, grade g where m.m_Id = g.m_Id and g.role_Name = 'ROLE_USER'

select m.* from member m, grade g where m.m_Id = g.m_Id and g.role_Name = 'ROLE_USER' and m.m_Store like '%b%' order by m.m_Id desc

select count(*) from member m, grade g where m.m_Id = g.m_Id and g.role_Name = 'ROLE_USER' and m.m_Store like '%b%' order by m.m_Id desc

update hq_stock set hp_Amount  = hp_Amount -1 where  hp_Code='1'

select * from product;

select count(*) from product p, st_stock s where p.hp_Code = s.hp_Code and s.m_Id = 'b' and p.hp_Code='2'


select count(*) from PRODUCT where hp_Code='aa'

select * from product;
select * from order_List

select o.o_Num, o.hp_Code, o.m_Id, o.o_Amount, o.o_Date, o.o_State, p.hp_Name, p.hp_Oprice, p.hp_Mprice, p.hp_Cprice 
		from order_List o, product p where o.hp_Code = p.hp_Code and m_id = 'b' and o.o_state=0 and TO_CHAR(o.o_date,'YYYY-MM-DD') = '2016-06-03'

insert into storeincome(m_Id, si_Date, si_Sale) values('a', '2016-05-07', 5000);
insert into storeincome(m_Id, si_Date, si_Sale) values('b', '2016-05-09', 7000);
		
select * from storeincome;
select * from member;

-- 지난 달 지역별 평균 매출

select m.m_Location1, avg(s.si_Sale)
from member m, STOREINCOME s
where m.m_Id = s.m_Id and s.si_Date like TO_CHAR(ADD_MONTHS(sysdate,-1),'YYYY-MM-%') group by m.m_Location1;

select count(*) from employee e, member m where e.m_Id=m.m_Id

select * from board where b_Title like '%z%';

select count(*) from employee e, member m, workingTime w where e.m_Id=m.m_Id and 
		w.e_Num=e.e_Num and e.e_Position = '아르바이트'
		
				select count(*) from 
		(
		
				select t1.month, t1.e_Num , t1.ct, t1.m_id AS m_Id, round(t1.workMinuteSum) as workMinuteSum,
				round(t1.workMinuteSum/60 , 1) as workHourSum, m.m_Store as m_Store, t1.e_position  , p.p_pay as e_Pay
				from(
					select to_char(wt_StartTime, 'yyyy/mm') as month, max(m_id) as m_id, 
					 		e_Num, count(*) as ct, sum(workMinute ) as workMinuteSum,  min(e_Position) as e_Position
				    from
				    	(
				    		select  wt_StartTime , wt_EndTime,to_char((wt_EndTime - wt_StartTime)*60*24)
						  	as workMinute, e.e_Num as e_Num, e.m_id as m_id ,e.e_Position as e_Position
							from  employee e, workingTime w where w.e_Num = e.e_Num and e_Position='아르바이트'
						) 
				group by to_char(wt_StartTime, 'yyyy/mm'), e_Num) t1, member m , pay p
				where m.m_id = t1.m_id and p.e_Num = t1.e_Num and p.p_date = 
					(select max(p_date) from  pay where e_num =  t1.e_Num and p_date <= t1.month group by e_num)
				order by t1.month desc
		
		)
		
select * from employee
select * from workingtime;

insert into workingTime values 
(workingTime_seq_num.nextval, 27, to_date('2016-06-11-09-00-12', 'yyyy-mm-dd-hh24-mi-ss'), 
to_date('2016-06-11-19-01-20', 'yyyy-mm-dd-hh24-mi-ss'));

insert into workingTime values 
(workingTime_seq_num.nextval, 41, to_date('2016-06-11-08-32-28', 'yyyy-mm-dd-hh24-mi-ss'), 
to_date('2016-06-11-20-03-32', 'yyyy-mm-dd-hh24-mi-ss'));