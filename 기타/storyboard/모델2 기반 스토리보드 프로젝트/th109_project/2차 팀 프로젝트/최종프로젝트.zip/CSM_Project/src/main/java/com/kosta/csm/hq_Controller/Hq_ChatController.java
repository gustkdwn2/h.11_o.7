package com.kosta.csm.hq_Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/hq/chat")
public class Hq_ChatController {
	
	@RequestMapping("/chat")
	public String chatView(){
		return "hq.chat.chat";
	}
}
