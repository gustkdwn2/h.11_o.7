package com.kosta.csm.vo;

import java.util.Date;
import java.util.List;

import org.springframework.web.multipart.commons.CommonsMultipartFile;

// 게시판 테이블
public class BoardVO {
	private int b_Num;			// 게시글 번호
	private String m_Id;		// 아이디
	private String b_Title;		// 글제목
	private String b_Content;	// 글내용
	private String b_Path1;		// 파일명1
	private String b_Path2;		// 파일명2
	private String b_Date;		// 작성날짜
	private int b_Hit;			// 조회수
	private int b_Important;	// 1:전체공지, 0:일반공지
	
	// Constructor
	public BoardVO() {
	}

	public BoardVO(int b_Num, String m_Id, String b_Title, String b_Content, String b_Path1, String b_Path2,
			int b_Important) {
		this.b_Num = b_Num;
		this.m_Id = m_Id;
		this.b_Title = b_Title;
		this.b_Content = b_Content;
		this.b_Path1 = b_Path1;
		this.b_Path2 = b_Path2;
		this.b_Important = b_Important;
	}
	
	
	// 멀티 파일 업로드///////////////////////////////
	private List<CommonsMultipartFile> files;

	public List<CommonsMultipartFile> getFiles() {
		return files;
	}

	public void setFiles(List<CommonsMultipartFile> files) {
		this.files = files;
	}
	////////////////////////////////////////////////
	
	
	
	// getter / setter
	public int getB_Num() {
		return b_Num;
	}

	public void setB_Num(int b_Num) {
		this.b_Num = b_Num;
	}

	public String getM_Id() {
		return m_Id;
	}

	public void setM_Id(String m_Id) {
		this.m_Id = m_Id;
	}

	public String getB_Title() {
		return b_Title;
	}

	public void setB_Title(String b_Title) {
		this.b_Title = b_Title;
	}

	public String getB_Content() {
		return b_Content;
	}

	public void setB_Content(String b_Content) {
		this.b_Content = b_Content;
	}

	public String getB_Path1() {
		return b_Path1;
	}

	public void setB_Path1(String b_Path1) {
		this.b_Path1 = b_Path1;
	}

	public String getB_Path2() {
		return b_Path2;
	}

	public void setB_Path2(String b_Path2) {
		this.b_Path2 = b_Path2;
	}

	public String getB_Date() {
		return b_Date;
	}

	public void setB_Date(String b_Date) {
		this.b_Date = b_Date;
	}

	public int getB_Hit() {
		return b_Hit;
	}

	public void setB_Hit(int b_Hit) {
		this.b_Hit = b_Hit;
	}

	public int getB_Important() {
		return b_Important;
	}

	public void setB_Important(int b_Important) {
		this.b_Important = b_Important;
	}
}
