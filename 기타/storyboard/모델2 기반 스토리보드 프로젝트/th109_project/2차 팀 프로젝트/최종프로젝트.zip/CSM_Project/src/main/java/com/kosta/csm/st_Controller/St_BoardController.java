package com.kosta.csm.st_Controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.kosta.csm.st_Service.St_IBoardService;
import com.kosta.csm.vo.BoardVO;
import com.kosta.csm.vo.Criteria;

@Controller
@RequestMapping("/st/board")
public class St_BoardController {

	@Autowired
	private St_IBoardService service;
	
	@RequestMapping(value="/list", method=RequestMethod.GET)
	public String list(Criteria cri, Model model){
		System.out.println("list() !");
		
		model.addAttribute("list", service.list(cri, model));
		model.addAttribute("cri", cri);
		
		return "st.board.list";
	}// list()
	
	
	@RequestMapping(value="/content", method=RequestMethod.GET)
	public String contentGet(@RequestParam("b_Num") int b_Num, Model model){
		System.out.println("contentGet");
		service.updateReadCount(b_Num);
		model.addAttribute("contentList", service.content(b_Num));
		return "st.board.content";
	}
	
	@RequestMapping("/download")
	public String download(@RequestParam("path") String path, @RequestParam("file") String file, 
			HttpServletRequest request, HttpServletResponse response) throws Exception{
		System.out.println("download");
		service.download(path, file, request, response);
		return "redirect:/st/board/content";
	}
	
	@RequestMapping(value="/boardListSearch")
	public String boardListSearch(Criteria cri, Model model, @RequestParam("boardSearch") String boardSearch,
			@RequestParam("searchType") String searchType){
		
		System.out.println("boardListSearch");
		model.addAttribute("list", service.boardSearch(cri, boardSearch, searchType, model));
		model.addAttribute("cri", cri);
		model.addAttribute("search_check", 1);
		model.addAttribute("boardSearch", boardSearch);
		model.addAttribute("searchType", searchType);
		
		return "st.board.list";
	}
	
}
