package com.kosta.csm.dao;

import com.kosta.csm.vo.MemberVO;

public interface CommonDAO {

	public void join(MemberVO vo);
	
	public MemberVO idSearch(MemberVO vo);

	public MemberVO pwdSearch(MemberVO vo);
		// resultType ,       parameterType

	public int idCheck(String m_Id);
}
