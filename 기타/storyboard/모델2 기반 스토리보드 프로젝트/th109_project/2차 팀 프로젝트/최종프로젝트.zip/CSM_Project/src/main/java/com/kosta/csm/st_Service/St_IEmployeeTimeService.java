package com.kosta.csm.st_Service;

import java.text.ParseException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.ui.Model;

import com.kosta.csm.vo.Criteria;
import com.kosta.csm.vo.StWorkingEmployee;

public interface St_IEmployeeTimeService {
	public List<StWorkingEmployee> timeList(Criteria cri, Model model);
	
	public void proModifyTime(StWorkingEmployee vo, HttpServletRequest request) throws ParseException;

	public List<StWorkingEmployee> employeeSearch(Criteria cri, Model model, String searchType, String employee);
}
