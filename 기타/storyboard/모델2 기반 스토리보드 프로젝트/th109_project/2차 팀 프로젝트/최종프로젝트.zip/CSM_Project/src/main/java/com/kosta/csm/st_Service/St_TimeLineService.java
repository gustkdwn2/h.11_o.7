package com.kosta.csm.st_Service;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.kosta.csm.st_Dao.St_ITimeLineDAO;
import com.kosta.csm.vo.Criteria;
import com.kosta.csm.vo.TimeLineVO;

@Service
public class St_TimeLineService implements St_ITimeLineService{
	
	@Autowired
	private SqlSession sqlSession;

	@Override
	public List<TimeLineVO> parentList(Criteria cri, Model model) {
		St_ITimeLineDAO dao=sqlSession.getMapper(St_ITimeLineDAO.class);
		model.addAttribute("count", dao.timeLineCount());
		return dao.parentList(cri);
	}
	@Override
	public List<TimeLineVO> childList() {
		St_ITimeLineDAO dao=sqlSession.getMapper(St_ITimeLineDAO.class);
		return dao.childList();
	}
	@Override
	public void writeReply(TimeLineVO vo) {
		St_ITimeLineDAO dao=sqlSession.getMapper(St_ITimeLineDAO.class);
		dao.writeReply(vo);
	}
	@Override
	public void writeTimeLine(TimeLineVO vo) {
		St_ITimeLineDAO dao=sqlSession.getMapper(St_ITimeLineDAO.class);
		
		if(dao.timeLineCount()==0){//부모글이 하나도 없다면
			dao.firstWriteTimeLine(vo);
		}else{
			dao.writeTimeLine(vo);
		}
	}
	@Override
	public void modifyTimeLine(TimeLineVO vo) {
		St_ITimeLineDAO dao=sqlSession.getMapper(St_ITimeLineDAO.class);
		dao.modifyTimeLine(vo);
	}
	@Override
	public void deleteTimeLine(int t_Num) {
		St_ITimeLineDAO dao=sqlSession.getMapper(St_ITimeLineDAO.class);
		dao.deleteTimeLine(t_Num);
	}
}
