package com.kosta.csm.vo;

import java.util.Date;

public class SaleVO {
	private int s_Num; //판매번호
	private String hp_Code; //회원ID
	private String m_Id; //상품코드
	private int s_Group; //구매그룹 번호
	private int s_Amount; //판매수량
	private Date s_Date; //판매날짜
	
	//생성자
	public SaleVO(){
		
	}
	public SaleVO(int s_Num, String hp_Code, String m_Id, int s_Group, int s_Amount) {
		this.s_Num = s_Num;
		this.hp_Code = hp_Code;
		this.m_Id = m_Id;
		this.s_Group = s_Group;
		this.s_Amount = s_Amount;
	}


	//getter setter
	public int getS_Num() {
		return s_Num;
	}
	public void setS_Num(int s_Num) {
		this.s_Num = s_Num;
	}
	public String getHp_Code() {
		return hp_Code;
	}
	public void setHp_Code(String hp_Code) {
		this.hp_Code = hp_Code;
	}
	public String getM_Id() {
		return m_Id;
	}
	public void setM_Id(String m_Id) {
		this.m_Id = m_Id;
	}
	public int getS_Group() {
		return s_Group;
	}
	public void setS_Group(int s_Group) {
		this.s_Group = s_Group;
	}
	public int getS_Amount() {
		return s_Amount;
	}
	public void setS_Amount(int s_Amount) {
		this.s_Amount = s_Amount;
	}
	public Date getS_Date() {
		return s_Date;
	}
	public void setS_Date(Date s_Date) {
		this.s_Date = s_Date;
	}
	
}
