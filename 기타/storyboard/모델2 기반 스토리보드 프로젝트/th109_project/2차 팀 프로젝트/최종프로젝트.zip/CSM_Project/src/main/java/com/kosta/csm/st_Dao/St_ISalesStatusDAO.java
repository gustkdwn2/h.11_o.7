package com.kosta.csm.st_Dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.kosta.csm.vo.CategoryStatusVO;
import com.kosta.csm.vo.Criteria;
import com.kosta.csm.vo.ProductVO;

public interface St_ISalesStatusDAO {

	List<CategoryStatusVO> categoryStatus(String user_id);

	List<CategoryStatusVO> categoryStatusRank(@Param("user_id") String user_id, @Param("category") String category);

	List<ProductVO> salesStatusAll(@Param("cri") Criteria cri, @Param("user_id") String user_id);
	
	int salesStatusAllCount(@Param("user_id") String user_id);

	List<ProductVO> salesStatusAllDay(@Param("cri") Criteria cri, @Param("user_id") String user_id, @Param("day") String day);

	int salesStatusAllDayCount(@Param("user_id") String user_id, @Param("day") String day);

	List<ProductVO> salesStatusAllCate(@Param("cri") Criteria cri, @Param("user_id") String user_id, @Param("category") String category);

	int salesStatusAllCountCate(@Param("user_id") String user_id, @Param("category") String category);

	List<ProductVO> salesStatusAllDayCate(@Param("cri") Criteria cri, @Param("user_id") String user_id, @Param("day") String day, @Param("category") String category);

	Object salesStatusAllDayCountCate(@Param("user_id") String user_id, @Param("day") String day, @Param("category") String category);

	List<CategoryStatusVO> categoryStatusDay(@Param("user_id") String user_id, @Param("day") String day);

	List<CategoryStatusVO> categoryStatusRankDay(@Param("user_id") String user_id, @Param("category") String category, @Param("day") String day);

	List<Integer> monthStatus(String user_id);

	int monthStatus(@Param("user_id") String user_id, @Param("date") String date);

	Integer yearStatus(@Param("user_id") String user_id, @Param("date") String date);
}
