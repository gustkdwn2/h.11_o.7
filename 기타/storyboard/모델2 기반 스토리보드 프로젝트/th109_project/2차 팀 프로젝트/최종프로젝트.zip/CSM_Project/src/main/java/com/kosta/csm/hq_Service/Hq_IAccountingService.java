package com.kosta.csm.hq_Service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.ui.Model;

import com.kosta.csm.vo.Criteria;
import com.kosta.csm.vo.HeadExpendPerMonth;
import com.kosta.csm.vo.HeadExpendVO;
import com.kosta.csm.vo.HqIncome;
import com.kosta.csm.vo.HqIncomeOfMonth;
import com.kosta.csm.vo.HqRevenue;
import com.kosta.csm.vo.HqRevenueMore;
import com.kosta.csm.vo.WorkingTimeMore;

public interface Hq_IAccountingService {

	List<HqRevenue> getSumRevenuePerMonth(Criteria cri, Model model);
	
	List<HqRevenueMore> getRevenueMore(Criteria cri, Model model);

	List<HeadExpendVO> getExpendOfMonth(Criteria cri, Model model, String he_Date);

	List<HeadExpendPerMonth> getExpendPerMonth(Criteria cri, Model model);

	void removeOfMonth(String yearAndMonth);

	void removeOfNum(Integer he_Num);

	void addTempExpend(String year, String month, String day, List<HeadExpendVO> list, HeadExpendVO vo);

	void addExpendList(List<HeadExpendVO> list);

	void updateExpend(String year, String month, String day, HeadExpendVO vo);

	List<HqIncome> incomePerMonth(Criteria cri, Model model);

	List<HqIncomeOfMonth> incomeOfMonthPerStore(Criteria cri, Model model, String income_Date);

	List<HqIncomeOfMonth> incomeOfMonthPerDay(Criteria cri, Model model, String income_Date);

	List<HqIncomeOfMonth> incomePerStoreDetail(Criteria cri, Model model, String m_Id, String income_Date);

	List<HqIncomeOfMonth> incomePerDayDetail(Criteria cri, Model model, String income_Date);

	List<HqIncomeOfMonth> allOfdayIncome(String income_Date);

	List<HqIncomeOfMonth> allOfStoreMonthIncome(String income_Date, String m_Id);

	List<HqRevenue> revenueSearch(Criteria cri, Model model, HttpServletRequest request);
	
	List<HqIncome> incomeSearch(Criteria cri, Model model, HttpServletRequest request);
	
	List<HeadExpendPerMonth> expendSearch(Criteria cri, Model model, HttpServletRequest request);

}
