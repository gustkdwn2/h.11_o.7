package com.kosta.csm.hq_Dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.kosta.csm.vo.Criteria;
import com.kosta.csm.vo.CriteriaIndex;
import com.kosta.csm.vo.OrderListVO;
import com.kosta.csm.vo.OrderList_MemberVO;
import com.kosta.csm.vo.OrderList_ProductVO_2;
import com.kosta.csm.vo.StStockVO;

public interface Hq_IOrderListDAO {
	
	public int approvalListCount();
	
	public List<OrderList_MemberVO> indexApprovalList(CriteriaIndex cri);
	
	public int indexApprovalListCount();

	/////////////////////////////////////////////////////////////////////////
	
	public void updateStates(int o_Num);
	
	public void orderDelete(int o_Num);
	
	public List<OrderListVO> getCodeAmount(@Param("m_Id") String m_Id, @Param("o_Date") String o_Date);
	
	
	
	public void cancelStates(@Param("m_Id") String m_Id, @Param("o_Date") String o_Date);
	
	public int completeListCount();

	public List<OrderList_MemberVO> orderApprovalList(Criteria cri);//새로운 발주 리스트
	
	public List<OrderList_ProductVO_2> orderApprovalDetail(@Param("m_Id") String m_Id, @Param("o_Date") String o_Date);
	
	public List<OrderList_MemberVO> orderCompleteList(Criteria cri);

	public List<OrderList_ProductVO_2> orderCompleteDetail(@Param("m_Id") String m_Id, @Param("o_Date") String o_Date);

	public int orderCompleteListCount();

	public List<OrderList_MemberVO> orderFinishList(Criteria cri);

	public int orderFinishListCount();

	public List<OrderList_ProductVO_2> orderFinishListDetail(@Param("m_Id") String m_Id, @Param("o_Date") String o_Date);

	public void finishStStock(StStockVO stStockVO);

	public void finishHqStock(StStockVO stStockVO);

	public void ostateFinish(int o_Num);

	public void ostateApproval(int o_Num);

	public List<StStockVO> getCodeAmount2(@Param("m_Id") String m_Id, @Param("o_Date") String o_Date);

	public List<OrderListVO> getCodeHp_Code(@Param("m_Id") String m_Id, @Param("o_Date") String o_Date);


	

	

	

	
}
