package com.kosta.csm.vo;

public class WorkingTimeMore {
	int wt_Num;;// --근무번호
	int e_Num;//--근무직원 번호
	String e_Name;//--근무직원 이름
	String wt_StartTime;//--출근날짜
	String wt_EndTime;// --퇴근날짜
	String m_Id;// --근무매장 번호
	String m_Store;// --근무매장 이름
	String e_Phone;// --근무직원 연락처
	int e_Pay;//급여
	String e_Position;//급여
	
	 
	public String getE_Position() {
		return e_Position;
	}
	public void setE_Position(String e_Position) {
		this.e_Position = e_Position;
	}
	public int getE_Pay() {
		return e_Pay;
	}
	public void setE_Pay(int e_Pay) {
		this.e_Pay = e_Pay;
	}
	public String getE_Name() {
		return e_Name;
	}
	public String getM_Id() {
		return m_Id;
	}
	public void setM_Id(String m_Id) {
		this.m_Id = m_Id;
	}
	public String getM_Store() {
		return m_Store;
	}
	public void setM_Store(String m_Store) {
		this.m_Store = m_Store;
	}
	public String getE_Phone() {
		return e_Phone;
	}
	public void setE_Phone(String e_Phone) {
		this.e_Phone = e_Phone;
	}
	public void setE_Name(String e_Name) {
		this.e_Name = e_Name;
	}
	public int getWt_Num() {
		return wt_Num;
	}
	public void setWt_Num(int wt_Num) {
		this.wt_Num = wt_Num;
	}
	public int getE_Num() {
		return e_Num;
	}
	public void setE_Num(int e_Num) {
		this.e_Num = e_Num;
	}
	public String getWt_StartTime() {
		return wt_StartTime;
	}
	public void setWt_StartTime(String wt_StartTime) {
		this.wt_StartTime = wt_StartTime;
	}
	public String getWt_EndTime() {
		return wt_EndTime;
	}
	public void setWt_EndTime(String wt_EndTime) {
		this.wt_EndTime = wt_EndTime;
	}
}
