package com.kosta.csm.vo;

public class CategoryStatusVO {
	private String hp_Category;
	private int totalAmount;
	private String hp_Name;
	
	
	public String getHp_Name() {
		return hp_Name;
	}
	public void setHp_Name(String hp_Name) {
		this.hp_Name = hp_Name;
	}
	public String getHp_Category() {
		return hp_Category;
	}
	public void setHp_Category(String hp_Category) {
		this.hp_Category = hp_Category;
	}
	public int getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(int totalAmount) {
		this.totalAmount = totalAmount;
	}
	
	
}
