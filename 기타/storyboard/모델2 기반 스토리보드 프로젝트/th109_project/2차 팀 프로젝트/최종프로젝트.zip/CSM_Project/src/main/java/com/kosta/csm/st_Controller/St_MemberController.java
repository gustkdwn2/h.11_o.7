package com.kosta.csm.st_Controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.kosta.csm.st_Service.St_IMemberService;
import com.kosta.csm.vo.MemberVO;

@Controller
@RequestMapping("/st")
public class St_MemberController {

	@Autowired
	private St_IMemberService service;

	

	// 회원정보 수정

	@RequestMapping(value = "/member/modify", method = RequestMethod.GET)
	public String modifyGet() {

		return "st_aside.member.modify";
	}

	@RequestMapping(value = "/member/modify", method = RequestMethod.POST)
	public String modifyPost(HttpServletRequest request, Model model) {

		return service.check(request, model);
	}

	@RequestMapping(value = "/member/memberModify", method = RequestMethod.GET)
	public String memberModifyGet(Model model) {
		System.out.println("memberModify Get");
		MemberVO vo = service.searchById();
		String[] m_Emails = vo.getM_Email().split("@");
		model.addAttribute("vo", vo);
		model.addAttribute("m_Emails", m_Emails);
		return "st_aside.member.memberModify";
	}

	@RequestMapping(value = "/member/memberModify", method = RequestMethod.POST)
	public String memberModifyPost(MemberVO vo, @RequestParam("m_Email1") String m_Email1,
			@RequestParam("m_Email2") String m_Email2) {
		System.out.println("memberModify Post");
		System.out.println(vo.getM_Id());
		vo.setM_Email(m_Email1 + "@" + m_Email2);
		return service.memberModify(vo);
	}

	@RequestMapping(value = "/member/pwdModify", method = RequestMethod.GET)
	public String pwdModifyGet(Model model) {
		System.out.println("pwdModify Get");
		model.addAttribute("pwd", service.check());
		return "st_aside.member.pwdModify";
	}

	@RequestMapping(value = "/member/pwdModify", method = RequestMethod.POST)
	public String pwdModifyPost(HttpServletRequest request, MemberVO vo) {
		System.out.println("pwdModify Post");
		System.out.println(vo.getM_Id());
		System.out.println(vo.getM_Pwd());
		return service.pwdModify(request, vo);
	}
}
