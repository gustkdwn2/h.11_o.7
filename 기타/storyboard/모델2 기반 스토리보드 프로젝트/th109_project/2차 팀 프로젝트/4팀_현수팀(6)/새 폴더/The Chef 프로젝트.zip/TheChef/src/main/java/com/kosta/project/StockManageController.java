package com.kosta.project;

import java.security.Principal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.kosta.project.dao.IAdmin_farm_orderDao;
import com.kosta.project.dao.IDealDao;
import com.kosta.project.dao.IStockManageDAO;
import com.kosta.project.dto.AdminMartOrderDTO;
import com.kosta.project.dto.RTPorderDTO;
import com.kosta.project.dto.StockManageDTO;

@Controller
public class StockManageController {

	@Autowired
	SqlSession sqlsession;
	
	@RequestMapping("/stockManage")
	public String stockManage(HttpServletRequest request,Model model) {
		System.out.println("stockManage()");
		
		
		IDealDao dao2 = sqlsession.getMapper(IDealDao.class);
		
        Date sysdate = dao2.findMonth();
        System.out.println("sysdate : " + sysdate);
       
        //SimpleDateFormat transFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        //Date타입을 String 타입으로 바꿔서 현재 년과 월을 구하기
        SimpleDateFormat transFormat = new SimpleDateFormat("MM");
        String month = transFormat.format(sysdate);
       
        transFormat = new SimpleDateFormat("yyyy");
        String year = transFormat.format(sysdate);
        
        transFormat = new SimpleDateFormat("dd");
        String day = transFormat.format(sysdate);
       
        System.out.println("현재 월 : " + month);//06
        System.out.println("현재 년 : " + year);//2016
        
        model.addAttribute("current_date",year + "-" + month + "-" + day);
           
		List<StockManageDTO> onePage_selectStockList = new ArrayList<StockManageDTO>();
		
		/*페이징처리*/
		int pageSize = 4;// 한페이지에 나오는 최대 데이터 갯수
		int allCount = 0; // 선택한 데이터 총 갯수
		int count = 0;//선택된 한페이지에 있는 데이터 총 갯수
		String pageNum = request.getParameter("pageNum"); // 페이지번호
		 //기본값 1로 get방식으로 받음
		if (pageNum == null) { // null인경우 1로 지정
	         pageNum = "1";
	    }
		int currentPage = Integer.parseInt(pageNum); // currentPage : 현재 보고 있는 페이지
		int startRow = (currentPage * pageSize) - (pageSize-1); // 현재페이지의 시작행
	    int endRow = currentPage * pageSize; // 현재페이지의 끝행
	    
		System.out.println("pageNum : " + pageNum);
		System.out.println("currentPage : " + currentPage);
		System.out.println("startRow : " + startRow);
		System.out.println("endRow : " + endRow);
		
		//////////////////////////////////////////////////////////////////////////
		Map map = new HashMap(); // collection
		map.put("startRow", startRow);
		map.put("endRow", endRow);
		/////////////////////////////////////////////////////////////////////////

		IStockManageDAO dao = sqlsession.getMapper(IStockManageDAO.class);
		allCount = dao.CountAllStockList(); //전체갯수
		onePage_selectStockList = dao.onePage_selectStockList(map);
		count = onePage_selectStockList.size(); // 한페이지크기
		
		System.out.println("allCount : "+allCount);
		System.out.println("count : "+count);
		
		model.addAttribute("stockList",onePage_selectStockList);
		model.addAttribute("count", new Integer(count));
	    model.addAttribute("currentPage", new Integer(currentPage));
	    model.addAttribute("allCount", new Integer(allCount));
	    model.addAttribute("pageSize", new Integer(pageSize));
		
	    return "back.storeManage.stockManage";
	}
	/////////////////////////////////////////////
	@RequestMapping("/stockOk")//상품확인 버튼 누르면 재고에 추가,orderManage.jsp에서 옴
	public String stockOk(HttpServletRequest request){
		//update admin_farmer_Order 'Y'에서 ok로 바꾸기
		IAdmin_farm_orderDao dao = sqlsession.getMapper(IAdmin_farm_orderDao.class);
		dao.updateStockOk(request.getParameter("seq_ordernum"));
		
		//insert or update stockManage
		String farm_Pid=request.getParameter("farm_Pid"); // 상품아이디
		IStockManageDAO sdao = sqlsession.getMapper(IStockManageDAO.class);
		int count = sdao.checkPid(farm_Pid);
		
		StockManageDTO sdto = new StockManageDTO();
		sdto.setProduct_from(request.getParameter("farm_id"));
		sdto.setProduct_id(farm_Pid);
		sdto.setProduct_name(request.getParameter("farm_Pname"));
		sdto.setproduct_totalCount(Integer.parseInt(request.getParameter("orderCount")));//구입 수량
		sdto.setProduct_category(request.getParameter("farm_Pcategory"));
		//farmInfo 테이블에서 상품 번호를 이용해 제품 하나당 가격을 뽑아서 재고 테이블에 insert 해준다.
		sdto.setProduct_price(sdao.findFarmPrice(farm_Pid));//해당 상품 번호의 개당 가격 set
		sdto.setProduct_unit(request.getParameter("farm_unit"));
		sdto.setProduct_status("1"); // 골라담기 재고인 경우 product_status에 1넣기
		if(count==0){
			//insert
			sdao.insertStock(sdto);
		}else{
			//update
			sdao.updateStockPlus(sdto);
		}
		
		return "redirect:/orderManage"; 
	}
	////귀농인들 이외의 상인, 상점과 거래한 물품 재고에 insert하기
	@RequestMapping("/stockMart")//stockManage.jsp에서 재료 재고 등록하기 버튼을 클릭 시 이쪽으로 옴
	public String stockMart(HttpServletRequest request, Principal principal){
		
		//insert or update stockManage
		IStockManageDAO sdao = sqlsession.getMapper(IStockManageDAO.class);
		
		StockManageDTO sdto = new StockManageDTO();
		sdto.setProduct_from(request.getParameter("product_from"));//거래처
		sdto.setProduct_name(request.getParameter("product_name"));//상품명
		sdto.setproduct_totalCount(Integer.parseInt(request.getParameter("count")));
		sdto.setProduct_unit(request.getParameter("unit"));
		sdto.setProduct_category(request.getParameter("category"));//카테고리
		sdto.setProduct_price(Integer.parseInt(request.getParameter("price"))/Integer.parseInt(request.getParameter("count")));//개당 가격을 set해준다.
		sdto.setProduct_status("2"); // 귀농인 이외의 상인이나 상점과 거래시 상태 2이다.
		
		//거래처, 상품명, 카테고리가 모두 같은 거를 또 한번 등록 했을 경우, 재고 테이블에 insert가 아니라 update
		int count = sdao.checkMartPid(request.getParameter("product_from"), request.getParameter("product_name"), request.getParameter("category"));
		
		//AdminMartOrder table에 insert 해주기
		AdminMartOrderDTO mdto = new AdminMartOrderDTO();
		mdto.setAdmin_id(principal.getName());
		mdto.setMart_name(request.getParameter("product_from"));
		mdto.setMart_orderCount(Integer.parseInt(request.getParameter("count")));
		mdto.setMart_orderPrice(Integer.parseInt(request.getParameter("price")));//결제 총 금액
		mdto.setMart_Pname(request.getParameter("product_name"));
		mdto.setMart_unit(request.getParameter("unit"));
		mdto.setMart_category(request.getParameter("category"));
		
		if(count==0){
			//insert
			sdao.insertStockMart(sdto);//재고 테이블에 insert 해주기
			sdao.insertAdminMartOrder(mdto);
		}else{//거래처, 상품명, 카테고리가 모두 같은 거를 또 한번 등록 했을 경우, 재고 테이블에 insert가 아니라 update
			//update
			sdao.updateStockMart(sdto);
			sdao.insertAdminMartOrder2(mdto);//거래처, 상품명, 카테고리가 모두 같은 거 찾아서 product_id를 재고테이블에서 찾고 AdminMartOrder테이블에 insert
		}
		
		
		
		return "redirect:/stockManage"; 
	}
	
	/*@RequestMapping("/recipeProductStockRegister")
	public String recipeProductStockRegister(Model model){
		System.out.println("recipeProductStockRegister");
		IStockManageDAO dao = sqlsession.getMapper(IStockManageDAO.class);
		model.addAttribute("RTPList",dao.selectRTPList());
		return "back.storeManage.recipeProductStockRegister";
	}*/
	
	//레시피/테마 부분 재고에 담는 부분
	@RequestMapping("insertRTPStock")
	public String insertRTPStock(StockManageDTO dto,HttpServletRequest request){
		System.out.println("insertRTPStock");
		IStockManageDAO sdao = sqlsession.getMapper(IStockManageDAO.class);
		
		//레시피테마 재고요청
		RTPorderDTO rtpDto = new RTPorderDTO();
		rtpDto.setRtp_count(Integer.parseInt(request.getParameter("product_totalCount")));
		rtpDto.setRtp_no(request.getParameter("product_id"));
		
		int p_price = Integer.parseInt(request.getParameter("p_price"));
		rtpDto.setRtp_totalPrice((int)(Integer.parseInt(request.getParameter("product_totalCount"))*p_price*0.5));
		System.out.println("get"+rtpDto.getRtp_totalPrice());
		sdao.insertRTPprice(rtpDto);
		
		//재고 테이블 insert or update stockManage
		int count = sdao.checkPid(dto.getProduct_id()); // 상품id로 재고테이블에 있는지없는지 확인하기
		 // 레시피테마 재고인 경우 product_status에 2넣기
		if(count==0){
			//insert - 재고테이블에 없으면
			sdao.insertStock(dto);
		}else{
			//update - 재고테이블에 있으면
			sdao.updateStockPlus(dto);
		}
		
		return "redirect:/recipeProductStockRegister";
	}
	
	//재고 수정
	/*@RequestMapping("updateAdminOrder")
	public String updateRTPAdminOrder(StockManageDTO dto){
		System.out.println("updateRTPAdminOrder()");
		
		IStockManageDAO sdao = sqlsession.getMapper(IStockManageDAO.class);
		sdao.modifyStock(dto);
		
		return "redirect:/stockManage";
	}*/
	
	@RequestMapping("updateComplete")
	public String updateStock(HttpServletRequest request){
		System.out.println("updateStock()");
		
		IStockManageDAO sdao = sqlsession.getMapper(IStockManageDAO.class);
		StockManageDTO dto = new StockManageDTO();
		
		String product_category = request.getParameter("product_category");
		String product_id = request.getParameter("product_id");
		int product_totalCount = Integer.parseInt(request.getParameter("product_totalCount"));
		String product_unit = request.getParameter("product_unit");
		String product_name = request.getParameter("product_name");
		int product_price = Integer.parseInt(request.getParameter("product_price"));
		
		dto.setProduct_category(product_category);
		dto.setProduct_id(product_id);
		dto.setproduct_totalCount(product_totalCount);
		dto.setProduct_unit(product_unit);
		dto.setProduct_name(product_name);
		dto.setProduct_price(product_price);
		
		sdao.updateStock(dto);
		
		return "redirect:/stockManage";
	}
	
	//재고 삭제
	@RequestMapping("deleteAdminOrder")
	public String deleteRTPAdminOrder(HttpServletRequest request){
		System.out.println("deleteRTPAdminOrder()");
		String product_id = request.getParameter("product_id");
		System.out.println("product_id : "+product_id);
		IStockManageDAO sdao = sqlsession.getMapper(IStockManageDAO.class);
		sdao.deleteAdminOrder(product_id);
		return "redirect:/stockManage";
	}
}
