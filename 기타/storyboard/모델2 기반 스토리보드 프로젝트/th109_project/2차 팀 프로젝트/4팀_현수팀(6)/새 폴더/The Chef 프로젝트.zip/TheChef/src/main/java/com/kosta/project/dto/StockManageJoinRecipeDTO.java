package com.kosta.project.dto;

public class StockManageJoinRecipeDTO {
	String product_id, product_category, product_name, product_from, product_status;
	int product_totalCount, product_price, priceIngredients;
	String product_regdate, product_unit;
	String p_no, unit, farm_name;
	int dose;
	
	public StockManageJoinRecipeDTO() {}

	public StockManageJoinRecipeDTO(String product_id, String product_category, String product_name,
			String product_from, String product_status, int product_totalCount, int product_price, int priceIngredients,
			String product_regdate, String product_unit, String p_no, String unit, String farm_name, int dose) {
		super();
		this.product_id = product_id;
		this.product_category = product_category;
		this.product_name = product_name;
		this.product_from = product_from;
		this.product_status = product_status;
		this.product_totalCount = product_totalCount;
		this.product_price = product_price;
		this.priceIngredients = priceIngredients;
		this.product_regdate = product_regdate;
		this.product_unit = product_unit;
		this.p_no = p_no;
		this.unit = unit;
		this.farm_name = farm_name;
		this.dose = dose;
	}



	public String getProduct_id() {
		return product_id;
	}

	public void setProduct_id(String product_id) {
		this.product_id = product_id;
	}

	public String getProduct_category() {
		return product_category;
	}

	public void setProduct_category(String product_category) {
		this.product_category = product_category;
	}

	public String getProduct_name() {
		return product_name;
	}

	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}

	public String getProduct_from() {
		return product_from;
	}

	public void setProduct_from(String product_from) {
		this.product_from = product_from;
	}

	public String getProduct_status() {
		return product_status;
	}

	public void setProduct_status(String product_status) {
		this.product_status = product_status;
	}

	public int getProduct_price() {
		return product_price;
	}

	public void setProduct_price(int product_price) {
		this.product_price = product_price;
	}

	public String getProduct_regdate() {
		return product_regdate;
	}

	public void setProduct_regdate(String product_regdate) {
		this.product_regdate = product_regdate;
	}

	public String getProduct_unit() {
		return product_unit;
	}

	public void setProduct_unit(String product_unit) {
		this.product_unit = product_unit;
	}

	public String getP_no() {
		return p_no;
	}

	public void setP_no(String p_no) {
		this.p_no = p_no;
	}

	public String getUnit() {
		return unit;
	}

	public void setUnit(String unit) {
		this.unit = unit;
	}

	public String getFarm_name() {
		return farm_name;
	}

	public void setFarm_name(String farm_name) {
		this.farm_name = farm_name;
	}

	public int getDose() {
		return dose;
	}

	public void setDose(int dose) {
		this.dose = dose;
	}

	public int getProduct_totalCount() {
		return product_totalCount;
	}

	public void setProduct_totalCount(int product_totalCount) {
		this.product_totalCount = product_totalCount;
	}

	public int getPriceIngredients() {
		return priceIngredients;
	}

	public void setPriceIngredients(int priceIngredients) {
		this.priceIngredients = priceIngredients;
	}

	
	
	
}
