package com.kosta.project.dto;

public class LikeDTO {
   private String k_no;
   private int rownum;
   
   public LikeDTO() {}

   public LikeDTO(String k_no, int rownum) {
      this.k_no = k_no;
      this.rownum = rownum;
   }

   public String getK_no() {
      return k_no;
   }

   public void setK_no(String k_no) {
      this.k_no = k_no;
   }

   public int getRownum() {
      return rownum;
   }

   public void setRownum(int rownum) {
      this.rownum = rownum;
   }
   
}