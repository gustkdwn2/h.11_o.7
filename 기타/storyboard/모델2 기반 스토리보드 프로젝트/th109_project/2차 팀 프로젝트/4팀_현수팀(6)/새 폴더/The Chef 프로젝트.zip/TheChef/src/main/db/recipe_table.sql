drop table recipe_table;
create table recipe_table(
	product_id varchar2(1000),
	product_name varchar2(1000),
	p_no VARCHAR2(1000),
	dose NUMBER,
	unit varchar2(50)
);
