package com.kosta.project.dto;

public class EmployeeDTO {
	int e_num;// number primary key, -- 직원코드
	String e_name;// varchar2(100),-- 직원명
	int ep_num;// number, -- 직책번호
	String e_phone;// varchar2(100), --연락처
	String e_account;// varchar2(100), -- 계좌번호
	String e_hiredate;// varchar2(100) -- 입사일
	String ep_name;// varchar2(100) -- 직원직책
	int s_salary;// number --직원 월급
	String ep_responsibility;// 하는일 상세

	public String getEp_responsibility() {
		return ep_responsibility;
	}

	public void setEp_responsibility(String ep_responsibility) {
		this.ep_responsibility = ep_responsibility;
	}

	public int getS_salary() {
		return s_salary;
	}

	public void setS_salary(int s_salary) {
		this.s_salary = s_salary;
	}

	public String getEp_name() {
		return ep_name;
	}

	public void setEp_name(String ep_name) {
		this.ep_name = ep_name;
	}

	public int getE_num() {
		return e_num;
	}

	public void setE_num(int e_num) {
		this.e_num = e_num;
	}

	public String getE_name() {
		return e_name;
	}

	public void setE_name(String e_name) {
		this.e_name = e_name;
	}

	public int getEp_num() {
		return ep_num;
	}

	public void setEp_num(int ep_num) {
		this.ep_num = ep_num;
	}

	public String getE_phone() {
		return e_phone;
	}

	public void setE_phone(String e_phone) {
		this.e_phone = e_phone;
	}

	public String getE_account() {
		return e_account;
	}

	public void setE_account(String e_account) {
		this.e_account = e_account;
	}

	public String getE_hiredate() {
		return e_hiredate;
	}

	public void setE_hiredate(String e_hiredate) {
		this.e_hiredate = e_hiredate;
	}
}
