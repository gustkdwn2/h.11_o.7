drop table  admin_mart_Order;
-- 관리자가 마트에 주문할 때 테이블
create table admin_mart_Order(
   mart_name varchar2(100), --마트 이름
   mart_Pid varchar2(1000), --마트에서 사려는 상품 번호
   mart_Pname varchar2(100), --마트에서 사려는 상품 이름
   mart_orderCount number, --구입 수량
   mart_orderPrice number, -- 결제 총 금액
   mart_unit varchar2(50), --상품 단위
   mart_orderDate date default sysdate, --마트에서 구입 일시
   admin_id varchar2(100) --요청한 관리자
);
delete from admin_mart_Order;
select * from admin_mart_Order;

