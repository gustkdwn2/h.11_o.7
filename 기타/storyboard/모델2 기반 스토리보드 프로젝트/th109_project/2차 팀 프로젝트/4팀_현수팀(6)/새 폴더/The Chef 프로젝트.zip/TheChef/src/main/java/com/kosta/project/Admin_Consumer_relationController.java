package com.kosta.project;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.kosta.project.dao.IAdmin_Consumer_relationDao;
import com.kosta.project.dto.CheckOutDTO;
import com.kosta.project.dto.DeliveryToCustomerDTO;

@Controller
public class Admin_Consumer_relationController {

	@Autowired
	SqlSession sqlSession;

	// 관리자가 소비자가 구매한 내역을 불러오는 페이지
	@RequestMapping(value = "/from_admin_to_consumer_productOrder")
	public String productOrder(Locale locale, Model model) {
		System.out.println("상품발주하기 클릭 후 진입");
		IAdmin_Consumer_relationDao dao = sqlSession.getMapper(IAdmin_Consumer_relationDao.class);

		/*
		 * Calendar calendar = Calendar.getInstance(); SimpleDateFormat
		 * dateFormat = new SimpleDateFormat("yyyy-MM-dd"); String fname =
		 * dateFormat.format(calendar.getTime());
		 */
		CheckOutDTO dto = new CheckOutDTO();
		/*
		 * dto.setReg_date(fname); System.out.println("fname"+fname);
		 */

		List check_out = dao.check_out_all(dto);
		List delivery = dao.delivery_all();

		model.addAttribute("check_out", check_out);
		model.addAttribute("delivery", delivery);

		/* model.addAttribute("fname",fname); */

		return "back.saleManage_consumer.productOrder";
	}

	// 관리자가 발송하기 버튼을 클릭시 checkout테이블 상태 바뀌어야되고 발송태이블 상태 바뀌어야함
	@RequestMapping(value = "/productOrderComplete")
	public String productOrderComplete(HttpServletRequest request) {
		System.out.println("productOrderComplete");
		IAdmin_Consumer_relationDao dao = sqlSession.getMapper(IAdmin_Consumer_relationDao.class);
		// dao.checkout_OrderAccept(아마도 c_ordernum?); // checkout table에서 주문한
		// 녀석의 상태 2로 바꾸는로직
		// dao.delivery_to_customerAccept(주문번호?혹은 고유한 무엇?); //발송테이블의 상태를 2로 바꾸는
		// 로직
		// dao.?????? // 재고가 빠져나가게 하기 위한 로직
		int orderNum = Integer.parseInt(request.getParameter("ordernum"));
		System.out.println("orderNum : " + orderNum);// 주문번호 가져오기

		dao.updateCheck_Out(orderNum);// 배송상태 수정(구매 테이블)
		dao.updateDelivery(orderNum);// 배송상태 수정(배송 테이블)

		// 주문번호에 해당하는 상품 번호 가지고 오기
		List<CheckOutDTO> c_no = dao.findCnoCount(orderNum);

		for (int i = 0; i < c_no.size(); i++) {
			// System.out.println(c_no.get(i).getC_no());//상품 번호 다 뽑아내기
			dao.updateStock(c_no.get(i).getC_no(), c_no.get(i).getCount());
		}

		// stockManage(재고테이블)에서 재고 수를 빼주어야 한다.
		// dao.updateStock(dto);

		return "redirect:/from_admin_to_consumer_productOrder";
	}

	//검색하기 버튼 눌렀을 때 		
	@RequestMapping(value="/productOrderSearch")
	public String productOrderSearch(HttpServletRequest request, Model model){
		
		System.out.println("productOrderSearch");
		System.out.println("orderStatus:"+request.getParameter("orderStatus"));
		System.out.println("searchby:"+request.getParameter("searchby"));
		System.out.println("searchby_value:"+request.getParameter("searchby_value"));
		
		IAdmin_Consumer_relationDao dao = sqlSession.getMapper(IAdmin_Consumer_relationDao.class);
		
		HashMap<String, Object> map = new HashMap<String, Object>();
		
		String orderStatus = request.getParameter("orderStatus");
		if( orderStatus!=""){
			if(orderStatus.equals("ready")){
				map.put("orderStatus", 1);
			}else if(orderStatus.equals("deleivering")){
				map.put("orderStatus", 2);
			}else if(orderStatus.equals("complete")){
				map.put("orderStatus", 3);
			}
		}else map.put("orderStatus",request.getParameter("orderStatus"));
		
		String searchby = request.getParameter("searchby");
		if( searchby !=""){
			map.put("searchby", request.getParameter("searchby_value"));
		}else map.put("searchby", searchby);
		
		map.put("dataFrom", request.getParameter("dataFrom"));
		map.put("dataTo", request.getParameter("dataTo"));
		
		
		int pg = 1;
		String strPg = request.getParameter("pg");
		if (strPg != null) {
			pg = Integer.parseInt(strPg);
		}
		int rowSize = 10;
		int start = (pg * rowSize) - (rowSize - 1);
		int end = pg * rowSize;
		
		map.put("start", start);
		map.put("end", end);
		
		
		List<DeliveryToCustomerDTO> list =dao.search(map);
		int total = dao.searchcount(map);
		
		
//		List<NoticeBoardDto> list =dao.backpage_search_bytitle(map);
//		int total = list.size(); // 아이디어 번뜩였는데? ㅎ

		System.out.println("total.size:"+total);
		
		int allPage = (int) Math.ceil(total / (double) rowSize); // 페이지수
		
		// int totalPage = total/rowSize + (total%rowSize==0?0:1);

		int block = 5; // 한페이지에 보여줄 범위 << [1] [2] [3] [4] [5] >>
		int fromPage = ((pg - 1) / block * block) + 1; // 보여줄 페이지의 시작
		// ((1-1)/10*10)
		int toPage = ((pg - 1) / block * block) + block; // 보여줄 페이지의 끝
		if (toPage > allPage) {
			toPage = allPage; 
		}
		
		Calendar calendar = Calendar.getInstance();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String fname = dateFormat.format(calendar.getTime());
        
        int newordercount = dao.newordercount();	//신규주문건수 표현하려고 추가
        
//////////paging할때 값물고가게 하려고 추가해준부분///////////////
        model.addAttribute("dataFrom", request.getParameter("dataFrom"));
		model.addAttribute("dataTo", request.getParameter("dataTo"));
		model.addAttribute("orderStatus", request.getParameter("orderStatus"));
		model.addAttribute("searchby", request.getParameter("searchby"));
		model.addAttribute("searchby_value", request.getParameter("searchby_value"));
        
////////////////////////////////////////////////////////////////
        
        
        if(request.getParameter("id") !=null && request.getParameter("d_orderNum") !=null){
        	
        	System.out.println("id:"+request.getParameter("id")+"d_orderNum:"+request.getParameter("d_orderNum"));
        	
        	IAdmin_Consumer_relationDao dao2 = sqlSession.getMapper(IAdmin_Consumer_relationDao.class);
	        String orderNum = request.getParameter("d_orderNum");
	        
	        List<CheckOutDTO> check_out = dao.check_out_by(orderNum);
			List<DeliveryToCustomerDTO> delivery = dao.delivery_by(orderNum);
	
			model.addAttribute("check_out", check_out);
			model.addAttribute("delivery", delivery); 
        }
        
        model.addAttribute("newordercount",newordercount);
		model.addAttribute("fname",fname);
		model.addAttribute("list", list);
		model.addAttribute("pg", pg);
		model.addAttribute("allPage", allPage);
		model.addAttribute("block", block);
		model.addAttribute("fromPage", fromPage);
		model.addAttribute("toPage", toPage);

		return "back.saleManage.sendManage";
	}
}