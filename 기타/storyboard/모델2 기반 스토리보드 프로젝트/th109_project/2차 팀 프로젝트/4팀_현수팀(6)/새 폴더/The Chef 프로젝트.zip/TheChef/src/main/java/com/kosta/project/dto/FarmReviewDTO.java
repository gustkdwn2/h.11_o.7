package com.kosta.project.dto;

public class FarmReviewDTO {
   private String fr_no;
   private String id;
   private String reg_date;
   private int score;
   private String fr_review;
   private String fr_title;
   
   public FarmReviewDTO() {}
   
   public FarmReviewDTO(String fr_no, String id, String reg_date, int score, String fr_review, String fr_title) {
      this.fr_no = fr_no;
      this.id = id;
      this.reg_date = reg_date;
      this.score = score;
      this.fr_review = fr_review;
      this.fr_title = fr_title;
   }

   public String getFr_no() {
      return fr_no;
   }
   public void setFr_no(String fr_no) {
      this.fr_no = fr_no;
   }
   public String getId() {
      return id;
   }
   public void setId(String id) {
      this.id = id;
   }
   public String getReg_date() {
      return reg_date;
   }
   public void setReg_date(String reg_date) {
      this.reg_date = reg_date;
   }
   public int getScore() {
      return score;
   }
   public void setScore(int score) {
      this.score = score;
   }
   public String getFr_review() {
      return fr_review;
   }
   public void setFr_review(String fr_review) {
      this.fr_review = fr_review;
   }
   public String getFr_title() {
      return fr_title;
   }
   public void setFr_title(String fr_title) {
      this.fr_title = fr_title;
   }
   
}