package com.kosta.project.dao;

import java.util.List;

import com.kosta.project.dto.EmployeeDTO;
import com.kosta.project.dto.EmployeePositionDTO;

//관련 테이블 employee ,  employee_position  , salary
public interface IEmployeeDAO {

	void insertEmployee(EmployeeDTO vo);
	void insertSalaryOfE_num(EmployeeDTO vo);
	void addEmployee_Position(EmployeePositionDTO vo);
	
	void removeEmployee(Integer e_num);
	void deleteEmployee_Position(Integer e_num);

	List<EmployeeDTO> getEmployee();
	List<EmployeeDTO> getEmployeeSearchEP_name(String ep_name);
	List<EmployeeDTO> getEmployeeSearchE_num(String e_num);
	List<EmployeeDTO> getEmployeeSearchE_name(String e_name);
	List<EmployeePositionDTO> getEmployeePosition();
	EmployeePositionDTO getEmployeePositionSearchEp_num(Integer ep_num);
	Integer getSalaryCntOfSameDateAndSameE_num(EmployeeDTO vo);
	Integer getMaxE_num();
	Integer getSearchEp_numFromEmployee(Integer ep_num);
	Integer getSearchEp_salaryFromEp_num(Integer ep_num);
	
	void updateEmployee(EmployeeDTO vo);
	void updateSalaryOfE_num(EmployeeDTO vo);//직원번호 를 통해 오늘(년/월)로 월급 기록수정
	void modifyEmployee_Position(EmployeePositionDTO vo);
	void updateSalaryE_name(EmployeeDTO vo);

	}
