package com.kosta.project.dto;

public class SalaryDTO {
   int s_num;//number primary key
   int e_num;// number     
   int s_salary;// number 
   String s_date;// varchar2(50)
   String e_name;// 이름
   public int getS_num() {
      return s_num;
   }
   public void setS_num(int s_num) {
      this.s_num = s_num;
   }
   public int getE_num() {
      return e_num;
   }
   public void setE_num(int e_num) {
      this.e_num = e_num;
   }
   public int getS_salary() {
      return s_salary;
   }
   public void setS_salary(int s_salary) {
      this.s_salary = s_salary;
   }
   public String getS_date() {
      return s_date;
   }
   public void setS_date(String s_date) {
      this.s_date = s_date;
   }
   public String getE_name() {
      return e_name;
   }
   public void setE_name(String e_name) {
      this.e_name = e_name;
   }
   
}