select * from recipe_review;

drop table recipe_review;
create table recipe_review (
	r_no varchar2(100) not null,
	id varchar2(1000) not null,
	reg_date date default sysdate,
	score number,
	r_review varchar2(1000),
	r_title varchar2(1000)
);


select to_char(sysdate, 'yyyy-mm-dd') from dual;

--r_no : 리뷰할 상품
--id : 리뷰 등록한 id
--reg_date : 리뷰 등록한 시간
--score : 평점
--r_review : 리뷰 내용

create table farm_review (
   fr_no varchar2(100) not null,
   id varchar2(1000) not null,
   reg_date date default sysdate,
   score number,
   fr_review varchar2(1000),
   fr_title varchar2(1000)
);