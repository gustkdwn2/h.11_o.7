package com.kosta.project.dto;

public class AdminOrderDTO {
	 String a_date;
     long a_price;   
     String a_where;
     int a_count;
     int a_pcount;
     String a_kind;
     String a_unit;
     String a_name;
	public String getA_date() {
		return a_date;
	}
	public void setA_date(String a_date) {
		this.a_date = a_date;
	}
	public long getA_price() {
		return a_price;
	}
	public void setA_price(long a_price) {
		this.a_price = a_price;
	}
	public String getA_where() {
		return a_where;
	}
	public void setA_where(String a_where) {
		this.a_where = a_where;
	}
	public int getA_count() {
		return a_count;
	}
	public void setA_count(int a_count) {
		this.a_count = a_count;
	}
	public int getA_pcount() {
		return a_pcount;
	}
	public void setA_pcount(int a_pcount) {
		this.a_pcount = a_pcount;
	}
	public String getA_kind() {
		return a_kind;
	}
	public void setA_kind(String a_kind) {
		this.a_kind = a_kind;
	}
	public String getA_unit() {
		return a_unit;
	}
	public void setA_unit(String a_unit) {
		this.a_unit = a_unit;
	}
	public String getA_name() {
		return a_name;
	}
	public void setA_name(String a_name) {
		this.a_name = a_name;
	}
     
}
