package com.kosta.project.dao;

import java.util.List;
import java.util.Map;

import com.kosta.project.dto.SellerDTO;
import com.kosta.project.dto.SellerJoinFarmNameDTO;

public interface ISellerDao {
	//등록
	public void insertSellerProduct(SellerDTO dto);
	//수정 내용 불러오기
	public SellerDTO updateSellerProductView(String farm_Pid);
	//수정하기
	public void updateSellerProduct(SellerDTO dto);
	//삭제하기
	public void deleteSellerProduct(String farm_Pid);
	//상품페이지 총 데이터 갯수
	public int countSellerInfo(String farm_id);
	//한페이지에 표시될 데이터    
	public List<SellerDTO> selectSellerInfo(Map map);
	//전체 선택
	public List<SellerJoinFarmNameDTO> selectAll();
	//물건재고수정
	public void updateProductCount(Map map);
	//귀농인이 같은 제품을 다시 올렸을 때 기존 제품을 update
	public void updateSellerProduct2(SellerDTO dto);
	//귀농인이 해당상품을 이미 올렸는지 여부 확인
	public List<SellerDTO> alreadyUploadFarmInfo(SellerDTO dto);
}
