create table pay_ingredients (
	id varchar2(1000) not null, --구입한 사람의 id
	p_no varchar2(1000), --레시피 번호
	product_id varchar2(1000), --재료 번호
	d_orderNum number(30), --발주 번호
	constraint fk_ingredients_product_id foreign key(product_id) references stockManage(product_id) ON DELETE CASCADE,
	constraint fk_ingredients_p_no foreign key(p_no) references recipe_theme_Products(p_no) ON DELETE CASCADE,
	constraint fk_ingredients_d_orderNum foreign key(d_orderNum) references delivery_to_customer(d_orderNum) ON DELETE CASCADE
);
drop table pay_ingredients;
select * from STOCKMANAGE;
select * from RECIPE_TABLE; --dose --p_no
select * from check_out; --count d_orderNum  c_orderNum --count
delete PAY_INGREDIENTS;
delete from stockManage where product_id = (select product_id from stockManage where product_totalCount <= 0)
select distinct p.product_id, r.dose*c.count from pay_ingredients p join recipe_table r on p.p_no = r.p_no join check_out c on c.c_orderNum = p.d_orderNum 
drop table pay_ingredients;

select * from pay_ingredients;
select * from check_out;
select * from stockManage;
insert into pay_ingredients(id, p_no, product_id, d_orderNum) values 
		('id11', (select c_no from check_out where c_orderNum = 
		(select max(d_orderNum) from delivery_to_customer)), '59', (select max(d_orderNum) from delivery_to_customer))