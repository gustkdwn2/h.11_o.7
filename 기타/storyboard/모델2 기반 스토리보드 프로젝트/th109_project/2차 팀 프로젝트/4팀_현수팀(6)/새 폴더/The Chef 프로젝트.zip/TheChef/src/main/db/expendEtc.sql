create table expendEtc (
  ee_num number primary key,   -- he_num : 지출번호 (자동증가)  (PK)
  ee_date varchar2(50) not null,   -- he_Date 년/월/일  2016/02/28
  ee_expend number default 0,  -- he_Expend : 지출금
  ee_content varchar2(50) not null,   -- he_Content: 지출내역
  ee_ExpendDirector varchar2(50)    -- he_ExpendDirector: 지출책임자
);
create sequence  ee_num_seq;
