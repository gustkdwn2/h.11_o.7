drop table farmInfo;
create table farmInfo(
   farm_id varchar2(100),
   farm_Pcategory varchar2(100),
   farm_Pid varchar2(1000) primary key,
   farm_unit varchar2(30),
   farm_Pname varchar2(100),
   farm_Pcount number,
   farm_Pprice number
);
select * from farmInfo;
delete from farmInfo;
create sequence farm_Pid;
drop sequence farm_Pid;

drop table farmName;
create table farmName(
	farm_id varchar2(100) primary key,
	farm_name varchar2(100)
);
select * from farmName;

select farm_name from farmName where farm_id='seller1'
