select * from cart;
select * from cart_ingredients;
select * from check_out;
select * from DELIVERY_TO_CUSTOMER;
select * from PAY_INGREDIENTS;
select * from FARM_PRODUCTS

select distinct p.product_id, (r.dose*c.count) as quantity 
from pay_ingredients p join recipe_table r on p.product_id = r.product_id 
and p.p_no = r.p_no join check_out c on c.c_ordernum = p.d_ordernum 
and r.p_no = c.c_no where c.c_no = 26 and c.c_ordernum = 6

delete cart;
delete cart_ingredients;

delete PAY_INGREDIENTS;
delete check_out;
delete DELIVERY_TO_CUSTOMER;

select * from stockManage;
select * from RECIPE_THEME_PRODUCTS;
select * from RECIPE_TABLE;

select distinct p.product_id, (r.dose*c.count) as quantity from pay_ingredients p 
		join recipe_table r on p.product_id = r.product_id and p.p_no = r.p_no 
		join check_out c on c.c_ordernum = p.d_ordernum and r.p_no = c.c_no 
		where c.c_no = 25 and c.c_ordernum = (select max(c_ordernum) from check_out)


drop table cart;
delete cart;

create table cart(
  f_no varchar2(100),
  id varchar2(1000),
  reg_date date not null,
  f_total_price number(30),
  f_total_count number(30) default 1
);

create table cart_ingredients(
	f_no varchar2(100),
	id varchar2(1000),
	product_id varchar2(1000)
);

