package com.kosta.project.dto;

public class TempDTO {
	String p_no, category1, product_name, p_category1, p_category2, p_title;
	int quantity;
	
	public TempDTO() {}

	public TempDTO(String p_no, String category1, String product_name, String p_category1, String p_category2,
			String p_title, int quantity) {
		this.p_no = p_no;
		this.category1 = category1;
		this.product_name = product_name;
		this.p_category1 = p_category1;
		this.p_category2 = p_category2;
		this.p_title = p_title;
		this.quantity = quantity;
	}

	public String getP_no() {
		return p_no;
	}

	public void setP_no(String p_no) {
		this.p_no = p_no;
	}

	public String getCategory1() {
		return category1;
	}

	public void setCategory1(String category1) {
		this.category1 = category1;
	}

	public String getProduct_name() {
		return product_name;
	}

	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}

	public String getP_category1() {
		return p_category1;
	}

	public void setP_category1(String p_category1) {
		this.p_category1 = p_category1;
	}

	public String getP_category2() {
		return p_category2;
	}

	public void setP_category2(String p_category2) {
		this.p_category2 = p_category2;
	}

	public String getP_title() {
		return p_title;
	}

	public void setP_title(String p_title) {
		this.p_title = p_title;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	

}
