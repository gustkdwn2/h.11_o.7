package com.kosta.project.dto;

public class CartIngredientsDTO {
	String f_no, id, product_id;
	
	public CartIngredientsDTO() {
		// TODO Auto-generated constructor stub
	}

	public CartIngredientsDTO(String f_no, String id, String product_id) {
		this.f_no = f_no;
		this.id = id;
		this.product_id = product_id;
	}

	public String getF_no() {
		return f_no;
	}

	public void setF_no(String f_no) {
		this.f_no = f_no;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getProduct_id() {
		return product_id;
	}

	public void setProduct_id(String product_id) {
		this.product_id = product_id;
	}
	
	
}
