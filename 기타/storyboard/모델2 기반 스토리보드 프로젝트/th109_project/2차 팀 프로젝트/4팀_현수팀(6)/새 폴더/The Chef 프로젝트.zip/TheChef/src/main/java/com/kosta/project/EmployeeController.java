package com.kosta.project;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.kosta.project.dao.IEmployeeDAO;
import com.kosta.project.dto.EmployeeDTO;
import com.kosta.project.dto.EmployeePositionDTO;

///인사관리에 관한 모든 요청(관리자메뉴  -인사관리에 속한 부가메뉴 모두)
@Controller
public class EmployeeController {

	@Autowired
	private SqlSession sqlSession;
	static List<EmployeeDTO> list = new ArrayList<EmployeeDTO>();

	///////////////////// 직원 관리(추가 삭제 수정등)////////////////////////////////////////////////////////////////
	// 직원관리뷰로
	@RequestMapping(value = "/manageEmployee", method = RequestMethod.GET)
	public String manageEmployee(Model model) {
		System.out.println("↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘personResource.java/  manageEmployee controller");

		IEmployeeDAO dao = sqlSession.getMapper(IEmployeeDAO.class);
		model.addAttribute("list", dao.getEmployee());
		System.out.println("get list size" + dao.getEmployee().size());
		System.out.println("return back.personResource.manageEmployee↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖");
		return "back.personResource.manageEmployee";
	}

	// 직원수정뷰로
	@RequestMapping(value = "/updateEmployee", method = RequestMethod.GET)
	public String updateEmployee(@RequestParam("e_num") Integer e_num, Model model) {
		System.out.println("↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘personResource.java/  updateEmployee controller");
		IEmployeeDAO dao = sqlSession.getMapper(IEmployeeDAO.class);
		System.out.println("e_num : " + e_num);
		EmployeeDTO vo = dao.getEmployeeSearchE_num(String.valueOf(e_num)).get(0);
		System.out.println("get value about e_num : " + vo.getE_account() + "/ " + vo.getE_name() + "/ " + vo.getE_num()
				+ "/ " + vo.getE_hiredate() + "/ " + vo.getEp_name() + "/ " + vo.getEp_num() + "...");
		model.addAttribute("list", dao.getEmployeePosition());
		model.addAttribute("vo", vo);
		System.out.println("get hiredate : " + vo.getE_hiredate());
		model.addAttribute("year", vo.getE_hiredate().substring(0, 4));
		model.addAttribute("month", vo.getE_hiredate().substring(5, 7));
		model.addAttribute("day", vo.getE_hiredate().substring(8, 10));
		System.out.println("return back.personResource.updateEmployee↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖");
		return "back.personResource.updateEmployee";
	}

	// 직원추가뷰로
	@RequestMapping(value = "/addEmployee")
	public String addEmployee(@ModelAttribute EmployeeDTO vo, Model model,
			@RequestParam(value = "month", required = false) String month,
			@RequestParam(value = "year", required = false) String year,
			@RequestParam(value = "day", required = false) String day) {
		System.out.println("↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘personResource.java/ addEmployee controller");
		IEmployeeDAO dao = sqlSession.getMapper(IEmployeeDAO.class);
		List<EmployeePositionDTO> employeePositionList = dao.getEmployeePosition();
		System.out.println("1.가져온 직책리스트 크기 :" + employeePositionList.size());
		model.addAttribute("employeePositionList", dao.getEmployeePosition());
		if (employeePositionList.size() > 0)// 직책이 존재하면
			model.addAttribute("first_s_salary", employeePositionList.get(0).getEp_salary());
		if (vo.getE_name() == null) {// 계속적으로 추가해주는 작업중이 아니었으면 : 다른뷰에서 처음왔으면
			list.clear();
			return "back.personResource.addEmployee";
		}
		if (month.length() == 1)
			month = "0" + month;
		if (day.length() == 1)
			day = "0" + day;
		vo.setE_hiredate(year + "/" + month + "/" + day);
		System.out.println("추가할 직원의 입사일 :" + vo.getE_hiredate());

		vo.setEp_name(dao.getEmployeePositionSearchEp_num(vo.getEp_num()).getEp_name());
		System.out.println("추가할 직원의 직책이름 :" + vo.getEp_name());

		list.add(vo);
		System.out.println("2.지금까지 추가완료된이후 현재 직원 리스트 크기 :" + list.size());
		model.addAttribute("employeeList", list);
		System.out.println("return back.personResource.addEmployee ↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖");
		return "back.personResource.addEmployee";
	}

	// 직원수정처리후 직원관리뷰로
	@RequestMapping(value = "/updateProEmployee", method = RequestMethod.POST)
	public String updateProEmployee(@ModelAttribute EmployeeDTO vo, Model model, @RequestParam("month") String month,
			@RequestParam("year") String year, @RequestParam("day") String day) {
		System.out.println("↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘personResource.java/ updateProEmployee controller");

		if (month.length() == 1)
			month = "0" + month;
		if (day.length() == 1)
			day = "0" + day;
		vo.setE_hiredate(year + "/" + month + "/" + day);
		System.out.println("직원수정시작");
		System.out.println("업데이트할 vo정보 일부 : " + vo.getE_account() + "/ " + vo.getE_hiredate() + " /" + vo.getEp_num()
				+ " /" + vo.getEp_num() + " / " + vo.getS_salary());
		IEmployeeDAO dao = sqlSession.getMapper(IEmployeeDAO.class);
		dao.updateEmployee(vo);
		System.out.println("update변경할 직원이름으로 월급테이블 직원이름도수정");
		System.out.println("e_num:"+  vo.getE_num());
		System.out.println("e_name:"+  vo.getE_name());
		dao.updateSalaryE_name(vo);
		System.out.println("직원의 월급기록 수정 시작");
		System.out.println("salary값 :  " + vo.getS_salary());
		if (dao.getSalaryCntOfSameDateAndSameE_num(vo) != 0) {
			dao.updateSalaryOfE_num(vo);
			System.out.println("수정할 직원 월급 정보값이 존재(같은 직원 ,현재와 같은 년/월로)");
			System.out.println("직원의 월급기록 업데이트");
		} else {
			dao.insertSalaryOfE_num(vo);
			System.out.println("수정할 직원 월급 정보값이 존재안함(같은 직원 ,현재와 같은 년/월로)");
			System.out.println("직원의 월급기록 추가");
		}

		System.out.println("return redirect:/manageEmployee↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖");
		return "redirect:/manageEmployee";
	}

	// 직원추가처리후 직원관리뷰로
	@RequestMapping(value = "/addProEmployee", method = RequestMethod.GET)
	public String addProEmployee() {
		System.out.println("↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘personResource.java/ addProEmployee controller");
		System.out.println("등록할직원수: " + list.size());
		IEmployeeDAO dao = sqlSession.getMapper(IEmployeeDAO.class);
		for (int a = 0; a < list.size(); a++) {
			System.out.println(a + "번째 등록할직원 정보  : " + list.get(a).getE_account() + "/ " + list.get(a).getE_hiredate()
					+ " / " + list.get(a).getE_name() + list.get(a).getE_num() + "/ " + list.get(a).getE_phone() + " / "
					+ list.get(a).getEp_num());
			dao.insertEmployee(list.get(a));
			System.out.println(a + "번째 직원 등록완료");
			list.get(a).setE_num(dao.getMaxE_num());
			System.out.println("최근 등록한 직원의 번호 셋팅   e_num : " + dao.getMaxE_num());
			System.out.println(a + "번째 등록할직원 월급" + list.get(a).getS_salary());
			dao.insertSalaryOfE_num(list.get(a));
			System.out.println(a + "번째 직원 월급기록 등록완료");
		}

		list.clear();
		System.out.println("return redirect:/manageEmployee ↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖");
		return "redirect:/manageEmployee";
	}

	// 직원삭제처리후 직원관리뷰로 
	@RequestMapping(value = "/removeEmployee", method = RequestMethod.POST)
	public String removeEmployee(@RequestParam(value = "e_num", required = false) Integer e_num,
			@RequestParam(value = "checkedEmployee", required = false) Integer[] checkedEmployee, Model model) {
		System.out.println("↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘personResource.java/  removeEmployee controller");
		IEmployeeDAO dao = sqlSession.getMapper(IEmployeeDAO.class);
		if (checkedEmployee != null && e_num == null) {
			System.out.println("checkedEmployee != null && e_num ==null   // 선탠된 직원들 삭제");
			System.out.println("checkedEmployee.length:" + checkedEmployee.length);
			for (int a = 0; a < checkedEmployee.length; a++){
				System.out.println("직원삭제후 월급기록 0으로");
				EmployeeDTO vo = new EmployeeDTO();
				vo.setE_num(checkedEmployee[a]);
				vo.setS_salary(0);
				System.out.println("해당 삭제번호로 찾은 급여기록 개수 :"+dao.getSalaryCntOfSameDateAndSameE_num(vo));
				if (dao.getSalaryCntOfSameDateAndSameE_num(vo) != 0) {
					System.out.println("vo."+vo.getE_num() + " / " + vo.getS_salary());
					dao.updateSalaryOfE_num(vo);
					System.out.println("수정할 직원 월급 정보값이 존재(같은 직원 ,현재와 같은 년/월로)");
					System.out.println("직원의 월급기록 업데이트");
				} else {
					dao.insertSalaryOfE_num(vo);
					System.out.println("수정할 직원 월급 정보값이 존재안함(같은 직원 ,현재와 같은 년/월로)");
					System.out.println("직원의 월급기록 추가");
				}
				//직원월급기록 0으로
				dao.removeEmployee(checkedEmployee[a]);
			}
		}
		if (e_num != null) {
			EmployeeDTO vo = new EmployeeDTO();
			vo.setE_num(e_num);
			vo.setS_salary(0);
			if (dao.getSalaryCntOfSameDateAndSameE_num(vo) != 0) {
				System.out.println("vo."+vo.getE_num() + " / " + vo.getS_salary());
				dao.updateSalaryOfE_num(vo);
				System.out.println("수정할 직원 월급 정보값이 존재(같은 직원 ,현재와 같은 년/월로)");
				System.out.println("직원의 월급기록 업데이트");
			} else {
				dao.insertSalaryOfE_num(vo);
				System.out.println("수정할 직원 월급 정보값이 존재안함(같은 직원 ,현재와 같은 년/월로)");
				System.out.println("직원의 월급기록 추가");
			}
			//직원월급기록 0으로
			
			System.out.println("e_num != null  //직원 한명만 삭제");
			System.out.println("e_num: " + e_num);
			dao.removeEmployee(e_num);
			System.out.println("직원삭제후 월급기록 0으로");
			
		}
		System.out.println("return redirect:/manageEmployee↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖");
		return "redirect:/manageEmployee";
	}

	// 직원관리뷰 - 직원검색
	@RequestMapping(value = "/employeeSearch")
	public String employeeSearch(Model model, @RequestParam("searchText") String searchText,
			@RequestParam("searchType") String searchType) {
		System.out.println("↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘personResource.java/  employeeSearch controller");
		IEmployeeDAO dao = sqlSession.getMapper(IEmployeeDAO.class);
		System.out.println("검색내용 : " + searchText);
		System.out.println("검색분류 : " + searchType);
		if (searchType.equals("직원명")) {
			model.addAttribute("list", dao.getEmployeeSearchE_name(searchText));
		} else if (searchType.equals("직책명"))
			model.addAttribute("list", dao.getEmployeeSearchEP_name(searchText));
		else if (searchType.equals("직원코드")) {
			try {// 직원코드로 찾으려고 하는데 에러가나면 :searchText 가 정수가 아니면
				model.addAttribute("list", dao.getEmployeeSearchE_num(searchText));
			} catch (Exception e) {
				model.addAttribute("list", new ArrayList<EmployeeDTO>());// size 가0인  비어있는  리스트로  넘김
			}
		}else if(searchType.equals("모두보기")){
			return "redirect:/manageEmployee";
		}
		System.out.println("return back.personResource.manageEmployee↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖");
		return "back.personResource.manageEmployee";
	}

	/////////////////////////////// 직책 관리(추가 삭제
	/////////////////////////////// 수정등)//////////////////////////////////////////////////////////////////////////
	// 직책관리뷰로
	@RequestMapping(value = "/managePosition", method = RequestMethod.GET)
	public String managePosition(Model model) {
		System.out.println("↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘personResource.java/ managePosition controller");
		IEmployeeDAO dao = sqlSession.getMapper(IEmployeeDAO.class);
		List<EmployeePositionDTO> list = dao.getEmployeePosition();
		model.addAttribute("list", list);
		if (list.size() == 0) {
			model.addAttribute("s_salary", null);
			System.out.println("가저온 직책수 :없음" + 0);
		} else {
			model.addAttribute("s_salary", dao.getSearchEp_salaryFromEp_num(list.get(0).getEp_num()));
			System.out.println("가저온 직책수:" + list.size());
		}
		System.out.println("return back.personResource.managePosition ↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖");
		return "back.personResource.managePosition";
	}
	// 직책수정뷰로
	@RequestMapping(value = "/updateEmployeePosition", method = RequestMethod.GET)
	public String updateEmployeePosition(@ModelAttribute EmployeePositionDTO vo, Model model) {
		System.out.println("↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘personResource.java/ updateEmployeePosition controller");
		IEmployeeDAO dao = sqlSession.getMapper(IEmployeeDAO.class);
		model.addAttribute("vo", dao.getEmployeePositionSearchEp_num(vo.getEp_num()));
		System.out.println("return back.personResource.updateEmployeePosition ↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖");
		return "back.personResource.updateEmployeePosition";
	}
	
	// 직책삭제후 직책관리뷰로
	@RequestMapping(value = "/deleteProEmployeePosition", method = RequestMethod.POST)
	public String deleteProEmployeePosition(@RequestParam("ep_num") Integer ep_num, Model model) {
		System.out.println("↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘personResource.java/ deleteProEmployeePosition controller");
		System.out.println("삭제할 직책번호: " + ep_num);
		IEmployeeDAO dao = sqlSession.getMapper(IEmployeeDAO.class);
		dao.deleteEmployee_Position(ep_num);
		System.out.println("return back.personResource.managePosition ↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖");
		return "redirect:/managePosition";
	}
	// 직책추가후 직책관리뷰로
	@RequestMapping(value = "/addProEmployeePosition", method = RequestMethod.POST)
	public String addProEmployeePosition(@ModelAttribute EmployeePositionDTO vo, Model model) {
		System.out.println("↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘personResource.java/ addProEmployeePosition controller");
		System.out.println("추가할 직책 정보 : " + vo.getEp_name() + " / " + vo.getEp_salary());
		IEmployeeDAO dao = sqlSession.getMapper(IEmployeeDAO.class);
		dao.addEmployee_Position(vo);
		System.out.println("return back.personResource.managePosition ↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖");
		return "redirect:/managePosition";
	}
	// 직책수정후 직책관리뷰로
	@RequestMapping(value = "/modifyProEmployeePosition", method = RequestMethod.POST)
	public String modeifyProEmployeePosition(@ModelAttribute EmployeePositionDTO vo, Model model) {
		System.out.println("↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘personResource.java/ modeifyProEmployeePosition controller");
		System.out.println("수정할 직책 정보 : " + vo.getEp_name() + " / " + vo.getEp_salary());
		IEmployeeDAO dao = sqlSession.getMapper(IEmployeeDAO.class);
		dao.modifyEmployee_Position(vo);
		System.out.println("return back.personResource.managePosition ↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖");
		return "redirect:/managePosition";
	}

	// 직책번호를 가지는 직원들 찾기
	@RequestMapping(value = "/getSearchEp_numFromEmployee", method = RequestMethod.POST)
	@ResponseBody
	public String getSearchEp_numFromEmployee(@RequestParam("ep_num") Integer ep_num, Model model) {
		System.out.println("↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘personResource.java/ getSearchEp_numFromEmployee controller");
		System.out.println("찾을 직책번호 : " + ep_num);
		IEmployeeDAO dao = sqlSession.getMapper(IEmployeeDAO.class);
		if (dao.getSearchEp_numFromEmployee(ep_num) > 0) {
			System.out.println("해당 직책번호를 가지는 직원이 존재함");
			System.out.println("return exist ↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖");
			return "exist";
		} else {
			System.out.println("해당 직책번호를 가지는 직원이 존재하지않음");
			System.out.println("return notExist ↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖");
			return "notExist";
		}
	}
	// 직책번호에대한 급여가저오기
	@RequestMapping(value = "/getSearchEp_salaryFromEp_num", method = RequestMethod.POST)
	@ResponseBody
	public String getSearchEp_salaryFromEp_num(@RequestParam("ep_num") Integer ep_num, Model model) {
		System.out.println("↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘personResource.java/ getSearchEp_salaryFromEp_num controller");
		IEmployeeDAO dao = sqlSession.getMapper(IEmployeeDAO.class);
		System.out.println("return  get salary값 : " + dao.getSearchEp_salaryFromEp_num(ep_num));
		return String.valueOf(dao.getSearchEp_salaryFromEp_num(ep_num));
	}

	/////////////////////////////// 급여 관리(추가 삭제
	/////////////////////////////// 수정등)////////////////////////////////////////////////////
	// 급여관리뷰로
	@RequestMapping(value = "/setSalary")
	public String setSalary(Model model,@RequestParam(value="s_salaryOfep_num", required =false) Integer s_salaryOfep_num
			,@RequestParam(value="ep_num", required =false) Integer ep_num) {
		System.out.println("↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘personResource.java/  setSalary controller");
		IEmployeeDAO dao = sqlSession.getMapper(IEmployeeDAO.class);
		model.addAttribute("employeeList", dao.getEmployee());
		System.out.println("get 직원 list size" + dao.getEmployee().size());
		model.addAttribute("employeePositionList", dao.getEmployeePosition());
		System.out.println("get 직책 list size" + dao.getEmployee().size());
		model.addAttribute("s_salaryOfep_num", s_salaryOfep_num);
		System.out.println("직책별로 수정할때 월급값  s_salaryOfep_num : "+ s_salaryOfep_num);
		model.addAttribute("ep_num", ep_num);
		System.out.println("직책별로 수정할때 해당 직책번호 값  ep_num: "+ ep_num);
		System.out.println("return back.personResource.setSalary↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖");
		return "back.personResource.setSalary";
	}
	//직원의 급여 여러사항들을 한번에 수정후 급여관리뷰로
	@RequestMapping(value = "/modifyProSelectsalaries", method = RequestMethod.POST)
	public String modifyProSelectsalaries(Model model,
			@RequestParam("e_nums") List<Integer> e_nums, @RequestParam("s_salaries") List<Integer> s_salaries) {
		System.out.println("↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘personResource.java/  modifyProSelectsalaries controller");
		IEmployeeDAO dao = sqlSession.getMapper(IEmployeeDAO.class);
		EmployeeDTO vo = new EmployeeDTO();
		for(int a=0; a< e_nums.size(); a++){
			System.out.println(a+"번쨰 급여수정값: " +e_nums.get(a)+"/"+s_salaries.get(a) +"  수정시작!");
			vo.setS_salary(s_salaries.get(a));
			vo.setE_num(e_nums.get(a));
			if (dao.getSalaryCntOfSameDateAndSameE_num(vo) != 0) {
				dao.updateSalaryOfE_num(vo);
				System.out.println("수정할 직원 월급 정보값이 존재(같은 직원 ,현재와 같은 년/월로)");
				System.out.println("직원의 월급기록 업데이트");
			} else {
				dao.insertSalaryOfE_num(vo);
				System.out.println("수정할 직원 월급 정보값이 존재안함(같은 직원 ,현재와 같은 년/월로)");
				System.out.println("직원의 월급기록 추가");
			}
		}
		System.out.println("수정 모두완료");
		
		System.out.println("return back.personResource.setSalary↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖");
		return "redirect:/setSalary";
	}
	//급여관리뷰에서 검색
	@RequestMapping(value = "/employeeSalarySearch")
	public String employeeSalarySearch(Model model, @RequestParam("searchText") String searchText,
			@RequestParam("searchType") String searchType) {
		System.out.println("↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘personResource.java/  employeeSalarySearch controller");
		IEmployeeDAO dao = sqlSession.getMapper(IEmployeeDAO.class);
		System.out.println("검색내용 : " + searchText);
		System.out.println("검색분류 : " + searchType);
		if (searchType.equals("직원명")) {
			model.addAttribute("employeeListlist", dao.getEmployeeSearchE_name(searchText));
		} else if (searchType.equals("직책명"))
			model.addAttribute("employeeList", dao.getEmployeeSearchEP_name(searchText));
		else if (searchType.equals("직원코드")) {
			try {// 직원코드로 찾으려고 하는데 에러가나면 :searchText 가 정수가 아니면
				model.addAttribute("employeeList", dao.getEmployeeSearchE_num(searchText));
			} catch (Exception e) {
				model.addAttribute("employeeList", new ArrayList<EmployeeDTO>());// size 가0인  비어있는  리스트로  넘김
			}
		}else if(searchType.equals("모두보기")){
			return "redirect:/setSalary";
		}
		model.addAttribute("employeePositionList", dao.getEmployeePosition());
		System.out.println("get 직책 list size" + dao.getEmployee().size());
		System.out.println("return back.personResource.setSalary↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖");
		return "back.personResource.setSalary";
	}
}
