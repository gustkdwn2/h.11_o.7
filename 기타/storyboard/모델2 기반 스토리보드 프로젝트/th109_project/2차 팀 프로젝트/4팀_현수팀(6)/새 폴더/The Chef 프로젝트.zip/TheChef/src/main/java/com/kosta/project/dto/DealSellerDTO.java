package com.kosta.project.dto;

public class DealSellerDTO {
	
	int  orderCount, orderPrice; 
	String ordernum, orderId, orderCode;
	String orderDate;
	
	public DealSellerDTO() {}

	public DealSellerDTO(int orderCount, int orderPrice, String ordernum, String orderId, String orderCode,
			String orderDate) {
		this.orderCount = orderCount;
		this.orderPrice = orderPrice;
		this.ordernum = ordernum;
		this.orderId = orderId;
		this.orderCode = orderCode;
		this.orderDate = orderDate;
	}

	public int getOrderCount() {
		return orderCount;
	}

	public void setOrderCount(int orderCount) {
		this.orderCount = orderCount;
	}

	public int getOrderPrice() {
		return orderPrice;
	}

	public void setOrderPrice(int orderPrice) {
		this.orderPrice = orderPrice;
	}

	public String getOrdernum() {
		return ordernum;
	}

	public void setOrdernum(String ordernum) {
		this.ordernum = ordernum;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getOrderCode() {
		return orderCode;
	}

	public void setOrderCode(String orderCode) {
		this.orderCode = orderCode;
	}

	public String getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}
	
	
}
