--관리자 창고내의 재고관리 

--product_id상품번호  farmInfo테이블의 farm_Pid를 참조
--product_name 상품명 >> 세분화된 재료 예)느타리버섯, 양송이 버섯, 총각김치 
--product_totalCount 재고총수량
--product_from 업체명 >> 어디에서 구입했는지
--product_status 1:골라담기 2:레시피테마  >> 1:귀농 2:마트

--product_category 큰 카테고리 예)버섯, 김치, 파
--product_price 재료 총 가격
--product_regdate 재고 등록 날짜

drop table stockManage;
create table stockManage(
	product_id varchar2(1000) primary key, --버섯번호
	product_category varchar2(100),
	product_name varchar2(100),
	product_price number, -- 딸기 한 개당 가격, 총가격이 아니라 제품 하나당의 가격이다!!
	product_totalCount number,
	product_unit varchar2(30),
	product_from varchar2(100),
	product_regdate date default sysdate,
	product_status varchar2(10)
);
select * from stockManage;

--유통기한table 추가
create table limit_date(
	product_id varchar2(1000), -- 재고번호
	product_date date not null
);

--product_date 유통기한