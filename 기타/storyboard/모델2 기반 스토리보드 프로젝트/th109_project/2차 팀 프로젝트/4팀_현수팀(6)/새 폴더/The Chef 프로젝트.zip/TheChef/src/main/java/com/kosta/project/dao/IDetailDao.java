package com.kosta.project.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.kosta.project.dto.CheckOutDTO;
import com.kosta.project.dto.FarmProductDto;
import com.kosta.project.dto.FarmReviewDTO;
import com.kosta.project.dto.MinPriceDTO;
import com.kosta.project.dto.PayIngredientsDTO;
import com.kosta.project.dto.RTPdto;
import com.kosta.project.dto.RecipeReviewDTO;
import com.kosta.project.dto.StockManageJoinRecipeDTO;
import com.kosta.project.dto.SubtractStockDTO;

public interface IDetailDao {
	// 레시피 테마 상품 상세정보
	public List<RTPdto> rtpList(@Param("_p_no") String p_no);

	// 상품 골라담기 상세정보
	public List<FarmProductDto> farmList(@Param("_s_no") String s_no);

	////////////// 레시피/테마 리뷰부분////////////
	public List<RecipeReviewDTO> reviewList(@Param("_r_no") String r_no);

	// 상품 상세정보 리뷰 부분//
	public List<FarmProductDto> reviewList2(@Param("_fr_no") String fr_no);

	// 결제되었을 때 장바구니에서 없애기deleteCart
	 public void deleteCart(@Param("_id") String id, @Param("_c_no") String c_no);

	public List<RecipeReviewDTO> searchOnePage(@Param("_r_no") String r_no, @Param("_startRow") int startRow,
			@Param("_endRow") int endRow);

	// 리뷰 등록 부분(레시피/테마)
	public void insertReview(RecipeReviewDTO dto);

	// 리뷰 등록 부분(상품 골라담기)
	public void insertReview2(FarmReviewDTO dto);

	// 구매 테이블에 insert
	public void insertCheckOut(CheckOutDTO dto);

	// 구매 테이블 delete
	public void deleteCheckOut(@Param("_c_no") String c_no, @Param("_id") String id);

	public void deleteCartIngredients(@Param("_id") String id, @Param("_c_no") String c_no);
	
	// 발송 테이블에 insert
	public void insertDelivery(@Param("_subtotal") int subtotal, @Param("_shipping_fee") int shipping_fee,
			@Param("_id") String id);

	public List<StockManageJoinRecipeDTO> ingredientsList(@Param("_p_no") String p_no);

	public List<MinPriceDTO> minPriceByingredient(@Param("_p_no") String p_no);

	public List<String> findProduct_Name(@Param("_p_no") String p_no);

	public void insertPayIngredients(PayIngredientsDTO idto);

	public List farmStock(@Param("_s_no") String s_no);

	public List<SubtractStockDTO> selectSubtractQuantity(@Param("_c_no") String c_no, @Param("_count") int count);

	public void subtractStock(@Param("_product_id") String product_id, @Param("_quantity") int quantity);

	public List isRecipeTheme(@Param("_c_no") String c_no);

	public List isCart(@Param("_c_no") String c_no, @Param("_id") String id);

	public List<String> productIdFromCart(@Param("_c_no") String c_no, @Param("_id") String id);

	public void deleteStockZero();

	public void subtractfarmStock(@Param("_c_no") String c_no, @Param("_quantity") int quantity);

	public int availableCount(@Param("_s_no") String s_no);

	public List cartF_no();

}