package com.kosta.project;

import java.security.Principal;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.kosta.project.dao.ICookDetailDao;
import com.kosta.project.dto.CookReviewDto;
import com.kosta.project.dto.LikeDTO;

@Controller
public class CookDetailController {

   @Autowired
   private SqlSession sqlSession;

   @RequestMapping("/cook_details") // 요리톡 리스트에서 클릭하였을 때 상세 페이지
   public String cook_details(HttpServletRequest request, Model model, Principal principal) throws Exception {
      request.setCharacterEncoding("utf-8");
      System.out.println("cook_details()");

      String k_no = request.getParameter("k_no");
      //int code = Integer.parseInt(request.getParameter("code"));
      ICookDetailDao dao = sqlSession.getMapper(ICookDetailDao.class);
      
      dao.updateHit(k_no);
      
      List cookList = dao.cookList(k_no);
      model.addAttribute("list", cookList);   
      
      List<LikeDTO> hot_no = dao.findHot_no();//좋아요가 많은 레시피 1위, 2위, 3위 뽑아오
      
      model.addAttribute("listLike", hot_no);//좋아요가 가장 많은 레시피
      
      //////////////// review 부분//////////////////
      List cookreviewList = dao.cookreviewList(k_no);   

      ////////////////////////////////////////////////////////////
      // page 처리 부분// 상품 리뷰부분 paging 처리!///
      int pageSize = 7;
      int Allcount = 0, count1 = 0;
      String pageNum = request.getParameter("pageNum");
      if (pageNum == null) {
         pageNum = "1";
      }
      System.out.println("pageNum : " + pageNum);

      int currentPage = Integer.parseInt(pageNum);
      System.out.println("currentPage : " + currentPage);

      int startRow = (currentPage * pageSize) - 6;// 8번부터 2페이지
      System.out.println("startRow: " + startRow);

      int endRow = currentPage * pageSize;// 1*20
      System.out.println("endRow: " + endRow);

      Allcount = cookreviewList.size();// 리뷰 총 개수
      System.out.println("Allcount: " + Allcount);
      //////////////////////////////////////////////
      List searchOnePageList = null;

      searchOnePageList = dao.searchOnePage(k_no, startRow, endRow);// 1~7
      count1 = searchOnePageList.size();// 5
      System.out.println("searchOnePageCount: " + count1);

      //model.addAttribute("code", new Integer(code));
      model.addAttribute("count1", new Integer(count1));
      model.addAttribute("searchOnePageList", searchOnePageList);// jsp에 뿌릴
      // 리스트
      /////////////////////////
      model.addAttribute("currentPage", new Integer(currentPage));
      model.addAttribute("startRow", new Integer(startRow));
      model.addAttribute("endRow", new Integer(endRow));
      model.addAttribute("Allcount", new Integer(Allcount));
      model.addAttribute("pageSize", new Integer(pageSize));

      return "front.cookboard.cook_details";
   }

   @RequestMapping("/review_write3")
   public String review_write3(HttpServletRequest request, Model model, Principal principal) throws Exception {
      request.setCharacterEncoding("utf-8");
      System.out.println("cookreview_write()");

      String k_no = request.getParameter("k_no");
      //int code = Integer.parseInt(request.getParameter("code"));

      model.addAttribute("k_no", k_no);
      model.addAttribute("id", principal.getName());
      //model.addAttribute("code", code);

      return "front.cookboard.review_write";
   }

   @RequestMapping("/listAfterWrite3")
   public String listAfterWrite3(HttpServletRequest request, Model model, Principal principal) throws Exception{
      request.setCharacterEncoding("utf-8");
      System.out.println("listAfterWrite3()");
      
      String kr_no = request.getParameter("k_no");
      String id = principal.getName();
      String kr_review = request.getParameter("r_review");
      String kr_title = request.getParameter("r_title");
      int score = Integer.parseInt(request.getParameter("r_score"));
      
      System.out.println(kr_no + "," + id + "," + kr_review + "," + kr_title + "," + score);
      
      CookReviewDto dto = new CookReviewDto();
      dto.setKr_no(kr_no);
      dto.setId(id);
      dto.setKr_review(kr_review);
      dto.setKr_title(kr_title);
      dto.setScore(score);

      ICookDetailDao dao = sqlSession.getMapper(ICookDetailDao.class);
      dao.insertReview3(dto);
      
      return "redirect:/cook_details?k_no=" + kr_no;
   }
}