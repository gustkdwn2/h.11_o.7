package com.kosta.project.dto;

public class RTPorderDTO {
	
	int seq_ordernum, rtp_count, rtp_totalPrice;
	String mart_name, rtp_no;
	String rtp_regdate;
	public RTPorderDTO(int seq_ordernum, String rtp_no, int rtp_count, int rtp_totalPrice, String mart_name,
			String rtp_regdate) {
		this.seq_ordernum = seq_ordernum;
		this.rtp_no = rtp_no;
		this.rtp_count = rtp_count;
		this.rtp_totalPrice = rtp_totalPrice;
		this.mart_name = mart_name;
		this.rtp_regdate = rtp_regdate;
	}
	public RTPorderDTO() {}
	
	public int getSeq_ordernum() {
		return seq_ordernum;
	}
	public void setSeq_ordernum(int seq_ordernum) {
		this.seq_ordernum = seq_ordernum;
	}
	public String getRtp_regdate() {
		return rtp_regdate;
	}
	public void setRtp_regdate(String rtp_regdate) {
		this.rtp_regdate = rtp_regdate;
	}
	public String getRtp_no() {
		return rtp_no;
	}
	public void setRtp_no(String rtp_no) {
		this.rtp_no = rtp_no;
	}
	public int getRtp_count() {
		return rtp_count;
	}
	public void setRtp_count(int rtp_count) {
		this.rtp_count = rtp_count;
	}
	public int getRtp_totalPrice() {
		return rtp_totalPrice;
	}
	public void setRtp_totalPrice(int rtp_totalPrice) {
		this.rtp_totalPrice = rtp_totalPrice;
	}
	public String getMart_name() {
		return mart_name;
	}
	public void setMart_name(String mart_name) {
		this.mart_name = mart_name;
	}
}
