--요리톡 리뷰 테이블
drop table cookrecipe_review;
create table cookrecipe_review (
	kr_no varchar2(100) not null,
	id varchar2(1000) not null,
	reg_date date default sysdate,
	score number,
	kr_review varchar2(1000),
	kr_title varchar2(1000)
);

select * from cookrecipe_review;
drop sequence  COMMENT_SEQ;
create sequence COMMENT_SEQ;

select * from cook_comment;
 select k_no, rownum from (select k_no from cook_recipe order by k_like desc) where rownum between 1 and 3;

insert into cook_comment values(notice_board_seq.nextVal, 'WRITER', 'COMMENT', sysdate )

select * from cook_comment, cook_board where cook_comment.E_NO = cook_board.E_NO;




select B.*, ROWSEQ from(select A.*,ROWNUM as ROWSEQ from(select * from check_out order by reg_date desc)A)B where ROWSEQ>=1 and ROWSEQ=7 and c_status >0;

select count(*) from check_out where and c_status >0;