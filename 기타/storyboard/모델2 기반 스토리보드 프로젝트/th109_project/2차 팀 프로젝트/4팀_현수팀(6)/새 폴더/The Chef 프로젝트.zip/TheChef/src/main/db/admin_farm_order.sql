drop table  admin_farmer_Order;
-- 관리자가 판매자에게 주문하는 주문 테이블 
create table admin_farmer_Order(
   seq_ordernum number primary key,
   farm_id varchar2(100),
   farm_Pid varchar2(1000),
   farm_Pcategory varchar2(100),
   farm_Pname varchar2(100),
   farm_unit varchar2(50),
   orderCount number,
   orderPrice number,
   orderDate date,
   admin_id varchar2(100),
   order_ok varchar2(10),
   okDate date
);
delete from admin_farmer_Order;
select * from admin_farmer_Order;
select * from RECIPE_THEME_PRODUCTS
-- 발주번호, 판매자id, 상품번호, 품종, 요청수량, 총금액, 발주보낸시간, 요청한 관리자id, 수락여부, 발송시간
-- 수락여부는 y/n으로 저장하기
drop sequence seq_ordernum;
create sequence seq_ordernum;
select * from  admin_farmer_Order;
select * from recipe_theme_order;

select * from cookrecipe_review;



select B.*, ROWSEQ from(select A.*,ROWNUM as ROWSEQ from(select * from delivery_to_customer order by reg_date desc)A where d_status between 1 and 3)B where ROWSEQ>=1 and ROWSEQ<=5 and d_status like 3
			
select * from DELIVERY_TO_CUSTOMER where d_status like 3;