package com.kosta.project.dao;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.kosta.project.dto.AdminFarmOrderDTO;
import com.kosta.project.dto.DealSellerDTO;
import com.kosta.project.dto.DeliveryToCustomerDTO;

public interface IDealDao {

   public List<DeliveryToCustomerDTO> dealList(@Param("_startRegdate") Date startRegdate,@Param("_endRegdate") Date endRegdate);
   
   public Date findMonth();
   
   public List<DeliveryToCustomerDTO> listSearch(@Param("_startRegdate") String startRegdate,@Param("_endRegdate") String endRegdate,@Param("_searchKeyword") String searchKeyword);

   public List<DealSellerDTO> sellerSearch(Map map);

   public List<DealSellerDTO> sellerDealAll(@Param("_startRegdate") Date startRegdate,@Param("_endRegdate") Date endRegdate);

   public List<AdminFarmOrderDTO> sellerDealID(@Param("_startRegdate") Date startRegdate,@Param("_endRegdate") Date endRegdate,@Param("_id") String id);

   public List<AdminFarmOrderDTO> sellerSearchID(Map map);

}