package com.kosta.project.dto;

public class SubtractStockDTO {
	String product_id;
	int quantity;
	
	public SubtractStockDTO() {
		// TODO Auto-generated constructor stub
	}

	public SubtractStockDTO(String product_id, int quantity) {
		super();
		this.product_id = product_id;
		this.quantity = quantity;
	}

	public String getProduct_id() {
		return product_id;
	}

	public void setProduct_id(String product_id) {
		this.product_id = product_id;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	
}
