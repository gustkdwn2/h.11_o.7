drop sequence seq_ordernum;
drop sequence COMMENT_SEQ;
drop sequence notice_board_seq;
--drop sequence afo_SeqOrderNum;
drop sequence COMMENT_SEQ_seq;
drop sequence orderNum_seq;
drop sequence cookrecipe_seq;
drop sequence event_board_seq;
drop sequence farm_Pid;
drop sequence frequent_question_seq;
drop sequence talk_board_seq;
drop table cart_ingredients CASCADE CONSTRAINT;
drop table recipe_table CASCADE CONSTRAINT;
drop table board_comment CASCADE CONSTRAINT;
drop table event_comment CASCADE CONSTRAINT;
drop table talk_comment CASCADE CONSTRAINT;
drop table recipe_review CASCADE CONSTRAINT;
drop table farm_review CASCADE CONSTRAINT;
drop table cookrecipe_review CASCADE CONSTRAINT;
drop table role CASCADE CONSTRAINT;
drop table admin_farmer_Order CASCADE CONSTRAINT;
drop table cart CASCADE CONSTRAINT;
drop table check_out CASCADE CONSTRAINT;
drop table recipe_like CASCADE CONSTRAINT;
drop table farmInfo CASCADE CONSTRAINT;
drop table frequent_question CASCADE CONSTRAINT;
drop table pay_ingredients cascade constraint;
drop table delivery_to_customer CASCADE CONSTRAINT;
drop table stockManage CASCADE CONSTRAINT;
drop table recipe_theme_Products CASCADE CONSTRAINT;
drop table cook_recipe CASCADE CONSTRAINT;
drop table farm_Products CASCADE CONSTRAINT;
drop table notice_board CASCADE CONSTRAINT;
drop table event_board CASCADE CONSTRAINT;
drop table talk_board CASCADE CONSTRAINT;
drop table member CASCADE CONSTRAINT;
drop table farmName CASCADE CONSTRAINT;
drop table employee cascade constraint;
drop table employee_position cascade constraint;
drop table salary cascade constraint;
drop table admin_mart_Order cascade constraint;
drop table expendEtc cascade constraint;
drop sequence employee_seq;
drop sequence employee_position_seq;
drop sequence salary_seq;
drop sequence ee_num_seq;

create table expendEtc (
  ee_num number primary key,   -- he_num : 지출번호 (자동증가)  (PK)
  ee_date varchar2(50) not null,   -- he_Date 년/월/일  2016/02/28
  ee_expend number default 0,  -- he_Expend : 지출금
  ee_content varchar2(50) not null,   -- he_Content: 지출내역
  ee_ExpendDirector varchar2(50)    -- he_ExpendDirector: 지출책임자
);
create sequence  ee_num_seq;

create table employee(
   e_num number primary key,  -- 吏곸썝肄붾뱶
   e_name varchar2(100),-- 吏곸썝紐�
   ep_num number, -- 吏곸콉踰덊샇 ----------------------------------employee_position 湲곕낯�궎李몄“
   e_phone varchar2(100), --�뿰�씫泥�
   e_account varchar2(100), -- 怨꾩쥖踰덊샇
   e_hiredate varchar2(100) -- �엯�궗�씪
);
create sequence employee_seq;
create table employee_position(
	ep_num number primary key, --吏곸콉踰덊샇
	ep_salary number, -- 吏곸콉 �썡湲�
	ep_name varchar2(70), --吏곴툒�씠由�
	ep_responsibility varchar2(100) -- 吏곸콉�뿉�뵲瑜� �븯�뒗�씪
);
create sequence employee_position_seq;
create table salary(
	s_Num number primary key,  --湲됱뿬踰덊샇
	e_Num number,      --吏곸썝踰덊샇   
	s_salary number,   --�썡湲�
	s_date varchar2(50), --湲됱뿬�궇吏�(�뀈/�썡)
	e_name varchar2(100)
);
create sequence salary_seq;


create table admin_farmer_Order(
   seq_ordernum number primary key,
   farm_id varchar2(100),
   farm_Pid varchar2(1000),
   farm_Pcategory varchar2(100),
   farm_Pname varchar2(100),
   farm_unit varchar2(50),
   orderCount number,
   orderPrice number,
   orderDate date,
   admin_id varchar2(100),
   order_ok varchar2(10),
   okDate date
);

create sequence seq_ordernum;
-- 발주번호, 판매자id, 상품번호, 품종, 요청수량, 총금액, 발주보낸시간, 요청한 관리자id, 수락여부, 발송시간
-- 수락여부는 y/n으로 저장하기


create table cart(
  f_no varchar2(100),
  id varchar2(1000),
  reg_date date not null,
  f_total_price number(30),
  f_total_count number(30) default 1
);

create table cart_ingredients(--레시피/테마에서 장바구니에 담았을 경우 고객이 선택한 재료를 저장하는 테이블
	f_no varchar2(100),
	id varchar2(1000),
	product_id varchar2(1000)
);


create table check_out (
   c_orderNum number(30), --delivery_to_customer에서 d_orderNum이랑 같은 번호
   c_no varchar2(100) not null,
   c_name varchar2(100) not null,
   id varchar2(1000) not null,
   reg_date date default sysdate,
   c_price number(30), -- 제품 하나당 가격
   count number(30),
   name varchar2(100),
   c_address varchar2(500),
   c_zip_code varchar2(100),
   c_phone varchar2(100),
   c_status number(10) default 1
);
create sequence orderNum_seq; --delivery_to_customer에서 주분번호 

create table cook_recipe(--나만의 레시피를 위한 테이블
   k_title varchar2(1000),
   id varchar2(100),
   k_no varchar2(1000) primary key,
   k_content varchar2 (2000),
   k_contentFile varchar2(2000),
   k_thumbFile varchar2(2000),
   k_regdate date,
   k_category varchar2(100),
   k_like number default 0,
   k_hit number default 0
);
create sequence cookrecipe_seq;

create table cookrecipe_review (
	kr_no varchar2(100) not null,
	id varchar2(1000) not null,
	reg_date date default sysdate,
	score number,
	kr_review varchar2(1000),
	kr_title varchar2(1000)
);


create table recipe_like(--나만의 레시피 게시판에서 좋아요를 위한 테이블
   k_no varchar2(1000),
   id varchar2(100)
);

create table delivery_to_customer
(
   d_orderNum number(30) primary key,
   d_shipping_fee number(30),
   d_total_price number(30),
   d_status number(10) default 1,
   id varchar2(1000) not null,
   reg_date date default sysdate
);

create table event_board(
	E_NO NUMBER primary key ,
	E_TITLE VARCHAR2(500),
	E_WRITER varchar2(50),
	E_REGDATE TIMESTAMP,
	E_Hit number(30),
	E_Contents VARCHAR2(4000)
);
create sequence event_board_seq;

create table event_comment(
	E_NO NUMBER ,
	COMMENT_SEQ VARCHAR2(50),
	COMMENT_NAME VARCHAR2(50),
	COMMENT_COMM VARCHAR2(500),
	COMMENT_REGDATE DATE,
	CONSTRAINT FK_event_comment FOREIGN KEY(E_NO) REFERENCES event_board(E_NO)
);

create table farmInfo(
   farm_id varchar2(100),
   farm_Pcategory varchar2(100),
   farm_Pid varchar2(1000) primary key,
   farm_unit varchar2(30),
   farm_Pname varchar2(100),
   farm_Pcount number,
   farm_Pprice number
);
create sequence farm_Pid;


create table farm_Products(
	s_title varchar2(1000),
	id varchar2(100),
	s_no varchar2(1000) primary key,
	s_contentFile varchar2(2000),
	s_thumbFile varchar2(2000),
	s_price number,
	s_regdate date,
	s_incomeRate number, -- 이율
	s_dose number, --정량
	s_unit varchar2(30),
	s_category varchar2(100)
);
create table frequent_question(
	FQ_NO NUMBER primary key ,
	FQ_CATEGORY varchar2(50),
	FQ_TITLE VARCHAR2(500),
	FQ_Contents VARCHAR2(4000)
);
create sequence frequent_question_seq;

create table admin_mart_Order(
   mart_name varchar2(100), --마트 이름
   mart_Pid varchar2(1000), --마트에서 사려는 상품 번호
   mart_Pname varchar2(100), --마트에서 사려는 상품 이름
   mart_orderCount number, --구입 수량
   mart_orderPrice number, -- 결제 총 금액
   mart_unit varchar2(50), --상품 단위
   mart_orderDate date default sysdate, --마트에서 구입 일시
   admin_id varchar2(100) --요청한 관리자
);

create table member (
	id varchar2(100) primary key,
	name varchar2(100) not null,
	password varchar2(100) not null,
	gender varchar2(100) not null,
	address varchar2(500) not null,
	phone varchar2(100) not null,
	birth varchar2(100) not null,
	email varchar2(100) not null,
	regdate date default sysdate,
	zip_code varchar2(100) not null
);

CREATE TABLE role (
  id VARCHAR2(100),
  role_name VARCHAR2(30)
);

create table notice_board(
	N_NO NUMBER primary key,
	N_TITLE VARCHAR2(500),
	N_WRITER varchar2(50),
	N_REGDATE TIMESTAMP,
	N_Hit number(30),
	N_Contents VARCHAR2(4000)
);
create sequence notice_board_seq;

create table board_comment(
	N_NO NUMBER,
	COMMENT_SEQ VARCHAR2(50),
	COMMENT_NAME VARCHAR2(50),
	COMMENT_COMM VARCHAR2(500),
	COMMENT_REGDATE DATE,
	CONSTRAINT FK_board_comment FOREIGN KEY(N_NO)
	REFERENCES notice_board(N_NO)
	
);

create sequence COMMENT_SEQ; --공지사항 댓글 코멘트 시퀀스

create table recipe_theme_Products(
	p_title varchar2(1000),
	id varchar2(100),
	p_no varchar2(1000) primary key,
	p_contentFile varchar2(2000),
	p_thumbFile varchar2(2000),
	p_price number,
	p_regdate date,
	p_category1 varchar2(100),
	p_category2 varchar2(100),
	p_incomeRate number,
	p_src varchar2(1000)
);

create table recipe_review (
	r_no varchar2(100) not null,
	id varchar2(1000) not null,
	reg_date date default sysdate,
	score number,
	r_review varchar2(1000),
	r_title varchar2(1000)
);

create table farm_review (
   fr_no varchar2(100) not null,
   id varchar2(1000) not null,
   reg_date date default sysdate,
   score number,
   fr_review varchar2(1000),
   fr_title varchar2(1000)
);


create table stockManage(
	product_id varchar2(1000) primary key,
	product_category varchar2(100),
	product_name varchar2(100),
	product_price number,
	product_totalCount number,
	product_unit varchar2(30),
	product_from varchar2(100),
	product_regdate date default sysdate,
	product_status varchar2(10)
);

create table recipe_table(
	product_id varchar2(1000),
	product_name varchar2(1000),
	p_no VARCHAR2(1000),
	dose NUMBER,
	unit varchar2(50)
);

create table talk_board(
	T_NO NUMBER primary key,
	T_TITLE VARCHAR2(500),
	T_WRITER VARCHAR2(500),
	T_REGDATE TIMESTAMP,
	T_HIT NUMBER(30),
	T_CONTENTS VARCHAR2(4000)
);
create sequence talk_board_seq;

create table talk_comment(
	T_NO NUMBER,
	COMMENT_SEQ VARCHAR2(50),
	COMMENT_NAME VARCHAR2(50),
	COMMENT_COMM VARCHAR2(500),
	COMMENT_REGDATE DATE,
	CONSTRAINT FK_talk_comment FOREIGN KEY(T_NO)
	REFERENCES talk_board(T_NO)	
);

create sequence COMMENT_SEQ_seq;

create table pay_ingredients (
	id varchar2(1000) not null, --구입한 사람의 id
	p_no varchar2(1000), --레시피 번호
	product_id varchar2(1000), --재료 번호
	d_orderNum number(30), --발주 번호
	constraint fk_ingredients_d_orderNum foreign key(d_orderNum) references delivery_to_customer(d_orderNum) ON DELETE CASCADE
);

create table farmName(
	farm_id varchar2(100) primary key,
	farm_name varchar2(100)
);



--데이터 insert

--일반회원 
-- id : user1 password: 1111
-- id : user2 password: 1111
-- id : user3 password: 1111
--관리자
-- id : admi password: 1111
--판매자
-- id : seller1 password: 1111
-- id : seller2 password: 1111
-- id : seller3 password: 1111

insert into member(id,name,password,gender,address,phone,birth,email,zip_code) values ('admin','관리자','1111','women','경기도성남시분당구','01020568213','1992-04-09','baeji49@naver.com','11111');
insert into role values ('admin','ROLE_ADMIN');
insert into member(id,name,password,gender,address,phone,birth,email,zip_code) values ('user1','김지영','1111','women','서울시','01011111111','1991-10-18','abcd1234@hanmail.net','11111');
insert into role values ('user1','ROLE_USER');
insert into member(id,name,password,gender,address,phone,birth,email,zip_code) values ('user2','정지훈','1111','man','서울시','01011111111','1990-10-18','abcd1234@hanmail.net','11111');
insert into role values ('user2','ROLE_USER');
insert into member(id,name,password,gender,address,phone,birth,email,zip_code) values ('user3','이현수','1111','man','서울시','01011111111','1988-10-18','abcd1234@hanmail.net','11111');
insert into role values ('user3','ROLE_USER');
insert into member(id,name,password,gender,address,phone,birth,email,zip_code) values ('seller1','유승주','1111','man','서울시','01011111111','1991-10-18','nice9010@hanmail.net','11111');
insert into role values ('seller1','ROLE_COP');
insert into member(id,name,password,gender,address,phone,birth,email,zip_code) values ('seller2','김덕현','1111','man','서울시','01011111111','1984-10-18','nice9010@hanmail.net','11111');
insert into role values ('seller2','ROLE_COP');
insert into member(id,name,password,gender,address,phone,birth,email,zip_code) values ('seller3','권민경','1111','woman','서울시','01011111111','1994-10-18','nice9010@hanmail.net','11111');
insert into role values ('seller3','ROLE_COP');

-----------------------------------
insert into farmName(farm_id, farm_name) values ('seller1', '승주네농장');
insert into farmName(farm_id, farm_name) values ('seller2', '덕현네농장');
insert into farmName(farm_id, farm_name) values ('seller3', '민경네농장');
------------------------------------
--농장 상품 올리기
insert into farmInfo(farm_id, farm_pcategory, farm_pid, farm_unit, farm_pname, farm_pcount, farm_pprice) values ('seller1', '유제품', farm_pid.nextVal, '개', '달걀', 5000, 200);
insert into farmInfo(farm_id, farm_pcategory, farm_pid, farm_unit, farm_pname, farm_pcount, farm_pprice) values ('seller1', '채소', farm_pid.nextVal, '개', '양파', 5000, 200);
insert into farmInfo(farm_id, farm_pcategory, farm_pid, farm_unit, farm_pname, farm_pcount, farm_pprice) values ('seller1', '채소', farm_pid.nextVal, '개', '당근', 5000, 200);
insert into farmInfo(farm_id, farm_pcategory, farm_pid, farm_unit, farm_pname, farm_pcount, farm_pprice) values ('seller1', '채소', farm_pid.nextVal, '개', '쪽파', 5000, 200);
insert into farmInfo(farm_id, farm_pcategory, farm_pid, farm_unit, farm_pname, farm_pcount, farm_pprice) values ('seller1', '채소', farm_pid.nextVal, '개', '대파', 5000, 200);
insert into farmInfo(farm_id, farm_pcategory, farm_pid, farm_unit, farm_pname, farm_pcount, farm_pprice) values ('seller1', '채소', farm_pid.nextVal, '개', '무', 5000, 200);
insert into farmInfo(farm_id, farm_pcategory, farm_pid, farm_unit, farm_pname, farm_pcount, farm_pprice) values ('seller1', '채소', farm_pid.nextVal, '개', '고추', 5000, 200);
insert into farmInfo(farm_id, farm_pcategory, farm_pid, farm_unit, farm_pname, farm_pcount, farm_pprice) values ('seller1', '채소', farm_pid.nextVal, '개', '버섯', 5000, 200);

insert into farmInfo(farm_id, farm_pcategory, farm_pid, farm_unit, farm_pname, farm_pcount, farm_pprice) values ('seller2', '유제품', farm_pid.nextVal, '개', '달걀', 5000, 350);
insert into farmInfo(farm_id, farm_pcategory, farm_pid, farm_unit, farm_pname, farm_pcount, farm_pprice) values ('seller2', '채소', farm_pid.nextVal, '개', '양파', 5000, 350);
insert into farmInfo(farm_id, farm_pcategory, farm_pid, farm_unit, farm_pname, farm_pcount, farm_pprice) values ('seller2', '채소', farm_pid.nextVal, '개', '당근', 5000, 350);
insert into farmInfo(farm_id, farm_pcategory, farm_pid, farm_unit, farm_pname, farm_pcount, farm_pprice) values ('seller2', '채소', farm_pid.nextVal, '개', '쪽파', 5000, 350);

insert into farmInfo(farm_id, farm_pcategory, farm_pid, farm_unit, farm_pname, farm_pcount, farm_pprice) values ('seller3', '유제품', farm_pid.nextVal, '개', '달걀', 5000, 500);
insert into farmInfo(farm_id, farm_pcategory, farm_pid, farm_unit, farm_pname, farm_pcount, farm_pprice) values ('seller3', '채소', farm_pid.nextVal, '개', '양파', 5000, 500);
insert into farmInfo(farm_id, farm_pcategory, farm_pid, farm_unit, farm_pname, farm_pcount, farm_pprice) values ('seller3', '채소', farm_pid.nextVal, '개', '쪽파', 5000, 500);
insert into farmInfo(farm_id, farm_pcategory, farm_pid, farm_unit, farm_pname, farm_pcount, farm_pprice) values ('seller3', '채소', farm_pid.nextVal, '개', '대파', 5000, 500);
insert into farmInfo(farm_id, farm_pcategory, farm_pid, farm_unit, farm_pname, farm_pcount, farm_pprice) values ('seller3', '채소', farm_pid.nextVal, '개', '버섯', 5000, 500);

--관리자가 귀농인에게 발주
insert into admin_farmer_Order(seq_ordernum, farm_id, farm_pid, farm_pcategory, farm_pname, farm_unit, ordercount, orderprice, orderdate, admin_id, order_ok, okdate)
values(seq_ordernum.nextVal, 'seller1', (select farm_pid from farmInfo where farm_pname='달걀' and farm_id='seller1'), '유제품', '달걀', '개', 5000, 1000000, '2016-06-01', 'admin', 'ok', '2016-06-03');
insert into admin_farmer_Order(seq_ordernum, farm_id, farm_pid, farm_pcategory, farm_pname, farm_unit, ordercount, orderprice, orderdate, admin_id, order_ok, okdate)
values(seq_ordernum.nextVal, 'seller1', (select farm_pid from farmInfo where farm_pname='양파' and farm_id='seller1'), '채소', '양파', '개', 5000, 1000000, '2016-06-01', 'admin', 'ok', '2016-06-03');
insert into admin_farmer_Order(seq_ordernum, farm_id, farm_pid, farm_pcategory, farm_pname, farm_unit, ordercount, orderprice, orderdate, admin_id, order_ok, okdate)
values(seq_ordernum.nextVal, 'seller1', (select farm_pid from farmInfo where farm_pname='당근' and farm_id='seller1'), '채소', '당근', '개', 5000, 1000000, '2016-06-01', 'admin', 'ok', '2016-06-03');
insert into admin_farmer_Order(seq_ordernum, farm_id, farm_pid, farm_pcategory, farm_pname, farm_unit, ordercount, orderprice, orderdate, admin_id, order_ok, okdate)
values(seq_ordernum.nextVal, 'seller1', (select farm_pid from farmInfo where farm_pname='쪽파' and farm_id='seller1'), '채소', '쪽파', '개', 5000, 1000000, '2016-06-01', 'admin', 'ok', '2016-06-03');
insert into admin_farmer_Order(seq_ordernum, farm_id, farm_pid, farm_pcategory, farm_pname, farm_unit, ordercount, orderprice, orderdate, admin_id, order_ok, okdate)
values(seq_ordernum.nextVal, 'seller1', (select farm_pid from farmInfo where farm_pname='대파' and farm_id='seller1'), '채소', '대파', '개', 5000, 1000000, '2016-06-01', 'admin', 'ok', '2016-06-03');
insert into admin_farmer_Order(seq_ordernum, farm_id, farm_pid, farm_pcategory, farm_pname, farm_unit, ordercount, orderprice, orderdate, admin_id, order_ok, okdate)
values(seq_ordernum.nextVal, 'seller1', (select farm_pid from farmInfo where farm_pname='무' and farm_id='seller1'), '채소', '무', '개', 5000, 1000000, '2016-06-01', 'admin', 'ok', '2016-06-03');
insert into admin_farmer_Order(seq_ordernum, farm_id, farm_pid, farm_pcategory, farm_pname, farm_unit, ordercount, orderprice, orderdate, admin_id, order_ok, okdate)
values(seq_ordernum.nextVal, 'seller1', (select farm_pid from farmInfo where farm_pname='고추' and farm_id='seller1'), '채소', '고추', '개', 5000, 1000000, '2016-06-01', 'admin', 'ok', '2016-06-03');
insert into admin_farmer_Order(seq_ordernum, farm_id, farm_pid, farm_pcategory, farm_pname, farm_unit, ordercount, orderprice, orderdate, admin_id, order_ok, okdate)
values(seq_ordernum.nextVal, 'seller1', (select farm_pid from farmInfo where farm_pname='버섯' and farm_id='seller1'), '채소', '버섯', '개', 5000, 1000000, '2016-06-01', 'admin', 'ok', '2016-06-03');

insert into admin_farmer_Order(seq_ordernum, farm_id, farm_pid, farm_pcategory, farm_pname, farm_unit, ordercount, orderprice, orderdate, admin_id, order_ok, okdate)
values(seq_ordernum.nextVal, 'seller2', (select farm_pid from farmInfo where farm_pname='달걀' and farm_id='seller2'), '유제품', '달걀', '개', 5000, 175000, '2016-06-03', 'admin', 'ok', '2016-06-05');
insert into admin_farmer_Order(seq_ordernum, farm_id, farm_pid, farm_pcategory, farm_pname, farm_unit, ordercount, orderprice, orderdate, admin_id, order_ok, okdate)
values(seq_ordernum.nextVal, 'seller2', (select farm_pid from farmInfo where farm_pname='양파' and farm_id='seller2'), '채소', '양파', '개', 5000, 175000, '2016-06-03', 'admin', 'ok', '2016-06-05');
insert into admin_farmer_Order(seq_ordernum, farm_id, farm_pid, farm_pcategory, farm_pname, farm_unit, ordercount, orderprice, orderdate, admin_id, order_ok, okdate)
values(seq_ordernum.nextVal, 'seller2', (select farm_pid from farmInfo where farm_pname='당근' and farm_id='seller2'), '채소', '당근', '개', 5000, 175000, '2016-06-03', 'admin', 'ok', '2016-06-05');
insert into admin_farmer_Order(seq_ordernum, farm_id, farm_pid, farm_pcategory, farm_pname, farm_unit, ordercount, orderprice, orderdate, admin_id, order_ok, okdate)
values(seq_ordernum.nextVal, 'seller2', (select farm_pid from farmInfo where farm_pname='쪽파' and farm_id='seller2'), '채소', '쪽파', '개', 5000, 175000, '2016-06-03', 'admin', 'ok', '2016-06-05');

insert into admin_farmer_Order(seq_ordernum, farm_id, farm_pid, farm_pcategory, farm_pname, farm_unit, ordercount, orderprice, orderdate, admin_id, order_ok, okdate)
values(seq_ordernum.nextVal, 'seller3', (select farm_pid from farmInfo where farm_pname='달걀' and farm_id='seller3'), '유제품', '달걀', '개', 5000, 2500000, '2016-07-01', 'admin', 'ok', '2016-07-03');
insert into admin_farmer_Order(seq_ordernum, farm_id, farm_pid, farm_pcategory, farm_pname, farm_unit, ordercount, orderprice, orderdate, admin_id, order_ok, okdate)
values(seq_ordernum.nextVal, 'seller3', (select farm_pid from farmInfo where farm_pname='양파' and farm_id='seller3'), '채소', '양파', '개', 5000, 2500000, '2016-07-01', 'admin', 'ok', '2016-07-03');
insert into admin_farmer_Order(seq_ordernum, farm_id, farm_pid, farm_pcategory, farm_pname, farm_unit, ordercount, orderprice, orderdate, admin_id, order_ok, okdate)
values(seq_ordernum.nextVal, 'seller3', (select farm_pid from farmInfo where farm_pname='쪽파' and farm_id='seller3'), '채소', '쪽파', '개', 5000, 2500000, '2016-07-01', 'admin', 'ok', '2016-07-03');
insert into admin_farmer_Order(seq_ordernum, farm_id, farm_pid, farm_pcategory, farm_pname, farm_unit, ordercount, orderprice, orderdate, admin_id, order_ok, okdate)
values(seq_ordernum.nextVal, 'seller3', (select farm_pid from farmInfo where farm_pname='대파' and farm_id='seller3'), '채소', '대파', '개', 5000, 2500000, '2016-07-01', 'admin', 'ok', '2016-07-03');
insert into admin_farmer_Order(seq_ordernum, farm_id, farm_pid, farm_pcategory, farm_pname, farm_unit, ordercount, orderprice, orderdate, admin_id, order_ok, okdate)
values(seq_ordernum.nextVal, 'seller3', (select farm_pid from farmInfo where farm_pname='버섯' and farm_id='seller3'), '채소', '버섯', '개', 5000, 2500000, '2016-07-01', 'admin', 'ok', '2016-07-03');



--재고에 insert
insert into stockManage(product_id, product_category, product_name, product_price, product_totalcount, product_unit, product_from, product_regdate, product_status)
values((select farm_pid from farmInfo where farm_pname='달걀' and farm_id='seller1'), '유제품', '달걀', 200, 5000, '개', 'seller1', '2016-06-03', 1);
insert into stockManage(product_id, product_category, product_name, product_price, product_totalcount, product_unit, product_from, product_regdate, product_status)
values((select farm_pid from farmInfo where farm_pname='양파' and farm_id='seller1'), '채소', '양파', 200, 5000, '개', 'seller1', '2016-06-03', 1);
insert into stockManage(product_id, product_category, product_name, product_price, product_totalcount, product_unit, product_from, product_regdate, product_status)
values((select farm_pid from farmInfo where farm_pname='당근' and farm_id='seller1'), '채소', '당근', 200, 5000, '개', 'seller1', '2016-06-03', 1);
insert into stockManage(product_id, product_category, product_name, product_price, product_totalcount, product_unit, product_from, product_regdate, product_status)
values((select farm_pid from farmInfo where farm_pname='쪽파' and farm_id='seller1'), '채소', '쪽파', 200, 5000, '개', 'seller1', '2016-06-03', 1);
insert into stockManage(product_id, product_category, product_name, product_price, product_totalcount, product_unit, product_from, product_regdate, product_status)
values((select farm_pid from farmInfo where farm_pname='대파' and farm_id='seller1'), '채소', '대파', 200, 5000, '개', 'seller1', '2016-06-03', 1);
insert into stockManage(product_id, product_category, product_name, product_price, product_totalcount, product_unit, product_from, product_regdate, product_status)
values((select farm_pid from farmInfo where farm_pname='무' and farm_id='seller1'), '채소', '무', 200, 5000, '개', 'seller1', '2016-06-03', 1);
insert into stockManage(product_id, product_category, product_name, product_price, product_totalcount, product_unit, product_from, product_regdate, product_status)
values((select farm_pid from farmInfo where farm_pname='고추' and farm_id='seller1'), '채소', '고추', 200, 5000, '개', 'seller1', '2016-06-03', 1);
insert into stockManage(product_id, product_category, product_name, product_price, product_totalcount, product_unit, product_from, product_regdate, product_status)
values((select farm_pid from farmInfo where farm_pname='버섯' and farm_id='seller1'), '채소', '버섯', 200, 5000, '개', 'seller1', '2016-06-03', 1);

insert into stockManage(product_id, product_category, product_name, product_price, product_totalcount, product_unit, product_from, product_regdate, product_status)
values((select farm_pid from farmInfo where farm_pname='달걀' and farm_id='seller2'), '유제품', '달걀', 350, 5000, '개', 'seller2', '2016-06-05', 1);
insert into stockManage(product_id, product_category, product_name, product_price, product_totalcount, product_unit, product_from, product_regdate, product_status)
values((select farm_pid from farmInfo where farm_pname='양파' and farm_id='seller2'), '채소', '양파', 350, 5000, '개', 'seller2', '2016-06-05', 1);
insert into stockManage(product_id, product_category, product_name, product_price, product_totalcount, product_unit, product_from, product_regdate, product_status)
values((select farm_pid from farmInfo where farm_pname='당근' and farm_id='seller2'), '채소', '당근', 350, 5000, '개', 'seller2', '2016-06-05', 1);
insert into stockManage(product_id, product_category, product_name, product_price, product_totalcount, product_unit, product_from, product_regdate, product_status)
values((select farm_pid from farmInfo where farm_pname='쪽파' and farm_id='seller2'), '채소', '쪽파', 350, 5000, '개', 'seller2', '2016-06-05', 1);

insert into stockManage(product_id, product_category, product_name, product_price, product_totalcount, product_unit, product_from, product_regdate, product_status)
values((select farm_pid from farmInfo where farm_pname='달걀' and farm_id='seller3'), '유제품', '달걀', 500, 5000, '개', 'seller3', '2016-07-03', 1);
insert into stockManage(product_id, product_category, product_name, product_price, product_totalcount, product_unit, product_from, product_regdate, product_status)
values((select farm_pid from farmInfo where farm_pname='양파' and farm_id='seller3'), '채소', '양파', 500, 5000, '개', 'seller3', '2016-07-03', 1);
insert into stockManage(product_id, product_category, product_name, product_price, product_totalcount, product_unit, product_from, product_regdate, product_status)
values((select farm_pid from farmInfo where farm_pname='쪽파' and farm_id='seller3'), '채소', '쪽파', 500, 5000, '개', 'seller3', '2016-07-03', 1);
insert into stockManage(product_id, product_category, product_name, product_price, product_totalcount, product_unit, product_from, product_regdate, product_status)
values((select farm_pid from farmInfo where farm_pname='대파' and farm_id='seller3'), '채소', '대파', 500, 5000, '개', 'seller3', '2016-07-03', 1);
insert into stockManage(product_id, product_category, product_name, product_price, product_totalcount, product_unit, product_from, product_regdate, product_status)
values((select farm_pid from farmInfo where farm_pname='버섯' and farm_id='seller3'), '채소', '버섯', 500, 5000, '개', 'seller3', '2016-07-03', 1);

--마트
insert into stockManage(product_id, product_category, product_name, product_price, product_totalcount, product_unit, product_from, product_regdate, product_status)
values(farm_Pid.nextVal, '소스', '식용유', 10, 10000, 'g', '이마트', '2016-07-01', 2);
insert into admin_mart_order(mart_name, mart_pid, mart_pname, mart_ordercount, mart_orderprice, mart_unit, mart_orderdate, admin_id)
values('이마트', (select max(product_id) from stockManage), '식용유', 10000, 100000, 'g', '2016-07-01', 'admin');

insert into stockManage(product_id, product_category, product_name, product_price, product_totalcount, product_unit, product_from, product_regdate, product_status)
values(farm_Pid.nextVal, '소스', '고춧가루', 10, 10000, 'g', '이마트', '2016-07-01', 2);
insert into admin_mart_order(mart_name, mart_pid, mart_pname, mart_ordercount, mart_orderprice, mart_unit, mart_orderdate, admin_id)
values('이마트', (select max(product_id) from stockManage), '고춧가루', 10000, 100000, 'g', '2016-07-01', 'admin');

insert into stockManage(product_id, product_category, product_name, product_price, product_totalcount, product_unit, product_from, product_regdate, product_status)
values(farm_Pid.nextVal, '소스', '생강', 10, 10000, 'g', '이마트', '2016-07-01', 2);
insert into admin_mart_order(mart_name, mart_pid, mart_pname, mart_ordercount, mart_orderprice, mart_unit, mart_orderdate, admin_id)
values('이마트', (select max(product_id) from stockManage), '생강', 10000, 100000, 'g', '2016-07-01', 'admin');

insert into stockManage(product_id, product_category, product_name, product_price, product_totalcount, product_unit, product_from, product_regdate, product_status)
values(farm_Pid.nextVal, '소스', '마늘', 10, 10000, 'g', '롯데마트', '2016-07-01', 2);
insert into admin_mart_order(mart_name, mart_pid, mart_pname, mart_ordercount, mart_orderprice, mart_unit, mart_orderdate, admin_id)
values('롯데마트', (select max(product_id) from stockManage), '마늘', 10000, 100000, 'g', '2016-07-01', 'admin');

insert into stockManage(product_id, product_category, product_name, product_price, product_totalcount, product_unit, product_from, product_regdate, product_status)
values(farm_Pid.nextVal, '소스', '소금', 10, 10000, 'g', '롯데마트', '2016-07-01', 2);
insert into admin_mart_order(mart_name, mart_pid, mart_pname, mart_ordercount, mart_orderprice, mart_unit, mart_orderdate, admin_id)
values('롯데마트', (select max(product_id) from stockManage), '소금', 10000, 100000, 'g', '2016-07-01', 'admin');

insert into stockManage(product_id, product_category, product_name, product_price, product_totalcount, product_unit, product_from, product_regdate, product_status)
values(farm_Pid.nextVal, '소스', '설탕', 10, 10000, 'g', '롯데마트', '2016-07-01', 2);
insert into admin_mart_order(mart_name, mart_pid, mart_pname, mart_ordercount, mart_orderprice, mart_unit, mart_orderdate, admin_id)
values('롯데마트', (select max(product_id) from stockManage), '설탕', 10000, 100000, 'g', '2016-07-01', 'admin');

---------------------------------------
--상품 골라담기 insert(2개)
insert into farm_products(s_title, id, s_no, s_contentfile, s_thumbfile, s_price, s_incomerate, s_dose, s_unit, s_category) 
values('승주네당근','admin',(select farm_pid from farmInfo where farm_id='seller1' and farm_pname='당근'),'carrot2.PNG','carrot1.PNG', 220, 10,1,'개','야채');

insert into farm_products(s_title, id, s_no, s_contentfile, s_thumbfile, s_price, s_incomerate, s_dose, s_unit, s_category) 
values('승주네무','admin',(select farm_pid from farmInfo where farm_id='seller1' and farm_pname='무'),'radish11.PNG','radish22.PNG', 220,10,1,'개','야채');
---------------------------------------
--레시피/테마 insert(1개)
insert into recipe_theme_products(p_title, id, p_no, p_contentfile, p_thumbfile, p_price, p_regdate, p_category1, p_category2, p_incomerate, p_src)
values('달걀말이','admin',farm_Pid.nextval, 'egg1.jpg','egg2.jpg',5500,'2016-07-26','밑반찬','달콤한 오후', 10, 'yXI3lCicoYU');
insert into recipe_table(product_id, product_name, p_no, dose, unit)
values((select farm_pid from farmInfo where farm_id='seller1' and farm_pname='달걀'),'달걀',(select max(p_no) from recipe_theme_products), 4, '개');
insert into recipe_table(product_id, product_name, p_no, dose, unit)
values((select farm_pid from farmInfo where farm_id='seller2' and farm_pname='달걀'),'달걀',(select max(p_no) from recipe_theme_products), 4, '개');
insert into recipe_table(product_id, product_name, p_no, dose, unit)
values((select farm_pid from farmInfo where farm_id='seller3' and farm_pname='달걀'),'달걀',(select max(p_no) from recipe_theme_products), 4, '개');

insert into recipe_table(product_id, product_name, p_no, dose, unit)
values((select farm_pid from farmInfo where farm_id='seller1' and farm_pname='양파'),'양파',(select max(p_no) from recipe_theme_products), 10, '개');
insert into recipe_table(product_id, product_name, p_no, dose, unit)
values((select farm_pid from farmInfo where farm_id='seller2' and farm_pname='양파'),'양파',(select max(p_no) from recipe_theme_products), 10, '개');
insert into recipe_table(product_id, product_name, p_no, dose, unit)
values((select farm_pid from farmInfo where farm_id='seller3' and farm_pname='양파'),'양파',(select max(p_no) from recipe_theme_products), 10, '개');

insert into recipe_table(product_id, product_name, p_no, dose, unit)
values((select farm_pid from farmInfo where farm_id='seller1' and farm_pname='당근'),'당근',(select max(p_no) from recipe_theme_products), 10, '개');
insert into recipe_table(product_id, product_name, p_no, dose, unit)
values((select farm_pid from farmInfo where farm_id='seller2' and farm_pname='당근'),'당근',(select max(p_no) from recipe_theme_products), 10, '개');

insert into recipe_table(product_id, product_name, p_no, dose, unit)
values((select farm_pid from farmInfo where farm_id='seller1' and farm_pname='쪽파'),'쪽파',(select max(p_no) from recipe_theme_products), 1, '개');
insert into recipe_table(product_id, product_name, p_no, dose, unit)
values((select farm_pid from farmInfo where farm_id='seller2' and farm_pname='쪽파'),'쪽파',(select max(p_no) from recipe_theme_products), 1, '개');
insert into recipe_table(product_id, product_name, p_no, dose, unit)
values((select farm_pid from farmInfo where farm_id='seller3' and farm_pname='쪽파'),'쪽파',(select max(p_no) from recipe_theme_products), 1, '개');

insert into recipe_table(product_id, product_name, p_no, dose, unit)
values((select product_id from stockManage where product_name='식용유'),'식용유',(select max(p_no) from recipe_theme_products), 3, '개');
insert into recipe_table(product_id, product_name, p_no, dose, unit)
values((select product_id from stockManage where product_name='소금'),'소금',(select max(p_no) from recipe_theme_products), 1, '개');
insert into recipe_table(product_id, product_name, p_no, dose, unit)
values((select product_id from stockManage where product_name='설탕'),'설탕',(select max(p_no) from recipe_theme_products), 1, '개');
----------------------------------------
--공지사항 글 1
insert into notice_board(n_no, n_title, n_writer, n_regdate, n_hit, n_contents) values (notice_board_seq.nextVal, '구매이용약관 개정', '관리자', '2015-07-26', 0, 
'안녕하세요?<br>
최상의 식자재 배달 서비스, The Chef 입니다.<br>
항상 The Chef를 이용해 주시고 사랑해 주시는 고객님들께 감사의 말씀을 드립니다.<br><br>

2015년 8월 24일부터 당사의 구매이용약관이 아래와 같이 개정됩니다.<br>
(*약관 변경 적용일까지 거부 의사를 표시하지 않으면, 약관의 변경에 동의한 것으로 간주합니다.)<br>
 The Chef에서 제공하는 서비스를 통하여 거래가 성사 되었을 때 회사는 판매자와 구매자 간에 물품거래와 배송 등의 이행과 관련하여<br>
필요한 범위 내에서 이용자의 구매자의 개인정보를 판매자에게 제공합니다.<br>');
insert into board_comment(n_no, comment_seq, comment_name, comment_comm, comment_regdate) values ((select max(n_no) from notice_board), COMMENT_SEQ.nextVal, 'user1', '좋은 정보 감사합니다', '2015-08-26');
insert into board_comment(n_no, comment_seq, comment_name, comment_comm, comment_regdate) values ((select max(n_no) from notice_board), COMMENT_SEQ.nextVal, 'user2', '감사합니다^^', '2015-09-26');
insert into board_comment(n_no, comment_seq, comment_name, comment_comm, comment_regdate) values ((select max(n_no) from notice_board), COMMENT_SEQ.nextVal, 'user3', '사이트 자주 이용하고 있습니다^^', '2015-10-28');
--공지사항 글 2
insert into notice_board(n_no, n_title, n_writer, n_regdate, n_hit, n_contents) values (notice_board_seq.nextVal, '서비스 정기 점검 공지','관리자', '2015-08-20', 0, 
'
안녕하세요. The Chef 입니다.<br><br>
보다 안정적인 서비스 제공을 위해, 아래 기간 동안 서비스 정기 점검 예정이며<br>
해당 기간 동안 가입이 일시 중단됩니다.<br>

■ 중단 일정 : 2015년 9월 26일(일) 00:00 ~ 06:00 (총 6시간)<br>
■ 상세내용<br>
- 사업자 구매회원으로의 가입 및 전환이 불가합니다.<br>
- 이외의 회원 가입 및 전환은 정상적으로 이용 가능합니다.<br><br>

앞으로도 보다 나은 서비스 혜택을 드릴 수 있는 The Chef가 되도록 노력하겠습니다.<br>
감사합니다.<br>
'
);
insert into board_comment(n_no, comment_seq, comment_name, comment_comm, comment_regdate) values ((select max(n_no) from notice_board), COMMENT_SEQ.nextVal, 'user1', '이용 참고 하겠습니다', '2015-09-05');
insert into board_comment(n_no, comment_seq, comment_name, comment_comm, comment_regdate) values ((select max(n_no) from notice_board), COMMENT_SEQ.nextVal, 'user2', '감사합니다^^', '2015-09-10');
insert into board_comment(n_no, comment_seq, comment_name, comment_comm, comment_regdate) values ((select max(n_no) from notice_board), COMMENT_SEQ.nextVal, 'user3', '알겠습니다^^', '2015-09-20');
--공지사항 글 3
insert into notice_board(n_no, n_title, n_writer, n_regdate, n_hit, n_contents) values (notice_board_seq.nextVal, '사이트 점검 공지','관리자', '2016-07-01', 0, 
'
안녕하세요. The Chef 입니다.<br><br>
 
항상 The Chef를 이용해 주시고 사랑해 주시는 회원님께 감사의 말씀을 드립니다.<br>
보다 안정적인 서비스 제공을 위해, 아래 기간 동안 시스템 점검이 진행될 예정입니다.<br><br>
 
■ The Chef 점검시간 :<br>
2016년 7월 26일(화) 04:00~05:00 (약 1시간)<br><br>
 
앞으로도 보다 나은 서비스 혜택을 드릴 수 있는 The Chef가 되도록 노력하겠습니다.<br>
감사합니다<br>
'
);
insert into board_comment(n_no, comment_seq, comment_name, comment_comm, comment_regdate) values ((select max(n_no) from notice_board), COMMENT_SEQ.nextVal, 'user1', '참고 하겠습니다.', '2016-07-02');
insert into board_comment(n_no, comment_seq, comment_name, comment_comm, comment_regdate) values ((select max(n_no) from notice_board), COMMENT_SEQ.nextVal, 'user2', '알겠습니다', '2016-07-03');
insert into board_comment(n_no, comment_seq, comment_name, comment_comm, comment_regdate) values ((select max(n_no) from notice_board), COMMENT_SEQ.nextVal, 'user3', '알겠습니다!!', '2016-07-04');
-------------------------------------
--귀농팁1
insert into event_board(e_no, e_title, e_writer, e_regdate, e_hit, e_contents) values (event_board_seq.nextVal, '귀농 이렇게 하면 망한다!', '귀농인A', '2016-02-04', 0, 
'
<h5>현장을 딛고 공부부터 해라</h5><br> 
도시와 농촌은 환경, 생활방식 등 삶 자체가 완전히 다르다. 따라서 귀농·귀촌 준비를 위해서는 사전교육이 필수다. <br>
준비 단계부터 차근차근 해야 할 공부가 수두룩하다. 농어업에서 새로운 일자리를 찾고 농어촌에서 살려면 하나부터 열까지 모든 걸 배워야 한다.<br>
새로운 삶을 시작하는 만큼 사전준비와 결심 단계까지 꼼꼼한 공부가 이뤄져야 한다.<br>
한국귀농귀촌진흥원이 추진하는 핵심 사업은 바로 귀농·귀촌 교육이다.<br>
전문가들은 적어도 귀농을 결심하고 실행에 옮기까지 3∼5년, 귀농 후에도 적응하는데 2∼3년이 걸린다는 생각으로 배워 나가야 한다고 입을 모은다.<br> 
'
);
insert into event_comment(e_no, comment_seq, comment_name, comment_comm, comment_regdate) values ((select max(e_no) from event_board), COMMENT_SEQ.nextVal, 'user1', '참고 하겠습니다.', '2016-07-02');
insert into event_comment(e_no, comment_seq, comment_name, comment_comm, comment_regdate) values ((select max(e_no) from event_board), COMMENT_SEQ.nextVal, 'user2', '소중한 팁 감사합니다.', '2016-07-02');
insert into event_comment(e_no, comment_seq, comment_name, comment_comm, comment_regdate) values ((select max(e_no) from event_board), COMMENT_SEQ.nextVal, 'user3', '좋은 정보입니다^^.', '2016-07-05');
--귀농팁2
insert into event_board(e_no, e_title, e_writer, e_regdate, e_hit, e_contents) values (event_board_seq.nextVal, '대박노리지 말고 소박하게 시작해라', '귀농인B', '2016-02-25', 0, 
'
<h5>대박노리지 말고 소박하게!!</h5><br> 
농촌에 살면서 농사를 짓는 것은 굉장히 고달프고 힘든 삶이다.<br>  
불볕더위와 강추위를 견뎌야 하는 것은 물론 각종 악조건 속에서도 힘든 노동이 쉼없이 이어지는 현실을 받아들여야 한다. <br> 
도시처럼 일한 만큼 금방 수입으로 이어지는 구조도 아니다. 논밭에 작물을 심고 피땀을 흘리고 공을 들여야 작물이 서서히 자란다. <br> 
작물은 커녕 잡초만 무성한 땅만 바라볼 수도 있다. <br> 
귀농 직후 초기에는 아예 수입은 포기해야 한다며 실패의 쓴잔을 마셔본 선배들은 훈수한다.<br> 
귀농 6년차이면서 충북 영동군귀농협의회를 이끄는 최규찬(60) 회장은 "농촌에 대한 막연한 동경이나 일단 부딪혀 보자는 막무가내식 귀농은 실패로 이어질 확률이 높다"고 경고했다.<br> 
'
);
insert into event_comment(e_no, comment_seq, comment_name, comment_comm, comment_regdate) values ((select max(e_no) from event_board), COMMENT_SEQ.nextVal, 'user1', '좋은 정보 감사합니다', '2016-06-02');
insert into event_comment(e_no, comment_seq, comment_name, comment_comm, comment_regdate) values ((select max(e_no) from event_board), COMMENT_SEQ.nextVal, 'user2', '소중한 팁 감사합니다.', '2016-06-02');
insert into event_comment(e_no, comment_seq, comment_name, comment_comm, comment_regdate) values ((select max(e_no) from event_board), COMMENT_SEQ.nextVal, 'user3', '도움 많이 되었습니다', '2016-06-05');
--귀농팁3
insert into event_board(e_no, e_title, e_writer, e_regdate, e_hit, e_contents) values (event_board_seq.nextVal, '이웃과 어울리고 가족은 뭉쳐야 ', '귀농인C', '2016-03-01', 0, 
'
<h5>이웃과 어울리고 가족은 뭉쳐야</h5><br> 
경남 창녕군은 지난해부터 지역 귀농귀촌인과 주민 간 화합 한마당 행사를 열고 있다.<br> 
그 만큼 귀농 귀촌인이 주민 속으로 쉽게 파고들지 못한다는 증거다.<br> 
도시생활에 익숙하던 귀농·귀촌인은 농촌 원주민과는 아예 생활 습관이나 문화·정서에서 큰 거리감을 느낀다.<br> 
김영기 울산시 농업정책과 사무관은 "귀농 준비가 부족하고 귀농 마을 주민과 유대관계를 제대로 형성하지 못하면 실패한다"고 조언했다.<br> 
이질감이 깊어질수록 귀농귀촌인은 적응에 힘들어하고 주민은 배척감만 생긴다.<br> 
막걸리 한통으로도 주민 속에 파고드는 노력이 필요하다. <br> 
더 중요한 것은 부부 일체감 형성이다. 귀농·귀촌 전에 충분히 교감하고 마음을 맞춰야 한다.<br> 
'
);
insert into event_comment(e_no, comment_seq, comment_name, comment_comm, comment_regdate) values ((select max(e_no) from event_board), COMMENT_SEQ.nextVal, 'user1', '감사합니다', '2016-05-02');
insert into event_comment(e_no, comment_seq, comment_name, comment_comm, comment_regdate) values ((select max(e_no) from event_board), COMMENT_SEQ.nextVal, 'user2', '소중한 정보 입니다^^', '2016-05-02');
insert into event_comment(e_no, comment_seq, comment_name, comment_comm, comment_regdate) values ((select max(e_no) from event_board), COMMENT_SEQ.nextVal, 'user3', '감사합니다^^', '2016-05-05');
---------------------------------------------
--수다톡1
insert into talk_board(t_no, t_title, t_writer, t_regdate, t_hit, t_contents) values (talk_board_seq.nextVal, '간편하게 해 먹을 수 있는 요리 추천해주세요!','김소연','2016-02-07',0,
'
	요즘 시간이 부족해 끼니를 거른 적이 많습니다ㅠㅠ<br>
	간편하고 빠르게 해 먹을 수 있는 요리 추천 부탁드려요^^<br>
'
);
--수다톡2
insert into talk_board(t_no, t_title, t_writer, t_regdate, t_hit, t_contents) values (talk_board_seq.nextVal, '사이트 이용 잘 하고 갑니다^^','김수영','2016-02-10',0,
'
	자취생이여서 그런지 이러한 사이트를 얼마나 원했는 지 몰라요ㅠㅠ<br>
	사이트 잘 이용하고 갑니다!<br> 
	앞으로도 많이 이용할께요!!<br>
'
);
--수다톡3
insert into talk_board(t_no, t_title, t_writer, t_regdate, t_hit, t_contents) values (talk_board_seq.nextVal, '빠른 업데이트 부탁드립니다!','김희석','2016-02-15',0,
'
	요 몇 달간 계속 이 사이트를 이용하고 있는 자취생입니다!<br>
	이미 올려져 있는 레시피를 다 한번씩 구매해서 만들어 보았는데요<br>
	다른 맛있는 음식도 많이 해보고 싶습니다<br>
	빠른 업데이트 부탁드릴께요^^<br>
'
);
----------------------------------------------
--요리톡 1 - 나만의 레시피   cookrecipe_seq
insert into cook_recipe(k_title, id, k_no, k_content, k_contentfile, k_thumbfile, k_regdate, k_category, k_like, k_hit) values 
('맛있는 된장찌개 만들기', 'user1', cookrecipe_seq.nextVal, 
'
1. 재료는 미리 먹기좋은 크기로 썰어서 준비해 놓는다.<br>
2. 멸치육수가 끓으면 멸치는 건져주고 된장을 푼다.<br>
3. 고추가루 한스푼, 그리고 썰어놓은 야채들을 넣어준다<br>
4. 끓을때 두부 넣고 팔팔 끓여주면 끝<br>
', 'doenjang2.PNG','doenjang1.PNG', '2016-01-05', '밥', 5, 10);
insert into cookrecipe_review(kr_no, id, reg_date, score, kr_review, kr_title) values ((select max(k_no) from cook_recipe), 'user2', '2016-07-02', 5, '정말 맛있습니다!!', '황금레시피예요^^');
insert into cookrecipe_review(kr_no, id, reg_date, score, kr_review, kr_title) values ((select max(k_no) from cook_recipe), 'user3', '2016-07-03', 5, '꼭 해먹어 보세요!!', '굳굳!!');
--요리톡 2
insert into cook_recipe(k_title, id, k_no, k_content, k_contentfile, k_thumbfile, k_regdate, k_category, k_like, k_hit) values 
('김치찌개 황금 레시피', 'user2', cookrecipe_seq.nextVal, 
'
1. 삼겹살은 식용유 약간 두른 팬에 달달 볶습니다.<br>
2. 청주 살짝 넣어 볶다 신김치도 넣고 설탕도 넣어 달달 볶아주세요.<br>
3. 김치 숨이 죽으면 육수를 붓고 양념도 넣어 한소끔 끓입니다.<br>
4. 나머지 재료 모두 넣어서 취향에 따라 5 ~ 20분 끓여 냅니다.<br>
', 'kimchi2.PNG','kimchi1.PNG', '2016-01-10', '밥', 2, 10);
insert into cookrecipe_review(kr_no, id, reg_date, score, kr_review, kr_title) values ((select max(k_no) from cook_recipe), 'user1', '2016-07-05', 3, '살짝 싱거운듯 합니다', '맛이...');
insert into cookrecipe_review(kr_no, id, reg_date, score, kr_review, kr_title) values ((select max(k_no) from cook_recipe), 'user3', '2016-07-10', 1, '저의 입맛에는 맞지 않는거 같아요ㅠㅠ', '비추천 입니다');
----------------------------------------------

