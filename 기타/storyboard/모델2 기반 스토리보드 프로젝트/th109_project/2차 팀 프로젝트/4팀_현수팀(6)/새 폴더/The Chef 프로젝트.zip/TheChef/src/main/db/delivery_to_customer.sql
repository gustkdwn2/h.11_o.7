drop table delivery_to_customer;

create table delivery_to_customer
(	
   d_orderNum number(30) primary key,
   d_shipping_fee number(30),
   d_total_price number(30),
   d_status number(10) default 1,
   id varchar2(1000) not null,
   reg_date date default sysdate
);
delete from delivery_to_customer;
delete from check_out;
select * from delivery_to_customer

select * from check_out;
select * from DELIVERY_TO_CUSTOMER;