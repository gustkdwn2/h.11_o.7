package com.kosta.project;

import java.security.Principal;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.kosta.project.dao.IAdmin_farm_orderDao;
import com.kosta.project.dao.ISellerDao;
import com.kosta.project.dto.AdminFarmOrderDTO;
import com.kosta.project.dto.SellerDTO;

@Controller
public class Admin_farm_orderController {
   
   @Autowired
   SqlSession sqlSession;
   
   @RequestMapping(value="/insertProductOrder")//관리자가 발주하기 버튼을 클릭했을 때, back/saleManage/productOrder.jsp에서 온다.
   public String insertProductOrder(HttpServletRequest request,AdminFarmOrderDTO dto,Principal principal){
      System.out.println("insertproductOrder");
      IAdmin_farm_orderDao dao = sqlSession.getMapper(IAdmin_farm_orderDao.class);
      dto.setOrderPrice(Integer.parseInt(request.getParameter("orderCount"))*Integer.parseInt(request.getParameter("farm_Pprice")));
      System.out.println(dto.getOrderPrice());
      dto.setAdmin_id(principal.getName());
      dto.setFarm_Pcategory(request.getParameter("farm_Pcategory"));//카테고리 받아오기
      dto.setFarm_unit(request.getParameter("farm_unit"));//단위 받아오기
      dao.insertProductOrder(dto);
      
      return "redirect:/productOrder";
   }
   @RequestMapping("updateOrderOk")
   public String updateOrderOk(HttpServletRequest request,SellerDTO dto,Model model){ 
      int seq_ordernum=Integer.parseInt(request.getParameter("seq_ordernum"));
      IAdmin_farm_orderDao dao = sqlSession.getMapper(IAdmin_farm_orderDao.class);
      dao.updateOrderOk(seq_ordernum);
      ////////////////////////////////
      int orderCount = Integer.parseInt(request.getParameter("orderCount")); // 발주요청수량
      String farm_Pid = request.getParameter("farm_Pid");
      
      Map map = new HashMap();
      map.put("orderCount", orderCount);
      map.put("farm_Pid", farm_Pid);
      
      ISellerDao sdao = sqlSession.getMapper(ISellerDao.class);
      sdao.updateProductCount(map);
      
      model.addAttribute("pg", request.getParameter("pg"));
      
      return "redirect:/sellerPage";
   }
   //판매자에게 발주
   @RequestMapping(value="/productOrder")
      public String productOrder(Locale locale, Model model){
         System.out.println("productOrder");
         ISellerDao dao = sqlSession.getMapper(ISellerDao.class);
         model.addAttribute("farmList",dao.selectAll());
         return "back.saleManage.productOrder";
      }
   @RequestMapping("/orderManage")
   public String orderSendManage(Model model, HttpServletRequest request) {
      System.out.println("orderSendManage()");
      
      
      /////////////////////발주상품확인해야할거_판매자가 발송한상태/////////////////////////////////////////////////////////
      IAdmin_farm_orderDao adao = sqlSession.getMapper(IAdmin_farm_orderDao.class);
      //model.addAttribute("OrderOkList",adao.adminOrderAllY());
      int pg = 1;
      String strPg = request.getParameter("pg");
      if (strPg != null) {
         pg = Integer.parseInt(strPg);
      }
      int rowSize = 4;
      int start = (pg * rowSize) - (rowSize - 1);
      int end = pg * rowSize;

      int total = adao.adminOrderCountY(); // 총 게시물수

      int allPage = (int) Math.ceil(total / (double) rowSize); // 페이지수

      int block = 5; // 한페이지에 보여줄 범위 << [1] [2] [3] [4] [5] >>
      int fromPage = ((pg - 1) / block * block) + 1; // 보여줄 페이지의 시작
      // ((1-1)/10*10)
      int toPage = ((pg - 1) / block * block) + block; // 보여줄 페이지의 끝
      if (toPage > allPage) {
         toPage = allPage;
      }

      HashMap<String, Object> map = new HashMap<String, Object>();
      map.put("start", start);
      map.put("end", end);
      
      List<AdminFarmOrderDTO> OrderOkList = adao.adminOrderAllY(map);
      System.out.println("pg : "+pg);
      System.out.println("total : "+total);
      System.out.println("allPage : "+allPage);
      System.out.println("block : "+block);
      System.out.println("fromPage : "+fromPage);
      System.out.println("toPage : "+toPage);
      
      model.addAttribute("OrderOkList", OrderOkList);
      model.addAttribute("pg", pg);
      model.addAttribute("allPage", allPage);
      model.addAttribute("block", block);
      model.addAttribute("fromPage", fromPage);
      model.addAttribute("toPage", toPage);
       
      ////////////////////발주상품전체보기///////////////////////////////////////////////////////////////////////
       //model.addAttribute("OrderAllList",adao.adminOrderAllList());
       int pg1 = 1;
      String strPg1 = request.getParameter("pg1");
      if (strPg1 != null) {
         pg1 = Integer.parseInt(strPg1);
      }
      int rowSize1 = 4;
      int start1 = (pg1 * rowSize1) - (rowSize1 - 1);
      int end1 = pg1 * rowSize1;
      int total1 = adao.adminOrderCountAll(); // 총 게시물수

      int allPage1 = (int) Math.ceil(total1 / (double) rowSize1); // 페이지수

      int block1 = 5; // 한페이지에 보여줄 범위 << [1] [2] [3] [4] [5] >>
      int fromPage1 = ((pg1 - 1) / block1 * block1) + 1; // 보여줄 페이지의 시작
      // ((1-1)/10*10)
      int toPage1 = ((pg1 - 1) / block1 * block1) + block1; // 보여줄 페이지의 끝
      if (toPage1 > allPage1) {
         toPage1 = allPage1;
      }

      HashMap<String, Object> map1 = new HashMap<String, Object>();
      map1.put("start1", start1);
      map1.put("end1", end1);
      
      List<AdminFarmOrderDTO> OrderAllList = adao.adminOrderAllList(map1);
      System.out.println("pg1 : "+pg1);
      System.out.println("total1 : "+total1);
      System.out.println("allPage1 : "+allPage1);
      System.out.println("block1 : "+block1);
      System.out.println("fromPage1 : "+fromPage1);
      System.out.println("toPage1 : "+toPage1);
      
      model.addAttribute("OrderAllList", OrderAllList);
      model.addAttribute("pg1", pg1);
      model.addAttribute("allPage1", allPage1);
      model.addAttribute("block1", block1);
      model.addAttribute("fromPage1", fromPage1);
      model.addAttribute("toPage1", toPage1);
       
      return "back.saleManage.orderManage";
   }
   
}