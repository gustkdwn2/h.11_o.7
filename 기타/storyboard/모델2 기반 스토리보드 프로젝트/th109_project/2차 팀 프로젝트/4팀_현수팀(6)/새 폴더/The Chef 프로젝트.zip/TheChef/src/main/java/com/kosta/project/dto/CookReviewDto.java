package com.kosta.project.dto;

public class CookReviewDto {
	private String kr_no;
	private String id;
	private String reg_date;
	private int score;
	private String kr_review;
	private String kr_title;
	
	public CookReviewDto() {}

	public CookReviewDto(String kr_no, String id, String reg_date, int score, String kr_review, String kr_title) {
		this.kr_no = kr_no;
		this.id = id;
		this.reg_date = reg_date;
		this.score = score;
		this.kr_review = kr_review;
		this.kr_title = kr_title;
	}

	public String getKr_no() {
		return kr_no;
	}

	public void setKr_no(String kr_no) {
		this.kr_no = kr_no;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getreg_date() {
		return reg_date;
	}

	public void setreg_date(String reg_date) {
		this.reg_date = reg_date;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	public String getKr_review() {
		return kr_review;
	}

	public void setKr_review(String kr_review) {
		this.kr_review = kr_review;
	}

	public String getKr_title() {
		return kr_title;
	}

	public void setKr_title(String kr_title) {
		this.kr_title = kr_title;
	}
	
	
}
