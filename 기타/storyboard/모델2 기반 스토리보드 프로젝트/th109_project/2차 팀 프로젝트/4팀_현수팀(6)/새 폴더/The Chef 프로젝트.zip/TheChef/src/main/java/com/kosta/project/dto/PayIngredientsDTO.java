package com.kosta.project.dto;

public class PayIngredientsDTO {
	String id, p_no, product_id;
	int d_orderNum;
	
	public PayIngredientsDTO() {}

	public PayIngredientsDTO(String id, String p_no, String product_id, int d_orderNum) {
		this.id = id;
		this.p_no = p_no;
		this.product_id = product_id;
		this.d_orderNum = d_orderNum;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getP_no() {
		return p_no;
	}

	public void setP_no(String p_no) {
		this.p_no = p_no;
	}

	public String getProduct_id() {
		return product_id;
	}

	public void setProduct_id(String product_id) {
		this.product_id = product_id;
	}

	public int getD_orderNum() {
		return d_orderNum;
	}

	public void setD_orderNum(int d_orderNum) {
		this.d_orderNum = d_orderNum;
	}
	
	
}
