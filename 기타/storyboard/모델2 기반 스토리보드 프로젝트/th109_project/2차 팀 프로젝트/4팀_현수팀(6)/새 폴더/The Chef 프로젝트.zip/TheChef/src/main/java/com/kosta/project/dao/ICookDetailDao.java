package com.kosta.project.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.kosta.project.dto.CookRecipeDto;
import com.kosta.project.dto.CookReviewDto;
import com.kosta.project.dto.LikeDTO;


public interface ICookDetailDao {
   //요리톡 테마 상품 상세정보
   public List<CookRecipeDto> cookList(@Param("_k_no") String k_no);
   
   //요리톡 리뷰부분
   public List<CookReviewDto> cookreviewList(@Param("_kr_no") String kr_no);
   
   //요리톡 페이징처리
   public List<CookReviewDto> searchOnePage(@Param("_kr_no") String kr_no, @Param("_startRow") int startRow, @Param("_endRow") int endRow);
   
   //리뷰 등록 부분(요리톡)
   public void insertReview3(CookReviewDto dto);
   
   //조회수 증가
   public void updateHit(@Param("_k_no") String k_no);
   
   //가장 인기있는 상품 찾기
   public List<LikeDTO> findHot_no();
}