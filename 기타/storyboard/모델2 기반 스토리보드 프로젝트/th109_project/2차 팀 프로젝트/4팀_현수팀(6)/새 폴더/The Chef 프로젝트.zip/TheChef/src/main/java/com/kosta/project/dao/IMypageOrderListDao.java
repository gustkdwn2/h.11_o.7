package com.kosta.project.dao;

import java.util.HashMap;
import java.util.List;

import com.kosta.project.dto.CheckOutDTO;

public interface IMypageOrderListDao {
      // 목록보기
      public List<CheckOutDTO> list(HashMap<String, Object> map);
      // 아이디로 구매관련 정보 가져오기
      public List<CheckOutDTO> idselectAll(HashMap<String, Object> map);
      
      public int getidselectAll_Count(HashMap<String, Object> map);
      
      // 구매테이블 구매취소
      public void chkout_cancel(String c_orderNum);
      // 발송테이블 구매취소
      public void delivery_cancel(String d_orderNum);
    //구매확정시
     public void orderconfirm(String parameter);
     
     //구매테이블의 상태 c_status=3
     public void cancelrequest(String orderNum);
     
     //발송테이블의 상태 d_status=4
     public void cancelrequest2(String orderNum);
     
     public void orderconfirm_c_status(String orderNum);
}