drop table check_out
select * from check_out;
delete check_out;
create table check_out (
   c_orderNum number(30),
   c_no varchar2(100) not null,
   c_name varchar2(100) not null,
   id varchar2(1000) not null,
   reg_date date default sysdate,
   c_price number(30), -- 제품 하나당 가격
   count number(30),
   name varchar2(100),
   c_address varchar2(500),
   c_zip_code varchar2(100),
   c_phone varchar2(100),
   c_status number(10) default 1
);
select * from STOCKMANAGE;
create sequence orderNum_seq;
drop sequence orderNum_seq;

-- c_no : 상품 구매 번호
-- id : 상품 구매 id
-- reg_date : 상품 구매 일시
-- c_price : 상품 가격
-- count : 상품 개수
-- shipping_fee : 배송비
-- c_total_price : 총 가격
-- c_name : 구매자 이름
-- c_address: 받을 사람 주소
-- c_zip_code : 받는 사람 우편번호
-- c_phone : 구매자의 핸드폰 번호