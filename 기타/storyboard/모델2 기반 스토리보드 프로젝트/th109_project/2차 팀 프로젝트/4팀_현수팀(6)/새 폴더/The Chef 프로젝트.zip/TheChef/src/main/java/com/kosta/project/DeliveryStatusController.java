package com.kosta.project;

import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller        
public class DeliveryStatusController {

	@Autowired
	private SqlSession sqlSession;

	// 상품현황관리 페이지
	@RequestMapping(value = "/deliveryStatus")
	public String deliveryStatus(Locale locale, Model model, HttpServletRequest request) {
		System.out.println("deliveryStatus()");

		return "back.saleManage.deliveryStatus";
	}
}
