package com.kosta.project;

import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.kosta.project.dao.IMembersDAO;

import net.nurigo.java_sdk.api.Message;
import net.nurigo.java_sdk.exceptions.CoolsmsException;

@Controller
public class pwdFindController {
   
   @Autowired
   SqlSession sqlSession;
   
   //pwd찾기//
   @RequestMapping(value = "/pwdFind")
   public String pwdFind(HttpServletRequest request, Model model){
      System.out.println("pwdFind()");
      
      String random = request.getParameter("random");
      String id = request.getParameter("id");
      String phone = request.getParameter("phone");
      String password = request.getParameter("password");
      
      System.out.println("random : " + random);
      System.out.println("id : " + id);
      System.out.println("phone : " + phone);
      System.out.println("password : "+password);
      
      if(random == null){
         random = "0";
         System.out.println("random2 : " + random);
      }
      
      model.addAttribute("id", id); //id넘겨주기
      model.addAttribute("random",random);//난수값 넘겨주기
      model.addAttribute("phone",phone);
      model.addAttribute("password",password);
      
      return "front.member.pwdFind";
   }
   
   
   @RequestMapping("/smssend")
   public String smsSend(HttpServletRequest request,Model model){
      
      System.out.println("smssend()");
      int random=0;
      String id = request.getParameter("id");
      String phone = request.getParameter("phone");
      System.out.println("id : " + id);
      System.out.println("phone : " + phone);
      
      IMembersDAO dao = sqlSession.getMapper(IMembersDAO.class);
      String password = dao.checkPWD(id);//pwd값을 얻는다.
      System.out.println("password : " + password);
      
      String index; // password가 있는지 없는지 여부
      
      if(password != null) {
         index = "yes";
         
         String api_key = "NCS5761934B5E9E0";
           String api_secret = "A907456E427CE1692FC8470D0107BE33";
           Message coolsms = new Message(api_key, api_secret);

           // 인증번호
         random = (int) (Math.floor(Math.random() * 1000000)+100000);
         if(random>1000000){
            random = random - 100000;
         }
           
           // 4 params(to, from, type, text) are mandatory. must be filled
           HashMap<String, String> params = new HashMap<String, String>();
           params.put("to", request.getParameter("phone")); // 수신번호
           params.put("from", "01020568213"); // 발신번호 
           params.put("type", "SMS"); // Message type ( SMS, LMS, MMS, ATA )
           params.put("text", "인증번호["+random+"]"); // 문자내용    
           params.put("app_version", "JAVA SDK v2.2"); // application name and version
           
           try {
               JSONObject obj = (JSONObject) coolsms.send(params);
               System.out.println(obj.toString());
             } catch (CoolsmsException e) {
               System.out.println(e.getMessage());
               System.out.println(e.getCode());
             }
      }else{
         index="no";
         System.out.println("아이디에 해당하는 정보가 없습니다.");
      }
      
      model.addAttribute("id", id); //id넘겨주기
      model.addAttribute("random",random);//난수값 넘겨주기
      model.addAttribute("phone",phone);
      model.addAttribute("password",password);
      model.addAttribute("index",index);
        
      return "front.member.pwdFind";
   }
}