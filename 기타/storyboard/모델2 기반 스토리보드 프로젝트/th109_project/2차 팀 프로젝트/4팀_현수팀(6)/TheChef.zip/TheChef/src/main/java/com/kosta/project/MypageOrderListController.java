package com.kosta.project;

import java.security.Principal;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.kosta.project.dao.IMypageOrderListDao;
import com.kosta.project.dto.CheckOutDTO;

@Controller
public class MypageOrderListController {

   @Autowired
   private SqlSession sqlSession;

   // 주문내역 조회
   @RequestMapping("/orderList")
   public String orderList() {
      return "front.mypage.orderList";
   }

   List<CheckOutDTO> paymentList; //

   @RequestMapping(value = "search_orderList")
   public String search_orderList(HttpServletRequest request, Principal principal, Model model) {

      /*
       * IMypageOrderListDao icdao =
       * sqlSession.getMapper(IMypageOrderListDao.class);
       */

      /* String id = principal.getName(); // 로그인한 아이디를 가져옴 */
      /*
       * for (int i = 0; i < paymentList.size(); i++) { codto = new
       * CheckOutDTO();//dto 객체 비우기 codto.setId(paymentList.get(i).getId());
       * codto.setC_name(paymentList.get(i).getC_name());
       * codto.setC_no(paymentList.get(i).getC_no());
       * codto.setC_price(paymentList.get(i).getC_price());
       * codto.setCount(paymentList.get(i).getCount());
       * codto.setName(paymentList.get(i).getName());
       * codto.setC_address(paymentList.get(i).getC_address());
       * codto.setC_zip_code(paymentList.get(i).getC_zip_code());
       * codto.setC_phone(paymentList.get(i).getC_phone()); } //
       */
      /*
       * dao.insertCheckOut(codto);//그 다음 구매 테이블에 insert //
       */

      ///////////////////////////////////////////////////////////////////////////

      IMypageOrderListDao icdao = sqlSession.getMapper(IMypageOrderListDao.class);
      HashMap<String, Object> map = new HashMap<String, Object>(); // hashmap
                                                      // 선언
      String id = principal.getName();

      // map에 값을 입력
      map.put("id", id);
      map.put("dateFrom", request.getParameter("dateFrom"));
      map.put("dateTo", request.getParameter("dateTo"));

      String searchData = request.getParameter("searchData");
      if (searchData != "") {
         System.out.println("내가실행되나1?");
         map.put("searchData", searchData);
      } else {
         System.out.println("내가실행되나2?");
         map.put("searchData", searchData);
      }

      System.out.println("id:" + principal.getName());
      System.out.println("searchData:" + request.getParameter("searchData"));

      /*
       * 
       * String orderStatus = request.getParameter("orderStatus"); if(
       * orderStatus!=""){ if(orderStatus.equals("ready")){
       * map.put("orderStatus", 1); }else
       * if(orderStatus.equals("deleivering")){ map.put("orderStatus", 2);
       * }else if(orderStatus.equals("complete")){ map.put("orderStatus", 3);
       * } }else map.put("orderStatus",request.getParameter("orderStatus"));
       * 
       * String searchby = request.getParameter("searchby"); if( searchby
       * !=""){ map.put("searchby", request.getParameter("searchby_value"));
       * }else map.put("searchby", searchby);
       * 
       * map.put("dataFrom", request.getParameter("dataFrom"));
       * map.put("dataTo", request.getParameter("dataTo"));
       */

      int pg = 1;
      String strPg = request.getParameter("pg");
      if (strPg != null) {
         pg = Integer.parseInt(strPg);
      }
      int rowSize = 10;
      int start = (pg * rowSize) - (rowSize - 1);
      int end = pg * rowSize;

      map.put("start", start);
      map.put("end", end);

      System.out.println("여까지오는가?");

      List<CheckOutDTO> codto1 = icdao.idselectAll(map); // 여기서 로그인 한 아이디의 모든
                                             // 정보가 codto1에 담긴다.
      // collect(toList())는 스트림의 값들을 리스트로 만들어서 반환하는 즉각적인 연산
      // CheckOutDTO에 있는 c_orderNum을 이용해서 그룹화 한다 => orderNum이 하나만 출력될 수 있는 부분
      Map<Integer, List<CheckOutDTO>> resultMap = codto1.stream().collect(Collectors.groupingBy(CheckOutDTO::getC_orderNum, Collectors.toList()));
      int total = icdao.getidselectAll_Count(map);

      System.out.println("total.size:" + total);
      int allPage = (int) Math.ceil(total / (double) rowSize); // 페이지수

      int block = 5; // 한페이지에 보여줄 범위 << [1] [2] [3] [4] [5] >>
      int fromPage = ((pg - 1) / block * block) + 1; // 보여줄 페이지의 시작
      // ((1-1)/10*10)
      int toPage = ((pg - 1) / block * block) + block; // 보여줄 페이지의 끝
      if (toPage > allPage) {
         toPage = allPage;
      }

      Calendar calendar = Calendar.getInstance();
      SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
      String fname = dateFormat.format(calendar.getTime());

      ////////// paging할때 값물고가게 하려고 추가해준부분///////////////

      model.addAttribute("dateFrom", request.getParameter("dateFrom"));
      model.addAttribute("dateTo", request.getParameter("dateTo"));
      model.addAttribute("searchData", request.getParameter("searchData"));
      ////////////////////////////////////////////////////////////////

      // System.out.println("???????"+codto1.get(0).getC_orderNum());
      // System.out.println(codto1.get(0).getC_name());
      // System.out.println(codto1.get(0).getC_price());

      model.addAttribute("fname", fname);
      model.addAttribute("resultMap", resultMap);
      model.addAttribute("pg", pg);
      model.addAttribute("allPage", allPage);
      model.addAttribute("block", block);
      model.addAttribute("fromPage", fromPage);
      model.addAttribute("toPage", toPage);
      // model.addAttribute("list", codto1);
      return "front.mypage.orderList";
   }

   @RequestMapping(value = "orderCancel")
   public String orderCancel(HttpServletRequest request, Model model) {
      IMypageOrderListDao imodao = sqlSession.getMapper(IMypageOrderListDao.class); // DB연동
      System.out.println("orderCancel()");
      String orderNum = request.getParameter("c_orderNum");
      String c_status = request.getParameter("c_status");
      String dateFrom = request.getParameter("dateFrom");
      String dateTo = request.getParameter("dateTo");
      String searchData = request.getParameter("searchData");
      String pg = request.getParameter("pg");
      System.out.println("orderNum:" + orderNum);
      System.out.println("c_status:" + c_status);

      if (c_status.equals("1")) {
         System.out.println("여기 들어오니?");
         imodao.chkout_cancel(orderNum); // 구매테이블 삭제
         imodao.delivery_cancel(orderNum); // 발송테이블 삭제
      } else {
         System.out.println("??????");
         imodao.cancelrequest(orderNum); // 취소요청
         imodao.cancelrequest2(orderNum); // 취소요청
      }
      
      return "redirect:/search_orderList?dateFrom=" + dateFrom + "&dateTo=" + dateTo + "&searchData=" + searchData + "&pg=" + pg;
   }

   @RequestMapping(value = "orderCancel2")
   public String orderCancel2(HttpServletRequest request, Model model) {
      IMypageOrderListDao imodao = sqlSession.getMapper(IMypageOrderListDao.class); // DB연동

      String orderNum = request.getParameter("c_orderNum");
      String d_status = request.getParameter("d_status");// 4

      System.out.println("orderNum:" + orderNum);
      System.out.println("d_status:" + d_status);

      imodao.chkout_cancel(orderNum); // 구매테이블 삭제
      imodao.delivery_cancel(orderNum); // 발송테이블에서 삭제

      ////////// paging할때 값물고가게 하려고 추가해준부분///////////////

      model.addAttribute("dateFrom", request.getParameter("dateFrom"));
      model.addAttribute("dateTo", request.getParameter("dateTo"));
      model.addAttribute("searchData", request.getParameter("searchData"));
      model.addAttribute("pg", request.getParameter("pg"));
      ////////////////////////////////////////////////////////////////

      return "redirect:/cancelPage";
   }

   @RequestMapping(value = "orderConfirm")
   public String orderConfirm(HttpServletRequest request, Model model) {
      System.out.println("orderConfirm");

      IMypageOrderListDao icdao = sqlSession.getMapper(IMypageOrderListDao.class);
      String orderNum = request.getParameter("c_orderNum");
      icdao.orderconfirm(orderNum);
      icdao.orderconfirm_c_status(orderNum); // 구매확정시 c_status가 4가 되게 수정

      ////////// paging할때 값물고가게 하려고 추가해준부분///////////////

      model.addAttribute("dateFrom", request.getParameter("dateFrom"));
      model.addAttribute("dateTo", request.getParameter("dateTo"));
      model.addAttribute("searchData", request.getParameter("searchData"));
      model.addAttribute("pg", request.getParameter("pg"));
      ////////////////////////////////////////////////////////////////

      return "redirect:/search_orderList";
   }
}