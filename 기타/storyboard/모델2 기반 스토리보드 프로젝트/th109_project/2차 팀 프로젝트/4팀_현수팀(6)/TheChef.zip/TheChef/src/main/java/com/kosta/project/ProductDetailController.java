package com.kosta.project;

import java.security.Principal;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.kosta.project.dao.IDetailDao;
import com.kosta.project.dto.CheckOutDTO;
import com.kosta.project.dto.FarmReviewDTO;
import com.kosta.project.dto.MinPriceDTO;
import com.kosta.project.dto.PayIngredientsDTO;
import com.kosta.project.dto.RecipeReviewDTO;
import com.kosta.project.dto.StockManageJoinRecipeDTO;
import com.kosta.project.dto.SubtractStockDTO;

@Controller
public class ProductDetailController {

   @Autowired
   private SqlSession sqlSession;

   @RequestMapping("/recipe_details") //레시피 테마 리스트에서 클릭하였을 때 상세 페이지
   public String recipe_details(HttpServletRequest request, Model model, Principal principal) throws Exception {
      request.setCharacterEncoding("utf-8");
      System.out.println("recipe_details()");

      String p_no = request.getParameter("p_no");
      int code = Integer.parseInt(request.getParameter("code"));
      
      IDetailDao dao = sqlSession.getMapper(IDetailDao.class);
      
      List recipeList = dao.rtpList(p_no);
      List<StockManageJoinRecipeDTO> ingredients = dao.ingredientsList(p_no);
      
	  List<MinPriceDTO> minPriceByingredient = dao.minPriceByingredient(p_no);//상품이름이랑 최소 가격 뽑아오기
	  
	  model.addAttribute("minPriceByingredient", minPriceByingredient);
	  for (int i = 0; i < minPriceByingredient.size(); i++) {
		  System.out.println("최소가격 재료 이름 : " + minPriceByingredient.get(i).getProduct_name());
		  System.out.println("해당 재료 최소가격 : " + minPriceByingredient.get(i).getProduct_price());
	}
	  for (int i = 0; i < ingredients.size(); i++) {
		  System.out.println("재료 가격 : " + ingredients.get(i).getProduct_price());
		  System.out.println("상품번호 : " + ingredients.get(i).getProduct_id());
	}
	  //model.addAttribute("productName", productName);//돼지고기, 고기 등등 분류 위해서
      model.addAttribute("ingredients_list", ingredients);
      model.addAttribute("ingredients", ingredients);
      model.addAttribute("list", recipeList);
      //////////////////////////카트에 담겨있는 모든 f_no 뽑아서 리스트에 담기
      List cartF_no = dao.cartF_no();//장바구니에 있는 모든 번호 가지고 오기
      
      if(cartF_no.size() != 0){
    	  model.addAttribute("cartF_no", cartF_no);
    	  model.addAttribute("cart_size", cartF_no.size());
      } else {//장바구니에 상품이 하나도 없을 때
    	  model.addAttribute("cart_size", 0);
      }
      
      //////////////// review 부분//////////////////
      List reviewList = dao.reviewList(p_no);

      ////////////////////////////////////////////////////////////
      // page 처리 부분// 상품 리뷰부분 paging 처리!///
      int pageSize = 7;
      int Allcount = 0, count1 = 0;

      String pageNum = request.getParameter("pageNum");
      if (pageNum == null) {
         pageNum = "1";
      }
      System.out.println("pageNum : " + pageNum);

      int currentPage = Integer.parseInt(pageNum);
      System.out.println("currentPage : " + currentPage);

      int startRow = (currentPage * pageSize) - 6;// 8번부터 2페이지
      System.out.println("startRow: " + startRow);

      int endRow = currentPage * pageSize;// 1*20
      System.out.println("endRow: " + endRow);

      Allcount = reviewList.size();// 전체 관심상품 목록 개수
      System.out.println("Allcount: " + Allcount);
      //////////////////////////////////////////////
      List searchOnePageList = null;

      searchOnePageList = dao.searchOnePage(p_no, startRow, endRow);// 1~7
      count1 = searchOnePageList.size();// 5
      System.out.println("searchOnePageCount: " + count1);
      
      model.addAttribute("code", new Integer(code));
      model.addAttribute("count1", new Integer(count1));
      model.addAttribute("searchOnePageList", searchOnePageList);// jsp에 뿌릴
                                                   // 리스트
      /////////////////////////
      model.addAttribute("currentPage", new Integer(currentPage));
      model.addAttribute("startRow", new Integer(startRow));
      model.addAttribute("endRow", new Integer(endRow));
      model.addAttribute("Allcount", new Integer(Allcount));
      model.addAttribute("pageSize", new Integer(pageSize));

      return "front.recipe_theme.recipe_details";
   }

   @RequestMapping("/farm_details") //상품 골라담기에서 클릭하였을 때 상세페이지
   public String farmProduct_details(HttpServletRequest request, Model model, Principal principal) throws Exception {
      request.setCharacterEncoding("utf-8");
      System.out.println("farm_details()");

      String s_no = request.getParameter("s_no");
      String s_dose = request.getParameter("s_dose");
      String s_unit = request.getParameter("s_unit");
      
      int code = Integer.parseInt(request.getParameter("code"));
      
      IDetailDao dao = sqlSession.getMapper(IDetailDao.class);
      List farmList = dao.farmList(s_no);
      
      List productCode = dao.farmStock(s_no);
      if(productCode.size() != 0){//해당 상품을 구입 가능할 때
    	  System.out.println("productCode : " + productCode.get(0));
    	  model.addAttribute("productCode", productCode);
    	  int availableCount = dao.availableCount(s_no);
    	  model.addAttribute("size",availableCount);//구매가능한 재고 개수
      } else {
    	  model.addAttribute("productCode", "none");
      }
      model.addAttribute("s_dose", s_dose);
      model.addAttribute("s_unit", s_unit);
      model.addAttribute("list", farmList);
      //////////////// review 부분//////////////////
      List reviewList2 = dao.reviewList2(s_no);

      ////////////////////////////////////////////////////////////
      // page 처리 부분// 상품 리뷰부분 paging 처리!///
      int pageSize = 7;
      int Allcount = 0, count1 = 0;

      String pageNum = request.getParameter("pageNum");
      if (pageNum == null) {
         pageNum = "1";
      }
      System.out.println("pageNum : " + pageNum);

      int currentPage = Integer.parseInt(pageNum);
      System.out.println("currentPage : " + currentPage);

      int startRow = (currentPage * pageSize) - 6;// 8번부터 2페이지
      System.out.println("startRow: " + startRow);

      int endRow = currentPage * pageSize;// 1*20
      System.out.println("endRow: " + endRow);

      Allcount = reviewList2.size();// 전체 관심상품 목록 개수
      System.out.println("Allcount: " + Allcount);
      //////////////////////////////////////////////
      List searchOnePageList = null;

      searchOnePageList = dao.searchOnePage(s_no, startRow, endRow);// 1~7
      count1 = searchOnePageList.size();// 5
      System.out.println("searchOnePageCount: " + count1);
      
      model.addAttribute("code", new Integer(code));
      model.addAttribute("count1", new Integer(count1));
      model.addAttribute("searchOnePageList", searchOnePageList);// jsp에 뿌릴
                                                   // 리스트
      /////////////////////////
      model.addAttribute("currentPage", new Integer(currentPage));
      model.addAttribute("startRow", new Integer(startRow));
      model.addAttribute("endRow", new Integer(endRow));
      model.addAttribute("Allcount", new Integer(Allcount));
      model.addAttribute("pageSize", new Integer(pageSize));

      return "front.farmProduct.farm_details";
   }
   
   @RequestMapping("/review_write")
   public String review_write(HttpServletRequest request, Model model, Principal principal) throws Exception{
      request.setCharacterEncoding("utf-8");
      System.out.println("review_write()");
      
      String p_no = request.getParameter("p_no");
      int code = Integer.parseInt(request.getParameter("code"));
      
      model.addAttribute("p_no", p_no);
      model.addAttribute("id", principal.getName());
      model.addAttribute("code", code);
      
      return "front.recipe_theme.review_write";
   }
   
   @RequestMapping("/review_write2")
   public String review_write2(HttpServletRequest request, Model model, Principal principal) throws Exception{
      request.setCharacterEncoding("utf-8");
      System.out.println("review_write2()");
      
      String p_no = request.getParameter("p_no");
      int code = Integer.parseInt(request.getParameter("code"));
      
      model.addAttribute("s_no", p_no);
      model.addAttribute("id", principal.getName());
      model.addAttribute("code", code);
      
      return "front.farmProduct.review_write";
   }
   
   @RequestMapping("/listAfterWrite")
   public String listAfterWrite(HttpServletRequest request, Model model, Principal principal) throws Exception{
      request.setCharacterEncoding("utf-8");
      System.out.println("listAfterWrite()");
      
      String p_no = request.getParameter("p_no");
      String id = request.getParameter("id");
      String r_review = request.getParameter("r_review");
      String r_title = request.getParameter("r_title");
      int r_score = Integer.parseInt(request.getParameter("r_score"));
      int code = Integer.parseInt(request.getParameter("code"));
      
      RecipeReviewDTO dto = new RecipeReviewDTO();
      dto.setR_no(p_no);
      dto.setId(id);
      dto.setR_review(r_review);
      dto.setR_title(r_title);
      dto.setScore(r_score);

      IDetailDao dao = sqlSession.getMapper(IDetailDao.class);
      dao.insertReview(dto);
      
      return "redirect:/recipe_details?p_no=" + p_no + "&code=" + code;
   }
   
   @RequestMapping("/listAfterWrite2")
   public String listAfterWrite2(HttpServletRequest request, Model model, Principal principal) throws Exception{
      request.setCharacterEncoding("utf-8");
      System.out.println("listAfterWrite2()");
      
      String p_no = request.getParameter("s_no");
      String id = request.getParameter("id");
      String r_review = request.getParameter("r_review");
      String r_title = request.getParameter("r_title");
      int r_score = Integer.parseInt(request.getParameter("r_score"));
      int code = Integer.parseInt(request.getParameter("code"));
      
      FarmReviewDTO dto = new FarmReviewDTO();
      dto.setFr_no(p_no);
      dto.setId(id);
      dto.setFr_review(r_review);
      dto.setFr_title(r_title);
      dto.setScore(r_score);

      IDetailDao dao = sqlSession.getMapper(IDetailDao.class);
      dao.insertReview2(dto);
      
      return "redirect:/farm_details?s_no=" + p_no + "&code=" + code;
   }
   
   
   CheckOutDTO dto = new CheckOutDTO();
   List<CheckOutDTO> list;
   List<String> ingredients_list;
   int distinguish;//상품 상세보기에서 결제하기를 눌렀는지 장바구니에서 결제하기를 눌렀는지 구분해주는 변수, 1일때는 레시피/테마 상품 상세보기에서 주문, 2일때는 상품골라담기에서 주문,3일때는장바구니에서 주문
   @RequestMapping("/check_out_rtp")//레시피/테마 상품 상세보기에서 주문하기 눌렀을 때
   public String check_out_rtp(HttpServletRequest request, Model model, Principal principal) throws Exception{
      request.setCharacterEncoding("utf-8");
      System.out.println("check_out()");
      distinguish = 1;//레시피/테마 상품 상세보기에서 결제
      
      String product_id[] = request.getParameterValues("product_id");
      String c_no = request.getParameter("p_no");
      int count = Integer.parseInt(request.getParameter("quantity"));
      int c_price = Integer.parseInt(request.getParameter("p_price"));//배송비를 뺀 총 결제금액
      String id = principal.getName();
      String c_name = request.getParameter("c_name");
      
      int shipping_fee;
      if(c_price >= 10000){
         shipping_fee=0;
      } else {
         shipping_fee=2500;
      }
      
      int c_total_price = c_price + shipping_fee;//배송비 포함한 총 결제 금액
      int code = Integer.parseInt(request.getParameter("code"));
      String p_thumbFile = request.getParameter("p_thumbFile");
      
      list = new ArrayList<CheckOutDTO>();
      ingredients_list = new ArrayList<String>();
      
      //IDetailDao dao = sqlSession.getMapper(IDetailDao.class);
      for (int i = 0; i < product_id.length; i++) {
    	  ingredients_list.add(product_id[i]);
	}
      
      dto = new CheckOutDTO();
      System.out.println("for문 처음");
      
      dto.setP_thumbFile(p_thumbFile);
      dto.setCode(code);
      
      dto.setC_no(c_no);
      dto.setC_name(c_name);
      dto.setCount(count);
      dto.setC_price(c_price/count);//레시피를 한개 샀을 때의 가격
      dto.setId(id);
      
      list.add(dto);
      /*dao.insertCheckOut(dto);*/
      model.addAttribute("list", list);
      //model.addAttribute("ingredients_list",ingredients_list);
      model.addAttribute("c_total_price", c_total_price);
      model.addAttribute("shipping_fee",shipping_fee);//배송비
      
      return "front.cart.check_out2";
   }
   @RequestMapping("/check_out_farm")//골라담기 상품 상세보기에서 주문하기 눌렀을 때
   public String check_out_farm(HttpServletRequest request, Model model, Principal principal) throws Exception{
      request.setCharacterEncoding("utf-8");
      System.out.println("check_out_farm()");
      distinguish = 2;//상품 골라담기 상세보기에서 결제
      
      String c_no = request.getParameter("p_no");
      int count = Integer.parseInt(request.getParameter("quantity"));
      int c_price = Integer.parseInt(request.getParameter("p_price"));//재료 하나당 가격, 개수 뺀 가격
      String id = principal.getName();
      String c_name = request.getParameter("c_name");
      
      int shipping_fee;
      if((c_price * count) >= 10000){//구매 금액이 10000원 이상이면
         shipping_fee=0;//배송비 0원
      } else {
         shipping_fee=2500;
      }
      
      int c_total_price = (c_price*count) + shipping_fee;//총 결제 금액
      int code = Integer.parseInt(request.getParameter("code"));
      String p_thumbFile = request.getParameter("p_thumbFile");
      
      list = new ArrayList<CheckOutDTO>();
      
      //IDetailDao dao = sqlSession.getMapper(IDetailDao.class);
      
      dto = new CheckOutDTO();
      
      dto.setP_thumbFile(p_thumbFile);
      dto.setCode(code);
      
      dto.setC_no(c_no);
      dto.setC_name(c_name);
      dto.setCount(count);
      dto.setC_price(c_price);//개당 가격
      dto.setId(id);
      
      list.add(dto);
      /*dao.insertCheckOut(dto);*/
      model.addAttribute("list", list);
      //model.addAttribute("ingredients_list",ingredients_list);
      model.addAttribute("c_total_price", c_total_price);
      model.addAttribute("shipping_fee",shipping_fee);//배송비
      
      return "front.cart.check_out2";
   }
   
   @RequestMapping("/check_out2")//장바구니에서 결제를 눌렀을 때
   public String check_out2(HttpServletRequest request, Model model, Principal principal) throws Exception{
      request.setCharacterEncoding("utf-8");
      System.out.println("check_out2()");
      distinguish = 3;//장바구니에서 결제
      
      int price=0;
      String c_no[] = request.getParameterValues("p_no");
      String count[] = request.getParameterValues("quantity");
      String c_price[] = request.getParameterValues("p_price");//개당 가격
      String total_price[] = request.getParameterValues("total_price");//갯수 * 가격
      String c_name[] = request.getParameterValues("c_name");
      String p_thumbFile[] = request.getParameterValues("p_thumbFile");
      String code[] = request.getParameterValues("code");
      
      String id = principal.getName();
      int shipping_fee;
      
      System.out.println("for문 전");
      for (int i = 0; i < total_price.length; i++) {
         price = price + Integer.parseInt(total_price[i]); //갯수 * 가격의 누적 합
         System.out.println("price : " + price);
      }
      if(price >= 10000){
         shipping_fee=0;
      } else {
         shipping_fee=2500;
      }
      int c_total_price = price + shipping_fee;//총 결제 금액
      IDetailDao dao = sqlSession.getMapper(IDetailDao.class);
      list = new ArrayList<CheckOutDTO>();//다시 장바구니 클릭, 상품 선택 후 결제 눌렀을 때 전에 목록을 지우려면 리스트를 비우고 시작
      for (int j = 0; j < c_no.length; j++) {
         dto = new CheckOutDTO();
         System.out.println("for문 처음");
         dto.setId(id);
         dto.setC_no(c_no[j]);
         dto.setC_price(Integer.parseInt(c_price[j]));//개당 가격
         System.out.println("c_price["+j+"] = " + c_price[j]);
         System.out.println("for문 중간");
         dto.setC_name(c_name[j]);
         dto.setCount(Integer.parseInt(count[j]));
         dto.setP_thumbFile(p_thumbFile[j]);
         dto.setCode(Integer.parseInt(code[j]));
         //dto.setC_tPrice(Integer.parseInt(total_price[j]));
         
         list.add(dto);
         //dao.insertFirst(dto);
         System.out.println("for문 마지막");
      }
      
      //List list = dao.selectFirst(dto);
      model.addAttribute("list", list);
      model.addAttribute("c_total_price",c_total_price);//총 금액
      model.addAttribute("shipping_fee",shipping_fee);//배송비
      System.out.println("check_out2로 보내기 직전");
      
      return "front.cart.check_out2";
   }
   
   List<CheckOutDTO> paymentList;
   int random = 0;
   @RequestMapping("/payment")//결제 테이블에 insert
   public String payment(HttpServletRequest request, Model model, Principal principal) throws Exception{
      request.setCharacterEncoding("utf-8");
      System.out.println("payment()");
	  IDetailDao dao = sqlSession.getMapper(IDetailDao.class);

      String name = request.getParameter("name");
      String c_address = request.getParameter("address1") +" "+ request.getParameter("address2");
      System.out.println("c_address : " + c_address);
      String c_zip_code = request.getParameter("zip_code");
      String c_phone = request.getParameter("phone1") + 
            request.getParameter("phone2")
            + request.getParameter("phone3");
      int c_total_price=0;//배송비 포함한 최종 금액
      int sum=0;//배송비 제외한 최종 금액
      int shipping_fee=0;//배송비
      
      paymentList = new ArrayList<>();
      for (int i = 0; i < list.size(); i++) {
         dto = new CheckOutDTO();//dto 객체 비우기
         dto.setId(list.get(i).getId());
         dto.setC_name(list.get(i).getC_name());
         dto.setC_no(list.get(i).getC_no());
         dto.setC_price(list.get(i).getC_price());
         dto.setCount(list.get(i).getCount());
         dto.setName(name);
         dto.setC_address(c_address);
         dto.setC_zip_code(c_zip_code);
         dto.setC_phone(c_phone);
         
         List isRecipeTheme = dao.isRecipeTheme(list.get(i).getC_no());//이 상품 번호가 레시피/테마 테이블에 있는지 확인
         System.out.println("isRecipeTheme : " + isRecipeTheme);
         
         System.out.println("c_price : " + list.get(i).getC_price());
         System.out.println("배송비 뺀 총 금액 : " + (list.get(i).getC_price()*list.get(i).getCount()));
         sum += (list.get(i).getC_price()*list.get(i).getCount());
         paymentList.add(dto);
         //dao.insertCheckOut(dto);
      }
      System.out.println("sum : " + sum);
      if(sum>=10000){
         shipping_fee=0;
      } else {
         shipping_fee=2500;
      }
      
      c_total_price = shipping_fee + sum;
      System.out.println("c_total_price : " + c_total_price);
      //List paymentList = dao.paymentList(dto);
      
      random = (int) (Math.floor(Math.random() * 1000000)+100000);
	  if(random>1000000){
		random = random - 100000;
	  }
	  
	  System.out.println("생성된 random 값 : " + random);
      
      model.addAttribute("random", random);
      model.addAttribute("list", paymentList);
      model.addAttribute("c_total_price", c_total_price);
      System.out.println("payment.jsp로 가기 직전");
      
      return "front.cart.payment";
   }
   
   @RequestMapping("/paymentFail") //결제 실패 시 디비에서 지운다
   public String paymentFail(HttpServletRequest request, Model model, Principal principal) throws Exception{
      request.setCharacterEncoding("utf-8");
      System.out.println("paymentFail()");
      
      //String c_no = request.getParameter("c_no");
      //String id = request.getParameter("id");
      
      IDetailDao dao = sqlSession.getMapper(IDetailDao.class);
      
      //dao.deleteCheckOut(c_no, id);
      
      return "front.cart.paymentFail";
   }
   @RequestMapping("/receipt")
   public String a(HttpServletRequest request, Model model, Principal principal) throws Exception {
	   request.setCharacterEncoding("utf-8");
	   System.out.println("receipt()");
	   List<SubtractStockDTO> ingredientsAndProductId;
	   IDetailDao dao = sqlSession.getMapper(IDetailDao.class);
	   int random2 = Integer.parseInt(request.getParameter("random"));
	   if(random == random2){
	      int subtotal=0, shipping_fee=0;
	      
	      for (int i = 0; i < paymentList.size(); i++) {
	         subtotal += (paymentList.get(i).getC_price() * paymentList.get(i).getCount());
	      }
	      
	      if(subtotal>=10000){
	         shipping_fee=0;
	      } else {
	         shipping_fee=2500;
	      }
	      dao.insertDelivery(subtotal, shipping_fee, principal.getName());//발송 테이블에 먼저 insert
	      System.out.println("발송 테이블에 insert 완료");
	      
	      PayIngredientsDTO idto;
	      for (int i = 0; i < paymentList.size(); i++) {
	         dto = new CheckOutDTO();//dto 객체 비우기
	         dto.setId(paymentList.get(i).getId());
	         dto.setC_name(paymentList.get(i).getC_name());
	         dto.setC_no(paymentList.get(i).getC_no());
	         dto.setC_price(paymentList.get(i).getC_price());
	         dto.setCount(paymentList.get(i).getCount());
	         dto.setName(paymentList.get(i).getName());
	         dto.setC_address(paymentList.get(i).getC_address());
	         dto.setC_zip_code(paymentList.get(i).getC_zip_code());
	         dto.setC_phone(paymentList.get(i).getC_phone());
	         
	         List isRecipeTheme = dao.isRecipeTheme(paymentList.get(i).getC_no());//이 상품 번호가 레시피/테마 테이블에 있는지 확인
	         List isCart = dao.isCart(paymentList.get(i).getC_no(),paymentList.get(i).getId());//카트에서 결제한 것인지 확인
	         
	         System.out.println("isRecipeTheme : " + isRecipeTheme);
	         System.out.println("isCart : " + isCart);
	         
	         if(isRecipeTheme.size() != 0 && isCart.size() != 0){//레시피 테마 상품이면서 장바구니에 있으면
	        	 System.out.println("레시피 테마 상품이면서 장바구니에 있으면");
	        	 List product_id = dao.productIdFromCart(paymentList.get(i).getC_no(),paymentList.get(i).getId());
	        	 for (int j = 0; j < product_id.size(); j++) {
	        		 idto = new PayIngredientsDTO();
	        		 idto.setId(paymentList.get(i).getId());
	        		 idto.setP_no(paymentList.get(i).getC_no());
	        		 idto.setProduct_id((String) product_id.get(j));
	        		 dao.insertPayIngredients(idto);//주문시 한 레시피 상품에 사용자가 선택한 재료들이 들어가 있는 테이블에 insert
				}
	        	 System.out.println("insertPayIngredients 완료");
	        	 
	        	 dao.deleteCartIngredients(principal.getName(),paymentList.get(i).getC_no());//장바구니에 있는 레시피/테마 상품 재료 지우기
	             System.out.println("장바구니에 있는 레시피/테마 상품 재료 지우기");
	             
	             dao.deleteCart(principal.getName(),paymentList.get(i).getC_no());//결제 완료 했을 때 장바구니에서 지우기 
		         System.out.println("장바구니에서 삭제");
		         
		         ingredientsAndProductId = new ArrayList<SubtractStockDTO>();
		         CheckOutDTO dto = new CheckOutDTO();
		         System.out.println("상품번호 : " + paymentList.get(i).getC_no());
		         ingredientsAndProductId = dao.selectSubtractQuantity(paymentList.get(i).getC_no(), paymentList.get(i).getCount());//재고에서 빼주기 위해서 재료량 총 구입 수량 찾기
		         
			     System.out.println("productCode.size() : " + ingredientsAndProductId.size());
			      
			    for(int k=0;k<ingredientsAndProductId.size();k++){
		      	System.out.println(ingredientsAndProductId.get(k).getProduct_id() + ":" + ingredientsAndProductId.get(k).getQuantity());
		      	
		      	//재고에서 빼주기
		        dao.subtractStock(ingredientsAndProductId.get(k).getProduct_id(), ingredientsAndProductId.get(k).getQuantity());
		        System.out.println("재고에서 수량 빼기 완료");
		      }
		         
	         } else if(isRecipeTheme.size() != 0 && isCart.size() == 0){ //레시피 테마 상품이면서 장바구니에 없으면
	        	 System.out.println("레시피 테마 상품이면서 장바구니에 없으면");//if distinguish==1 때로 간다.
	         } else if(isRecipeTheme.size() == 0 && isCart.size() != 0){//상품 골라담기 상품이면서 장바구니에 있으면
	        	 System.out.println("상품 골라담기 상품이면서 장바구니에 있으면");
	        	 dao.deleteCart(principal.getName(),paymentList.get(i).getC_no());//결제 완료 했을 때 장바구니에서 지우기 
		         System.out.println("상품 골라담기 장바구니에서 삭제");
		         //재고에서 삭제
		         dao.subtractfarmStock(paymentList.get(i).getC_no(),paymentList.get(i).getCount());//골라담기 상품 번호(재고테이블에서 번호)랑 수량 가지고 재고테이블에서 재고 빼주기 
	         } else if(isRecipeTheme.size() == 0 && isCart.size() == 0){//상품 골라담기 상품이면서 장바구니에 없으면
	        	 System.out.println("상품 골라담기 상품이면서 장바구니에 없으면");
	        	 //재고에서 삭제
		         dao.subtractfarmStock(paymentList.get(i).getC_no(),paymentList.get(i).getCount());//골라담기 상품 번호(재고테이블에서 번호)랑 수량 가지고 재고테이블에서 재고 빼주기 
	         }
	         dao.insertCheckOut(dto);//그 다음 구매 테이블에 insert
	      }//for
	      System.out.println("구매 테이블에 insert 완료");
	      System.out.println("distinguish : " + distinguish);
	      if(distinguish == 1){//레시피/테마 상품 상세페이지에서 바로 결제하기를 눌렀을 때
	    	  System.out.println("레시피/테마 상품 상세페이지에서 바로 결제하기를 눌렀을 때");
	    	  for(int i=0;i<ingredients_list.size();i++){
	    		  idto = new PayIngredientsDTO();
	        	  idto.setId(principal.getName());
	        	  idto.setP_no(paymentList.get(0).getC_no());//상품이 하나 이므로
	        	  idto.setProduct_id(ingredients_list.get(i));
	        	  dao.insertPayIngredients(idto);//사용자가 구입한 품목에 해당하는 재료 테이블에 insert
	          }
	    	  System.out.println("사용자가 구입한 품목에 해당하는 재료테이블에 insert 완료");
	    	  
	    	  List<SubtractStockDTO> productCode = new ArrayList<SubtractStockDTO>();
	    	  /*CheckOutDTO dto = new CheckOutDTO();
		      dto.setC_no(paymentList.get(0).getC_no());*/
		      productCode = dao.selectSubtractQuantity(paymentList.get(0).getC_no(), paymentList.get(0).getCount());//재고에서 빼주기 위해서 재료량 총 구입 수량 찾기
		      
		      System.out.println("size : " + productCode.size());
		      System.out.println("productCode (c_no) : " + paymentList.get(0).getC_no());
		      
		      for(int i=0;i<productCode.size();i++){
		      	System.out.println(productCode.get(i).getProduct_id() + ":" + productCode.get(i).getQuantity());
		      	
		      	//재고에서 빼주기
		        dao.subtractStock(productCode.get(i).getProduct_id(), productCode.get(i).getQuantity());
		        System.out.println("재고에서 수량 빼기 완료");
		      }
	      } /*else if(distinguish == 4){//레시피 테마 상품이면서 장바구니에 있으면
	    	  List<SubtractStockDTO> productCode = new ArrayList<SubtractStockDTO>();
		      productCode = dao.selectIdQuantity();//재고에서 빼주기 위해서 재료량 총 구입 수량 찾기
		      
		      for(int i=0;i<productCode.size();i++){
		      	System.out.println(productCode.get(i).getProduct_id() + ":" + productCode.get(i).getQuantity());
		      	
		      	//재고에서 빼주기
		        dao.subtractStock(productCode.get(i).getProduct_id(), productCode.get(i).getQuantity());
		        System.out.println("재고에서 수량 빼기 완료");
		      }
	      }*/
	      //재고수가 0이면 재고테이블에서 지우기
	      //dao.deleteStockZero();
	      
	      model.addAttribute("name",paymentList.get(0).getName());
	      model.addAttribute("address",paymentList.get(0).getC_address());
	      model.addAttribute("phone",paymentList.get(0).getC_phone());
	      model.addAttribute("reg_date",dto.getReg_date());
	      model.addAttribute("shipping_fee", shipping_fee);//배송비
	      model.addAttribute("subtotal", subtotal);//배송비를 뺀 총 합
	      model.addAttribute("list", paymentList);
	      
	      System.out.println("구매완료 receipt.jsp가기 직전");
	   } else {
		   System.out.println("결제 실패");
		   return "redirect:/paymentFail";
	   }
	      return "front.cart.receipt";
   }
   
}