package com.kosta.project;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.kosta.project.dao.IRevenueDao;
import com.kosta.project.dto.AdminOrderDTO;
import com.kosta.project.dto.CheckOutDTO;
import com.kosta.project.dto.ExpendEtcDTO;
import com.kosta.project.dto.ExpendEtcSumPerMonthDTO;
import com.kosta.project.dto.SalaryDTO;

///인사관리에 관한 모든 요청(관리자메뉴  -인사관리에 속한 부가메뉴 모두)
@Controller
public class RevenueController {

	@Autowired
	private SqlSession sqlSession;

	// ---------------------------------1.지출관리----------------------
	// 1.1 지출관리 - 총지출
	@RequestMapping(value = "/allExpend", method = RequestMethod.GET)
	public String allExpend(Model model) {
		System.out.println("↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘RevenueController.java/  allExpend controller");
		ArrayList<String> newEtcList = new ArrayList<String> ();
		ArrayList<String> newOrderList = new ArrayList<String> ();
		ArrayList<String> newDateList  =  new ArrayList<String>();
		ArrayList<String> newAllSumSalaryList  =  new ArrayList<String>();
		getExpendList( newDateList, newAllSumSalaryList, newOrderList, newEtcList);
		ArrayList<Integer> list = new ArrayList<Integer>();
		for(int a=0; a<newDateList.size(); a++){
			list.add(Integer.parseInt(newOrderList.get(a))
					+ Integer.parseInt(newEtcList.get(a)) 
					 + Integer.parseInt(newAllSumSalaryList.get(a)) );
		}
		model.addAttribute("newDateList", newDateList);
		model.addAttribute("list", list);
		System.out.println("return back.revenue.allExpend↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖");
		return "back.revenue.allExpend";
	}	
	
	// 1.1 지출관리 - 총지출 - 자세히 종류별금액
	@RequestMapping(value = "/allExpendPerKind", method = RequestMethod.GET)
	public String allExpendPerKind(Model model) {
		System.out.println("↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘RevenueController.java/  allExpendPerKind controller");
		ArrayList<String> newEtcList = new ArrayList<String> ();
		ArrayList<String> newOrderList = new ArrayList<String> ();
		ArrayList<String> newDateList  =  new ArrayList<String>();
		ArrayList<String> newAllSumSalaryList  =  new ArrayList<String>();
		getExpendList( newDateList, newAllSumSalaryList, newOrderList, newEtcList);
		System.out.println(newDateList.size());
		model.addAttribute("newDateList", newDateList);
		model.addAttribute("newOrderList", newOrderList);
		model.addAttribute("newEtcList", newEtcList);
		model.addAttribute("newAllSumSalaryList", newAllSumSalaryList);
		System.out.println("return back.revenue.allExpendPerKind↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖");
		return "back.revenue.allExpendPerKind";
	}	
		
     public void getExpendList(
    		 ArrayList<String> newDateList, ArrayList<String> newAllSumSalaryList,
    		 ArrayList<String> newOrderList, ArrayList<String> newEtcList){
    	 IRevenueDao dao = sqlSession.getMapper(IRevenueDao.class);
 		
 		System.out.println("모든 지출기록만 getExpendList->>>>>>>>>>>>>>>>>>>>>");
 		List<List<String>> allSalaryList = getExpendSalaryList();
 		System.out.println("모든 급여지출관련 리스트 가저옴  size: " + allSalaryList.size());
 		ArrayList<String> dateList  =  new ArrayList<String>();
 		ArrayList<String> allSumSalaryList  =  new ArrayList<String>();
 		int  sum =0;
 		for(int a=allSalaryList.size() -1; a >= 2; a--){//오름차순 ->내림차순으로 입력
 			dateList.add(allSalaryList.get(a).get(0));
 			sum  =0 ;
 			for(int b=1; b< allSalaryList.get(a).size(); b++)
 				sum += Integer.parseInt(allSalaryList.get(a).get(b));
 			allSumSalaryList.add(String.valueOf(sum));
 		}
 		System.out.println("list 2개 size : " +  dateList.size() +"/ "+ allSumSalaryList.size());
 		
 		System.out.println("기타지출기록 가져오기");
 		List<ExpendEtcSumPerMonthDTO> etcList = dao.expendEtcSumPerMonth();
 		System.out.println("가저온기타지출기록 수 : "+ etcList.size());
 		
 		System.out.println("구매기록 가져오기");
 		List<AdminOrderDTO> orderList =dao.getAdminOrder();
 		System.out.println("가저온구매기록 수 : "+ orderList.size());
 		System.out.println("가장오래된날기준 찾기 " );
 		
 		System.out.println("get salary월급list size : " +allSalaryList.size() );

 		String etcListDate,  dateListDate, orderListDate;
 		if(etcList.size() <1) etcListDate ="9999/99";
 		else etcListDate= etcList.get(etcList.size()-1).getEe_date();
 		if(dateList.size() <1) dateListDate ="9999/99";
 		else dateListDate= dateList.get(dateList.size()-1);
 		
 		if(orderList.size() <1) orderListDate="9999/99";
 		else orderListDate = orderList.get(orderList.size()-1).getA_date();
 		System.out.println("각최소날짜 : etcListDate:" + etcListDate + 
 				"/ dateListDate:" +dateListDate + "/ orderListDate" + orderListDate);
 		int temp1= Integer.parseInt(etcListDate.substring(0, 4))*10000 +Integer.parseInt(etcListDate.substring(5, 7));
 		int temp2= Integer.parseInt(dateListDate.substring(0, 4))*10000 + Integer.parseInt(dateListDate.substring(5, 7));
 		int temp3= Integer.parseInt(orderListDate.substring(0, 4))*10000 + Integer.parseInt(orderListDate.substring(5, 7));
 		int temp =temp1 ;
 		String minDate;
 		minDate = etcListDate;
 		if(temp2 < temp ){
 			temp = temp2;
 			minDate = dateListDate;
 		}
 		if(temp3 < temp){
 			temp = temp3;
 			minDate = orderListDate;
 		}
 		
 		SimpleDateFormat mSimpleDateFormat = new SimpleDateFormat ( "yyyy/MM", Locale.KOREA );
 		Date currentTime = new Date ( );
 		String mTime = mSimpleDateFormat.format ( currentTime );
 		
 		String inFirst = minDate;
 		String inLast = mTime;
 		System.out.println("first " + inFirst);
 		System.out.println("inLast " + inLast);
 		int fyyyy,fmm,lyyyy,lmm;
 		fyyyy = Integer.parseInt(inFirst.substring(0, 4));
 		fmm = Integer.parseInt(inFirst.substring(5, 7));
 		lyyyy = Integer.parseInt(inLast.substring(0, 4));
 		lmm = Integer.parseInt(inLast.substring(5, 7));
 		String strMonth;
 		System.out.println("list3개의 값을 새롭게 만듬");
 	
 		int EtcIt=etcList.size()-1;
 		int OrderIt=orderList.size()-1;
 		int DateIt=allSumSalaryList.size()-1;
 		System.out.println("? ??? ?? "+dateList);
 		while(fyyyy<2017){
 			if(fmm > 12){
 				fmm = 1;
 				fyyyy ++;
 			}
 			if(fmm<10)    strMonth = "0"+ fmm;
 			else          strMonth = "" + fmm;
 			System.out.println(fyyyy + "/"+strMonth);
 			newDateList.add(fyyyy+"년"+strMonth+"월");
 			if(DateIt >= 0){
 				System.out.println( "DateIt:"+DateIt);
 				System.out.println( "dateList의 현재 date값:"+dateList.get(DateIt));
 				if(dateList.get(DateIt).equals(fyyyy + "/"+strMonth)){
 					System.out.println("dateList 값대임  it :" + DateIt);
 					System.out.println(String.valueOf(allSumSalaryList.get(DateIt)));
 					newAllSumSalaryList.add(allSumSalaryList.get(DateIt));
 					DateIt--;
 				}
 				else newAllSumSalaryList.add("0");
 			}else newAllSumSalaryList.add("0");
 			if(OrderIt >=0){
 				System.out.println("orderList의 현재 date값:"+orderList.get(OrderIt).getA_date());
 				if(orderList.get(OrderIt).getA_date().equals(fyyyy +"/"+ strMonth)){
 					System.out.println("orderList 값대임  it :" + OrderIt);
 					System.out.println(String.valueOf(orderList.get(OrderIt).getA_price()));
 					newOrderList.add(String.valueOf(orderList.get(OrderIt).getA_price()));
 					OrderIt--;
 				}
 				else {
 					newOrderList.add("0");
 					System.out.println("orderList 값 0 대입");
 				}
 			} 
 			else {
 				newOrderList.add("0");
 				System.out.println("orderList 값 0 대입");
 			}
 			if(EtcIt >=0){
 				System.out.println("newEtcList의 현재 EtcIt값:"+EtcIt);
 				System.out.println("newEtcList의 현재 date값:"+etcList.get(EtcIt).getEe_date());
 				if(etcList.get(EtcIt).getEe_date().equals(fyyyy + "/"+strMonth)){
 					System.out.println("newEtcList 값대임  it :" + EtcIt);
 					System.out.println(etcList.get(EtcIt).getEe_expend());
 					newEtcList.add(String.valueOf(etcList.get(EtcIt).getEe_expend()));
 					EtcIt--;
 				}
 				else {
 					newEtcList.add("0");
 					System.out.println("newEtcList 값 0 대입");
 				}
 			}else {
 				newEtcList.add("0");
 				System.out.println("newEtcList 값 0 대입");
 			}
 			if(fyyyy == lyyyy && fmm == lmm){
 				System.out.println(fyyyy + fmm +" /" +lyyyy + lmm);
 				break;
 			}
 			fmm++;
 		}
 		System.out.println(newEtcList.size());
 		System.out.println(newOrderList.size());
 		System.out.println(newDateList.size());
 		System.out.println(newAllSumSalaryList.size());
 		
 		for(int a=0; a<newEtcList.size(); a++){
 			System.out.print(newDateList.get(a)+"/");
 			System.out.print(newAllSumSalaryList.get(a)+"/");
 			System.out.print(newEtcList.get(a)+"/");
 			System.out.print(newOrderList.get(a)+"/");
 			System.out.println();
 		}
     }
	// 1.2 지출관리 - 기타지출 (년/월별 합)
	@RequestMapping(value = "/expendEtcSumPerMonth", method = RequestMethod.GET)
	public String expendEctSumPerMonth(Model model) {
		System.out.println("↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘RevenueController.java/  expendEtcSumPerMonth controller");
		System.out.println("기타지출내역을 월별합으로 가져와 list에 담는다.");
		IRevenueDao dao = sqlSession.getMapper(IRevenueDao.class);
		model.addAttribute("list", dao.expendEtcSumPerMonth());
		System.out.println("size: " + dao.expendEtcSumPerMonth().size());
		System.out.println("return back.revenue.expendEtcSumPerMonth↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖");
		return "back.revenue.expendEtcSumPerMonth";
	}

	// 1.2 지출관리 - 기타지출 - (년/월)선택삭제처리
	@RequestMapping(value = "/removeProExpendEtc", method = RequestMethod.GET)
	public String removeProExpendEtc(Model model, @RequestParam("ee_num") Integer ee_num) {
		System.out.println("↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘RevenueController.java/  removeProExpendEtc controller");
		System.out.println("기타지출내역중 선택한 년/월을 받아 기타지출내역에서 모두삭제처리");
		IRevenueDao dao = sqlSession.getMapper(IRevenueDao.class);
		System.out.println("삭제할대상 ee_num:"+ ee_num);
		String monthOfEe_date = dao.getDateOfEe_num(ee_num).substring(0, 7);
		System.out.println("돌아갈 페이지의 년/월 확보됨 :"+ monthOfEe_date);
		dao.deleteExpendEtc(ee_num);
		System.out.println("redirect:/expendEtcListAboutMonth?monthOfEe_date="+monthOfEe_date+"↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖");
		return "redirect:/expendEtcListAboutMonth?monthOfEe_date="+monthOfEe_date;
	}

	// 1.2 지출관리 - 기타지출 - 년/월 자세히뷰
	@RequestMapping(value = "/expendEtcListAboutMonth", method = RequestMethod.GET)
	public String expendEtcListAboutMonth(Model model, @RequestParam("monthOfEe_date") String monthOfEe_date) {
		System.out.println("↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘RevenueController.java/  expendEtcListAboutMonth controller");
		System.out.println("기타지출내역중 선택한 년/월(" + monthOfEe_date + ")과 같은 값을 모두 가저와 list에 담는다.");
		IRevenueDao dao = sqlSession.getMapper(IRevenueDao.class);
		model.addAttribute("list", dao.expendEtcListAboutMonth(monthOfEe_date));
		System.out.println("size: " + dao.expendEtcListAboutMonth(monthOfEe_date).size());
		System.out.println("return back.revenue.expendEtcListAboutMonth↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖");
		return "back.revenue.expendEtcListAboutMonth";
	}

	// 1.2 지출관리 - 기타지출 - 년/월 자세히뷰 - 수정뷰
	@RequestMapping(value = "/updateExpendEtc", method = RequestMethod.POST)
	public String updateExpend(@ModelAttribute ExpendEtcDTO vo, Model model) {
		System.out.println("↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘RevenueController.java/  updateExpendEtc controller");
		System.out.println("기타지출내역의 년/월/일 값을 받아 값을가저와 dto에 담는다");
		model.addAttribute("vo", vo);
		model.addAttribute("year", vo.getEe_date().substring(0, 4));
		model.addAttribute("month", vo.getEe_date().substring(5, 7));
		model.addAttribute("day", vo.getEe_date().substring(8, 10));
		System.out.println("수정뷰로이동");
		System.out.println("return back.revenue.updateExpendEtc↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖");
		return "back.revenue.updateExpendEtc";
	}

	// 1.2 지출관리 - 기타지출 - 년/월 자세히뷰 - 수정뷰 - 수정처리
	@RequestMapping(value = "/proUpdateExpendEtc", method = RequestMethod.POST)
	public String proUpdateExpendEtc(@ModelAttribute ExpendEtcDTO vo, Model model, @RequestParam("year") String year,
			@RequestParam("month") String month, @RequestParam("day") String day) {
		System.out.println("↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘RevenueController.java/  proUpdateExpendEtc controller");
		System.out.println("변경할값   month:" + month + "/ year:" + year + "/ day:" + day);
		System.out.println("변경할값  content:" + vo.getEe_content());
		System.out.println("해당 번호 :" + vo.getEe_num() + "의 값을 수정");
		
		if (month.length() == 1)
			month = "0" + month;
		if (day.length() == 1)
			day = "0" + day;
		vo.setEe_date(year + "/" + month + "/" + day);
		
		System.out.println("변경할값 날짜 최종 설정: " + vo.getEe_date());
		IRevenueDao dao = sqlSession.getMapper(IRevenueDao.class);
		dao.updateExpendEtc(vo);
        System.out.println("수정완료!");
		System.out.println("redirect:/expendEtcListAboutMonth?ee_date=" + year + "/" + month + "↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖");
		return "redirect:/expendEtcListAboutMonth?monthOfEe_date=" + year + "/" + month;
	}

	// 1.2 지출관리 - 기타지출 - 추가뷰
	@RequestMapping(value = "/addExpendEtc", method = RequestMethod.GET)
	public String addExpend(Model model) {
		System.out.println("↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘RevenueController.java/  addExpendEtc controller");
		System.out.println("기타지출내역 추가뷰로이동");
		System.out.println("return back.revenue.addExpend↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖");
		return "back.revenue.addExpendEtc";
	}

	// 1.2 지출관리 - 기타지출 - 추가뷰 - 추가처리
	@RequestMapping(value = "/proAddExpendEtc", method = RequestMethod.POST)
	public String proAddExpendEtc(@RequestParam("ee_content") List<String> ee_content, 
			@RequestParam("ee_expend") List<Integer> ee_expend,
			@RequestParam("ee_expendDirector") List<String> ee_expendDirector, Model model,
			 @RequestParam("year") String year, @RequestParam("month") String month, 
			 @RequestParam("day") String day) {
		System.out.println("↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘RevenueController.java/  proAddExpendEtc controller");
		System.out.println("추 가처리 ");
		System.out.println("input list size: " +ee_expend.size()+"/"+ee_expendDirector.size()+"/"+ee_content.size());
		ExpendEtcDTO vo = new ExpendEtcDTO();
		IRevenueDao dao = sqlSession.getMapper(IRevenueDao.class);
		System.out.println("날짜설정");
		if (month.length() == 1)
			month = "0" + month;
		if (day.length() == 1)
			day = "0" + day;
		vo.setEe_date(year + "/" + month + "/" + day);
		System.out.println("다른정보set하면서 추가");
		for(int a=0; a<ee_expend.size(); a++){
			System.out.println(a +"번째 추가");
			vo.setEe_content(ee_content.get(a));
			vo.setEe_expendDirector(ee_expendDirector.get(a));
			vo.setEe_expend(ee_expend.get(a));
			dao.addExpendEtc(vo);
		}
		System.out.println("return redirect:/expendEctSumPerMonth↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖");
		return "redirect:/expendEtcSumPerMonth";
	}
	
	// 1.3 지출관리 - 구매지출
	@RequestMapping(value = "/expendBuy", method = RequestMethod.GET)
	public String expendBuy(Model model) {
		System.out.println("↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘RevenueController.java/  expendBuy controller");
		IRevenueDao dao = sqlSession.getMapper(IRevenueDao.class);
		System.out.println("get size: "  +dao.getAdminOrder().size());
		model.addAttribute("list" , dao.getAdminOrder());
		System.out.println("return back.revenue.expendBuy↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖");
		return "back.revenue.expendBuy";
	}
	// 1.3 지출관리 - 구매지출 - 월에대한상세내역
		@RequestMapping(value = "/expendBuyAboutDate", method = RequestMethod.GET)
		public String expendBuyAboutDate(Model model, @RequestParam ("a_date") String a_date) {
			System.out.println("↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘RevenueController.java/  expendBuyAboutDate controller");
			IRevenueDao dao = sqlSession.getMapper(IRevenueDao.class);
			System.out.println("get size: "  +dao.getAdminOrderAboutDate(a_date).size());
			model.addAttribute("list" , dao.getAdminOrderAboutDate(a_date));
			System.out.println("return back.revenue.expendBuyAboutDate↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖");
			return "back.revenue.expendBuyAboutDate";
		}
		
	// 1.3 지출관리 - 구매지출 마트
	@RequestMapping(value = "/expendBuyInMart", method = RequestMethod.GET)
	public String expendBuyInMart(Model model) {
		System.out.println("↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘expendBuyInMart.java/  expendBuyInMart controller");
		IRevenueDao dao = sqlSession.getMapper(IRevenueDao.class);
		model.addAttribute("list" , dao.expendBuyInMart());
		System.out.println("get size: "  +dao.expendBuyInMart().size());
		System.out.println("return back.revenue.expendBuyInMart↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖");
		return "back.revenue.expendBuyInMart";
	}
	// 1.3 지출관리 - 구매지출 마트 - 월에대한상세내역
	@RequestMapping(value = "/expendBuyInMartAboutDate", method = RequestMethod.GET)
	public String expendBuyInMartAboutDate(Model model,@RequestParam("mart_orderDate") String mart_orderDate) {
		System.out.println("↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘expendBuyInMart.java/  expendBuyInMartAboutDate controller");
		IRevenueDao dao = sqlSession.getMapper(IRevenueDao.class);
		System.out.println("okdate : "  + mart_orderDate);
		model.addAttribute("list" , dao.expendBuyInMARTAboutMart_orderdate(mart_orderDate));
		System.out.println("get size: "  +dao.expendBuyInMARTAboutMart_orderdate(mart_orderDate).size());
		System.out.println("return back.revenue.expendBuyInMartAboutDate↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖");
		return "back.revenue.expendBuyInMartAboutDate";
	}
	
	// 1.3 지출관리 - 구매지출 농장
	@RequestMapping(value = "/expendBuyInFarm", method = RequestMethod.GET)
	public String expendBuyInFarm(Model model) {
		System.out.println("↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘RevenueController.java/  expendBuy expendBuyInFarm");
		IRevenueDao dao = sqlSession.getMapper(IRevenueDao.class);
		model.addAttribute("list" , dao.expendBuyInFarm());
		System.out.println("get size: "  +dao.expendBuyInFarm().size());
		System.out.println("return back.revenue.expendBuyInFarm↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖");
		return "back.revenue.expendBuyInFarm";
	}

	// 1.3 지출관리 - 구매지출 농장  -- 월에대한 상세내역
	@RequestMapping(value = "/expendBuyInFarmAboutOkDate", method = RequestMethod.GET)
	public String expendBuyInFarmAboutOkDate(Model model, @RequestParam("okDate") String okDate) {
		System.out.println("↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘RevenueController.java/  expendBuy expendBuyInFarmAboutOkDate");
		IRevenueDao dao = sqlSession.getMapper(IRevenueDao.class);
		System.out.println("okdate : "  + okDate);
		model.addAttribute("list" , dao.expendBuyInFarmAboutOkDate(okDate));
		System.out.println("get size: "  +dao.expendBuyInFarmAboutOkDate(okDate).size());
		System.out.println("return back.revenue.expendBuyInFarmAboutOkDate↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖");
		return "back.revenue.expendBuyInFarmAboutDate";
	}                        

	// 1.4 지출관리 - 급여지출 - 월별
	@RequestMapping(value = "/expendSalary", method = RequestMethod.GET)
	public String expendSalary(Model model) {
		System.out.println("↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘RevenueController.java/  expendSalary controller");
		List<List<String>> allSalaryList = getExpendSalaryList();
		System.out.println("모든 급여지출관련 리스트 가저옴  size: " + allSalaryList.size());
		ArrayList<String> dateList  =  new ArrayList<String>();
		ArrayList<String> allSumSalaryList  =  new ArrayList<String>();
	
		int  sum =0;
		for(int a=allSalaryList.size() -1; a >= 2; a--){//오름차순 ->내림차순으로 입력
			dateList.add(allSalaryList.get(a).get(0));
			sum  =0 ;
			for(int b=1; b< allSalaryList.get(a).size(); b++)
				sum += Integer.parseInt(allSalaryList.get(a).get(b));
			allSumSalaryList.add(String.valueOf(sum));
		}
		System.out.println("보내줄 list 2개 size : " +  dateList.size() +"/ "+ allSumSalaryList.size());
		
		if(allSalaryList.size() == 0) model.addAttribute("count", 0 );
		else model.addAttribute("count",  allSalaryList.get(0).size()-1);
		System.out.println("?!" + dateList);
		System.out.println("?!" +allSumSalaryList);
		model.addAttribute("dateList", dateList);
		model.addAttribute("allSalaryList", allSumSalaryList);
		System.out.println("return back.revenue.expendSalary↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖");
		return "back.revenue.expendSalary";
	}
	// 1.4 지출관리 - 급여지출 펼치기(모두보기)
		@RequestMapping(value = "/expendSalaryAll", method = RequestMethod.GET)
		public String expendSalaryAll(Model model) {
			System.out.println("↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘RevenueController.java/  expendSalaryAll controller");
			List<List<String>> allSalaryList = getExpendSalaryList();
			System.out.println("모든 급여지출관련 리스트 가저옴  size: " + allSalaryList.size());
			model.addAttribute("allSalaryList", allSalaryList);
			System.out.println("return back.revenue.expendSalaryAll↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖");
			return "back.revenue.expendSalaryAll";
		}
		
	// 1.4 지출관리 - 급여지출 - 선택 년월에대해  상세
		@RequestMapping(value = "/expendSalaryAboutMonth", method = RequestMethod.GET)
		public String expendSalaryAboutMonth(Model model, @RequestParam ("month") String s_date) {
			System.out.println("↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘RevenueController.java/  expendSalaryAboutMonth controller");
			System.out.println("가저온 (검색할)month : " + s_date);
			List<List<String>> allSalaryList = getExpendSalaryList();
			System.out.println("모든 급여지출관련 리스트 가저옴  size: " + allSalaryList.size());
			
			/* allSalaryList내용
			 직원이름     ''      ''     ''    ...
			 직원번호    ''       ''    ''    ...
			 날짜1  '급여값'  '급여값'  '급여값' ...
			 날짜2  '급여값'  '급여값'  '급여값' ...
			 */
			int salaryIt;
			for(salaryIt=allSalaryList.size() -1; salaryIt >= 2; salaryIt--){//날짜수  만큼 
				if(s_date.equals(allSalaryList.get(salaryIt).get(0))){
					System.out.println("같은날!: " +allSalaryList.get(salaryIt).get(0) );
					allSalaryList.get(0).remove(0);
					allSalaryList.get(1).remove(0);
					allSalaryList.get(salaryIt).remove(0);
					System.out.println("불필요정보 제거후 size3: " +allSalaryList.get(salaryIt).size()+"/"
							+allSalaryList.get(1).size()+"/" +allSalaryList.get(0).size()+"/");
					System.out.println("정리할 리스트");
					for(int s=0; s<allSalaryList.get(0).size(); s++ )
						System.out.println(allSalaryList.get(salaryIt).get(s) +"/" + allSalaryList.get(0).get(s)+ "/"+allSalaryList.get(1).get(s));
					System.out.println();
					for(int b=0; b< allSalaryList.get(salaryIt).size(); b++){//날짜하다에대한 모든급여만만큼
						System.out.println(allSalaryList.get(0).get(b));
						if(allSalaryList.get(salaryIt).get(b).equals("0")){
							allSalaryList.get(0).remove(b);
							allSalaryList.get(1).remove(b);
							allSalaryList.get(salaryIt).remove(b);
							System.out.println("지우고:"+allSalaryList.get(salaryIt) +"\n"+ allSalaryList.get(0) +"\n" +allSalaryList.get(1));
							b--;
						}
					}
					break;
				}
			}
		System.out.println(allSalaryList.get(salaryIt) +"\n"+ allSalaryList.get(0) +"\n" +allSalaryList.get(1));
			System.out.println("allSalaryList.get(salaryIt) size : " + allSalaryList.get(salaryIt).size());
			System.out.println("allSalaryList.get(0) size: " + allSalaryList.get(0).size());
			System.out.println("allSalaryList.get(1) size: " + allSalaryList.get(1).size());
			model.addAttribute("s_date", s_date);
			model.addAttribute("s_salaryList", allSalaryList.get(salaryIt));
			model.addAttribute("e_numList", allSalaryList.get(0));
			model.addAttribute("e_nameList", allSalaryList.get(1));
			System.out.println("return back.revenue.expendSalaryAboutMonth↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖");
			return "back.revenue.expendSalaryAboutMonth";
		}
		
	// 급여지출관련 모든정보 리스트
	public List<List<String>> getExpendSalaryList() {
		System.out.println("↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘RevenueController.java/  public String getExpendSalaryList(Model model)  일반함수");
		IRevenueDao dao = sqlSession.getMapper(IRevenueDao.class);
		List<SalaryDTO> salaryList = dao.getSalaryList();
		List<SalaryDTO> s_numAndS_nameList = dao.getSalaryExistE_numANDE_name();
		List<List<String>> allSalaryList = new ArrayList< List<String> >();
		int listWidth = s_numAndS_nameList.size();

		List<String> NumList = new ArrayList<String>();
		List<String> NameList = new ArrayList<String>();
		NumList.add("직원번호");
		NameList.add("직원이름");
		for(int a=0; a<listWidth; a++){
			NumList.add(String.valueOf(s_numAndS_nameList.get(a).getE_num()));
			NameList.add(s_numAndS_nameList.get(a).getE_name());
		}
		listWidth+=1;
		System.out.println("listWidth:  " + listWidth);
		
		System.out.println("전체에 ('직원번호' + 직원번호들) 리스트를 하나추가");
		allSalaryList.add(NumList);
		System.out.println("전체에 ('직원이름' + 직원이름들) 리스트를 하나추가");
		allSalaryList.add(NameList);
		System.out.println("전체 size : " + allSalaryList.size());
		System.out.println("전체리스트 출력");
		for(int a=0; a<allSalaryList.size(); a++){
			for(int b=0; b<allSalaryList.get(a).size(); b++)
				System.out.print(allSalaryList.get(a).get(b) +" ");
			System.out.println();
		}
		
		System.out.println("get salary월급list size : " +allSalaryList.size() );
		if(salaryList.size()==0){
			System.out.println("데이터가 월급에대해 존재안함 size : 0");
			System.out.println("return back.revenue.expendSalary↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖");
			return new ArrayList< List<String> >();
		}
		
		int year = Integer.parseInt(salaryList.get(0).getS_date().substring(0, 4));
		int month = Integer.parseInt(salaryList.get(0).getS_date().substring(5, 7));
		String strMonth = salaryList.get(0).getS_date().substring(5, 7);
		System.out.println("출력할 시작 날짜  설정  year:" + year +"   month:" + month );
		
		int it_salaryList = 0;
		ArrayList<String> tempInsertSalaryList = new ArrayList<String>(listWidth);
		tempInsertSalaryList.add(year+"/"+strMonth);
		for(int a=1; a<listWidth; a++)                 
			tempInsertSalaryList.add("0");
		
		boolean first = true;
		while(true){/*
			System.out.println("진행중인 월급 설정날짜 : " + year + " / " + month);
			System.out.println(year + "/" + month);
			System.out.println(salaryList.get(it_salaryList).getS_date());*/
			if(month<10)  strMonth = "0"+ month;
			else          strMonth = "" + month;
			if((year + "/" + strMonth).equals(salaryList.get(it_salaryList).getS_date())){
				/*System.out.println("같은날짜임");*/
				for(int a=0; a< listWidth; a++){
					/*System.out.println("salarylist(현제 돌리고잇는 소스)의 enum: "+salaryList.get(it_salaryList).getE_num());
					System.out.println("NumList(자리가 정해진) enum: "+NumList.get(a));*/
					if(String.valueOf(salaryList.get(it_salaryList).getE_num()).equals(NumList.get(a))){
						/*System.out.println("같은 날짜중 같은 번호   e_num: " +NumList.get(a) + "  /e_name: " +NameList.get(a) );
						System.out.println("해당날짜 임시리스트에  같은 직원번호 자리로 삽입 1개  급여값: " + salaryList.get(it_salaryList).getS_salary());*/
						tempInsertSalaryList.set(a, String.valueOf(salaryList.get(it_salaryList).getS_salary()));
						it_salaryList++;/*
						System.out.println("현제위치에서 변화된 다음 검색 위치 :"+ it_salaryList);
						System.out.println("한번진행후 (삽입1개)완료된 결과  ->->->");
						for(int b=0; b< tempInsertSalaryList.size(); b++){
							System.out.print("["+tempInsertSalaryList.get(b) +"]");
						}System.out.println();	*/
						month--;
						break;
					}
				}
			}
			month++;
			if(month > 12){
				month = 1; 
				year ++;
			}
			if(month<10)  strMonth = "0"+ month;
			else          strMonth = "" + month;
			if(first){
				first =false;
				continue;
			}
			System.out.println("salaryList.size():"+ salaryList.size()+"//it_salaryList:"+it_salaryList );
			if(it_salaryList < salaryList.size()){/*
				System.out.println(salaryList.get(it_salaryList-1).getS_date() +
						" 과 " + salaryList.get(it_salaryList).getS_date()+" 이 다른지 비교");*/
				if(!salaryList.get(it_salaryList-1).getS_date().equals(salaryList.get(it_salaryList).getS_date())){
					/*System.out.println("해당날짜(어느하나의대한날짜) 에대한 삽입이 끝났으므로 그리스트를 전체에 추가");*/
					allSalaryList.add(tempInsertSalaryList);
					/*System.out.println("이전과 다른날짜이므로 새로운 리스트로 생성");*/
						
					tempInsertSalaryList = new ArrayList<String>(listWidth);
					tempInsertSalaryList.add(year + "/" + strMonth);
					for(int a=1; a<listWidth; a++)
						tempInsertSalaryList.add("0");
				}
			}else{
				System.out.println("마지막접근임");
				System.out.println("해당날짜(어느하나의대한날짜) 에대한 삽입이 끝났으므로 그리스트를 전체에 추가");
				System.out.println("마지막리스트:"+tempInsertSalaryList);
				allSalaryList.add(tempInsertSalaryList);
				break;
			}
		}
		for(int a=3; a<allSalaryList.size(); a++){
				if(allSalaryList.get(a).get(0).equals(allSalaryList.get(a-1).get(0))){
					System.out.println("중복제거 :" + allSalaryList.get(a));
					allSalaryList.remove(a);
				}
		}
				
		System.out.println("만들어진 총 list");
		for(int a=0; a<allSalaryList.size(); a++){
			for(int b=0; b< allSalaryList.get(a).size(); b++)
				System.out.print(allSalaryList.get(a));
			System.out.println();
		}
		
		SimpleDateFormat mSimpleDateFormat = new SimpleDateFormat ( "yyyy/MM", Locale.KOREA );
		Date currentTime = new Date ( );
		String mTime = mSimpleDateFormat.format ( currentTime );
		
		String inFirst = allSalaryList.get(allSalaryList.size()-1).get(0);
		String inLast = mTime;
		System.out.println("first " + inFirst);
		System.out.println("inLast " + inLast);
		int fyyyy,fmm,lyyyy,lmm;
		fyyyy = Integer.parseInt(inFirst.substring(0, 4));
		fmm = Integer.parseInt(inFirst.substring(5, 7));
		lyyyy = Integer.parseInt(inLast.substring(0, 4));
		lmm = Integer.parseInt(inLast.substring(5, 7));
		while(true){
			fmm++;
			if(fmm > 12){
				fmm = 1;
				fyyyy ++;
			}
			System.out.println(fyyyy+"/"+ fmm +": 양쪽같으면 종료  :" +lyyyy +"/"+ lmm);
			if(fyyyy > lyyyy || (fyyyy == lyyyy && fmm> lmm)){
				break;
			}
			if(fmm<10)    strMonth = "0"+ fmm;
			else          strMonth = "" + fmm;
			System.out.println(fyyyy + strMonth);
			tempInsertSalaryList = new ArrayList<String>(listWidth);
			tempInsertSalaryList.add(fyyyy + "/" + fmm);
			for(int a=1; a< listWidth; a++)
				tempInsertSalaryList.add("0");
			allSalaryList.add(tempInsertSalaryList);

			System.out.println("allSalaryList 크기:"+ allSalaryList.size());
			System.out.println("allSalaryList마지맏 최근 : " + allSalaryList.get(allSalaryList.size() - 1));
		}
		for(int a=2; a<allSalaryList.size(); a++){
			for(int b=0; b< allSalaryList.get(a).size(); b++)
				if(allSalaryList.get(a).get(b).equals("0")){
					if(a != 2) 	allSalaryList.get(a).set(b,allSalaryList.get(a-1).get(b));
					else 	allSalaryList.get(a).set(b,"0");
						
				}
		}

		/*System.out.println("만들어진 총 list");
		for(int a=0; a<allSalaryList.size(); a++){
			for(int b=0; b< allSalaryList.get(a).size(); b++)
				System.out.print(allSalaryList.get(a).get(b));
			System.out.println();
		}*/
		
		System.out.println("return allSalaryList(모든월급지출리스트)↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖");
		return allSalaryList;
	}
	
	// ---------------------------------2.매출관리----------------------
	// 2.1 매출관리 - 총수익
	@RequestMapping(value = "/allIncome", method = RequestMethod.GET)
	public String allIncome(Model model) {
		System.out.println("↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘RevenueController.java/  allIncome controller");
		IRevenueDao dao = sqlSession.getMapper(IRevenueDao.class);
		model.addAttribute("list" , dao.allIncome());
		System.out.println("get size: "  +dao.allIncome().size());
		System.out.println("return back.revenue.allIncome↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖");
		return "back.revenue.allIncome";
	}
	
	// 2.1 매출관리 - 총수익 - 월별 상세
	@RequestMapping(value = "/allIncomeAboutMonth", method = RequestMethod.GET)
	public String allIncomeAboutMonth(Model model, @RequestParam String reg_date) {
		System.out.println("↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘RevenueController.java/  allIncomeAboutMonth controller");
		IRevenueDao dao = sqlSession.getMapper(IRevenueDao.class);
		model.addAttribute("list" , dao.allIncomeAboutMonth(reg_date));
		System.out.println("get size: "  +dao.allIncomeAboutMonth(reg_date).size());
		System.out.println("return back.revenue.allIncomeAboutMonth↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖");
		return "back.revenue.allIncomeAboutMonth";
	}
	
	// --------------------------------3.순이익관리----------------------
	// 3.1 순이익관리 - 총순이익
	@RequestMapping(value = "/allRevenue", method = RequestMethod.GET)
	public String allRevenue(Model model) {
		System.out.println("↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘RevenueController.java/  allRevenue controller");
		ArrayList<String> newEtcList = new ArrayList<String> ();
		ArrayList<String> newOrderList = new ArrayList<String> ();
		ArrayList<String> newDateList  =  new ArrayList<String>();
		ArrayList<String> newAllSumSalaryList  =  new ArrayList<String>();
		ArrayList<String> newIncomeList  =  new ArrayList<String>();
		getAllRevenueList( newDateList, newAllSumSalaryList, newOrderList, newEtcList,newIncomeList);

		ArrayList<Integer> list = new ArrayList<Integer>();
		for(int a=0; a<newDateList.size(); a++){
			list.add( Integer.parseInt(newIncomeList.get(a))
					  - Integer.parseInt(newEtcList.get(a)) 
					  - Integer.parseInt(newAllSumSalaryList.get(a))
					  -Integer.parseInt(newOrderList.get(a)) );
		}
		model.addAttribute("newDateList", newDateList);
		model.addAttribute("list", list);
		
		System.out.println("return back.revenue.allRevenue↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖");
		return "back.revenue.allRevenue";
	}
	
	// 3.1 순이익관리 - 총순이익
		@RequestMapping(value = "/allRevenuePerKind", method = RequestMethod.GET)
		public String allRevenuePerKind(Model model) {
			System.out.println("↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘↘RevenueController.java/  allRevenuePerKind controller");
			ArrayList<String> newEtcList = new ArrayList<String> ();
			ArrayList<String> newOrderList = new ArrayList<String> ();
			ArrayList<String> newDateList  =  new ArrayList<String>();
			ArrayList<String> newAllSumSalaryList  =  new ArrayList<String>();
			ArrayList<String> newIncomeList  =  new ArrayList<String>();
			getAllRevenueList( newDateList, newAllSumSalaryList, newOrderList, newEtcList,newIncomeList);

			ArrayList<Integer> list = new ArrayList<Integer>();
			for(int a=0; a<newDateList.size(); a++){
				list.add( Integer.parseInt(newIncomeList.get(a))
						  - Integer.parseInt(newEtcList.get(a)) 
						  - Integer.parseInt(newAllSumSalaryList.get(a))
						  -Integer.parseInt(newOrderList.get(a)) );
			}
			model.addAttribute("newEtcList", newEtcList);
			model.addAttribute("newOrderList", newOrderList);
			model.addAttribute("newDateList", newDateList);
			model.addAttribute("newAllSumSalaryList", newAllSumSalaryList);
			model.addAttribute("newIncomeList", newIncomeList);
			model.addAttribute("list", list);
			
			System.out.println("return back.revenue.allRevenuePerKind↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖↖");
			return "back.revenue.allRevenuePerKind";
		}
	
	
	
	 public void getAllRevenueList(
    		 ArrayList<String> newDateList, ArrayList<String> newAllSumSalaryList,
    		 ArrayList<String> newOrderList, ArrayList<String> newEtcList,ArrayList<String> newIncomeList){
    	 IRevenueDao dao = sqlSession.getMapper(IRevenueDao.class);
 		
 		System.out.println("getAllRevenueList 수입 지출모두->>>>>>>>>>>>>>>>>>");
 		List<List<String>> allSalaryList = getExpendSalaryList();
 		System.out.println("모든 급여지출관련 리스트 가저옴  size: " + allSalaryList.size());
 		ArrayList<String> dateList  =  new ArrayList<String>();
 		ArrayList<String> allSumSalaryList  =  new ArrayList<String>();
 		int  sum =0;
 		for(int a=allSalaryList.size() -1; a >= 2; a--){//오름차순 ->내림차순으로 입력
 			dateList.add(allSalaryList.get(a).get(0));
 			sum  =0 ;
 			for(int b=1; b< allSalaryList.get(a).size(); b++)
 				sum += Integer.parseInt(allSalaryList.get(a).get(b));
 			allSumSalaryList.add(String.valueOf(sum));
 		}
 		System.out.println("list 2개 size : " +  dateList.size() +"/ "+ allSumSalaryList.size());
 		
 		System.out.println("기타지출기록 가져오기");
 		List<ExpendEtcSumPerMonthDTO> etcList = dao.expendEtcSumPerMonth();
 		System.out.println("가저온기타지출기록 수 : "+ etcList.size());
 		
 		System.out.println("구매기록 가져오기");
 		List<AdminOrderDTO> orderList =dao.getAdminOrder();
 		System.out.println("가저온구매기록 수 : "+ orderList.size());
 		System.out.println("가장오래된날기준 찾기 " );

 		System.out.println("매출기록 가져오기");
 		List<CheckOutDTO>  incomeList = dao.allIncome();
 		System.out.println("가저온 매출기록 수 : "+ incomeList.size());
 		
 		String etcListDate,  dateListDate, orderListDate, incomeListDate;
 		System.out.println("가져온 4종류리스트 지출 수입관련 :" +etcList.size()+ "/"+dateList.size() +"/"+incomeList.size()+ "/"+orderList.size() );

 		System.out.println(dateList.size() +"/"+ (dateList.size() <0));
 		if(etcList.size() <=0) etcListDate ="9999/99";
 		else etcListDate= etcList.get(etcList.size()-1).getEe_date();
 		if(dateList.size() <=0) dateListDate ="9999/99";
 		else dateListDate= dateList.get(dateList.size()-1);
 		if(incomeList.size() <= 0) incomeListDate ="9999/99";
 		else incomeListDate= incomeList.get(incomeList.size()-1).getReg_date();
 		if(orderList.size() <=0) orderListDate="9999/99";
 		else orderListDate = orderList.get(orderList.size()-1).getA_date();
 		System.out.println("각최소날짜 : etcListDate:" + etcListDate + 
 				"/ dateListDate:" +dateListDate + "/ orderListDate" + 
 				orderListDate+"/ incomeListDate" + incomeListDate);
 		int temp1= Integer.parseInt(etcListDate.substring(0, 4))*10000 +Integer.parseInt(etcListDate.substring(5, 7));
 		int temp2= Integer.parseInt(dateListDate.substring(0, 4))*10000 + Integer.parseInt(dateListDate.substring(5, 7));
 		int temp3= Integer.parseInt(orderListDate.substring(0, 4))*10000 + Integer.parseInt(orderListDate.substring(5, 7));
 		int temp4= Integer.parseInt(incomeListDate.substring(0, 4))*10000 + Integer.parseInt(incomeListDate.substring(5, 7));
 		int temp =temp1 ;
 		String minDate;
 		minDate = etcListDate;
 		if(temp2 < temp ){
 			temp = temp2;
 			minDate = dateListDate;
 		}
 		if(temp3 < temp){
 			temp = temp3;
 			minDate = orderListDate;
 		}
 		if(temp4 < temp){
 			temp = temp4;
 			minDate = incomeListDate;
 		}
 		
 		SimpleDateFormat mSimpleDateFormat = new SimpleDateFormat ( "yyyy/MM", Locale.KOREA );
 		Date currentTime = new Date ( );
 		String mTime = mSimpleDateFormat.format ( currentTime );
 		
 		String inFirst = minDate;
 		String inLast = mTime;
 		System.out.println("first " + inFirst);
 		System.out.println("inLast " + inLast);
 		int fyyyy,fmm,lyyyy,lmm;
 		fyyyy = Integer.parseInt(inFirst.substring(0, 4));
 		fmm = Integer.parseInt(inFirst.substring(5, 7));
 		lyyyy = Integer.parseInt(inLast.substring(0, 4));
 		lmm = Integer.parseInt(inLast.substring(5, 7));
 		String strMonth;
 		System.out.println("list3개의 값을 새롭게 만듬");
 	
 		int EtcIt=etcList.size()-1;
 		int OrderIt=orderList.size()-1;
 		int DateIt=allSumSalaryList.size()-1;
 		int IncomIt=incomeList.size()-1;
 		System.out.println("? ??? ?? "+dateList);
 		while(fyyyy<2017){
 			if(fmm > 12){
 				fmm = 1;
 				fyyyy ++;
 			}
 			if(fmm<10)    strMonth = "0"+ fmm;
 			else          strMonth = "" + fmm;
 			System.out.println(fyyyy + "/"+strMonth);
 			newDateList.add(fyyyy+"년"+strMonth+"월");
 			if(DateIt >= 0){
 				System.out.println( "DateIt:"+DateIt);
 				System.out.println( "dateList의 현재 date값:"+dateList.get(DateIt));
 				if(dateList.get(DateIt).equals(fyyyy + "/"+strMonth)){
 					System.out.println("dateList 값대임  it :" + DateIt);
 					System.out.println(String.valueOf(allSumSalaryList.get(DateIt)));
 					newAllSumSalaryList.add(allSumSalaryList.get(DateIt));
 					DateIt--;
 				}
 				else newAllSumSalaryList.add("0");
 			}else newAllSumSalaryList.add("0");
 			if(OrderIt >=0){
 				System.out.println("orderList의 현재 date값:"+orderList.get(OrderIt).getA_date());
 				if(orderList.get(OrderIt).getA_date().equals(fyyyy +"/"+ strMonth)){
 					System.out.println("orderList 값대임  it :" + OrderIt);
 					System.out.println(String.valueOf(orderList.get(OrderIt).getA_price()));
 					newOrderList.add(String.valueOf(orderList.get(OrderIt).getA_price()));
 					OrderIt--;
 				}
 				else {
 					newOrderList.add("0");
 					System.out.println("orderList 값 0 대입");
 				}
 			} 
 			else {
 				newOrderList.add("0");
 				System.out.println("orderList 값 0 대입");
 			}
 			if(EtcIt >=0){
 				System.out.println("newEtcList의 현재 EtcIt값:"+EtcIt);
 				System.out.println("newEtcList의 현재 date값:"+etcList.get(EtcIt).getEe_date());
 				if(etcList.get(EtcIt).getEe_date().equals(fyyyy + "/"+strMonth)){
 					System.out.println("newEtcList 값대임  it :" + EtcIt);
 					System.out.println(etcList.get(EtcIt).getEe_expend());
 					newEtcList.add(String.valueOf(etcList.get(EtcIt).getEe_expend()));
 					EtcIt--;
 				}
 				else {
 					newEtcList.add("0");
 					System.out.println("newEtcList 값 0 대입");
 				}
 			}else {
 				newEtcList.add("0");
 				System.out.println("newEtcList 값 0 대입");
 			}
 			
 			if(IncomIt >=0){
 				System.out.println("incomeList의 현재 date값:"+incomeList.get(IncomIt).getReg_date());
 				if(incomeList.get(IncomIt).getReg_date().equals(fyyyy +"/"+ strMonth)){
 					System.out.println("incomeList 값대임  it :" + IncomIt);
 					newIncomeList.add(String.valueOf(incomeList.get(IncomIt).getC_price()));
 					IncomIt--;
 				}
 				else {
 					newIncomeList.add("0");
 					System.out.println("newIncomeList 값 0 대입");
 				}
 			} 
 			else {
 				newIncomeList.add("0");
 				System.out.println("newIncomeList 값 0 대입");
 			}
 			if(fyyyy == lyyyy && fmm == lmm){
 				System.out.println(fyyyy + fmm +" /" +lyyyy + lmm);
 				break;
 			}
 			fmm++;
 		}
 		System.out.println("size:"+ newEtcList.size());
 		System.out.println("size:"+ newOrderList.size());
 		System.out.println("size :"+ newDateList.size());
 		System.out.println("size:"+ newIncomeList.size());
 		System.out.println("size:"+ newAllSumSalaryList.size());
 		
 		for(int a=0; a<newEtcList.size(); a++){
 			System.out.print(newDateList.get(a)+"/");
 			System.out.print(newAllSumSalaryList.get(a)+"/");
 			System.out.print(newEtcList.get(a)+"/");
 			System.out.print(newOrderList.get(a)+"/");
 			System.out.print(newIncomeList.get(a)+"/");
 			System.out.println();
 		}
 		System.out.println("<---------------------------");
     }
	 
}
