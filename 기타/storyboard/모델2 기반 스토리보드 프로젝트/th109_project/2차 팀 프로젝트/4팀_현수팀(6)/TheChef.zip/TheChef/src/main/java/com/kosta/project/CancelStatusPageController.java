package com.kosta.project;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.kosta.project.dao.ICancelStatusPageDao;
import com.kosta.project.dto.CheckOutDTO;
import com.kosta.project.dto.DeliveryToCustomerDTO;

@Controller
public class CancelStatusPageController {

   @Autowired
   private SqlSession sqlSession;

   @RequestMapping(value = "/cancelStatusDelete")
   public String cancelStatusDelete(Locale locale, Model model, HttpServletRequest request) {
      System.out.println("구매,발송 필드 삭제");
      
      String orderNum = request.getParameter("d_orderNum");;
      ICancelStatusPageDao dao = sqlSession.getMapper(ICancelStatusPageDao.class);
      dao.chkout_cancel(orderNum);
      dao.delivery_cancel(orderNum);
      System.out.println("orderNum : "+orderNum);
      return "redirect:/cancelPage";
   }

   // 상품현황관리 페이지
   @RequestMapping(value = "/cancelPage")
   public String cancelStatus(Locale locale, Model model, HttpServletRequest request) {
      System.out.println("cancelPage()");

      ICancelStatusPageDao dao = sqlSession.getMapper(ICancelStatusPageDao.class);
      HashMap<String, Object> map = new HashMap<String, Object>();

      String searchby = request.getParameter("searchby");
      System.out.println("search by : " + searchby);
      if (searchby != null) {
         if (searchby.equals("purchase_id")) {
                map.put("search",searchby);
            map.put("searchby", request.getParameter("searchby_value"));//입력값
            map.put("dataFrom", request.getParameter("dataFrom"));
            map.put("dataTo", request.getParameter("dataTo"));
            System.out.println("1");
         } else if (searchby.equals("orderNumber")) {
            map.put("search",searchby);
            map.put("searchby", request.getParameter("searchby_value"));//입력값
            map.put("dataFrom", request.getParameter("dataFrom"));
            map.put("dataTo", request.getParameter("dataTo"));
            System.out.println("2");
         } else if(searchby.equals("all")) {
            map.put("search",searchby);
            map.put("searchby", request.getParameter("searchby_value"));//입력값
            map.put("dataFrom", request.getParameter("dataFrom"));
            map.put("dataTo", request.getParameter("dataTo"));
            System.out.println("3");
         }
      } else {
         System.out.println("초기 null이다");
         return "back.saleManage.cancelPage";
      }

      int pg = 1;
      String strPg = request.getParameter("pg");
      if (strPg != null) {
         pg = Integer.parseInt(strPg);
      }
      int rowSize = 10;
      int start = (pg * rowSize) - (rowSize - 1);
      int end = pg * rowSize;

      map.put("start", start);
      map.put("end", end);

      List<DeliveryToCustomerDTO> list = dao.search(map);
      int total = dao.searchcount(map);

      System.out.println("total.size:" + total);

      int allPage = (int) Math.ceil(total / (double) rowSize); // 페이지수

      int totalPage = total / rowSize + (total % rowSize == 0 ? 0 : 1);

      int block = 5; // 한페이지에 보여줄 범위 << [1] [2] [3] [4] [5] >>
      int fromPage = ((pg - 1) / block * block) + 1; // 보여줄 페이지의 시작
      // ((1-1)/10*10)
      int toPage = ((pg - 1) / block * block) + block; // 보여줄 페이지의 끝
      if (toPage > allPage) {
         toPage = allPage;
      }

      // paging할때 값물고가게 하려고 추가해준부분///////////////
      model.addAttribute("dataFrom", request.getParameter("dataFrom"));
      model.addAttribute("dataTo", request.getParameter("dataTo"));
      model.addAttribute("searchby", request.getParameter("searchby"));
      model.addAttribute("searchby_value", request.getParameter("searchby_value"));

      int cancelordercount = dao.cancelordercount(); // 취소 요청수 표시

      if (request.getParameter("id") != null && request.getParameter("d_orderNum") != null) {

         System.out.println("id:" + request.getParameter("id") + "d_orderNum:" + request.getParameter("d_orderNum"));

         ICancelStatusPageDao dao2 = sqlSession.getMapper(ICancelStatusPageDao.class);
         String orderNum = request.getParameter("d_orderNum");

         List<CheckOutDTO> check_out = dao.check_out_by(orderNum);
         List<DeliveryToCustomerDTO> delivery = dao.delivery_by(orderNum);

         model.addAttribute("check_out", check_out);
         model.addAttribute("delivery", delivery);
      }
     
      model.addAttribute("cancelordercount", cancelordercount);
      model.addAttribute("list", list);
      model.addAttribute("pg", pg);
      model.addAttribute("allPage", allPage);
      model.addAttribute("block", block);
      model.addAttribute("fromPage", fromPage);
      model.addAttribute("toPage", toPage);

      return "back.saleManage.cancelPage";
   }
}