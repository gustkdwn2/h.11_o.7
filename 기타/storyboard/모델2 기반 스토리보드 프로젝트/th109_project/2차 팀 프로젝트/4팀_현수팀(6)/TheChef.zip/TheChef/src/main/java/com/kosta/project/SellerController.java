package com.kosta.project;

import java.security.Principal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.kosta.project.dao.IAdmin_farm_orderDao;
import com.kosta.project.dao.IDealDao;
import com.kosta.project.dao.IFarmNameDao;
import com.kosta.project.dao.ISellerDao;
import com.kosta.project.dto.FarmNameDTO;
import com.kosta.project.dto.SellerDTO;


@Controller
public class SellerController {
   @Autowired
   private SqlSession SqlSession;
   
   ///////////////seller///////////////////
   @RequestMapping(value = "/sellerPage")
      public String seller(Principal principal,Model model,HttpServletRequest request){
         System.out.println("sellerPage()");
         String id = principal.getName(); // 로그인한 id값 가져오기
         
         int pageSize = 3; // 한페이지에 나오는 최대 데이터 갯수
         int allCount = 0;// 데이터 총 갯수
         int count = 0;// 한페이지에 나오는 데이터 총 갯수
         String pageNum = request.getParameter("pageNum");//페이지번호
         if(pageNum == null){ // null인 경우 1로 지정
            pageNum = "1";
         }
         int currentPage = Integer.parseInt(pageNum); // currentPage : 현재 보고 있는 페이지
         int startRow = (currentPage * pageSize) - (pageSize-1); // 현재페이지의 시작행
          int endRow = currentPage * pageSize; // 현재페이지의 끝행
          
          
          System.out.println("pageNum : " + pageNum);
          System.out.println("currentPage : " + currentPage);
          System.out.println("startRow : " + startRow);
          System.out.println("endRow : " + endRow);
         
          Map map = new HashMap<>();
          map.put("farm_id", id);
          map.put("startRow", startRow);
          map.put("endRow", endRow);
          
         ISellerDao dao = SqlSession.getMapper(ISellerDao.class);
         
         //farm_id에 해당하는 총 데이터 갯수
         allCount = dao.countSellerInfo(id);
         System.out.println("count : "+count);
         
         //farm_Name가져오기
         IFarmNameDao fdao = SqlSession.getMapper(IFarmNameDao.class);         
         
         //한페이지에 표시할 farm_id에 해당하는 데이터 
         List<SellerDTO> sellerInfo = dao.selectSellerInfo(map);
         count = sellerInfo.size();
         System.out.println("allCount : "+allCount);
         model.addAttribute("count", new Integer(count));
          model.addAttribute("currentPage", new Integer(currentPage));
          model.addAttribute("startRow", new Integer(startRow));
          model.addAttribute("endRow", new Integer(endRow));
          model.addAttribute("allCount", new Integer(allCount));
          model.addAttribute("pageSize", new Integer(pageSize));
         
          model.addAttribute("sellerInfo",sellerInfo);
          model.addAttribute("farm_name",fdao.selectFarmName(id));
          
          System.out.println(fdao.selectFarmName(id));
          
   
          
          //////////////아래 페이징쪽 추가해보껭///////////
          int pg = 1;
         String strPg = request.getParameter("pg");
         if (strPg != null) {
            pg = Integer.parseInt(strPg);
         }
         int rowSize = 10;
         int start = (pg * rowSize) - (rowSize - 1);
         int end = pg * rowSize;
         Map map0 = new HashMap<>();
         map0.put("start", start);
         map0.put("end", end);
         map0.put("farm_id", id);
         int total=0;
         int total1=0;
/////////////////////발주건 /////////////////////////////////////////////////////////
         IAdmin_farm_orderDao adao = SqlSession.getMapper(IAdmin_farm_orderDao.class);
         model.addAttribute("OrderList",adao.selectOrderAll(map0));
         total = adao.OrderListCount(map0);
/////////////////////발주완료건 /////////////////////////////////////////////////////////
          int pg1 = 1;
         String strPg1 = request.getParameter("pg1");
         if (strPg1 != null) {
            pg1 = Integer.parseInt(strPg1);
         }
         int rowSize1 = 10;
         int start1 = (pg1 * rowSize1) - (rowSize1 - 1);
         int end1 = pg1 * rowSize1;
         Map map1 = new HashMap<>();
         map1.put("start", start1);
         map1.put("end", end1);
         map1.put("farm_id", id);
         
         model.addAttribute("OrderOkList",adao.selectOrderOkAll(map1));
         total1 = adao.OrderOkListCount(map1);
/////////////////////////////////////////////////////////////////////////////////////         
         
         
         int allPage = (int) Math.ceil(total / (double) rowSize); // 페이지수
         // int totalPage = total/rowSize + (total%rowSize==0?0:1);

         int block = 5; // 한페이지에 보여줄 범위 << [1] [2] [3] [4] [5] >>
         int fromPage = ((pg - 1) / block * block) + 1; // 보여줄 페이지의 시작
         // ((1-1)/10*10)
         int toPage = ((pg - 1) / block * block) + block; // 보여줄 페이지의 끝
         if (toPage > allPage) {
            toPage = allPage; 
         }
         
         model.addAttribute("pg", pg);
         model.addAttribute("allPage", allPage);
         model.addAttribute("block", block);
         model.addAttribute("fromPage", fromPage);
         model.addAttribute("toPage", toPage);

         
///////////////////////////////////////////////////////////////////////////////////////         
         /*int pg1 = 1;
         String strPg1 = request.getParameter("pg1");
         if (strPg1 != null) {
            pg1 = Integer.parseInt(strPg1);
         }*/
         int allPage1 = (int) Math.ceil(total1 / (double) rowSize); // 페이지수
         // int totalPage = total/rowSize + (total%rowSize==0?0:1);

         int block1 = 5; // 한페이지에 보여줄 범위 << [1] [2] [3] [4] [5] >>
         int fromPage1 = ((pg1 - 1) / block1 * block1) + 1; // 보여줄 페이지의 시작
         // ((1-1)/10*10)
         int toPage1 = ((pg1 - 1) / block1 * block1) + block1; // 보여줄 페이지의 끝
         if (toPage1 > allPage1) {
            toPage1 = allPage1; 
         }
         
         
         model.addAttribute("pg1", pg1);
         model.addAttribute("allPage1", allPage1);
         model.addAttribute("block1", block1);
         model.addAttribute("fromPage1", fromPage1);
         model.addAttribute("toPage1", toPage1);
      ////////////////////////////////////////////////////////////////////////////////////   
         
          return "seller.accept.productAccept";
   }

   @RequestMapping(value = "/SellerProductWrite", method = RequestMethod.GET)
   public String home(Locale locale, Model model) {
      System.out.println("sellerProductWrite()");
      return "seller.accept.SellerProductWrite";
   }
   @RequestMapping(value="/insertSellerProduct") //SellerProductWrite.jsp에서 왔음, 판매자가 상품등록하는 부분
   public String insertSellerProduct(Principal principal, SellerDTO dto, HttpServletRequest request){
      System.out.println("insertSellerProduct");
      String id = principal.getName();
      dto.setFarm_id(id);
      
      //카테고리랑 상품명이 같으면 귀농인은 또다른 상품 insert가 아닌 기존에 올렸던 거에 update
      /*String farm_Pcategory = request.getParameter("farm_Pcategory");
      String productName = request.getParameter("productName");*/
      
      ISellerDao dao = SqlSession.getMapper(ISellerDao.class);
      
      List<SellerDTO> alreadyUploadFarmInfo = dao.alreadyUploadFarmInfo(dto);
      
      if(alreadyUploadFarmInfo.size() == 0){//insert
          dao.insertSellerProduct(dto);//farmInfo테이블에 데이터 삽입
      } else { //이미 같은 상품을 올렸다면, update
    	  dto.setFarm_Pid(alreadyUploadFarmInfo.get(0).getFarm_Pid());
    	  dao.updateSellerProduct2(dto);
      }
      
      return "redirect:/sellerPage";
   }
   @RequestMapping("/updateSellerProduct_View")
   public String updateSellerProduct_View(Model model, HttpServletRequest request){
      System.out.println("updateSellerProduct_View");
      String farm_Pid = request.getParameter("farm_Pid");
      /*
      String farm_Pname = request.getParameter("farm_Pname");
      String farm_Pcount = request.getParameter("farm_Pcount");
      String farm_Pprice = request.getParameter("farm_Pprice");
      */
      ISellerDao dao= SqlSession.getMapper(ISellerDao.class);
      model.addAttribute("list",dao.updateSellerProductView(farm_Pid));
      
      return "seller.accept.SellerProductUpdate";
   }
   @RequestMapping(value="/updateSellerProduct")
   public String updateSellerProduct(Model model, HttpServletRequest request, SellerDTO dto){
      System.out.println("updateSellerProduct");
      /*SellerDTO dto = new SellerDTO();
      dto.setFarm_Pname(request.getParameter("farm_Pname"));
      dto.setFarm_Pprice(Integer.parseInt(request.getParameter("farm_Pprice")));
      dto.setFarm_Pcount(Integer.parseInt(request.getParameter("farm_Pcount")));*/
      ISellerDao dao = SqlSession.getMapper(ISellerDao.class);
      dao.updateSellerProduct(dto);
      return "redirect:/sellerPage";
   }
   @RequestMapping("/sellerProduct_delete")
   public String sellerProduct_delete(HttpServletRequest request,Model model, SellerDTO dto){
      String farm_Pid = request.getParameter("farm_Pid");
      System.out.println("sellerProduct_delete");
      ISellerDao dao = SqlSession.getMapper(ISellerDao.class);
      dao.deleteSellerProduct(farm_Pid);
      model.addAttribute("farm_Pid",farm_Pid);
      return "redirect:/sellerPage";
   }
   
   
   ///////////////////back-saleManage////////////////////////////////
   @RequestMapping("/farmName")
   public String farmName(){
      System.out.println("farmName");
      return "seller.accept.farmName";
   }
   @RequestMapping("/insertFarmName")
   public String insertFarmName(Principal principal,FarmNameDTO dto){
      System.out.println("insertFarmName");
      String id = principal.getName();
      dto.setFarm_id(id);
      
      IFarmNameDao dao = SqlSession.getMapper(IFarmNameDao.class);
      dao.insertFarmName(dto);
      return "redirect:/sellerPage";
   }
   @RequestMapping("/farmNameUpdate")
   public String farmName2(){
      System.out.println("farmNameUpdate");
      return "seller.accept.farmNameUpdate";
   }
   @RequestMapping("/updateFarmName")
   public String updateFarmName(Principal principal,FarmNameDTO dto){
      dto.setFarm_id(principal.getName());
      IFarmNameDao dao = SqlSession.getMapper(IFarmNameDao.class);
      dao.updateFarmName(dto);
      return "redirect:/sellerPage";
   }
   
   @RequestMapping("/sellerCalculatorPage")
   public String sellerCalculatorPage(HttpServletRequest request,Model model,Principal principal){
      IDealDao dao = SqlSession.getMapper(IDealDao.class);
      System.out.println("sellerCalculatorPage()");
      String id = principal.getName(); // id저장
      if(request.getParameter("index")==null){ // 검색하지 않은 첫화면
         System.out.println(request.getParameter("index"));
         Date sysdate = dao.findMonth();
            System.out.println("sysdate : " + sysdate);
            
          //Date타입을 String 타입으로 바꿔서 현재 년과 월을 구하기
            SimpleDateFormat transFormat = new SimpleDateFormat("MM");
            String month = transFormat.format(sysdate);
            
            transFormat = new SimpleDateFormat("yyyy");
            String year = transFormat.format(sysdate);
            
            System.out.println("현재 월 : " + month);//06
            System.out.println("현재 년 : " + year);//2016
            
        ////string 타입의 날짜를 Date타입으로 바꾸기//////
            String start  = year + "-" + month + "-" + "01";// 형식을 지켜야 함
            java.sql.Date startRegdate = java.sql.Date.valueOf(start);
            
            String end  = year + "-" + month + "-" + "31";// 형식을 지켜야 함
            java.sql.Date endRegdate = java.sql.Date.valueOf(end);
            
            model.addAttribute("date", year +"-" + month);
            model.addAttribute("sellerSearch",dao.sellerDealID(startRegdate,endRegdate,id)); //전체정산조회
      }else{//검색누른페이지
         System.out.println(request.getParameter("index"));
         String startRegdate = request.getParameter("startRegdate");
            String endRegdate = request.getParameter("endRegdate");
            String searchKeyword = request.getParameter("searchKeyword");
            
            System.out.println("startRegdate : " + startRegdate);
            System.out.println("startRegdate : " + endRegdate);
            System.out.println("searchKeyword : " + searchKeyword);
         
            Map map = new HashMap<>();
            map.put("startRegdate", request.getParameter("startRegdate"));
            map.put("endRegdate", request.getParameter("endRegdate"));
            map.put("searchKeyword",request.getParameter("searchKeyword"));
            map.put("farm_id",id);
            
            model.addAttribute("sellerSearch",dao.sellerSearchID(map));
      }
      
      return "seller.accept.calculatorPage";
   }
   
}