package com.kosta.project.dto;

public class DeliveryToCustomerDTO {
	private int d_orderNum, d_shipping_fee, d_total_price, d_status;
	private String id;
	private String reg_date;
	
	public DeliveryToCustomerDTO() {}

	public DeliveryToCustomerDTO(int d_orderNum, int d_shipping_fee, int d_total_price, int d_status, String id,
			String reg_date) {
		this.d_orderNum = d_orderNum;
		this.d_shipping_fee = d_shipping_fee;
		this.d_total_price = d_total_price;
		this.d_status = d_status;
		this.id = id;
		this.reg_date = reg_date;
	}

	public int getD_orderNum() {
		return d_orderNum;
	}

	public void setD_orderNum(int d_orderNum) {
		this.d_orderNum = d_orderNum;
	}

	public int getD_shipping_fee() {
		return d_shipping_fee;
	}

	public void setD_shipping_fee(int d_shipping_fee) {
		this.d_shipping_fee = d_shipping_fee;
	}

	public int getD_total_price() {
		return d_total_price;
	}

	public void setD_total_price(int d_total_price) {
		this.d_total_price = d_total_price;
	}

	public int getD_status() {
		return d_status;
	}

	public void setD_status(int d_status) {
		this.d_status = d_status;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getReg_date() {
		return reg_date;
	}

	public void setReg_date(String reg_date) {
		this.reg_date = reg_date;
	}
	
}
