package com.kosta.project.dao;

import java.util.List;
import java.util.Map;

import com.kosta.project.dto.AdminFarmOrderDTO;

public interface IAdmin_farm_orderDao { 
   //등록
   public void insertProductOrder(AdminFarmOrderDTO dto);
   //발주건
   public List<AdminFarmOrderDTO> selectOrderAll(Map map);
   //발송완료했을때!!
   public void updateOrderOk (int seq_ordernum);
   //발송완료건
   public List<AdminFarmOrderDTO> selectOrderOkAll(Map map);

   //관리자_발주상품조회_'Y'인것만
   public List<AdminFarmOrderDTO> adminOrderAllY();
   
   // 관리자가 확인하면 'Y'에서 'ok'로 업데이트
   public void updateStockOk(String seq_ordernum);
   
   // 관리자가 발주상품조회 전체
   public List<AdminFarmOrderDTO> adminOrderAllList();
   
   //페이징 위해 갯수 가져오는 메소드
   public int OrderListCount(Map map);
   public int OrderOkListCount(Map map);
   
   //관리자_발주상품조회_'Y'인것만 / 페이징
   public List<AdminFarmOrderDTO> adminOrderAllY(Map map);
   
   // 관리자가 발주상품조회 전체 / 페이징
   public List<AdminFarmOrderDTO> adminOrderAllList(Map map1);
   
   //관리자_발주상품조회_'Y'인것만 count
      public int adminOrderCountY();
      
   //관리자 발주상품 전체 count
   public int adminOrderCountAll();
}