package com.kosta.project.dto;

public class AdminMartOrderDTO {
	String mart_name, mart_Pid, mart_Pname, mart_unit, mart_orderDate, admin_id, mart_category;
	int mart_orderCount, mart_orderPrice;
	
	public AdminMartOrderDTO() {}

	

	public AdminMartOrderDTO(String mart_name, String mart_Pid, String mart_Pname, String mart_unit,
			String mart_orderDate, String admin_id, int mart_orderCount, int mart_orderPrice, String mart_category) {
		this.mart_name = mart_name;
		this.mart_Pid = mart_Pid;
		this.mart_Pname = mart_Pname;
		this.mart_unit = mart_unit;
		this.mart_orderDate = mart_orderDate;
		this.admin_id = admin_id;
		this.mart_orderCount = mart_orderCount;
		this.mart_orderPrice = mart_orderPrice;
		this.mart_category = mart_category;
	}

	public String getMart_name() {
		return mart_name;
	}

	public void setMart_name(String mart_name) {
		this.mart_name = mart_name;
	}

	public String getMart_Pid() {
		return mart_Pid;
	}

	public void setMart_Pid(String mart_Pid) {
		this.mart_Pid = mart_Pid;
	}

	public String getMart_Pname() {
		return mart_Pname;
	}

	public void setMart_Pname(String mart_Pname) {
		this.mart_Pname = mart_Pname;
	}

	public String getMart_unit() {
		return mart_unit;
	}

	public void setMart_unit(String mart_unit) {
		this.mart_unit = mart_unit;
	}

	public String getMart_orderDate() {
		return mart_orderDate;
	}

	public void setMart_orderDate(String mart_orderDate) {
		this.mart_orderDate = mart_orderDate;
	}

	public String getAdmin_id() {
		return admin_id;
	}

	public void setAdmin_id(String admin_id) {
		this.admin_id = admin_id;
	}

	public int getMart_orderCount() {
		return mart_orderCount;
	}

	public void setMart_orderCount(int mart_orderCount) {
		this.mart_orderCount = mart_orderCount;
	}

	public int getMart_orderPrice() {
		return mart_orderPrice;
	}

	public void setMart_orderPrice(int mart_orderPrice) {
		this.mart_orderPrice = mart_orderPrice;
	}

	public String getMart_category() {
		return mart_category;
	}

	public void setMart_category(String mart_category) {
		this.mart_category = mart_category;
	}
	
	
}
