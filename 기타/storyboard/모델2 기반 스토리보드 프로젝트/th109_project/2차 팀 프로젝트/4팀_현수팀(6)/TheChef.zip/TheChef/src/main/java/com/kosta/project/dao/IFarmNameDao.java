package com.kosta.project.dao;

import com.kosta.project.dto.FarmNameDTO;

public interface IFarmNameDao {
	//등록
	public void insertFarmName(FarmNameDTO dto);

	public String selectFarmName(String farm_id);
	
	//수정
	public void updateFarmName(FarmNameDTO dto);
}
