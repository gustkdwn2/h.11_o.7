package com.kosta.project.dto;

public class AdminFarmOrderDTO {

	int seq_ordernum, orderCount, orderPrice;
	String orderDate, okDate;
	String farm_id, farm_Pid, farm_Pname, admin_id, order_ok, farm_Pcategory, farm_unit;

	public AdminFarmOrderDTO() {}

	public AdminFarmOrderDTO(int seq_ordernum, int orderCount, int orderPrice, String orderDate, String okDate,
			String farm_id, String farm_Pid, String farm_Pname, String admin_id, String order_ok, String farm_Pcategory,
			String farm_unit) {
		this.seq_ordernum = seq_ordernum;
		this.orderCount = orderCount;
		this.orderPrice = orderPrice;
		this.orderDate = orderDate;
		this.okDate = okDate;
		this.farm_id = farm_id;
		this.farm_Pid = farm_Pid;
		this.farm_Pname = farm_Pname;
		this.admin_id = admin_id;
		this.order_ok = order_ok;
		this.farm_Pcategory = farm_Pcategory;
		this.farm_unit = farm_unit;
	}

	public int getSeq_ordernum() {
		return seq_ordernum;
	}

	public void setSeq_ordernum(int seq_ordernum) {
		this.seq_ordernum = seq_ordernum;
	}

	public int getOrderCount() {
		return orderCount;
	}

	public void setOrderCount(int orderCount) {
		this.orderCount = orderCount;
	}

	public int getOrderPrice() {
		return orderPrice;
	}

	public void setOrderPrice(int orderPrice) {
		this.orderPrice = orderPrice;
	}

	public String getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}

	public String getOkDate() {
		return okDate;
	}

	public void setOkDate(String okDate) {
		this.okDate = okDate;
	}

	public String getFarm_id() {
		return farm_id;
	}

	public void setFarm_id(String farm_id) {
		this.farm_id = farm_id;
	}

	public String getFarm_Pid() {
		return farm_Pid;
	}

	public void setFarm_Pid(String farm_Pid) {
		this.farm_Pid = farm_Pid;
	}

	public String getFarm_Pname() {
		return farm_Pname;
	}

	public void setFarm_Pname(String farm_Pname) {
		this.farm_Pname = farm_Pname;
	}

	public String getAdmin_id() {
		return admin_id;
	}

	public void setAdmin_id(String admin_id) {
		this.admin_id = admin_id;
	}

	public String getOrder_ok() {
		return order_ok;
	}

	public void setOrder_ok(String order_ok) {
		this.order_ok = order_ok;
	}

	public String getFarm_Pcategory() {
		return farm_Pcategory;
	}

	public void setFarm_Pcategory(String farm_Pcategory) {
		this.farm_Pcategory = farm_Pcategory;
	}

	public String getFarm_unit() {
		return farm_unit;
	}

	public void setFarm_unit(String farm_unit) {
		this.farm_unit = farm_unit;
	}
	
	
}