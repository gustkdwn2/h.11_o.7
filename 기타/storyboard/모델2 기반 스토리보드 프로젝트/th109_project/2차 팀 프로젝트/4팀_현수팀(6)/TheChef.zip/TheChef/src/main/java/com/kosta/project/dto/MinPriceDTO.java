package com.kosta.project.dto;

public class MinPriceDTO {
	String product_name;
	int product_price;
	
	public MinPriceDTO() {
		// TODO Auto-generated constructor stub
	}

	public MinPriceDTO(String product_name, int product_price) {
		this.product_name = product_name;
		this.product_price = product_price;
	}

	public String getProduct_name() {
		return product_name;
	}

	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}

	public int getProduct_price() {
		return product_price;
	}

	public void setProduct_price(int product_price) {
		this.product_price = product_price;
	}
	
	
}
