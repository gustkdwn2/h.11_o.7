package com.kosta.project.dto;

public class SellerDTO {// farmInfo에 대한 DTO

	String farm_id, farm_Pid, farm_Pname, farm_Pcategory, farm_unit;
	int farm_Pcount, farm_Pprice;

	public SellerDTO() {
	}

	public SellerDTO(String farm_id, String farm_Pid, String farm_Pname, String farm_Pcategory, String farm_unit,
			int farm_Pcount, int farm_Pprice) {
		super();
		this.farm_id = farm_id;
		this.farm_Pid = farm_Pid;
		this.farm_Pname = farm_Pname;
		this.farm_Pcategory = farm_Pcategory;
		this.farm_unit = farm_unit;
		this.farm_Pcount = farm_Pcount;
		this.farm_Pprice = farm_Pprice;
	}

	public String getFarm_id() {
		return farm_id;
	}

	public void setFarm_id(String farm_id) {
		this.farm_id = farm_id;
	}

	public String getFarm_Pid() {
		return farm_Pid;
	}

	public void setFarm_Pid(String farm_Pid) {
		this.farm_Pid = farm_Pid;
	}

	public String getFarm_Pname() {
		return farm_Pname;
	}

	public void setFarm_Pname(String farm_Pname) {
		this.farm_Pname = farm_Pname;
	}

	public String getFarm_Pcategory() {
		return farm_Pcategory;
	}

	public void setFarm_Pcategory(String farm_Pcategory) {
		this.farm_Pcategory = farm_Pcategory;
	}

	public String getFarm_unit() {
		return farm_unit;
	}

	public void setFarm_unit(String farm_unit) {
		this.farm_unit = farm_unit;
	}

	public int getFarm_Pcount() {
		return farm_Pcount;
	}

	public void setFarm_Pcount(int farm_Pcount) {
		this.farm_Pcount = farm_Pcount;
	}

	public int getFarm_Pprice() {
		return farm_Pprice;
	}

	public void setFarm_Pprice(int farm_Pprice) {
		this.farm_Pprice = farm_Pprice;
	}

}
