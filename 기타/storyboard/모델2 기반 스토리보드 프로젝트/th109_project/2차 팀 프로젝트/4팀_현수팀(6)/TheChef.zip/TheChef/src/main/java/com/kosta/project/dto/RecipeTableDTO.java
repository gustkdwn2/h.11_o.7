package com.kosta.project.dto;

public class RecipeTableDTO {
	String product_id, p_no, unit, product_name;
	int dose;
	
	public RecipeTableDTO() {}

	public RecipeTableDTO(String product_id, String p_no, String unit, String product_name, int dose) {
		this.product_id = product_id;
		this.p_no = p_no;
		this.unit = unit;
		this.product_name = product_name;
		this.dose = dose;
	}

	public String getProduct_id() {
		return product_id;
	}

	public void setProduct_id(String product_id) {
		this.product_id = product_id;
	}

	public String getP_no() {
		return p_no;
	}

	public void setP_no(String p_no) {
		this.p_no = p_no;
	}

	public String getUnit() {
		return unit;
	}

	public void setUnit(String unit) {
		this.unit = unit;
	}

	public int getDose() {
		return dose;
	}

	public void setDose(int dose) {
		this.dose = dose;
	}

	public String getProduct_name() {
		return product_name;
	}

	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}
	
	
}
