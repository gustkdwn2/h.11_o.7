package com.kosta.project.dto;

public class FarmNameDTO {
	String farm_id, farm_name;

	public String getFarm_id() {
		return farm_id;
	}

	public void setFarm_id(String farm_id) {
		this.farm_id = farm_id;
	}

	public String getFarm_name() {
		return farm_name;
	}

	public void setFarm_name(String farm_name) {
		this.farm_name = farm_name;
	}

	public FarmNameDTO(String farm_id, String farm_name) {
		this.farm_id = farm_id;
		this.farm_name = farm_name;
	}

	public FarmNameDTO() {
	}
	
	
}
