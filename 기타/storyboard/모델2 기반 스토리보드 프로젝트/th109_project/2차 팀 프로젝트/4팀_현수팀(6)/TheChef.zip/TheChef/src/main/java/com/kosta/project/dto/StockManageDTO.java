package com.kosta.project.dto;

public class StockManageDTO {

	String product_id, product_category, product_name, product_from, product_status;
	int product_totalCount, product_price;
	String product_regdate, product_unit;

	public StockManageDTO() {}

	public StockManageDTO(String product_id, String product_category, String product_name, String product_from,
			String product_status, int product_totalCount, int product_price, String product_regdate,
			String product_unit) {
		this.product_id = product_id;
		this.product_category = product_category;
		this.product_name = product_name;
		this.product_from = product_from;
		this.product_status = product_status;
		this.product_totalCount = product_totalCount;
		this.product_price = product_price;
		this.product_regdate = product_regdate;
		this.product_unit = product_unit;
	}

	public String getProduct_id() {
		return product_id;
	}

	public void setProduct_id(String product_id) {
		this.product_id = product_id;
	}

	public String getProduct_category() {
		return product_category;
	}

	public void setProduct_category(String product_category) {
		this.product_category = product_category;
	}

	public String getProduct_name() {
		return product_name;
	}

	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}

	public String getProduct_from() {
		return product_from;
	}

	public void setProduct_from(String product_from) {
		this.product_from = product_from;
	}

	public String getProduct_status() {
		return product_status;
	}

	public void setProduct_status(String product_status) {
		this.product_status = product_status;
	}

	public int getproduct_totalCount() {
		return product_totalCount;
	}

	public void setproduct_totalCount(int product_totalCount) {
		this.product_totalCount = product_totalCount;
	}

	public int getProduct_price() {
		return product_price;
	}

	public void setProduct_price(int product_price) {
		this.product_price = product_price;
	}

	public String getProduct_regdate() {
		return product_regdate;
	}

	public void setProduct_regdate(String product_regdate) {
		this.product_regdate = product_regdate;
	}

	public String getProduct_unit() {
		return product_unit;
	}

	public void setProduct_unit(String product_unit) {
		this.product_unit = product_unit;
	}
}