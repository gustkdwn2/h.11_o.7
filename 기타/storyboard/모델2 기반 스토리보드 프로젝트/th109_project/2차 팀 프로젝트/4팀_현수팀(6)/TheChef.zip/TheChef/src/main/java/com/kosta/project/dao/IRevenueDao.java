package com.kosta.project.dao;

import java.util.ArrayList;
import java.util.List;

import com.kosta.project.dto.AdminFarmOrderDTO;
import com.kosta.project.dto.AdminMartOrderDTO;
import com.kosta.project.dto.AdminOrderDTO;
import com.kosta.project.dto.CheckOutDTO;
import com.kosta.project.dto.ExpendEtcDTO;
import com.kosta.project.dto.ExpendEtcSumPerMonthDTO;
import com.kosta.project.dto.SalaryDTO;

public interface IRevenueDao {

	List<ExpendEtcSumPerMonthDTO> expendEtcSumPerMonth();
	List<ExpendEtcSumPerMonthDTO> expendEtcListAboutMonth(String monthOfEe_date);
	String getDateOfEe_num(Integer ee_num);

	void updateExpendEtc(ExpendEtcDTO vo);

	void deleteExpendEtc(Integer ee_num);
	void addExpendEtc(ExpendEtcDTO vo);
	List<SalaryDTO> getSalaryList();
	List<SalaryDTO> getSalaryExistE_numANDE_name();
	List<AdminFarmOrderDTO> expendBuyInFarmAboutOkDate(String okDate);
	List<AdminFarmOrderDTO> expendBuyInFarm();
	List<AdminMartOrderDTO> expendBuyInMARTAboutMart_orderdate(String mart_orderDate);
	List<AdminMartOrderDTO> expendBuyInMart();
	List<AdminOrderDTO> getAdminOrder();
	List<AdminOrderDTO> getAdminOrderAboutDate(String a_date);
	List<CheckOutDTO> allIncome();
	List<CheckOutDTO> allIncomeAboutMonth(String reg_date);
	
	
}