package com.kosta.project.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.kosta.project.dto.AdminMartOrderDTO;
import com.kosta.project.dto.RTPdto;
import com.kosta.project.dto.RTPorderDTO;
import com.kosta.project.dto.StockManageDTO;

public interface IStockManageDAO {
	
	//총 재고 목록 갯수
	public int CountAllStockList();
	
	//한페이지에 뜨는 재고 목록
	public List<StockManageDTO> onePage_selectStockList(Map map);

	// 관리자 재고에 상품이 있는지없는지 확인
	public int checkPid(String farm_Pid);

	// 관리자 재고에 상품이 없는경우 insert
	public void insertStock(StockManageDTO sdto);
	
	//귀농 인들 이외에서 거래한 품목 재고에 등록시
	public void insertStockMart(StockManageDTO sdto);
	
	// 관리자 재고에 상품이 있는경우 update +
	public void updateStockPlus(StockManageDTO sdto);
	
	public List<RTPdto> selectRTPList();

	// 관리자 재고 삭제
	public void deleteAdminOrder(String product_id);
	
	// 관리자 재고 수정
	//public void modifyStock(StockManageDTO dto);

	//레시피테마상품 요청
	public void insertRTPprice(RTPorderDTO rtpDto);

	public List<String> getMeat();

	public List<String> getVegetable();

	public List<String> getMilk();

	public List<String> getSauce();

	public List<String> getFish();

	public List<String> getFruit();

	public List<String> getEtc();

	public List<StockManageDTO> findProduct_id(String product_name);

	public List<StockManageDTO> findUnit(String product_name);

	public void updateStock(StockManageDTO dto);

	public int findFarmPrice(@Param("_farm_Pid") String farm_Pid);

	public void insertAdminMartOrder(AdminMartOrderDTO mdto);
	
	//마트에서 거래한 상품 등록시) 거래처, 상품명, 카테고리가 모두 같은 거를 또 한번 등록 했을 경우, 재고 테이블에 insert가 아니라 update
	public int checkMartPid(@Param("_product_from") String product_from, @Param("_product_name") String product_name, @Param("_category") String category);

	public void updateStockMart(StockManageDTO sdto);

	public void insertAdminMartOrder2(AdminMartOrderDTO mdto);
}
