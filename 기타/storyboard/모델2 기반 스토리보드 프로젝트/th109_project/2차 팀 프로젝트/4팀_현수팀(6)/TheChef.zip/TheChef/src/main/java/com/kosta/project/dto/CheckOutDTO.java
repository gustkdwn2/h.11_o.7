package com.kosta.project.dto;

public class CheckOutDTO {
   private String c_no, id, c_name, c_address, c_zip_code, c_phone, name;
   private String reg_date;
   private int c_price, count, code, c_tPrice, c_orderNum, c_status;
   private String p_thumbFile;

   public CheckOutDTO() {
   }

   public CheckOutDTO(String c_no, String id, String c_name, String c_address, String c_zip_code, String c_phone,
         String name, String reg_date, int c_price, int count, int code, int c_tPrice, int c_orderNum, int c_status,
         String p_thumbFile) {
      this.c_no = c_no;
      this.id = id;
      this.c_name = c_name;
      this.c_address = c_address;
      this.c_zip_code = c_zip_code;
      this.c_phone = c_phone;
      this.name = name;
      this.reg_date = reg_date;
      this.c_price = c_price;
      this.count = count;
      this.code = code;
      this.c_tPrice = c_tPrice;
      this.c_orderNum = c_orderNum;
      this.c_status = c_status;
      this.p_thumbFile = p_thumbFile;
   }

   public String getC_no() {
      return c_no;
   }

   public void setC_no(String c_no) {
      this.c_no = c_no;
   }

   public String getId() {
      return id;
   }

   public void setId(String id) {
      this.id = id;
   }

   public String getC_name() {
      return c_name;
   }

   public void setC_name(String c_name) {
      this.c_name = c_name;
   }

   public String getC_address() {
      return c_address;
   }

   public void setC_address(String c_address) {
      this.c_address = c_address;
   }

   public String getC_zip_code() {
      return c_zip_code;
   }

   public void setC_zip_code(String c_zip_code) {
      this.c_zip_code = c_zip_code;
   }

   public String getC_phone() {
      return c_phone;
   }

   public void setC_phone(String c_phone) {
      this.c_phone = c_phone;
   }

   public String getName() {
      return name;
   }

   public void setName(String name) {
      this.name = name;
   }

   public String getReg_date() {
      return reg_date;
   }

   public void setReg_date(String reg_date) {
      this.reg_date = reg_date;
   }

   public int getC_price() {
      return c_price;
   }

   public void setC_price(int c_price) {
      this.c_price = c_price;
   }

   public int getCount() {
      return count;
   }

   public void setCount(int count) {
      this.count = count;
   }

   public int getCode() {
      return code;
   }

   public void setCode(int code) {
      this.code = code;
   }

   public int getC_tPrice() {
      return c_tPrice;
   }

   public void setC_tPrice(int c_tPrice) {
      this.c_tPrice = c_tPrice;
   }

   public int getC_orderNum() {
      return c_orderNum;
   }

   public void setC_orderNum(int c_orderNum) {
      this.c_orderNum = c_orderNum;
   }

   public int getC_status() {
      return c_status;
   }

   public void setC_status(int c_status) {
      this.c_status = c_status;
   }

   public String getP_thumbFile() {
      return p_thumbFile;
   }

   public void setP_thumbFile(String p_thumbFile) {
      this.p_thumbFile = p_thumbFile;
   }

}