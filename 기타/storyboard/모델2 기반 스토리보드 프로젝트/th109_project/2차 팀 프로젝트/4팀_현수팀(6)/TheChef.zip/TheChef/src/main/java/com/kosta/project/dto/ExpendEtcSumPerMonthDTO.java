package com.kosta.project.dto;

public class ExpendEtcSumPerMonthDTO {
	String ee_date;// varchar2(50) not null,   -- he_Date 년/월/일  2016/02/28
	long ee_expend;// number default 0,  -- he_Expend : 지출금
	int count;//지출 건수(해당 년/월과같은)
	public String getEe_date() {
		return ee_date;
	}
	public void setEe_date(String ee_date) {
		this.ee_date = ee_date;
	}
	public long getEe_expend() {
		return ee_expend;
	}
	public void setEe_expend(long ee_expend) {
		this.ee_expend = ee_expend;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
}
