package com.kosta.project.dto;

public class SoldOutDTO {
	String product_name, p_no;
	
	public SoldOutDTO() {}

	public SoldOutDTO(String product_name, String p_no) {
		this.product_name = product_name;
		this.p_no = p_no;
	}

	public String getProduct_name() {
		return product_name;
	}

	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}

	public String getP_no() {
		return p_no;
	}

	public void setP_no(String p_no) {
		this.p_no = p_no;
	}
	
	
}
