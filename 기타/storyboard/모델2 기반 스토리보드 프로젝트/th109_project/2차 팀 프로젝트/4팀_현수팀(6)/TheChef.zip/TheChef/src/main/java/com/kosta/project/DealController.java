package com.kosta.project;

import java.security.Principal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.kosta.project.dao.IDealDao;
import com.kosta.project.dto.DeliveryToCustomerDTO;

@Controller
public class DealController {

    @Autowired
      private SqlSession sqlSession;
    
    
    @RequestMapping("/ConsumerDealList") //정산페이지
      public String ConsumerDealList(HttpServletRequest request, Model model, Principal principal) throws Exception {
       
            IDealDao dao = sqlSession.getMapper(IDealDao.class);
            
            System.out.println("ConsumerDealList()");
            
           if(request.getParameter("index")==null){ 
              System.out.println(request.getParameter("index"));
               
              Date sysdate = dao.findMonth();
               System.out.println("sysdate : " + sysdate);
               
               //SimpleDateFormat transFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
               //Date타입을 String 타입으로 바꿔서 현재 년과 월을 구하기
               SimpleDateFormat transFormat = new SimpleDateFormat("MM");
               String month = transFormat.format(sysdate);
               
               transFormat = new SimpleDateFormat("yyyy");
               String year = transFormat.format(sysdate);
               
               System.out.println("현재 월 : " + month);//06
               System.out.println("현재 년 : " + year);//2016
               
               ////string 타입의 날짜를 Date타입으로 바꾸기//////
               String start  = year + "-" + month + "-" + "01";// 형식을 지켜야 함
               java.sql.Date startRegdate = java.sql.Date.valueOf(start);
               
               String end  = year + "-" + month + "-" + "31";// 형식을 지켜야 함
               java.sql.Date endRegdate = java.sql.Date.valueOf(end);
               
               List<DeliveryToCustomerDTO> ConsumerList = dao.dealList(startRegdate,endRegdate);//현재 월에 해당하는 리스트만 출력
               
               model.addAttribute("ConsumerList", ConsumerList);
               model.addAttribute("date", year +"-" + month);
               model.addAttribute("sellerSearch",dao.sellerDealAll(startRegdate,endRegdate)); //전체정산조회
           } else{ // 검색 누른 페이지
               System.out.println(request.getParameter("index"));
               
               System.out.println("searchDeal()");
               
               String startRegdate = request.getParameter("startRegdate");
               String endRegdate = request.getParameter("endRegdate");
               String searchKeyword = request.getParameter("searchKeyword");
               
               System.out.println("startRegdate : " + startRegdate);
               System.out.println("startRegdate : " + endRegdate);
               System.out.println("searchKeyword : " + searchKeyword);
               
               List<DeliveryToCustomerDTO> ConsumerList = dao.listSearch(startRegdate,endRegdate,searchKeyword);
               
               
                Map map = new HashMap<>();
               map.put("startRegdate", request.getParameter("startRegdate"));
               map.put("endRegdate", request.getParameter("endRegdate"));
               map.put("searchKeyword",request.getParameter("searchKeyword"));
               
               model.addAttribute("sellerSearch",dao.sellerSearch(map));
               
               model.addAttribute("ConsumerList", ConsumerList);
           }
          return "back.calculateManage.DealList";
    }
}