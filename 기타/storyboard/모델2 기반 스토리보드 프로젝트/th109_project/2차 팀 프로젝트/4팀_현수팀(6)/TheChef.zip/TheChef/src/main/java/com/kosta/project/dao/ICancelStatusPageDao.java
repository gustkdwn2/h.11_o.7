package com.kosta.project.dao;

import java.util.HashMap;
import java.util.List;

import com.kosta.project.dto.CheckOutDTO;
import com.kosta.project.dto.DeliveryToCustomerDTO;

public interface ICancelStatusPageDao {

   // 취소 내역 가져오기
   public List<CheckOutDTO> check_out_all(CheckOutDTO dto);

   // 발송 내역 가져오기
   public List<DeliveryToCustomerDTO> delivery_all();

   public void chkout_cancel(String c_orderNum);

   public void delivery_cancel(String d_orderNum);

   public List<DeliveryToCustomerDTO> search(HashMap<String, Object> map);

   public int searchcount(HashMap<String, Object> map);

   // 취소건수 표현용
   public int cancelordercount();

   // 발송하기 페이지에서 아이디 누르면 뜨게 하려고
   public List<CheckOutDTO> check_out_by(String orderNum);

   public List<DeliveryToCustomerDTO> delivery_by(String orderNum);
}