package com.kosta.project.dto;

public class ExpendEtcDTO {
	int ee_num;// number primary key,   -- he_num : 지출번호 (자동증가)  (PK)
	String  ee_date;// varchar2(50) not null,   -- he_Date 년/월/일  2016/02/28
	long  ee_expend;// number default 0,  -- he_Expend : 지출금
	String  ee_content;// varchar2(50) not null,   -- he_Content: 지출내역
	String ee_expendDirector;// varchar2(50)    -- he_ExpendDirector: 지출책임자
	public int getEe_num() {
		return ee_num;
	}
	public void setEe_num(int ee_num) {
		this.ee_num = ee_num;
	}
	public String getEe_date() {
		return ee_date;
	}
	public void setEe_date(String ee_date) {
		this.ee_date = ee_date;
	}
	public long getEe_expend() {
		return ee_expend;
	}
	public void setEe_expend(long ee_expend) {
		this.ee_expend = ee_expend;
	}
	public String getEe_content() {
		return ee_content;
	}
	public void setEe_content(String ee_content) {
		this.ee_content = ee_content;
	}            
	public String getEe_expendDirector() {
		return ee_expendDirector;
	}
	public void setEe_expendDirector(String ee_expendDirector) {
		this.ee_expendDirector = ee_expendDirector;
	}
	
	
}
