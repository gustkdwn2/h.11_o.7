package com.kosta.project.dto;

public class EmployeePositionDTO {
	int ep_num;//직책번호
	String ep_name;//직책이름
	int ep_salary;//월급 
	String ep_responsibility;//하는일 상세
	
	public String getEp_responsibility() {
		return ep_responsibility;
	}
	public void setEp_responsibility(String ep_responsibility) {
		this.ep_responsibility = ep_responsibility;
	}
	public int getEp_num() {
		return ep_num;
	}
	public void setEp_num(int ep_num) {
		this.ep_num = ep_num;
	}
	public String getEp_name() {
		return ep_name;
	}
	public void setEp_name(String ep_name) {
		this.ep_name = ep_name;
	}
	public int getEp_salary() {
		return ep_salary;
	}
	public void setEp_salary(int ep_salary) {
		this.ep_salary = ep_salary;
	}
		
}
