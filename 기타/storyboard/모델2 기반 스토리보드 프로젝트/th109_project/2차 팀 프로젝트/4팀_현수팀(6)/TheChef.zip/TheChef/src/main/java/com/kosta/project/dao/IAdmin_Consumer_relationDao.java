package com.kosta.project.dao;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.kosta.project.dto.CheckOutDTO;
import com.kosta.project.dto.DeliveryToCustomerDTO;

public interface IAdmin_Consumer_relationDao {
	
	// 구매완료한 내역 뽑아오기
	public List<CheckOutDTO> check_out_all(CheckOutDTO dto);

	// 주문 건수 구하기
	public List<DeliveryToCustomerDTO> delivery_all();

	// 구매 테이블 상태 변경
	public void updateCheck_Out(@Param("_c_orderNum") int c_orderNum);

	// 발송 테이블 상태 변경
	public void updateDelivery(@Param("_d_orderNum") int d_orderNum);

	// 해당 주문번호에 해당하는 모든 상품번호와 해당 상품의 갯수 뽑아오기
	public List<CheckOutDTO> findCnoCount(@Param("_d_orderNum") int d_orderNum);

	//재고수 빼기
    public void updateStock(@Param("_c_no") String c_no, @Param("_count") int count);

	public List<DeliveryToCustomerDTO> search(HashMap<String, Object> map);

	public int searchcount(HashMap<String, Object> map);

	//신규주문건수 표현용
	public int newordercount();

	
	//발송하기 페이지에서 아이디 누르면 뜨게 하려고
	public List<CheckOutDTO> check_out_by(String orderNum);
	public List<DeliveryToCustomerDTO> delivery_by(String orderNum);

	
	
	
}
