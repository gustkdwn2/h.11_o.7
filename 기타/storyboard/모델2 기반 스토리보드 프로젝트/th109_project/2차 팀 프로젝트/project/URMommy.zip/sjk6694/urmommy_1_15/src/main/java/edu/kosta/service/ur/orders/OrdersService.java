package edu.kosta.service.ur.orders;

import java.util.List;

import edu.kosta.model.dto.ur.orders.OrdersDTO;
import edu.kosta.model.dto.user.UserDTO;

public interface OrdersService {
   UserDTO getOrdererInfo(String user_id);
   
   void orderOne(OrdersDTO ordersDTO);

   void orderMulti(String[] o_pic, String[] item_num, String[] o_item_name, 
   				String[] o_size, int[] o_amountInt, int[] o_sell_priceInt, 
   				int[] o_total_priceInt, int[] cart_numInt, OrdersDTO ordersDTO);
      
   List<Integer> ordersNums();
   List<OrdersDTO> getOrderedList(String user_id);
   
   OrdersDTO getReceiver(int o_num);
   List<OrdersDTO> getOrderDetail(int o_num);

   void deleteOrders(String user_id);

   void updateO_state(OrdersDTO ordersDTO);

   void cancelOrder(String string, int o_num);
}