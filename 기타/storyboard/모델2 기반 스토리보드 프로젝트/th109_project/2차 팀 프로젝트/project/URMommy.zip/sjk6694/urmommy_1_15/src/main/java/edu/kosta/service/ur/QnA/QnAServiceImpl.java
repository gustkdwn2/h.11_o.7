package edu.kosta.service.ur.QnA;

import java.util.HashMap;



import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import edu.kosta.model.dto.ur.QnA.QnADAO;
import edu.kosta.model.dto.ur.QnA.QnADTO;
import edu.kosta.model.dto.ur.QnA.QnaCommentDTO;


@Component
public class QnAServiceImpl implements QnAService{
	
	@Autowired
	private SqlSession sqlsession;
	//QnA 게시판
	//QnA 게시판 리스트 출력
	@Override
	public List<QnADTO> getQnAList(HashMap<String,Object> map) {
		QnADAO qnaDAO = sqlsession.getMapper(QnADAO.class);
		return qnaDAO.getQnAList(map);
	}
	//QnA 게시판 입력
	@Override
	public void insertQnA(QnADTO dto) {
		QnADAO qnaDAO = sqlsession.getMapper(QnADAO.class);
		qnaDAO.insertQnA(dto);
	}
	
	//QnA 게시글 사용자가 원하는 부분만 DB에서 가져오기
	@Override
	public QnADTO getQnADTO(int num) {
		QnADAO qnaDAO = sqlsession.getMapper(QnADAO.class);
		return qnaDAO.getQnADTO(num);
	}
	//QnA 게시판 삭제
	@Override
	public void deleteQnA(QnADTO dto) {
		QnADAO qnaDAO = sqlsession.getMapper(QnADAO.class);
		qnaDAO.deleteQnA(dto);
	}
	//QnA 페이징 되어 리스트 출력
	@Override
	public int getQnACount(String item_num) {
		QnADAO qnaDAO = sqlsession.getMapper(QnADAO.class);
		return qnaDAO.getQnACount(item_num);
	}
	//QnA 게시판 수정
	@Override
	public int updateQnA(QnADTO dto) {
		QnADAO qnaDAO = sqlsession.getMapper(QnADAO.class);
		return qnaDAO.updateQnA(dto);
	}
	///////////////////QnA 댓글////////////////////////
	//QnA 댓글 입력
	@Override
	public void insertReply(QnaCommentDTO qnaVo) {
		QnADAO qnaDAO = sqlsession.getMapper(QnADAO.class);
		qnaDAO.insertReply(qnaVo);
		
	}
	//QnA 댓글 출력
	@Override
	public List<QnaCommentDTO> selectReply() {
		QnADAO qnaDAO = sqlsession.getMapper(QnADAO.class);
		return qnaDAO.selectReply();
		
	}

}
