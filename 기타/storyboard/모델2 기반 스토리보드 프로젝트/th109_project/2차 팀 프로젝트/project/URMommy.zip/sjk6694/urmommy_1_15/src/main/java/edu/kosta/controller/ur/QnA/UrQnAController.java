package edu.kosta.controller.ur.QnA;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import edu.kosta.model.dto.ur.QnA.QnADTO;
import edu.kosta.model.dto.ur.QnA.QnaCommentDTO;
import edu.kosta.service.ur.QnA.QnAService;
import edu.kosta.service.ur.item.ItemService;
import edu.kosta.service.ur.review.ReviewService;
/* 
 * @author (do hyup)
 * 
 * 이 컨트롤러는 QnA에서 실행되는 메소드를 담고 있다.
 * */

@Controller
public class UrQnAController {

	@Resource
	private QnAService qnaService;
	@Resource
	private ItemService itemService;	//일혜 추가.
	@Resource
	ReviewService reviewService;	//승모 추가.
	
	/*
	 * 
	 * 이 메소드는 QnA에 글을 쓸때에 item_num으로 StockDTO를 받아와 
	 * questionWriteform.jsp페이지로 이동을 하게한다.
	 * 
	 * 
	 * */
	@RequestMapping("/questionWriteform.do")
	public String writeform(QnADTO dto, HttpServletRequest request) {
		request.setAttribute("item_num", dto.getItem_num());
		return "question/questionWriteform";
	}
	/*
	 * 
	 * 이 메소드는 QnA에 글을 쓸때에 쓰는 메소드이다.
	 * @Param item_num 상품 번호.
	 * 글을 쓸때에 DB에 저장하는 부분이다.
	 * 
	 * */
	@RequestMapping(value="/questionWrite.do", method=RequestMethod.POST)
	public String write(HttpServletRequest request,QnADTO dto) {
		qnaService.insertQnA(dto);
		String item_num = request.getParameter("item_num");
		
		return "redirect:/itemDetail.do?item_num="+item_num;	
		}

	/*
	 * 
	 * 이 메소드는 QnA에 글을 수정 할 때에 QnADTO에 
	 * q_contents에 대한 내용을 글을 questionUpdateform.jsp페이지로 보낸다.
	 * 
	 * */
	@RequestMapping("/questionUpdateform.do")
	public String upadteform(HttpServletRequest request){
		request.setAttribute("q_contents", request.getParameter("q_contents"));
		return "question/questionUpdateform"; 
	}
	/*
	 * ITEM_NUM으로 페이지 처리를 하고 수정된 부분을 itemDetail.jsp부분으로 보낸다. 
	 * 
	 * */
	@RequestMapping("/questionUpdate.do")
	public String upadte(QnADTO dto, int page, HttpServletRequest request){
		page=Integer.parseInt(request.getParameter("page"));
		String item_num=request.getParameter("item_num");		
		int result = qnaService.updateQnA(dto);
		String res = "redirect:/itemDetail.do?page="+page+"&item_num="+item_num; 
		if(result == 0){
			res = "question/questionFail" ; //fail.jsp
		}
		return res;
	}

	/*
	 * ITEM_NUM으로 삭제할 게시물을 선택하고 결과값을 itemDetail.jsp로 보낸다. 
	 * 
	 * */
	@RequestMapping("/questionDelete.do")
	public String delete(HttpServletRequest request, QnADTO dto,int q_num) {
		String item_num =request.getParameter("item_num");	 
		qnaService.deleteQnA(dto); // 실패 : 0 , 성공 : 1
		return "redirect:/itemDetail.do?item_num="+item_num;
	}

	/*
	 *  답변에 대한 메소드.
	 *  QnADTO에서 변수를 받아온다.
	 * */
	  @RequestMapping("/questionReplyform.do") 
	  public String replyform(int num,Model model){
	  QnADTO dto = qnaService.getQnADTO(num); 
	  model.addAttribute("b",dto);
	  return "question/questionReplyform"; 
	  }
	  
	  /*
		 *  QnaCommentDTO에 QnADTO의 q_num을 저장하고
		 *  QnA에 추가를 한다. itemDetail.jsp로 보낸다.
		 * */
	@RequestMapping("/questionReply.do")
	public String reply(QnaCommentDTO vo,HttpSession session, HttpServletRequest request, int page,String item_num) {
		vo.setQ_num(Integer.parseInt(request.getParameter("q_num")));
		qnaService.insertReply(vo);
		return "redirect:/itemDetail.do?item_num=" + item_num;
	}
	
}
