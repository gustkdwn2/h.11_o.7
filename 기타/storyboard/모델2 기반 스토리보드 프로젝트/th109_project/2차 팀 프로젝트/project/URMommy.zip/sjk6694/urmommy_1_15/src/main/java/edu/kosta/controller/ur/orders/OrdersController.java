package edu.kosta.controller.ur.orders;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import edu.kosta.model.dto.ur.cart.CartDTO;
import edu.kosta.model.dto.ur.orders.OrdersDTO;
import edu.kosta.model.dto.ur.web_manage.Web_ManageDTO;
import edu.kosta.model.dto.user.UserDTO;
import edu.kosta.service.ur.bankbook.BankBookService;
import edu.kosta.service.ur.cart.CartService;
import edu.kosta.service.ur.orders.OrdersService;
import edu.kosta.service.ur.web_manage.Web_ManageService;

/* 
 * @author (EELHEA CHO)
 * 
 * 이 컨트롤러는 주문관련 메소드를 담고 있다.
 * */

@Controller
public class OrdersController {

	@Resource
	private Web_ManageService web_manageService;
	@Resource
	private OrdersService ordersService;
	@Resource
	private CartService cartService;
	@Resource
	private BankBookService bankbookservice;

	public void callCommonMethod(HttpServletRequest request){
		Web_ManageDTO mainlogo = web_manageService.getMainLogo();
		request.setAttribute("mainlogo", mainlogo);	
	}
	
   /*
    * @see cart/cartList.jsp
    * 
    * 이 메소드는 장바구니에서 하나의 상품을 구매했을때 실행되는 메소드이다.
    * 유지된 session에서 user_id를 가지고 온다.
    * 선택된 하나의 상품정보를 가지고 온 후, 구매액이 50000원 이상일 경우 배송비가 무료로 측정된다.
    * user_id를 통해 userAccount DB에서 주문자 정보를 가지고 온다.
    * 배송자 정보를 입력할 수 있는 주문하기 폼으로 넘어가게 된다.
    */
   @RequestMapping(value = "/getOrderOne.do", method = RequestMethod.GET)
   public String getOrderOne(HttpServletRequest request, int cart_num, HttpSession session) {
      
      UserDTO loginUser = (UserDTO) session.getAttribute("loginUser");
      String user_id = loginUser.getUser_id();
      
      callCommonMethod(request);
      
      CartDTO cartDTO = cartService.cartOneSelect(cart_num, user_id);

      int deli_price = 2500;
      int totals_price = cartDTO.getTotal_price();
      if (totals_price > 50000) {
         deli_price = 0;
      }
      int last_price = deli_price + totals_price;
      
      UserDTO ordererInfo = ordersService.getOrdererInfo(user_id);
      
      request.setAttribute("loginUser", loginUser);
      request.setAttribute("ordererInfo", ordererInfo);
      request.setAttribute("cartDTO", cartDTO);
      request.setAttribute("totals_price", totals_price);
      request.setAttribute("deli_price", deli_price);
      request.setAttribute("last_price", last_price);
      request.setAttribute("user_id", user_id);
      request.setAttribute("cart_num", cart_num);

      return "orders/orderOneInsertForm";
   }
   
   /*
    * @see orders/orderForm.jsp
    * @see edu.kosta.service.ur.bankbook.BankBook_income_insert
    * 
    * 상품 한 개를 주문했을 때 주문하기 폼에서 넘어오는 메소드이다.
    * 
    * 숫자 10자리 주문번호를 랜덤으로 생성한 후, o_num에 세팅해준다.
    * 만약 랜덤의 주문번호가 이미 존재한다면, 랜덤수에-1을 한 후 세팅해준다.
    * 
    * 서비스단에서 하나 주문 했을 시 실행되는 함수를 실행한다.
    */
   @RequestMapping(value = "/putOrderOne.do", method = RequestMethod.POST)
   public String putOrderOne(@ModelAttribute("ordersDTO") OrdersDTO ordersDTO, BindingResult bindingResult, HttpServletRequest request){
      
	  callCommonMethod(request);
	  
      Random ran = new Random();
      int o_num = ran.nextInt(999999999) + 2;
      List<Integer> chkOnum = ordersService.ordersNums();
      
      for (int i = 0; i < chkOnum.size(); i++) {
         if (o_num == chkOnum.get(i)) {
            o_num = o_num - 1;
         }//end if
      }//end for
      ordersDTO.setO_num(o_num);
      
      String postcode = request.getParameter("o_postcode");
      String address1 = request.getParameter("o_address1");
      String address2 = request.getParameter("o_address2");
      String o_address = postcode+", "+address1+" "+address2;
      ordersDTO.setO_address(o_address);
      
      ordersService.orderOne(ordersDTO);
      
      request.setAttribute("user_id", ordersDTO.getUser_id());
      request.setAttribute("o_num", ordersDTO.getO_num());
      
      return "orders/orderFinish";
      
   }

   /*
    * 이 메소드는 장바구니에서 여러개의 상품을 선택 구매했을때 배송자 입력 폼을 보여주는 메소드이다.
    * 유지된 session에서 user_id를 가지고 온다.
    * 
    * 각 상품의 장바구니 번호를 가지고 올 때, 콤마로 이어진 상태로 전달이 되기 때문에 split으로 나누어서 String배열에 저장한다.
    * String배열을 int배열로 변경해준다.
    * 
    * 선택한 여러개의 상품정보를 CartDTO형태의 List로 담아온다.
    * 각 상품의 결제액의 합이 50000원 이상일 경우 배송비가 무료로 측정된다.
    * 
    * user_id를 통해 userAccount DB에서 주문자 정보를 가지고 온다.
    * 배송자 정보를 입력할 수 있는 주문하기 폼으로 넘어가게 된다.
    */
   @RequestMapping(value = "/getOrderMulti.do", method = RequestMethod.GET)
   public String getOrderMulti(HttpServletRequest request, String cart_num, HttpSession session) {
      
      UserDTO loginUser = (UserDTO) session.getAttribute("loginUser");
      String user_id = loginUser.getUser_id();
      
      callCommonMethod(request);
      
      List<CartDTO> orderMultiList = new ArrayList<CartDTO>();

      int totals_price = 0;

      String[] splitOrderNum = cart_num.split(",");
      int[] orderNums = new int[splitOrderNum.length];
      for (int i = 0; i < orderNums.length; i++) {
         orderNums[i] = Integer.parseInt(splitOrderNum[i]);
         CartDTO cartDTO = cartService.cartOneSelect(orderNums[i], user_id);
         orderMultiList.add(cartDTO);
         totals_price += cartDTO.getTotal_price();
      }//end for
      int deli_price = 2500;
      if (totals_price > 50000) {
         deli_price = 0;
      }
      int last_price = deli_price + totals_price;

      UserDTO ordererInfo = ordersService.getOrdererInfo(user_id);
      
      request.setAttribute("loginUser", loginUser);
      request.setAttribute("user_id", user_id);
      request.setAttribute("orderMultiList", orderMultiList);
      request.setAttribute("totals_price", totals_price);
      request.setAttribute("deli_price", deli_price);
      request.setAttribute("last_price", last_price);
      request.setAttribute("ordererInfo", ordererInfo);

      return "orders/orderMultiInsertForm";
   }

   /*
    * @Param o_pic         String배열형태 /주문한 상품대표사진 
    * @Param item_num      String배열형태 /주문한 상품코드
    * @Param o_item_name   String배열형태 /주문한 상품명
    * @Param o_size      String배열형태 /주문한 상품사이즈
    * @Param o_amount      String배열형태 /주문한 각 상품의 수량 
    * @Param o_sell_price   String배열형태 /주문한 상품 판매가 
    * @Param o_total_price   String배열형태 /주문한 각 상품의 결제가
    * @Param cart_num      String배열형태 /주문한 상품 카트번호
    * 
    * 이 메소드는 장바구니에서 여러개의 상품을 선택 구매했을때 주문을 진행하는 메소드이다. 
    * 
    * o_amount, o_sell_price, o_total_price, cart_num 은 String배열에서 int배열로 변환해준다.
    * 
    * 숫자 10자리 주문번호를 랜덤으로 생성한 후, o_num에 세팅해준다.
    * 만약 랜덤의 주문번호가 이미 존재한다면, 랜덤수에-1을 한 후 세팅해준다.
    * 
    * user_id는 OrdersDTO가 넘어올 때,for문으로 인래 중복되서 넘어오기 때문에 split으로 나누어 하나를 추출한다.
    * ordersDB에 주문내역을 등록한다. 이때 item_num은 ,으로 연결해서 등록하도록 한다.
    * ordersItemDB에 주문한 모든 상품정보를 저장한다.
    * 
    */
   @RequestMapping(value = "/putOrderMulti.do", method = RequestMethod.POST)
   public String putOrderMulti(@ModelAttribute("ordersDTO") OrdersDTO ordersDTO, BindingResult bindingResult, HttpServletRequest request) {
      
	  callCommonMethod(request);
	   
	  String[] o_pic = request.getParameterValues("o_pic");
      String[] item_num = request.getParameterValues("item_num");
      String[] o_item_name = request.getParameterValues("o_item_name");
      String[] o_size = request.getParameterValues("o_size");
      
      String[] o_amount = request.getParameterValues("o_amount");
      int[] o_amountInt = new int[o_amount.length];
      for (int i = 0; i < o_amount.length; i++) {
         o_amountInt[i] = Integer.parseInt(o_amount[i]);
      }

      String[] o_sell_price = request.getParameterValues("o_sell_price");
      int[] o_sell_priceInt = new int[o_sell_price.length];
      for (int i = 0; i < o_sell_price.length; i++) {
         o_sell_priceInt[i] = Integer.parseInt(o_sell_price[i]);
      }

      String[] o_total_price = request.getParameterValues("o_total_price");
      int[] o_total_priceInt = new int[o_total_price.length];
      for (int i = 0; i < o_total_price.length; i++) {
         o_total_priceInt[i] = Integer.parseInt(o_total_price[i]);
      }

      String[] cart_num = request.getParameterValues("cart_num");
      int[] cart_numInt = new int[cart_num.length];
      for (int i = 0; i < cart_num.length; i++) {
         cart_numInt[i] = Integer.parseInt(cart_num[i]);
      }

      Random ran = new Random();
      int o_num = ran.nextInt(999999999) + 2;
      List<Integer> chkOnum = ordersService.ordersNums();
      for (int i = 0; i < chkOnum.size(); i++) {
         if (o_num == chkOnum.get(i)) {
            o_num = o_num - 1;
         }//end if
      }//end for
      ordersDTO.setO_num(o_num);
      
      String user_id_ori = ordersDTO.getUser_id();
      String user_id = user_id_ori.split(",")[0];
      ordersDTO.setUser_id(user_id);
      
      String postcode = request.getParameter("o_postcode");
      String address1 = request.getParameter("o_address1");
      String address2 = request.getParameter("o_address2");
      
      String o_address = postcode+", "+address1+" "+address2;
      
      ordersDTO.setO_address(o_address);
      
      ordersService.orderMulti(o_pic,item_num,o_item_name,o_size,o_amountInt,o_sell_priceInt,o_total_priceInt,cart_numInt,ordersDTO);
      
      request.setAttribute("user_id", ordersDTO.getUser_id());
      request.setAttribute("o_num", ordersDTO.getO_num());

      return "orders/orderFinish";
   }

   /*
    * 이 메소드는 장바구니에 있는 모든 상품을 구매하면 매핑되는 메소드이다.
    * 
    * 장바구니에 있는 모든 상품의 정보를 가져온다.
    * 각 상품들의 수량과 판매가를 곱한 각 상품 결제가를 더한 후, 50000원 이상이면 배송비를 무료로 측정한다.
    * userAccountDB에서 주문자 정보를 가지고 온 후, 배송자 정보 입력폼을 보여준다.
    * (이때의 입력폼은 여러개의 상품을 구매했을 때의 입력폼과 동일하다.)
    */
   @RequestMapping(value = "/getOrderAll.do", method = RequestMethod.GET)
   public String getOrderAll(HttpServletRequest request, HttpSession session) {

      UserDTO loginUser = (UserDTO) session.getAttribute("loginUser");
      String user_id = loginUser.getUser_id();
      
      callCommonMethod(request);
      
      List<CartDTO> orderAllList = cartService.cartAllSelect(user_id);

      int totals_price = cartService.getTotalsPrice(user_id);
      int deli_price = 2500;
      if (totals_price > 50000) {
         deli_price = 0;
      }
      int last_price = deli_price + totals_price;
      
      UserDTO ordererInfo = ordersService.getOrdererInfo(user_id);

      request.setAttribute("loginUser", loginUser);
      request.setAttribute("orderMultiList", orderAllList);
      request.setAttribute("totals_price", totals_price);
      request.setAttribute("deli_price", deli_price);
      request.setAttribute("last_price", last_price);
      request.setAttribute("ordererInfo", ordererInfo);
      request.setAttribute("user_id", user_id);

      return "orders/orderMultiInsertForm";
   }

   /*
    * @see orders/orderedList.jsp
    * 
    * 이 메소드는 해당 user_id의 주문내역 리스트를 출력한다.
    * 주문한 상품의 상품이름을 가지고 온 후, 콤마로 나누어서 개수를 센다.
    * 첫 번째 상품이름과 상품개수에서-1한 것을 세팅해서 return해준다.
    * 즉, "첫번째 상품이름" 외 "상품개수-1"개 로 주문내역 상품명이 출력된다.
    * 
    */
   @RequestMapping(value = "/orderedList.do", method = {RequestMethod.POST, RequestMethod.GET})
   public String orderedList(OrdersDTO ordersDTO, HttpServletRequest request) throws Exception {

      String user_id = request.getParameter("user_id");
      
      callCommonMethod(request);
      
      List<OrdersDTO> orderedList = ordersService.getOrderedList(user_id);
      
      for(int i=0; i<orderedList.size(); i++){
         String o_order_items = orderedList.get(i).getO_order_items();
         String[] orderItems = o_order_items.split(", ");
         
         for(int j=0; j<orderItems.length; j++){
            if(orderItems.length>1){
               int countItems = orderItems.length-1;
               orderedList.get(i).setCountItems(countItems);
               orderedList.get(i).setO_order_items(orderItems[0]);
            }//end if
         }//end inner for
      }//end outer for
      
      request.setAttribute("orderedList", orderedList);
      request.setAttribute("user_id", user_id);

      return "orders/orderedList";
   }
   
   /*
    * @see orders/orderedList.jsp
    * @see orders/orderedDetail.jsp
    * 
    * 이 메소드는 주문내역 목록에서 상세보기를 하면 매핑된다.
    * 
    * user_accountDB에서 주문자 정보를 가져오고,
    * ordersDB에서 배송자 정보를 가져오고,
    * ordersItemDB에서 주문한 상품 상세내역을 가져와서 출력한다.
    */
   @RequestMapping(value="/orderedDetail.do", method = RequestMethod.GET)
   public String orderedDetail(HttpServletRequest request){
      
	  callCommonMethod(request);
	   
      String user_id = request.getParameter("user_id");
      int o_num = Integer.parseInt(request.getParameter("o_num"));
      
      UserDTO orderedUser = ordersService.getOrdererInfo(user_id);   
      OrdersDTO receiver = ordersService.getReceiver(o_num);      
      List<OrdersDTO> orderDetail = ordersService.getOrderDetail(o_num);   
      
      request.setAttribute("orderedUser", orderedUser);
      request.setAttribute("receiver", receiver);
      request.setAttribute("orderDetail", orderDetail);
      
      return "orders/orderedDetail";
   }

   /*
    * 주문 취소를 하게 되면 실행되는 메소드이다.
    * 
    * 주문취소는 입금확인중이거나 상품준비중이 상태에서만 취소가 가능하다.
    * 주문정보를 불러와서 o_state를 4로 변경한다.
    */
   @RequestMapping(value="/orderCancel.do", method = RequestMethod.POST)
   public String orderCancel(HttpServletRequest request){
	   String user_id = request.getParameter("user_id");
	   int o_num = Integer.parseInt(request.getParameter("o_num"));
	   
	   OrdersDTO ordersDTO = ordersService.getReceiver(o_num);
	   ordersDTO.setO_state(4);
	   ordersService.updateO_state(ordersDTO);
	   
	   return "redirect:/orderedList.do?user_id="+user_id;
   }
}