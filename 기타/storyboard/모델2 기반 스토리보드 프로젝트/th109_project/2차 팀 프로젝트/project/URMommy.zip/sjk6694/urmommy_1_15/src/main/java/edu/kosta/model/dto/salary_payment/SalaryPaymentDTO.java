package edu.kosta.model.dto.salary_payment;

public class SalaryPaymentDTO {
	private String payment_date;
	private String admin_name;
	private int admin_salary;
	public String getPayment_date() {
		return payment_date;
	}
	public void setPayment_date(String payment_date) {
		this.payment_date = payment_date;
	}
	public String getAdmin_name() {
		return admin_name;
	}
	public void setAdmin_name(String admin_name) {
		this.admin_name = admin_name;
	}
	public int getAdmin_salary() {
		return admin_salary;
	}
	public void setAdmin_salary(int admin_salary) {
		this.admin_salary = admin_salary;
	}
	@Override
	public String toString() {
		return "SalaryPaymentDTO [payment_date=" + payment_date + ", admin_name=" + admin_name + ", admin_salary="
				+ admin_salary + "]";
	}
	
}
