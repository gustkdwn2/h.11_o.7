package edu.kosta.model.dto.ur.receiving;

import java.util.List;

public interface ReceivingDAO {
	public List<ReceivingDTO> getReceiving_day_list();
	//오늘 판매량
	
	public List<ReceivingDTO> getReceiving_month_list(String day);
	//월별 판매량
	
	public List<ReceivingDTO> getReceiving_year_list(String day);
	//년별 판매량
	
	public List<ReceivingDTO> getReceiving_day_search(String day);
	//날짜검색 판매량
	
	public List<ReceivingDTO> getBarChart_day_list();
	//오늘 상품별 입금량(BarChar에서 사용된다.)
	
	public List<ReceivingDTO> getBarChart_day_search(String day);
	//날짜검색 상품별 입금량(BarChar에서 사용된다.)
	
	public List<ReceivingDTO> getBarChart_month_list(String day);
	//월별 상품별 입금량(BarChar에서 사용된다.)
	
	public List<ReceivingDTO> getBarChart_year_list(String day);
	//년별 상품별 입금량(BarChar에서 사용된다.)
}
