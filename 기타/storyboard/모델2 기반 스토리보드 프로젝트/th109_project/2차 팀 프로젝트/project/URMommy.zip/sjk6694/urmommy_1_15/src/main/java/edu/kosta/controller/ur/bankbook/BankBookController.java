package edu.kosta.controller.ur.bankbook;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import edu.kosta.model.dto.ur.bankbook.BankBookDTO;
import edu.kosta.service.ur.bankbook.BankBookService;

/* 
 * @author (Seung Mo)
 * 
 * 이 컨트롤러는 입출금관리에 관련된 컨트롤러이다.
 * */
@Controller
public class BankBookController {
   
   @Resource
   private BankBookService bankbookservice;

   /*
	 *이 메소드는 재무목록에서 입출금관리를 처음 누렀을때 들어온다.
	 *오늘 입출금된 리스트를 보내준다.
	 * @see BankBookList.jsp
	*/
   @RequestMapping(value = "/bankbook.do", method = RequestMethod.GET)
   public String bankbookSelect(Locale locale, Model model, BankBookDTO dto, HttpServletRequest request){
      List<BankBookDTO> bankList = getBankbook_Paging(model,request,"1","오늘 통계");
      request.setAttribute("bankList", bankList);
      request.setAttribute("title", "오늘 통계");
      return "sell_manage/BankBookList";
   }
   
   /*
	 * 이 메소드는 입출금관리페이지에서 일변/월별/년도별을 클릭하고 날짜를 클릭하고 검색을 눌렀을 때 
	 * 해당하는 일별/월별/년도별의 리스트를 보내준다.
	 * @Param date					선택된 날짜
	 * @see BankBookList.jsp
	*/
   @RequestMapping(value = "/bank_calendar.do", method = RequestMethod.POST)
   public String bank_calendar(Locale locale, Model model, BankBookDTO dto, HttpServletRequest request){
      String temp = request.getParameter("date");
      List<BankBookDTO> bankList = null;
      String day = "";
      
      if(request.getParameter("calendar").equals("day")){
         day = temp;
         bankList = getBankbook_Paging(model,request,"1",day);
         model.addAttribute("title", day);
      }else if(request.getParameter("calendar").equals("month")){
         day = temp.substring(0, 7);
         bankList = getBankbook_Paging(model,request,"1",day);
         model.addAttribute("title", day);
      }else if(request.getParameter("calendar").equals("year")){
         day = temp.substring(0, 4);
         bankList = getBankbook_Paging(model,request,"1",day);
         model.addAttribute("title", day);
      }
      
      request.setAttribute("bankList", bankList);
      return "sell_manage/BankBookList";
   }
   
   /*
	 * 이 메소드는 BankBookList.jsp에서 지출입력을 했을때 DB에 지출내역을 등록하는 메소드이다.
	 * @see BankBookList.jsp
	*/
   @RequestMapping(value = "/bank_outcome.do", method = RequestMethod.POST)
   public String bank_outcome(Locale locale, Model model, BankBookDTO dto, HttpServletRequest request){
      
      
      HashMap<String,Object> map = new HashMap<String,Object>();
      map.put("outcome_title", dto.getOutcome_title());
      map.put("outcome", dto.getOutcome());
      
      bankbookservice.BankBook_outcome_insert(map);
      
      List<BankBookDTO> bankList = getBankbook_Paging(model,request,"1","오늘 통계");
      request.setAttribute("bankList", bankList);
      
      return "sell_manage/BankBookList";
   }
   
  
   /*
    * 이 메소드 BankBookList.jsp에서 페이징되어 보여주는 것에서 페이지번호나 
    * 다음 페이지 또는 이전 페이지를 눌렀을때 페이지를 바꿔주는 메소드이다
    * @see BankBookList.jsp
   */ 
   @RequestMapping(value = "/bank_paging.do", method = RequestMethod.GET)
   public String bank_paging(Locale locale, Model model, BankBookDTO dto, HttpServletRequest request){
      
      List<BankBookDTO> bankList = getBankbook_Paging(model,request,request.getParameter("pg"),request.getParameter("title"));
      
      request.setAttribute("bankList", bankList);
      return "sell_manage/BankBookList";
   }
   
   /*
    * 이 메소드 Bankbook의 페이징을 해주는 메소드이다.
    * 이 메소드는 인자로 Model model,HttpServletRequest request,String temp,String day을 총4개를 인자로 받는다.
    * request의 setAttribute을 이용해서 페이징된 정보를 넘겨준다.
    * temp는 페이지의 번호이고 day는 DB에서 검색해서 보여주는 데이터의 날짜이다.
    * 
    * 
   */ 
   public List<BankBookDTO> getBankbook_Paging(Model model, HttpServletRequest request, String temp, String day){
      int pg=1;
      String strPg = temp; 
      if(strPg!=null){
         pg = Integer.parseInt(strPg);         
      }
      
      int rowSize = 10;
      int start = (pg*rowSize)-(rowSize -1);
      int end = pg*rowSize;
      int total = 0;
      
      if(day.equals("오늘 통계")){
         total = bankbookservice.getBank_book_Count(); 
      }else if(day.length()==10){
         total = bankbookservice.getBank_book_day_count(day); 
      }else if(day.length()==7){
         total = bankbookservice.getBank_book_month_count(day); 
      }else if(day.length()==4){
         total = bankbookservice.getBank_book_year_count(day);
      }
      
      int allPage = (int) Math.ceil(total/(double)rowSize); 
      
      int block = 10;
      int fromPage = ((pg-1)/block*block)+1;  
      
      int toPage = ((pg-1)/block*block)+block; 
      if(toPage> allPage){ 
         toPage = allPage;
      }
      
      HashMap<String,Object> map = new HashMap<String,Object>();
      map.put("start", start);
      map.put("end", end);
      map.put("day", day);
      
      List<BankBookDTO> bankList = null;
      
      if(day.equals("오늘 통계")){
         bankList = bankbookservice.getBankBookList(map);
         request.setAttribute("title", "오늘 통계");
      }else if(day.length()==10){
         bankList = bankbookservice.getBankBook_Day_Search(map); 
         model.addAttribute("title", day);
      }else if(day.length()==7){
         bankList = bankbookservice.getBankBook_Month_Search(map);
         model.addAttribute("title", day);
      }else if(day.length()==4){
         bankList = bankbookservice.getBankBook_Year_Search(map); 
         model.addAttribute("title", day);
      }
      
      request.setAttribute("pg",pg);
      request.setAttribute("allPage",allPage);
      request.setAttribute("block",block);
      request.setAttribute("fromPage",fromPage);
      request.setAttribute("toPage",toPage);
      
      return bankList;
   }
   
   /*
	 * 이 메소드는 highChart의 LineChart를 그려주는 메소드이다.
	 * 이 메소드는 BankBookList.jsp에 들어가 페이지가 그려질때 Ajax로 호출되어서 
	 * 각 일별/월별/년도별의 입금된 제품의 금액을 합해서 LineChart를 그려주는 데이터를 JSON형태로 반환해준다.
	*/
   @Async
   @ResponseBody
   @RequestMapping(value = "/bankbook_line_chart.do", method = RequestMethod.POST, produces = "application/json; charset=utf8")
   public String bankbook_line_chart(Locale locale, Model model,HttpServletRequest request) {
      
      JSONObject jsonObject = new JSONObject();
      List<BankBookDTO> bankbook_list = bankbookservice.getBankBook_total_list();
      
      try {
         int[] data = new int[bankbook_list.size()];
           for(int i=0; i<bankbook_list.size();i++){
              data[i] = bankbook_list.get(i).getRemain_price();
           }
           jsonObject.put("data",data);
           
        } catch (JSONException e) {
            e.printStackTrace();
        }
      
        return jsonObject.toString();
   }
   
}