package edu.kosta.service.ur.review;

import java.util.HashMap;
import java.util.List;

import edu.kosta.model.dto.ur.review.ReviewDTO;
import edu.kosta.model.dto.ur.review.Review_CommentDTO;

public interface ReviewService {
	public void Review_insert(ReviewDTO dto);//리뷰 입력
	public List<ReviewDTO> getReview_List(HashMap<String,Object> map);//리뷰 전체 리스트
	public ReviewDTO getReview(int num); //리뷰 선택된 게시물 정보 가져오기
	public int getReview_Count(String item_num); //리뷰 전체 글의수
	public void Review_delete(ReviewDTO dto);//리뷰 삭제
	public int Review_update(ReviewDTO dto);//리뷰 업데이트
	
	public void Review_Comment_insert(Review_CommentDTO dto);//리뷰 댓글 입력	
	public List<Review_CommentDTO> getReview_Comment_List(HashMap<String,Object> map);//리뷰 댓글 리스트
	public void Review_comment_delete(Review_CommentDTO dto);//리뷰 댓글 삭제
}
