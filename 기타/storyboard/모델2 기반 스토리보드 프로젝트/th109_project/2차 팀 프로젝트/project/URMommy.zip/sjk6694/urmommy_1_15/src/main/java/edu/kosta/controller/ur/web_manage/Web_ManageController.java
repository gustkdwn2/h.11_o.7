package edu.kosta.controller.ur.web_manage;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import edu.kosta.model.dto.ur.web_manage.Web_ManageDTO;
import edu.kosta.service.ur.web_manage.Web_ManageService;

/* 
 * @author (EELHEA CHO)
 * 이 컨트롤러는 재고관리에서 실행되는 모든 메소드를 담고 있다.
 * */
@Controller
public class Web_ManageController {
	
	@Resource
	Web_ManageService web_manageService;
	
	/*
	 * 웹페이지 관리에서 로고를 변경할 수 있는 페이지를 불러오는 메소드이다.
	 * 지금까지 추가 했던 로고를 getLogos()라는 함수를 통해서 불러와 출력한다.
	 */
	@RequestMapping(value="/webMange.do", method = RequestMethod.GET)
	public String webManage(Model model, HttpServletRequest request){
		
		List<Web_ManageDTO> logos = web_manageService.getLogos();
		
		request.setAttribute("logos", logos);
		
		return "web_manage/webDesign";
	}
	
	/*
	 * 로고를 변경하는 메소드이다.
	 * web_manage DB에 새로운 로고 정보를 추가한다.
	 */
	@RequestMapping(value = "/logoChange.do", method = RequestMethod.POST)
	public String logoChange(@ModelAttribute("web_manageDTO") @Valid Web_ManageDTO web_manageDTO, BindingResult bindingResult, MultipartHttpServletRequest mul){
		
		web_manageDTO.setMainlogo(web_manageService.getFileName(mul));
		web_manageService.logoInsert(web_manageDTO);
		
		return "redirect:/mainList.do";
	}
}
