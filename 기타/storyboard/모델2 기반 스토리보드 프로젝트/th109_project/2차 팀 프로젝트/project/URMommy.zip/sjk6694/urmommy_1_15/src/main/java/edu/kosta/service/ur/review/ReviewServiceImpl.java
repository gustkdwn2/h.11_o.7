package edu.kosta.service.ur.review;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import edu.kosta.model.dto.ur.review.ReviewDAO;
import edu.kosta.model.dto.ur.review.ReviewDTO;
import edu.kosta.model.dto.ur.review.Review_CommentDTO;

@Component
public class ReviewServiceImpl implements ReviewService {

	@Autowired
	private SqlSession sqlsession; //SqlSessionTemplate
	
	/* 리뷰 페이징되서 리스트 가져오기 */
	@Override
	public List<ReviewDTO> getReview_List(HashMap<String,Object> map) {
		ReviewDAO reviewdao = sqlsession.getMapper(ReviewDAO.class);
		return reviewdao.getReview_List(map);
	}

	/* 리뷰 페이징되서 리스트 가져오기 */
	@Override
	public int getReview_Count(String item_num) {
		ReviewDAO reviewdao = sqlsession.getMapper(ReviewDAO.class);
		return reviewdao.getReview_Count(item_num);
	}
	
	/* 이용자가 선택한 리뷰 게시물만 DB에서 가져오기 */
	@Override
	public ReviewDTO getReview(int num) {
		ReviewDAO reviewdao = sqlsession.getMapper(ReviewDAO.class);
		return reviewdao.getReview(num);
	}

	/* 리뷰 입력페이지에서 입력된 정보 DB에 insert */
	@Override
	public void Review_insert(ReviewDTO dto) {
		ReviewDAO reviewdao = sqlsession.getMapper(ReviewDAO.class);
		reviewdao.Review_insert(dto);
	}

	//리뷰 글 삭제
	@Override
	public void Review_delete(ReviewDTO dto) {
		ReviewDAO reviewdao = sqlsession.getMapper(ReviewDAO.class);
		reviewdao.Review_delete(dto);
	}

	//리뷰 글 수정
	@Override
	public int Review_update(ReviewDTO dto) {
		ReviewDAO reviewdao = sqlsession.getMapper(ReviewDAO.class);
		return reviewdao.Review_update(dto);
	}
//////////////////////////리뷰 댓글 부분/////////////////////////////////////////
	//리뷰 댓글 입력
	@Override
	public void Review_Comment_insert(Review_CommentDTO dto) {
		ReviewDAO reviewdao = sqlsession.getMapper(ReviewDAO.class);
		reviewdao.review_comment_insert(dto);
	}
	//리뷰 댓글 리스트
	@Override
	public List<Review_CommentDTO> getReview_Comment_List(HashMap<String,Object> map) {
		ReviewDAO reviewdao = sqlsession.getMapper(ReviewDAO.class);
		return reviewdao.getReview_Comment_List(map);
	}
	//리뷰 댓글 삭제
	@Override
	public void Review_comment_delete(Review_CommentDTO dto) {
		ReviewDAO reviewdao = sqlsession.getMapper(ReviewDAO.class);
		reviewdao.Review_comment_delete(dto);
	}
	
	
	
	
}
