package edu.kosta.service.user;

import java.util.List;

import edu.kosta.model.dto.admin.AdminDTO;
import edu.kosta.model.dto.user.UserDTO;

public interface UserService {
	// 쓰기 , 리스트, 읽기, 수정, 삭제 , 조회수 증가, 글의 수
	public void insertJoin(UserDTO userDTO); // 회원가입

	// public UserDTO getLoginCheck(UserDTO loginInform, HttpSession session);
	public UserDTO getLoginCheck(UserDTO userDTO);
	
	public UserDTO confirmId(UserDTO userDTO);	//아이디중복
	
	public void userUpdate(UserDTO userDTO);	//회원정보수정
	
	//public void userDelete(UserDTO userDTO);	//회원삭제
	public void userDelete(String user_id);
	
	public List<UserDTO> userAllSelect();
	
	public AdminDTO getAdminLoginCheck(AdminDTO adminDTO);

	public UserDTO userSelect(String user_id);

	public int getNewOrderCount(String user_id);	//사용자 별 새주문 개수 가져오기

	public int getCancelOrderCount(String user_id); //사용자 별 취소주문 개수 가져오기
}// end
