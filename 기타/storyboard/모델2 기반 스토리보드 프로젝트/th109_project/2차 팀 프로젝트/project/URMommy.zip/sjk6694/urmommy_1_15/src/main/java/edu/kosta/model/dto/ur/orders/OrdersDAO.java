package edu.kosta.model.dto.ur.orders;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import edu.kosta.model.dto.user.UserDTO;

public interface OrdersDAO {
   //주문자 정보 가져오기
   UserDTO getOrdererInfo(String user_id);
   
   //한개주문
   void ordersInsert(OrdersDTO ordersDTO);               
   void ordersItemOneInsert(OrdersDTO ordersDTO);         
   void deleteCart(OrdersDTO ordersDTO);               
   
   //여러개주문
   void ordersInserts(HashMap<String, Object> ordersMap);         
   void ordersItemMultiInsert(HashMap<String, Object> ordersMap);   
   void deleteCartMulti(HashMap<String, Object> ordersMultiMap);   
   void deleteCartPrice(OrdersDTO ordersDTO);
      
   List<Integer> ordersNums();
   List<OrdersDTO> getOrderedList(@Param("user_id") String user_id);
   OrdersDTO getReceiver(@Param("o_num") int o_num);
   List<OrdersDTO> getOrderDetail(@Param("o_num") int o_num);

   void deleteOrders(String user_id);

   void updateO_state(OrdersDTO ordersDTO);

   void cancelOrder(@Param("user_id") String user_id, @Param("o_num") int o_num);

   int getOrderCount(@Param("user_id") String user_id, @Param("o_num") int o_num);

   void cancelOrderItems(@Param("o_num") int o_num); 

}