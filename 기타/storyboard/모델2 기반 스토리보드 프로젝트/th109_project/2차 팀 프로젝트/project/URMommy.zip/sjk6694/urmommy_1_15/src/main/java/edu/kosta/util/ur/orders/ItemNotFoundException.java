package edu.kosta.util.ur.orders;

public class ItemNotFoundException extends RuntimeException{
	
	private String item_num;

	public ItemNotFoundException(String item_num) {
		super("존재하지 않는 상품입니다 : " + item_num);
		this.item_num = item_num;
	}

	public String getItem_num() {
		return item_num;
	}

	public void setItem_num(String item_num) {
		this.item_num = item_num;
	}
}
