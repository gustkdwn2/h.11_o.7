package edu.kosta.model.dao.ur.notice;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import edu.kosta.model.dto.ur.notice.NoticeDTO;

public interface NoticeDAO {
	public void insertNotice(Map<String,Object> map); //����
	public List<NoticeDTO> getNoticeList(HashMap<String,Object> map); //����Ʈ
	public NoticeDTO getNotice(int notice_num); //�б�
	
	public int updateNotice(NoticeDTO dto); //����
	public void deleteNotice(int num); //����
	
	public void updateNOTICE_HIT(int notice_num); //��ȸ�� ����
	public int getNoticeCount(); //���Ǽ�
	public List<NoticeDTO> getNotice_rolling(); //rooling 메소드 추가.
}
