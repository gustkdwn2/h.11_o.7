package edu.kosta.service.ur.cart;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import edu.kosta.model.dto.ur.cart.CartDAO;
import edu.kosta.model.dto.ur.cart.CartDTO;
import edu.kosta.model.dto.ur.item.ItemDTO;

@Component
public class CartServiceImpl implements CartService {

   @Autowired
   private SqlSession sqlsession;

   /*
    * @see edu.kosta.service.ur.cart.CartService#getCartAdd(java.lang.String, edu.kosta.model.dto.ur.item.ItemDTO, java.lang.String, int)
    * 
    * 장바구니 목록에 상품을 저장하는 메소드이다.
    * 
    * itemDTO로부터 itemDB의 단가,판매가,상품코드,상품명,대표사진을 가지고 온다.
    * 
    * 유지된 세션의 아이디에 해당하는 장바구니 목록을 조회한다.
    * 상품번호와 사이즈가 같은 것이 있으면 수량만 추가해주고, 가격을 변경한다.
    * 없으면 cartDB에 바로 추가한다.
    */
   @Override
   public void getCartAdd(String user_id, ItemDTO item_cart, String cart_size, int cart_amount) {
      boolean flag = false;
      
      CartDAO cartDAO = sqlsession.getMapper(CartDAO.class);

      int up = item_cart.getUnit_price();
      int sp = item_cart.getSell_price();
      String iNum = item_cart.getItem_num();
      String iName = item_cart.getItem_name();
      String pu = item_cart.getPic_url();
      
      HashMap<String,Object> cartMap = new HashMap<String,Object>();
      List<CartDTO> cartList = cartDAO.getCartList(cartMap, user_id);

      for(CartDTO cartListSet : cartList){
    	  String item_num = cartListSet.getItem_num();
    	  String item_size = cartListSet.getCart_size();
         if(item_num.equals(iNum) && cart_size.equals(item_size)){
            int iNumCount = cartListSet.getCart_amount();
            int cart_amount_add = cart_amount + iNumCount;
            int total_price = sp * cart_amount_add;
            cartDAO.addQuantity(user_id, cart_amount_add, total_price, item_num);
            flag=true;
            break;
         }//end if
      }//end for
      if(!flag){
         int total_price = sp * cart_amount;
         cartDAO.getCartAdd(user_id, up, sp, iNum, iName, pu, cart_size, cart_amount, total_price);
      }//end if
   }
   
   /*
    * @see edu.kosta.service.ur.cart.CartService#getTotalsPrice(java.lang.String)
    * 
    * 장바구니에 저장되어있는 상품가격을 더해서 총 결제가를 계산하는 메소드이다
    */
   @Override
   public int getTotalsPrice(String user_id) {
      CartDAO cartDAO = sqlsession.getMapper(CartDAO.class);
      HashMap<String,Object> cartMap = new HashMap<String,Object>();
      List<CartDTO> cartList = cartDAO.getCartList(cartMap, user_id);
      int totals_price=0;
      
      for(CartDTO cartListSet : cartList){
         totals_price += cartListSet.getTotal_price();
      }
      return totals_price;
   }

   @Override
   public List<CartDTO> getCartList(HashMap<String,Object> cartMap, String user_id) {
      CartDAO cartDAO = sqlsession.getMapper(CartDAO.class);
      return cartDAO.getCartList(cartMap, user_id);
   }
   @Override
   public int getCartListCount(String user_id) {
      CartDAO cartDAO = sqlsession.getMapper(CartDAO.class);
      return cartDAO.getCartListCount(user_id);
   }
   @Override
   public void putLastTotals(String user_id,int totals_p,int deli_p,int last_p) {
      CartDAO cartDAO = sqlsession.getMapper(CartDAO.class);
      cartDAO.putLastTotals(user_id,totals_p,deli_p,last_p);
   }
   @Override
   public CartDTO getLastTotals(String user_id) {
      CartDAO cartDAO = sqlsession.getMapper(CartDAO.class);
      return cartDAO.getLastTotals(user_id);
   }
   @Override
   public void cartAmountSub(int cart_amount,int cart_num,int total_price,String user_id) {
      CartDAO cartDAO = sqlsession.getMapper(CartDAO.class);
      cartDAO.cartAmountSub(cart_amount,cart_num,total_price,user_id);   
   }
   @Override
   public void cartAmountAdd(int cart_amount,int cart_num,int total_price,String user_id) {
      CartDAO cartDAO = sqlsession.getMapper(CartDAO.class);
      cartDAO.cartAmountAdd(cart_amount,cart_num,total_price,user_id);   
   }
   @Override
   public void cartOneDelete(int cart_num, String user_id) {
      CartDAO cartDAO = sqlsession.getMapper(CartDAO.class);
      cartDAO.cartOneDelete(cart_num, user_id);
   }
   @Override
   public void deleteAllCart(String user_id) {
      CartDAO cartDAO = sqlsession.getMapper(CartDAO.class);
      cartDAO.deleteAllCart(user_id);
   }
   @Override
   public void deleteAllCartPrice(String user_id) {
      CartDAO cartDAO = sqlsession.getMapper(CartDAO.class);
      cartDAO.deleteAllCartPrice(user_id);
   }

   @Override
   public CartDTO cartOneSelect(int cart_num, String user_id) {
      CartDAO cartDAO = sqlsession.getMapper(CartDAO.class);
      return cartDAO.cartOneSelect(cart_num,user_id);
   }
   @Override
   public List<CartDTO> cartAllSelect(String user_id) {
	  HashMap<String,Object> cartMap = new HashMap<String,Object>();
      CartDAO cartDAO = sqlsession.getMapper(CartDAO.class);
      return cartDAO.getCartList(cartMap, user_id);
   }
}