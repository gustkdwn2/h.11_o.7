package edu.kosta.service.admin;

import java.util.ArrayList;

import edu.kosta.model.dto.admin.AdminDTO;

public interface AdminService {

	void insertAdminJoin(AdminDTO AdminDTO);	//관리자 회원가입
	
	public AdminDTO adminConfirmId(AdminDTO AdminDTO);	//관리자 아이디중복
	
	public ArrayList<AdminDTO> adminAllSelect();	//모든 관리자 보기

	public void adminDelete(String admin_id);	//관리자 삭제

}
