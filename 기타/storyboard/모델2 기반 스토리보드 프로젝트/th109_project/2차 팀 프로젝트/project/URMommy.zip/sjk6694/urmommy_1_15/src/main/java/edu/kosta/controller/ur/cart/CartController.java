package edu.kosta.controller.ur.cart;

import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import edu.kosta.model.dto.ur.cart.CartDTO;
import edu.kosta.model.dto.ur.item.ItemDTO;
import edu.kosta.model.dto.ur.web_manage.Web_ManageDTO;
import edu.kosta.model.dto.user.UserDTO;
import edu.kosta.service.ur.cart.CartService;
import edu.kosta.service.ur.item.ItemService;
import edu.kosta.service.ur.web_manage.Web_ManageService;

/* 
 * @author (EELHEA CHO)
 * 
 * 이 컨트롤러는 장바구니에서 실행되는 메소드를 담고 있다.
 * */

@Controller
public class CartController {

	@Resource
	private Web_ManageService web_manageService;
	@Resource
	private CartService cartService;
	@Resource
	private ItemService itemService;
	
	public void callCommonMethod(HttpServletRequest request){
		Web_ManageDTO mainlogo = web_manageService.getMainLogo();
		request.setAttribute("mainlogo", mainlogo);	
	}
	
	/* 
	 * 이 메소드는 상품을 "카트에 담기"했을 때 alert창에서 장바구니로 가기=> no를 누르면 실행되는 메소드이다.
	 * 
	 * item_num 으로 ItemDTO에서 상품정보를 모두 가져온 후,
	 * user_id, 상품정보, cart_size(주문 사이즈), cart_amount(주문 수량) 를 cartDB에 저장한다.
	 * 
	 * 장바구니 목록으로 가지 않고 계속 쇼핑 할 수 있도록 mainList.do로 redirect된다.
	 * @see itemDetail.jsp
	 * 
	 * */
	@RequestMapping(value="/cartAdd.do", method=RequestMethod.POST)
	public String cartAdd(HttpServletRequest request, String item_num,String user_id,CartDTO cartDTO){
		
		ItemDTO item_cart = (ItemDTO)itemService.getItemDetail(item_num);
		cartService.getCartAdd(user_id, item_cart,cartDTO.getCart_size(),cartDTO.getCart_amount());
		return "redirect:/mainList.do";
	}
	
	/* 
	 * 이 메소드는 상품을 "카트에 담기"했을 때 alert창에서 장바구니로 가기=> yes를 누르면 실행되는 메소드이다.
	 * 
	 * item_num 으로 ItemDTO에서 상품정보를 모두 가져온 후,
	 * user_id, 상품정보, cart_size(주문 사이즈), cart_amount(주문 수량) 를 cartDB에 저장하고
	 * cartList 메소드를 호출한다.
	 * 
	 * */
	@RequestMapping(value="/cartAddList.do", method=RequestMethod.POST)
	public String cartAddList(HttpServletRequest request, String item_num, CartDTO cartDTO, HttpSession session){
		
		UserDTO loginUser = (UserDTO) session.getAttribute("loginUser");
	    request.setAttribute("loginUser", loginUser);
	    String user_id = loginUser.getUser_id();
	    
	    callCommonMethod(request);
	    
		ItemDTO item_cart = (ItemDTO)itemService.getItemDetail(item_num);
		cartService.getCartAdd(user_id, item_cart,cartDTO.getCart_size(),cartDTO.getCart_amount());
		
		cartList(request, session);
		
		return "cart/cartList";
	}
	
	/* 
	 * @see edu.kosta.controller.ur.cart.cartAddList
	 * 
	 * 이 메소드는 장바구니 목록을 출력한다.
	 * 
	 * cartDB에서 유지된 session의 user_id에 해당하는 장바구니 목록을 가져온 후,
	 * 장바구니 목록 개수를 cartListCount변수에 저장한다.
	 * 목록에 있는 모든 상품가격의 합(totals_price)에 의해 배송비(deli_price)가 결정되는데 
	 * 모든 상품가격의 합이 50000을 넘을 시, 배송비를 무료로 측정한다.
	 * 최종 결제가격은 모든 상품가격의 합과 배송비를 합한 가격이 된다.
	 * 
	 * */
	@RequestMapping(value="/cartList.do", method=RequestMethod.GET)
	public String cartList(HttpServletRequest request, HttpSession session){
		
		HashMap<String,Object> cartMap = new HashMap<String,Object>();
		UserDTO loginUser = (UserDTO) session.getAttribute("loginUser");
	    String user_id = loginUser.getUser_id();

	    callCommonMethod(request);
	    
	    List<CartDTO> cartList = cartService.getCartList(cartMap, user_id);

	    int cartListCount = cartService.getCartListCount(user_id);
		int totals_price = cartService.getTotalsPrice(user_id);
		int deli_price=2500;
			if(totals_price > 50000){
				deli_price=0;
			}//end if
			if(cartListCount==0){
	            deli_price=0;
	         }//end if
		int last_price = totals_price + deli_price;
		cartService.putLastTotals(user_id,totals_price,deli_price,last_price);
		CartDTO cartPrice = (CartDTO)cartService.getLastTotals(user_id);
		
		request.setAttribute("loginUser", loginUser);
		request.setAttribute("cartList", cartList);
		request.setAttribute("cartListCount", cartListCount);
		request.setAttribute("cartPrice", cartPrice);
		
		return "cart/cartList";
	}
	
	/* 
	 * 이 메소드는 장바구니에서 각 상품의 수량을 감소할 때 실행된다.
	 * 수량을 감소하다가 0이 되면 장바구니에서 지워지게된다.
	 * 수량이 변함에 따라 각 상품의 총 가격 또한 수정된다.
	 * */
	@RequestMapping(value="/cartAmountSub.do", method=RequestMethod.POST)
	public String cartAmountSub(HttpServletRequest request){
		
		int cart_amount = Integer.parseInt(request.getParameter("cart_amount"))-1;
		int cart_num = Integer.parseInt(request.getParameter("cart_num"));
		int sell_price = Integer.parseInt(request.getParameter("sell_price"));
		int total_price = Integer.parseInt(request.getParameter("total_price"));
		String user_id = request.getParameter("user_id");
		
		if(cart_amount == 0){
			cartOneDelete(cart_num,user_id);
		}//end if
		total_price = cart_amount * sell_price;
		cartService.cartAmountSub(cart_amount,cart_num,total_price,user_id);
		
		return "redirect:/cartList.do?user_id="+user_id;
	}
	/* 
	 * 이 메소드는 장바구니에서 각 상품의 수량을 증가시킬 때 실행된다.
	 * 수량이 변함에 따라 각 상품의 총 가격 또한 수정된다.
	 * */
	@RequestMapping(value="/cartAmountAdd.do", method=RequestMethod.POST)
	public String cartAmountAdd(HttpServletRequest request){
		
		int cart_amount = Integer.parseInt(request.getParameter("cart_amount"))+1;
		int cart_num = Integer.parseInt(request.getParameter("cart_num"));
		int sell_price = Integer.parseInt(request.getParameter("sell_price"));
		int total_price = Integer.parseInt(request.getParameter("total_price"));
		String user_id = request.getParameter("user_id");

		total_price = cart_amount * sell_price;
		cartService.cartAmountAdd(cart_amount,cart_num,total_price,user_id);
		
		return "redirect:/cartList.do?user_id="+user_id;
	}
	
	/*
	 * 장바구니에 있는 하나의 상품을 삭제하는 메소드이다.
	 * 각 상품 옆에 있는 상품삭제하기 버튼을 누르면 실행된다.
	 */
	@RequestMapping(value="/cartOneDelete.do", method=RequestMethod.GET)
	public String cartOneDelete(int cart_num, String user_id){
		cartService.cartOneDelete(cart_num, user_id);
		return "redirect:/cartList.do?user_id="+user_id;
	}
	
	/*
	 * 장바구니에 있는 여러개의 상품을 삭제하는 메소드이다.
	 * 삭제할 상품의 체크박스를 선택 한 후, 선택상품삭제 버튼을 누르면 실행된다.
	 * 각 상품의 상품코드가 ,로 이어진 String으로 넘어오게 되는데 이때 split으로 각 상품코드를 분해해준 후,
	 * for문에서 장바구니에서 각 상품을 삭제한다.
	 */
	@RequestMapping(value="/cartSelectDelete.do", method=RequestMethod.GET)
	public String cartSelectDelete(String cart_num, String user_id){
		
		String[] splitCartNum = cart_num.split(",");
		int[] cartNums = new int[splitCartNum.length];
		for(int i=0; i < cartNums.length; i++){
			cartNums[i] = Integer.parseInt(splitCartNum[i]);
			cartService.cartOneDelete(cartNums[i], user_id);
		}//end for
		return "redirect:/cartList.do?user_id="+user_id;
	}
	
	/* 
	 * 장바구니의 전체 상품을 삭제하는 메소드이다.
	 * 목록 아래에 있는 전체상품삭제 버튼을 누르면 실행된다.
	 * cart DB와 cart_price DB 에서 해당 user_id의 모든 상품을 삭제한다.
	 */
	@RequestMapping(value="/deleteAllCart.do", method=RequestMethod.GET)
	public String deleteAllCart(HttpServletRequest request, String user_id){
		
		callCommonMethod(request);
		
		cartService.deleteAllCart(user_id);
		cartService.deleteAllCartPrice(user_id);

		return "cart/cartList";
	}
}
