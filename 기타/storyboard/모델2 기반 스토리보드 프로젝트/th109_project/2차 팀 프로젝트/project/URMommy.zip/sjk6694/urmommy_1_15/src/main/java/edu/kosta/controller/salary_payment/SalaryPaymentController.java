package edu.kosta.controller.salary_payment;

import java.util.ArrayList;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import edu.kosta.model.dto.humanResource.HumanResourceDTO;
import edu.kosta.model.dto.salary_payment.SalaryPaymentDTO;
import edu.kosta.service.humanResource.HumanResourceService;
import edu.kosta.service.salary_payment.SalaryPaymentService;

/* 
 * @author (BONA RYU)
 * 
 * 이 컨트롤러는 관리자 페이지에서 월급지불에 관련된 메소드를 담고 있다.
 * */

@Controller
public class SalaryPaymentController {
	@Resource
	private HumanResourceService hrService;
	@Resource
	private SalaryPaymentService spService;
	
	/* 
	 * 이 메소드는 "월급지불" 버튼을 클릭했을때 실행 되는 메소드이다.
	 * HumanResourceDTO에서 admin_name 과 admin_pay를 가져온뒤
	 * @Param payment_date 월급지불날짜
	 * "월급지불" 버튼을 클릭한 시간과 함께 salary_paymentDB에 저장한다.
	 * 
	 * 관리자 페이지에 계속 머무를수 있도록 adminSelect.do로 redirect 된다.
	 * 
	 * */
	
	@RequestMapping("/adminSalaryPayment.do")
	public String adminSalaryPayment(HttpServletRequest request){
		String date = request.getParameter("payment_date");
		ArrayList<HumanResourceDTO> salaryList = hrService.adminPaymentList();
		for(int i=0; i<salaryList.size(); i++){
			SalaryPaymentDTO spDTO = new SalaryPaymentDTO();
			spDTO.setPayment_date(date);
			spDTO.setAdmin_name(salaryList.get(i).getAdmin_name());
			spDTO.setAdmin_salary(salaryList.get(i).getAdmin_pay());
			spService.insertSalaryPaymentList(spDTO);
		}
		return "redirect:/adminSelect.do";
	}
	
	/*
	 * 이 메소드는 "월급지불내역" 버튼을 클릭했을 때 실행 되는 메소드이다.
	 * salary_paymentDB에 담긴 정보를 가져와
	 * salayPaymentList 라는 이름으로 저장해 adminSalaryPaymentList.jsp에 뿌려준다.
	 * 
	 * @see adminSalaryPaymentList.jsp
	 */
	@RequestMapping("/salaryPaymentList.do")
	public String salaryPaymentList(HttpServletRequest request){
		ArrayList<SalaryPaymentDTO> salaryPaymentList = spService.selectSalaryPaymentList();
		request.setAttribute("salaryPaymentList", salaryPaymentList);
		return "admin/adminSalaryPaymentList";
	}
}
