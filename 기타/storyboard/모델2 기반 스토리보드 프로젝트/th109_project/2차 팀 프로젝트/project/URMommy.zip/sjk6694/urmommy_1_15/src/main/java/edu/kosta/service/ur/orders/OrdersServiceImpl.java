package edu.kosta.service.ur.orders;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import edu.kosta.model.dto.ur.bankbook.BankBookDAO;
import edu.kosta.model.dto.ur.item.ItemDAO;
import edu.kosta.model.dto.ur.item.ItemDTO;
import edu.kosta.model.dto.ur.orders.OrdersDAO;
import edu.kosta.model.dto.ur.orders.OrdersDTO;
import edu.kosta.model.dto.ur.stock.StockDAO;
import edu.kosta.model.dto.ur.stock.StockDTO;
import edu.kosta.model.dto.user.UserDTO;
import edu.kosta.util.ur.orders.ItemNotFoundException;
import edu.kosta.util.ur.orders.NoStockAmountException;

@Service
public class OrdersServiceImpl implements OrdersService {

	@Autowired
	private SqlSession sqlsession;

	@Override
	public UserDTO getOrdererInfo(String user_id) {
		OrdersDAO ordersDAO = sqlsession.getMapper(OrdersDAO.class);
		return ordersDAO.getOrdererInfo(user_id);
	}

	// 주문번호 가져오기
	@Override
	public List<Integer> ordersNums() {
		OrdersDAO ordersDAO = sqlsession.getMapper(OrdersDAO.class);
		return ordersDAO.ordersNums();
	}

	/*
	 * @see
	 * edu.kosta.service.ur.orders.OrdersService#orderOne(edu.kosta.model.dto.ur
	 * .orders.OrdersDTO)
	 * 
	 * 주문 할 상품이 존재하지 않으면 ItemNotFoundException 예외를 발생시킨다.
	 * 
	 * 재무관리 입금테이블에 주문된 상품이름과 가격을 추가해준다.
	 * 
	 * orders DB에 주문자 정보와 최종결제가격을 저장한다. ordersItem DB에 위에 저장한 orders DB의 o_num으로
	 * 주문한 물품의 정보를 저장한다.
	 * 
	 * 주문이 완료되면, ordersDTO에 있는 user_id에 저장된 정보를 cart_price DB와 cart DB에서 삭제한다.
	 * 
	 * 재고가 없는 상품일 때 NoStockAmountException 예외를 발생시킨다.
	 * 
	 * stock DB 에서 구매한 상품코드(item_num)와 상품사이즈(item_size)에 해당하는 재고량(item_amount)을
	 * 가져와서 받아온 item_amount를 기존재고량(ori_amount)로 설정해주고, 주문한 상품개수를
	 * 출고량(out_amount)로 설정해주고, 최종 남은 재고량(item_amount)는 ori_amount-out_amount로
	 * 계산해서 item_size, item_amount, ori_amount, out_amount 를 stockInfo DB에
	 * 저장해준다.
	 * 
	 * 즉, 추후에 어떠한 item_size에 해당되는 item_amount를 부르면 수정된 item_amount가 불려진다.
	 * 
	 */
	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public void orderOne(OrdersDTO ordersDTO) throws ItemNotFoundException{
		
		BankBookDAO bankbookDAO = sqlsession.getMapper(BankBookDAO.class);
		OrdersDAO ordersDAO = sqlsession.getMapper(OrdersDAO.class);
		ItemDAO itemDAO = sqlsession.getMapper(ItemDAO.class);
		StockDAO stockDAO = sqlsession.getMapper(StockDAO.class);
		
		ItemDTO item = itemDAO.findByItemNum(ordersDTO.getItem_num());
		//ItemNotFoundException Transaction 처리
		if(item == null) {
			throw new ItemNotFoundException(ordersDTO.getItem_num());
		}
		
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("income_title", ordersDTO.getO_item_name());
		map.put("income", ordersDTO.getO_last_price());
		bankbookDAO.BankBook_income_insert(map);

		ordersDAO.ordersInsert(ordersDTO);
		ordersDAO.ordersItemOneInsert(ordersDTO);

		ordersDAO.deleteCartPrice(ordersDTO);
		ordersDAO.deleteCart(ordersDTO);

		StockDTO stockSizeAmount = stockDAO.getStockSizeAmount(ordersDTO.getItem_num(), ordersDTO.getO_size());
		//NoStockAmountException Transaction 처리
		if(stockSizeAmount.getItem_amount() == 0){
			throw new NoStockAmountException(stockSizeAmount.getItem_size(),stockSizeAmount.getItem_amount());
		}
		
		String item_num = ordersDTO.getItem_num();
		String item_size = ordersDTO.getO_size();
		int ori_amount = stockSizeAmount.getItem_amount();
		int out_amount = ordersDTO.getO_amount();
		int item_amount = ori_amount - out_amount;

		HashMap<String, Object> delStockMap = new HashMap<String, Object>();

		delStockMap.put("item_num", item_num);
		delStockMap.put("item_size", item_size);
		delStockMap.put("ori_amount", ori_amount);
		delStockMap.put("out_amount", out_amount);
		delStockMap.put("item_amount", item_amount);

		stockDAO.delStockAmount(delStockMap);
	}

	/*
	 * @see 
	 * edu.kosta.service.ur.orders.OrdersService#orderMulti(java.lang.String[],
	 * java.lang.String[], java.lang.String[], java.lang.String[], int[], int[],
	 * int[], int[], edu.kosta.model.dto.ur.orders.OrdersDTO)
	 * 
	 * 주문 할 상품이 존재하지 않으면 ItemNotFoundException 예외를 발생시킨다.
	 * 
	 * bankbookDB에 입금내역을 등록한다. 상품이름과 최종 가격을 저장하도록 한다.
	 * 
	 * cart_priceDB와 cartDB에서 주문이 완료된 상품들을 삭제한다.
	 * 
	 * 재고가 없는 상품일 때 NoStockAmountException 예외를 발생시킨다.
	 * 
	 * stockDB에서 주문완료된 상품의 재고 사이즈의 개수를 감소시켜준다. 구매한 상품코드(item_num)와
	 * 상품사이즈(item_size)에 해당하는 재고량(item_amount)을 가져와서 받아온 item_amount를
	 * 기존재고량(ori_amount)로 설정해주고, 주문한 상품개수를 출고량(out_amount)로 설정해주고, 최종 남은
	 * 재고량(item_amount)는 ori_amount-out_amount로 계산해서 item_size, item_amount,
	 * ori_amount, out_amount 를 stockInfo DB에 저장해준다.
	 */
	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public void orderMulti(String[] o_pic, String[] item_num, String[] o_item_name, 
							String[] o_size, int[] o_amountInt, int[] o_sell_priceInt, 
							int[] o_total_priceInt, int[] cart_numInt, OrdersDTO ordersDTO) {

		BankBookDAO bankbookDAO = sqlsession.getMapper(BankBookDAO.class);
		OrdersDAO ordersDAO = sqlsession.getMapper(OrdersDAO.class);
		ItemDAO itemDAO = sqlsession.getMapper(ItemDAO.class);
		StockDAO stockDAO = sqlsession.getMapper(StockDAO.class);
		
		for(int i=0; i<item_num.length; i++){
			ItemDTO item = itemDAO.findByItemNum(item_num[i]);
			//ItemNotFoundException Transaction 처리
			if(item == null) {
				throw new ItemNotFoundException(item_num[i]);
			}
		}
		
		HashMap<String, Object> ordersMap = new HashMap<String, Object>();

		StringBuffer sb = new StringBuffer();
		for (int k = 0; k < o_pic.length; k++) {
			sb.append(o_item_name[k]);
			if (k < o_pic.length - 1) {
				sb.append(", ");
			} // end if
		} // end for
		String o_item_names = sb.toString();

		
		ordersMap.put("o_item_name", o_item_names);
		ordersMap.put("user_id", ordersDTO.getUser_id());
		ordersMap.put("o_num", ordersDTO.getO_num());
		ordersMap.put("o_name", ordersDTO.getO_name());
		ordersMap.put("o_phone", ordersDTO.getO_phone());
		ordersMap.put("o_email", ordersDTO.getO_email());
		ordersMap.put("o_address", ordersDTO.getO_address());
		ordersMap.put("o_message", ordersDTO.getO_message());
		ordersMap.put("o_totals_price", ordersDTO.getO_totals_price());
		ordersMap.put("o_deli_price", ordersDTO.getO_deli_price());
		ordersMap.put("o_last_price", ordersDTO.getO_last_price());
		ordersDAO.ordersInserts(ordersMap);

		for (int i = 0; i < o_pic.length; i++) {
			HashMap<String, Object> ordersItemMap = new HashMap<String, Object>();
			ordersItemMap.put("o_num", ordersDTO.getO_num());
			ordersItemMap.put("cart_num", cart_numInt[i]);
			ordersItemMap.put("item_num", item_num[i]);
			ordersItemMap.put("o_pic", o_pic[i]);
			ordersItemMap.put("o_item_name", o_item_name[i]);
			ordersItemMap.put("o_size", o_size[i]);
			ordersItemMap.put("o_amount", o_amountInt[i]);
			ordersItemMap.put("o_sell_price", o_sell_priceInt[i]);
			ordersItemMap.put("o_total_price", o_total_priceInt[i]);
			ordersDAO.ordersItemMultiInsert(ordersItemMap);
		}
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("income_title", ordersDTO.getO_item_name());
		map.put("income", ordersDTO.getO_last_price());
		bankbookDAO.BankBook_income_insert(map);

		ordersDAO.deleteCartPrice(ordersDTO);

		for (int j = 0; j < o_pic.length; j++) {
			HashMap<String, Object> ordersMultiMap = new HashMap<String, Object>();
			ordersMultiMap.put("cart_num", cart_numInt[j]);
			ordersMultiMap.put("user_id", ordersDTO.getUser_id());
			ordersDAO.deleteCartMulti(ordersMultiMap);
		}

		List<StockDTO> stockMultiSizeAmount = new ArrayList<StockDTO>();
		for (int i = 0; i < item_num.length; i++) {
			StockDTO stockSizeAmount = stockDAO.getStockSizeAmount(item_num[i], o_size[i]);
			//NoStockAmountException Transaction 처리
			if(stockSizeAmount.getItem_amount() == 0){
				throw new NoStockAmountException(stockSizeAmount.getItem_size(),stockSizeAmount.getItem_amount());
			}
			stockMultiSizeAmount.add(stockSizeAmount);
		} // end for

		for (int j = 0; j < stockMultiSizeAmount.size(); j++) {
			int ori_amount = stockMultiSizeAmount.get(j).getItem_amount();
			int item_amount = ori_amount - o_amountInt[j];

			HashMap<String, Object> delMultiStockMap = new HashMap<String, Object>();

			delMultiStockMap.put("item_num", item_num[j]);
			delMultiStockMap.put("item_size", o_size[j]);
			delMultiStockMap.put("ori_amount", ori_amount);
			delMultiStockMap.put("out_amount", o_amountInt[j]);
			delMultiStockMap.put("item_amount", item_amount);
			stockDAO.delStockAmount(delMultiStockMap);
		} // end for
	}
   
	@Override
	public List<OrdersDTO> getOrderedList(String user_id) {
		OrdersDAO ordersDAO = sqlsession.getMapper(OrdersDAO.class);
		return ordersDAO.getOrderedList(user_id);
	}

	@Override
	public OrdersDTO getReceiver(int o_num) {
		OrdersDAO ordersDAO = sqlsession.getMapper(OrdersDAO.class);
		return ordersDAO.getReceiver(o_num);
	}

	@Override
	public List<OrdersDTO> getOrderDetail(int o_num) {
		OrdersDAO ordersDAO = sqlsession.getMapper(OrdersDAO.class);
		return ordersDAO.getOrderDetail(o_num);
	}

	@Override
	public void deleteOrders(String user_id) {
		OrdersDAO ordersDAO = sqlsession.getMapper(OrdersDAO.class);
		ordersDAO.deleteOrders(user_id);
	}

	@Override
	public void updateO_state(OrdersDTO ordersDTO) {
		OrdersDAO ordersDAO = sqlsession.getMapper(OrdersDAO.class);
		ordersDAO.updateO_state(ordersDTO);
	}

	@Override
	public void cancelOrder(String user_id, int o_num) {
		OrdersDAO ordersDAO = sqlsession.getMapper(OrdersDAO.class);
		ordersDAO.cancelOrder(user_id, o_num);
	}
}