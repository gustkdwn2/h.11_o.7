package edu.kosta.model.dto.ur.review;

import java.util.Date;

public class Review_CommentDTO {
	private int r_com_num; //리뷰 댓글 번호
	private int review_num;//리뷰 번호
	private String admin_id;//관리자 아이디
	private Date r_com_date;//리뷰 댓글 작성 날짜
	private String r_com_contents;//리뷰 댓글 작성 내용
	
	public int getR_com_num() {
		return r_com_num;
	}
	public void setR_com_num(int r_com_num) {
		this.r_com_num = r_com_num;
	}
	public int getReview_num() {
		return review_num;
	}
	public void setReview_num(int review_num) {
		this.review_num = review_num;
	}
	public String getAdmin_id() {
		return admin_id;
	}
	public void setAdmin_id(String admin_id) {
		this.admin_id = admin_id;
	}
	public Date getR_com_date() {
		return r_com_date;
	}
	public void setR_com_date(Date r_com_date) {
		this.r_com_date = r_com_date;
	}
	public String getR_com_contents() {
		return r_com_contents;
	}
	public void setR_com_contents(String r_com_contents) {
		this.r_com_contents = r_com_contents;
	}
	
	@Override
	public String toString() {
		return "Review_CommentDTO [r_com_num=" + r_com_num + ", review_num=" + review_num + ", admin_id=" + admin_id
				+ ", r_com_date=" + r_com_date + ", r_com_contents=" + r_com_contents + "]";
	}
}
