package edu.kosta.service.ur.receiving;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import edu.kosta.model.dto.ur.receiving.ReceivingDAO;
import edu.kosta.model.dto.ur.receiving.ReceivingDTO;

@Component
public class ReceivngServiceImpl implements receivingService {

	@Autowired
	private SqlSession sqlsession;
	/* 입금 금액 관리 */
	/* 입금 금액 오늘 날짜 리스트 출력 */
	@Override
	public List<ReceivingDTO> getReceiving_day_list() {
		ReceivingDAO receivingdao = sqlsession.getMapper(ReceivingDAO.class);
		return receivingdao.getReceiving_day_list();
	}
	/* 입금 금액 선택 날짜 리스트 출력 */
	@Override
	public List<ReceivingDTO> getReceiving_day_search(String day) {
		ReceivingDAO receivingdao = sqlsession.getMapper(ReceivingDAO.class);
		return receivingdao.getReceiving_day_search(day);
	}
	/* 입금 금액 월별 날짜 리스트 출력 */
	@Override
	public List<ReceivingDTO> getReceiving_month_list(String day) {
		ReceivingDAO receivingdao = sqlsession.getMapper(ReceivingDAO.class);
		return receivingdao.getReceiving_month_list(day);
	}
	/* 입금 금액 년별 날짜 리스트 출력 */
	@Override
	public List<ReceivingDTO> getReceiving_year_list(String day) {
		ReceivingDAO receivingdao = sqlsession.getMapper(ReceivingDAO.class);
		return receivingdao.getReceiving_year_list(day);
	}
	
	/* ------------------------------------------------------------- */
	
	/* 상품별 입금 오늘 날짜 리스트 출력 */
	@Override
	public List<ReceivingDTO> getBarChart_day_list() {
		ReceivingDAO receivingdao = sqlsession.getMapper(ReceivingDAO.class);
		return receivingdao.getBarChart_day_list();
	}
	/* 상품별 입금 선택 날짜 리스트 출력 */
	@Override
	public List<ReceivingDTO> getBarChart_day_search(String day) {
		ReceivingDAO receivingdao = sqlsession.getMapper(ReceivingDAO.class);
		return receivingdao.getBarChart_day_search(day);
	}
	/* 상품별 입금 월별 날짜 리스트 출력 */
	@Override
	public List<ReceivingDTO> getBarChart_month_list(String day) {
		ReceivingDAO receivingdao = sqlsession.getMapper(ReceivingDAO.class);
		return receivingdao.getBarChart_month_list(day);
	}
	/* 상품별 입금 년별 날짜 리스트 출력 */
	@Override
	public List<ReceivingDTO> getBarChart_year_list(String day) {
		ReceivingDAO receivingdao = sqlsession.getMapper(ReceivingDAO.class);
		return receivingdao.getBarChart_year_list(day);
	}

	
	
	

	

}
