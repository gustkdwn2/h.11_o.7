package edu.kosta.controller.user;

import java.text.ParseException;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import edu.kosta.model.dto.ur.web_manage.Web_ManageDTO;
import edu.kosta.model.dto.user.UserDTO;
import edu.kosta.service.ur.cart.CartService;
import edu.kosta.service.ur.orders.OrdersService;
import edu.kosta.service.ur.web_manage.Web_ManageService;
import edu.kosta.service.user.UserService;
/* 
 * @author (BONA RYU)
 * 
 * 이 컨트롤러는 회원들의 회원가입에 관련된 메소드와
 * 회원의 정보수정에 관련된 메소드와
 * 회원의 탈퇴에 관련된 메소드와
 * 회원의 로그인에 관련된 메소드를 담고 있다.
 * */

@Controller
public class UserController {

	@Resource
	private UserService userService;
	@Resource
	private CartService cartService;
	@Resource
	private OrdersService ordersService;
	@Resource
	private Web_ManageService web_manageService;
	
	/*
	 *  이 메소드는 회원가입 버튼을 누르면
	 *  joinWriteForm.jsp 페이지로 이동시켜준다.
	 *  
	 *  @see joinWriteForm.jsp
	 */
	
	@RequestMapping("/joinWriteForm.do")
	public String joinWriteForm() {
		return "join/joinWriteForm";
	}
	
	/*
	 *  이 메소드는 회원가입 폼을 작성하고 완료를 누르면
	 *  @Param user_id					회원 아이디
	 *  @Param user_pwd				회원 비밀번호
	 *  @Param m_name					회원(엄마) 이름
	 *  @Param b_name					아기 이름
	 *  @Param m_birthday 				회원(엄마) 생일
	 *  @Param b_birthday 				아기 생일
	 *  @Param phone					회원 전화번호
	 *  @Param email						회원 이메일
	 *  @Param address					회원 주소
	 *  @Param b_gender					아기 성별
	 *  user_id, user_pwd, m_name, b_name, m_birthday, b_birthday, phone, email, address, b_gender
	 *  를 User_AccountDB에 저장한다.
	 *  이 중 b_name, b_birthday, b_gender는 입력을 받지 않으면 DB에 NULL 값이 들어간다.
	 *  회원가입을 성공하면 메인페이지로 이동한다.
	 */

	@RequestMapping("/joinWrite.do")
	public ModelAndView insert(HttpServletRequest request) throws ParseException{
        
		UserDTO userDTO = new UserDTO();

		userDTO.setUser_id(request.getParameter("user_id"));
		userDTO.setUser_pwd(request.getParameter("user_pwd"));
		userDTO.setM_name(request.getParameter("m_name"));
		userDTO.setB_name(request.getParameter("b_name"));
		userDTO.setM_birthday(request.getParameter("m_birthday"));
		userDTO.setB_birthday(request.getParameter("b_birthday"));
        userDTO.setPhone(request.getParameter("phone"));
        userDTO.setEmail(request.getParameter("email"));
        userDTO.setPostcode(request.getParameter("postcode"));
        userDTO.setAddress1(request.getParameter("address1"));
        userDTO.setAddress2(request.getParameter("address2"));
        
        String b_gender = request.getParameter("b_gender");
        if("male".equals(b_gender)){
        	userDTO.setB_gender("남");
        }else if("femail".equals(b_gender)){
        	userDTO.setB_gender("여");
        }else if("".equals(b_gender)){
        	userDTO.setB_gender("");
        }else if(b_gender==null){
        	userDTO.setB_gender("");
        }
        
        this.userService.insertJoin(userDTO);
        
        ModelAndView mav = new ModelAndView();
        mav.setViewName("redirect:/start.jsp");	//성공하면 메인 페이지로 이동
        return mav;
    }
	
	/*
	 * 회원가입시 아이디 중복체크 버튼을 누르면 이 메소드가 실행된다.
	 * 
	 * @Param user_id		회원 아이디
	 * 입력한 아이디가 존재하면 입력한 아이디의 관련 정보를 'loginUser'라는 이름으로
	 * joinConfirmId.jsp 로 넘겨진다.
	 * 입력한 아이디가 존재하지 않으면 'emptyloginUser'라는 이름으로
	 * joinConfirmId.jsp 로 넘겨진다.
	 * 
	 * @see joinConfirmId.jsp
	 */
	@RequestMapping("/confirmId.do")
	public ModelAndView confirmId(UserDTO user,HttpServletRequest request) throws Exception{
		ModelAndView mav = new ModelAndView();
		UserDTO userDTO = new UserDTO();
		userDTO.setUser_id((String)request.getParameter("user_id"));
	
		try{    
			UserDTO loginUser = this.userService.confirmId(userDTO);	//
			if(loginUser!=null){	
			mav.addObject("loginUser",loginUser);
			mav.setViewName("join/joinConfirmId");
			return mav;
			}else{	
				mav.addObject("emptyloginUser",userDTO.getUser_id());
				mav.setViewName("join/joinConfirmId");
				return mav;
			}
		}catch(Exception e){
			e.printStackTrace();
			return mav;
		}
	}
	
	///////////////////////////////////////////////////////////////
	
	/*
	 * 로그인된 회원이 MODIFY 버튼을 누르면 실행되는 메소드이다
	 * 'loginUser'라는 이름으로 세션에 유지된 것을 UserDTO 형의 loginUser 객체에 담는다
	 * 정보가 담긴 loginUser는 loginUser라는 이름으로 userModifyPwdCheckForm 페이지로 이동한다
	 * @see userModifyPwdCheckForm.jsp
	 */
	@RequestMapping("/userModify.do")
	public ModelAndView userModify(HttpSession session){
		ModelAndView mav = new ModelAndView();

		UserDTO loginUser = (UserDTO) session.getAttribute("loginUser");
		Web_ManageDTO mainlogo = web_manageService.getMainLogo();
		
		mav.addObject("mainlogo", mainlogo);
		mav.addObject("loginUser", loginUser);
		mav.setViewName("login/userModifyPwdCheckForm");
		
		return mav;
	}
	
	/*
	 * @Param user_id			회원 아이디
	 * @Param user_pwd		회원 비밀번호
	 * 넘겨받은 회원 아이디와 비밀번호를 UserDTO 타입의 userDTO에 담아 
	 * 두정보에 해당하는 User_AccountDB정보를 UserDTO 타입에 loginUser에 담는다
	 * loginUser에 담긴 정보가 있다면 userModifyForm으로 페이지를 이동시킨다
	 * @see userModifyForm.jsp
	 * loginUser에 담긴 정보가 없다면 실패 페이지로 이동한다
	 * @see loginFail.jsp
	 * 
	 */
	@RequestMapping("/userModifyForm.do")
	public ModelAndView userModifyPwdCheck(HttpServletRequest request, HttpSession session) {
		ModelAndView mav = new ModelAndView();
		
		UserDTO userDTO = new UserDTO();
		
		userDTO.setUser_id((String) request.getParameter("user_id"));
		userDTO.setUser_pwd((String) request.getParameter("user_pwd"));

		Web_ManageDTO mainlogo = web_manageService.getMainLogo();
		mav.addObject("mainlogo", mainlogo);
		
		try {
			UserDTO loginUser = this.userService.getLoginCheck(userDTO); 
			if (loginUser != null) {
				mav.setViewName("login/userModifyForm");
				return mav;
			} else {
				mav.setViewName("login/loginFail");
				return mav;
			}
		} catch (Exception e) {
			return mav;
		}
	}
	
	/*
	 * 회원 정보수정창에서 입력한 정보들을 객체에 담아 가져온후
	 * User_AccountDB를 수정한다.
	 * 로그인된 세션을 유지시켜 메인으로 이동한다.
	 */
	@RequestMapping("/userModifyCheck.do")
	public ModelAndView userModifyCheck(UserDTO userDTO, HttpServletRequest request, HttpSession session) {
		this.userService.userUpdate(userDTO);

		ModelAndView mav = new ModelAndView();

		UserDTO loginUser = (UserDTO) session.getAttribute("loginUser");
		mav.addObject("loginUser", loginUser);
		mav.setViewName("redirect:/start.jsp");
		return mav;
	}
	
	///////////////////////////////////////////////////////////////
	
	/*
	 * 회원이 로그인된 상태에서 MODIFY(개인정보수정) 에 들어가
	 * 회원탈퇴를 누르게 되면 실행되는 메소드이다
	 * 'loginUser'라는 이름으로 세션에 저장된것을 UserDTO형의 loginUser객체에 담는다
	 * loginUser의 user_id를 가져와 userDelete함수를 실행시켜 해당아이디의 모든 정보를 삭제시키고
	 * 해당아이디에 맞는 cartDB와 cartPriceDB의 정보를 삭제시켜주며, 또 주문내역(order)의 정보를 삭제시킨다.
	 * 삭제후 세션을 해제시켜 로그아웃 되도록하며 메인페이지로 이동한다.
	 * 'loginUser' 라는 이름으로 세션에 저장된것을 받아오지 못한다면 
	 * loginFail 페이지로 이동한다.
	 * @see loginFail.jsp
	 */
	@RequestMapping("/userDelete.do")
	public ModelAndView userDelete(HttpSession session){
		ModelAndView mav = new ModelAndView();
		try {
		     UserDTO loginUser = (UserDTO) session.getAttribute("loginUser");
		      
			if (loginUser != null) {
				String userId = loginUser.getUser_id();
				this.userService.userDelete(userId);
				cartService.deleteAllCart(userId);
				cartService.deleteAllCartPrice(userId);
				ordersService.deleteOrders(userId);
				
				session.invalidate();
				mav.setViewName("redirect:/start.jsp");
				return mav;
			} else {
				mav.setViewName("login/loginFail");
				return mav;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return mav;
		}
	}
	
	///////////////////////////////////////////////////////////////

	/*
	 * 이 메소드는 로그인 버튼을 누르면
	 * 로그인 폼으로 이동시켜준다.
	 * @see loginForm.jsp
	 */
	@RequestMapping("/loginForm.do")
	public String loginForm() {
		return "login/loginForm";
	}
	
	/*
	 * 회원이 로그인폼에 정보를 입력하면 입력받은 정보가
	 *	User_AccountDB의 정보와 일치하는지 확인하는 메소드이다.
	 *	@Param user_id			회원 아이디
	 *	@Param user_pwd			회원 비밀번호
	 *	입력받은 아이디와 비밀번호와 일치하는 정보가 있다면 'loginUser'에 담고, 또 그것을 세션에 담아 
	 *	첫페이지로 돌아간다
	 *	일치하는 정보가 없다면 로그인 실패 페이지로 이동한다
	 *	@see loginFail.jsp
	 */
	@RequestMapping("/login.do")
	public ModelAndView login(HttpSession session, HttpServletRequest request) {

		ModelAndView mav = new ModelAndView();
		UserDTO userDTO = new UserDTO();

		userDTO.setUser_id(request.getParameter("user_id"));
		userDTO.setUser_pwd(request.getParameter("user_pwd"));

		try {
			UserDTO loginUser = this.userService.getLoginCheck(userDTO); //
			if (loginUser != null) {
				session.setAttribute("loginUser", loginUser);
				mav.addObject("loginUser", loginUser);
				mav.setViewName("redirect:/start.jsp");
				return mav;
			} else {
				Web_ManageDTO mainlogo = web_manageService.getMainLogo();
				mav.addObject("mainlogo", mainlogo);
				mav.setViewName("login/loginFail");
				return mav;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return mav;
		}

	}
	
	/*
	 * 이 메소드가 실행되면 세션이 해제되어 로그아웃된다.
	 * 로그아웃 후엔 메인페이지로 이동한다.
	 */
	@RequestMapping("/logout.do") // 로그아웃
	public ModelAndView logout(HttpSession session) {
		ModelAndView mav = new ModelAndView();

		session.invalidate(); // 세션해제(로그아웃)
		mav.setViewName("redirect:/start.jsp");
		
		return mav;
	}
}
