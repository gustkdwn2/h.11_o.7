package edu.kosta.service.ur.notice;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.kosta.model.dao.ur.notice.NoticeDAO;
import edu.kosta.model.dto.ur.notice.NoticeDTO;

@Service
public class NoticeServiceImpl implements NoticeService {
	@Autowired
	private SqlSession sqlsession;

	@Override
	public NoticeDTO getNotice(int num) {
		NoticeDAO noticeDAO = sqlsession.getMapper(NoticeDAO.class);
		return noticeDAO.getNotice(num);
		
	}

	@Override
	public int updateNotice(NoticeDTO dto) {
		NoticeDAO noticeDAO = sqlsession.getMapper(NoticeDAO.class);
		return noticeDAO.updateNotice(dto);
	}

	@Override
	public void deleteNotice(int num) {
		NoticeDAO noticeDAO = sqlsession.getMapper(NoticeDAO.class);
		noticeDAO.deleteNotice(num);
	}

	@Override
	public void updateHit(int num) {
		NoticeDAO noticeDAO = sqlsession.getMapper(NoticeDAO.class);
		noticeDAO.updateNOTICE_HIT(num);
		
	}

	@Override
	public int getNoticeCount() {
		NoticeDAO noticeDAO = sqlsession.getMapper(NoticeDAO.class);
		return noticeDAO.getNoticeCount();
	}



	@Override
	public List<NoticeDTO> getNoticeList(HashMap<String,Object> map) {
		NoticeDAO noticeDAO = sqlsession.getMapper(NoticeDAO.class);
		return noticeDAO.getNoticeList(map);
	}

	@Override
	public void insertNotice(Map<String,Object> map) {
		NoticeDAO noticeDAO = sqlsession.getMapper(NoticeDAO.class);
		noticeDAO.insertNotice(map); 
	}

	@Override
	public List<NoticeDTO> getNotice_rolling() {
		NoticeDAO noticeDAO = sqlsession.getMapper(NoticeDAO.class);
		return noticeDAO.getNotice_rolling();
	}
}
