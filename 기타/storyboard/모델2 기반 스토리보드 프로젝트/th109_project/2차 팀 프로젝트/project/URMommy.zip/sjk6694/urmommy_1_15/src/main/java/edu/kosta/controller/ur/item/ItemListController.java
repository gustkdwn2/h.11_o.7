package edu.kosta.controller.ur.item;

import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import edu.kosta.model.dto.ur.item.ItemDTO;
import edu.kosta.model.dto.ur.notice.NoticeDTO;
import edu.kosta.model.dto.ur.stock.StockDTO;
import edu.kosta.model.dto.ur.web_manage.Web_ManageDTO;
import edu.kosta.service.ur.item.ItemService;
import edu.kosta.service.ur.notice.NoticeService;
import edu.kosta.service.ur.stock.StockService;
import edu.kosta.service.ur.web_manage.Web_ManageService;

/* 
 * @author (EELHEA CHO)
 * 
 * 이 컨트롤러는 상품으로 등록된 물건들을 출력하는 메소드를 담고 있다.
 * */

@Controller
public class ItemListController {

	@Resource
	private Web_ManageService web_manageService;
	@Resource
	private ItemService itemService;
	@Resource
	private NoticeService noticeService;
	@Resource
	private StockService stockService;
	
	/*
	 * 이 메소드는 각 상품의 품절여부를 검사한다.
	 * 한 상품의 모든 사이즈가 품절이 되었다면, 상품대표사진 아래에 SoldOut이미지가 출력된다.
	 */
	public void itemSoldOut(List<ItemDTO> list){
		for(int i=0; i<list.size(); i++){
			int count = stockService.countNoStock(list.get(i).getItem_num());
			list.get(i).setCountNoStock(count);
		}
	}
	
	/*
	 * web_manage에서 가장 최근에 등록한 메인사진을 메인사진으로 등록하는 함수를 호출한다.
	 * itemSoldOut함수를 호출해서 품절된 상품여부를 검사한다.
	 * main header에 공지사항을 rolling해준다.
	 */
	public void callCommonMethod(HttpServletRequest request, List<ItemDTO> list, String menu){
		Web_ManageDTO mainlogo = web_manageService.getMainLogo();
		itemSoldOut(list);	
		List<NoticeDTO> noticeList = noticeService.getNotice_rolling();
		
		request.setAttribute("mainlogo", mainlogo);	
		request.setAttribute("noticeList", noticeList);
		request.setAttribute("menu", menu);
	}
	
	/*
	 * 메인을 불러왔을 때 전체 리스트가 출력되는 메소드이다.
	 * itemDB에서 모든 상품을 list로 저장해서 불러온다.
	 * 불러온 상품의 개수를 가지고 jsp페이지로 보내준다.
	 * 
	 * 공통 된 함수를 호출하는 함수를 호출한다.
	 * 공통 함수에는 품절여부검사 함수/공지사항 rolling함수/메인사진 출력함수가 있다.
	 * 
	 * stockDB에서 전체 상품 중 가장 많이 팔린 상품 중 TOP 8을 가지고 와서 출력해준다.
	 */
	@RequestMapping("/mainList.do")
	public String mainList(HttpServletRequest request) {
		String menu = request.getParameter("menu");
		HashMap<String,Object> map = new HashMap<String,Object>();
		
		List<ItemDTO> list = itemService.getItemMainList(map);
		int mainListTotal = itemService.getItemMainCount(); 
		
		callCommonMethod(request, list, menu);
		
		List<StockDTO> bestItem = stockService.getBestItem(map);

		request.setAttribute("list", list);
		request.setAttribute("listTotal", mainListTotal);
		request.setAttribute("bestItem", bestItem);
		
		return "item/itemListMain";
	}

	/*
	 * 메인에서 남자아이 옷을 선택했을 때 리스트가 출력되는 메소드이다.
	 * itemDB에서 상품성별이 boy인 상품을 list로 저장해서 불러온다.
	 * 불러온 item의 개수를 가지고 jsp페이지로 보내준다.
	 * 
	 * 공통 된 함수를 호출하는 함수를 호출한다.
	 * 공통 함수에는 품절여부검사 함수/공지사항 rolling함수/메인사진 출력함수가 있다.
	 */
	@RequestMapping("/boysList.do")
	public String boyList(HttpServletRequest request) {
		String menu = request.getParameter("menu");
		HashMap<String,Object> map = new HashMap<String,Object>();

		List<ItemDTO> list = itemService.getItemBoyList(map);
		int boyListTotal = itemService.getItemBoyCount();
		
		callCommonMethod(request, list, menu);
		
		request.setAttribute("list", list);
		request.setAttribute("listTotal", boyListTotal);

		return "item/itemListBoy";
	}

	/*
	 * 메인에서 여자아이 옷을 선택했을 때 리스트가 출력되는 메소드이다.
	 * itemDB에서 상품성별이 girl인 상품을 list로 저장해서 불러온다.
	 * 불러온 item의 개수를 가지고 jsp페이지로 보내준다.
	 * 
	 * 공통 된 함수를 호출하는 함수를 호출한다.
	 * 공통 함수에는 품절여부검사 함수/공지사항 rolling함수/메인사진 출력함수가 있다.
	 */
	@RequestMapping("/girlsList.do")
	public String girlList(HttpServletRequest request) {
		String menu = request.getParameter("menu");
		HashMap<String,Object> map = new HashMap<String,Object>();
		
		List<ItemDTO> list = itemService.getItemGirlList(map);
		int girlListTotal = itemService.getItemGirlCount(); 
		
		callCommonMethod(request, list, menu);
		
		request.setAttribute("list", list);
		request.setAttribute("listTotal", girlListTotal);

		return "item/itemListGirl";
	}

	/*
	 * 메인에서 URMOM을 선택하고 상품타입을 선택했을 때 리스트가 출력되는 메소드이다.
	 * itemDB에서 상품타입이 out/top/bot/dre인 상품을 list로 저장해서 불러온다.
	 * 불러온 item의 개수를 가지고 jsp페이지로 보내준다.
	 * 
	 * 공통 된 함수를 호출하는 함수를 호출한다.
	 * 공통 함수에는 품절여부검사 함수/공지사항 rolling함수/메인사진 출력함수가 있다.
	 */
	@RequestMapping("/urmomList.do")
	public String urmomList(HttpServletRequest request, String it, String menu) {

		HashMap<String,Object> map = new HashMap<String,Object>();
		List<ItemDTO> list = itemService.getUrmomList(map, it);
		int urmomListTotal = itemService.getUrmomCount(it);
		
		callCommonMethod(request, list, menu);
		
		request.setAttribute("list", list);
		request.setAttribute("listTotal", urmomListTotal);

		return "item/itemListMain";
	}

	/*
	 * 메인에서 URMOM을 선택하고 top을 선택했을 때 리스트가 출력되는 메소드이다.
	 * itemDB에서 전체 상품 중 상품타입이 top이고,
	 * dropdown으로 선택된 top의 상세타입에 해당하는 상품을 list로 저장해서 불러온다.
	 * 불러온 item의 개수를 가지고 jsp페이지로 보내준다.
	 * 
	 * 공통 된 함수를 호출하는 함수를 호출한다.
	 * 공통 함수에는 품절여부검사 함수/공지사항 rolling함수/메인사진 출력함수가 있다.
	 */
	@RequestMapping("/topDetailList.do")
	public String topDetailList(HttpServletRequest request, String itd, String menu) {

		HashMap<String,Object> map = new HashMap<String,Object>();
		List<ItemDTO> list = itemService.getItemTopDetailList(map, itd);
		int topDetailTotal = itemService.getItemTopDetailCount(itd);
		
		callCommonMethod(request, list, menu);
		
		request.setAttribute("list", list);
		request.setAttribute("listTotal", topDetailTotal);

		return "item/itemListMain";
	}

	/*
	 * 메인에서 URMOM을 선택하고 bottom을 선택했을 때 리스트가 출력되는 메소드이다.
	 * itemDB에서 전체 상품 중 상품타입이 bottom이고,
	 * dropdown으로 선택된 bottom의 상세타입에 해당하는 상품을 list로 저장해서 불러온다.
	 * 불러온 item의 개수를 가지고 jsp페이지로 보내준다.
	 * 
	 * 공통 된 함수를 호출하는 함수를 호출한다.
	 * 공통 함수에는 품절여부검사 함수/공지사항 rolling함수/메인사진 출력함수가 있다.
	 */
	@RequestMapping("/botDetailList.do")
	public String botDetailList(HttpServletRequest request, String itd, String menu) {

		HashMap<String,Object> map = new HashMap<String,Object>();
		List<ItemDTO> list = itemService.getItemBotDetailList(map, itd);
		int botDetailTotal = itemService.getItemBotDetailCount(itd);
		
		callCommonMethod(request, list, menu);
		
		request.setAttribute("list", list);
		request.setAttribute("listTotal", botDetailTotal);

		return "item/itemListMain";
	}

	/*
	 * 메인에서 BOY를 선택하고 상품타입을 선택했을 때 리스트가 출력되는 메소드이다.
	 * itemDB에서 상품성별이 boy이면서, 상품타입이 out/top/bot/dre인 상품을 list로 저장해서 불러온다.
	 * 불러온 item의 개수를 가지고 jsp페이지로 보내준다.
	 * 
	 * 공통 된 함수를 호출하는 함수를 호출한다.
	 * 공통 함수에는 품절여부검사 함수/공지사항 rolling함수/메인사진 출력함수가 있다.
	 */
	@RequestMapping("/boyList.do")
	public String boyList(HttpServletRequest request, String it, String menu) {

		HashMap<String,Object> map = new HashMap<String,Object>();
		List<ItemDTO> list = itemService.getBoyList(map, it);
		int boyListTotal = itemService.getBoyCount(it); 
		
		callCommonMethod(request, list, menu);
		
		request.setAttribute("list", list);
		request.setAttribute("listTotal", boyListTotal);

		return "item/itemListBoy";
	}

	/*
	 * 메인에서 BOY를 선택하고 top을 선택했을 때 리스트가 출력되는 메소드이다.
	 * itemDB에서 상품성별이 boy이면서, 상품타입이 top이고,
	 * dropdown으로 선택된 top의 상세타입에 해당하는 상품을 list로 저장해서 불러온다.
	 * 
	 * 불러온 item의 개수를 가지고 jsp페이지로 보내준다.
	 * 
	 * 공통 된 함수를 호출하는 함수를 호출한다.
	 * 공통 함수에는 품절여부검사 함수/공지사항 rolling함수/메인사진 출력함수가 있다.
	 */
	@RequestMapping("/boyTopDetailList.do")
	public String boyTopDetailList(HttpServletRequest request, String itd, String menu) {

		HashMap<String,Object> map = new HashMap<String,Object>();
		List<ItemDTO> list = itemService.getItemBoyTopDetailList(map, itd);
		int boyTopDetailTotal = itemService.getItemBoyTopDetailCount(itd);
		
		callCommonMethod(request, list, menu);
		
		request.setAttribute("list", list);
		request.setAttribute("listTotal", boyTopDetailTotal);

		return "item/itemListBoy";
	}

	/*
	 * 메인에서 GIRL를 선택하고 상품타입을 선택했을 때 리스트가 출력되는 메소드이다.
	 * itemDB에서 상품성별이 boy이면서, 상품타입이 out/top/bot/dre인 상품을 list로 저장해서 불러온다.
	 * 불러온 item의 개수를 가지고 jsp페이지로 보내준다.
	 * 
	 * 공통 된 함수를 호출하는 함수를 호출한다.
	 * 공통 함수에는 품절여부검사 함수/공지사항 rolling함수/메인사진 출력함수가 있다.
	 */
	@RequestMapping("/girlList.do")
	public String girlList(HttpServletRequest request, String it, String menu) {

		HashMap<String,Object> map = new HashMap<String,Object>();
		List<ItemDTO> list = itemService.getGirlList(map, it);
		int girlListTotal = itemService.getGirlCount(it);
		
		callCommonMethod(request, list, menu);
		
		request.setAttribute("list", list);
		request.setAttribute("listTotal", girlListTotal);

		return "item/itemListGirl";
	}

	/*
	 * 메인에서 GIRL를 선택하고 top을 선택했을 때 리스트가 출력되는 메소드이다.
	 * itemDB에서 상품성별이 girl이면서, 상품타입이 top이고,
	 * dropdown으로 선택된 top의 상세타입에 해당하는 상품을 list로 저장해서 불러온다.
	 * 
	 * 불러온 item의 개수를 가지고 jsp페이지로 보내준다.
	 * 
	 * 공통 된 함수를 호출하는 함수를 호출한다.
	 * 공통 함수에는 품절여부검사 함수/공지사항 rolling함수/메인사진 출력함수가 있다.
	 */
	@RequestMapping("/girlTopDetailList.do")
	public String girlTopDetailList(HttpServletRequest request, String itd, String menu) {

		HashMap<String,Object> map = new HashMap<String,Object>();
		List<ItemDTO> list = itemService.getItemGirlTopDetailList(map, itd);
		int girlTopDetailTotal = itemService.getItemGirlTopDetailCount(itd);
		
		callCommonMethod(request, list, menu);
		
		request.setAttribute("list", list);
		request.setAttribute("listTotal", girlTopDetailTotal);

		return "item/itemListGirl";
	}

	/*
	 * 메인에서 GIRL를 선택하고 bottom을 선택했을 때 리스트가 출력되는 메소드이다.
	 * itemDB에서 상품성별이 girl이면서, 상품타입이 bottom이고,
	 * dropdown으로 선택된 bottom의 상세타입에 해당하는 상품을 list로 저장해서 불러온다.
	 * 
	 * 불러온 item의 개수를 가지고 jsp페이지로 보내준다.
	 * 
	 * 공통 된 함수를 호출하는 함수를 호출한다.
	 * 공통 함수에는 품절여부검사 함수/공지사항 rolling함수/메인사진 출력함수가 있다.
	 */
	@RequestMapping("/girlBotDetailList.do")
	public String girlBotDetailList(HttpServletRequest request, String itd, String menu) {

		HashMap<String,Object> map = new HashMap<String,Object>();
		List<ItemDTO> list = itemService.getItemGirlBotDetailList(map, itd);
		int girlBotDetailTotal = itemService.getItemGirlBotDetailCount(itd);
		
		callCommonMethod(request, list, menu);
		
		request.setAttribute("list", list);
		request.setAttribute("listTotal", girlBotDetailTotal);

		return "item/itemListGirl";
	}
	

}
