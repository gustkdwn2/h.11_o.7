select * from trade;

delete from trade where trade_num='3';
drop table trade cascade constraints;

select * from trade_comment

CREATE TABLE trade(
	trade_num NUMBER(10) NOT NULL PRIMARY KEY,
	user_id VARCHAR(50)  NOT NULL,     
	trade_TITLE VARCHAR2(100) NOT NULL,
	trade_phone varchar2(20) NOT NULL,
	trade_category VARCHAR2(50) NOT NULL,
	trade_content VARCHAR2(2000) NOT NULL,
	trade_DATE DATE default sysdate NOT NULL, 
	trade_hit NUMBER(20) NOT NULL,
	trade_pic VARCHAR2(500),
    trade_success number(10) DEFAULT '0',
    which_board varchar2(20) DEFAULT 'TRADE'
);


create sequence trade_comment_seq start with 1 increment by 1 nocache;
drop sequence trade_comment_seq
create sequence trade_num_seq start with 1 increment by 1 nocache;
drop sequence trade_num_seq;
 	 	
create table trade_comment(
	trade_com_num NUMBER(5) NOT NULL PRIMARY KEY,
	user_id VARCHAR(50) NOT NULL,     
	trade_com_title VARCHAR2(100) NOT NULL,
	trade_com_content VARCHAR2(2000) NOT NULL,
	trade_com_date DATE default sysdate NOT NULL,
	trade_com_phone varchar2(20) NOT NULL,
	trade_com_pic varchar2(500) NULL,
	reply_num_fk NUMBER(20) references trade(trade_num) ON DELETE CASCADE
)SEGMENT creation IMMEDIATE;

drop table trade_comment cascade constraints;
  ALTER TABLE trade_comment
ADD CONSTRAINT reply_num_fk FOREIGN KEY (trade_com_num)
REFERENCES trade (trade_num) ON DELETE CASCADE


