package edu.kosta.model.dto.ur.cart;

import java.util.Date;

/*
 * 장바구니 변수 선언
 */
public class CartDTO {
   private int cart_num;      // 장바구니 번호
   private String user_id;      // 구매자 아이디
   private String cart_size;   // 구매 상품 사이즈
   private int cart_amount;   // 구매 상품 수량
   private int unit_price;      // 구매 상품 원가
   private int sell_price;      // 구매 상품 판매가
   private int total_price;   // 구매 상품별 총액
   
   private int deli_price;      // 배송비(50000원 이상 시,무료배송)
   private int totals_price;   // 총 구매 상품 합계
   private int last_price;      // 결제가
   private Date updateTime;   // 구매 시각

   private String item_num;   // 상품코드
   private String item_name;   // 상품명
   private String pic_url;      // 상품 대표사진
   
   public int getCart_num() {
      return cart_num;
   }
   public void setCart_num(int cart_num) {
      this.cart_num = cart_num;
   }
   public String getUser_id() {
      return user_id;
   }
   public void setUser_id(String user_id) {
      this.user_id = user_id;
   }
   public String getCart_size() {
      return cart_size;
   }
   public void setCart_size(String cart_size) {
      this.cart_size = cart_size;
   }
   public int getCart_amount() {
      return cart_amount;
   }
   public void setCart_amount(int cart_amount) {
      this.cart_amount = cart_amount;
   }
   public int getUnit_price() {
      return unit_price;
   }
   public void setUnit_price(int unit_price) {
      this.unit_price = unit_price;
   }
   public int getSell_price() {
      return sell_price;
   }
   public void setSell_price(int sell_price) {
      this.sell_price = sell_price;
   }
   public int getTotal_price() {
      return total_price;
   }
   public void setTotal_price(int total_price) {
      this.total_price = total_price;
   }
   
   
   public int getDeli_price() {
      return deli_price;
   }
   public void setDeli_price(int deli_price) {
      this.deli_price = deli_price;
   }
   public int getTotals_price() {
      return totals_price;
   }
   public void setTotals_price(int totals_price) {
      this.totals_price = totals_price;
   }
   public int getLast_price() {
      return last_price;
   }
   public void setLast_price(int last_price) {
      this.last_price = last_price;
   }
   public Date getUpdateTime() {
      return updateTime;
   }
   public void setUpdateTime(Date updateTime) {
      this.updateTime = updateTime;
   }
   
   
   public String getItem_num() {
      return item_num;
   }
   public void setItem_num(String item_num) {
      this.item_num = item_num;
   }
   public String getItem_name() {
      return item_name;
   }
   public void setItem_name(String item_name) {
      this.item_name = item_name;
   }
   public String getPic_url() {
      return pic_url;
   }
   public void setPic_url(String pic_url) {
      this.pic_url = pic_url;
   }
   
   @Override
   public String toString() {
      return "CartDTO [cart_num=" + cart_num + ", user_id=" + user_id + ", cart_size=" + cart_size + ", cart_amount="
            + cart_amount + ", unit_price=" + unit_price + ", sell_price=" + sell_price + ", deli_price="
            + deli_price + ", total_price=" + total_price + ", totals_price=" + totals_price + ", last_price="
            + last_price + ", item_num=" + item_num + ", item_name=" + item_name + ", pic_url=" + pic_url + "]";
   }
}