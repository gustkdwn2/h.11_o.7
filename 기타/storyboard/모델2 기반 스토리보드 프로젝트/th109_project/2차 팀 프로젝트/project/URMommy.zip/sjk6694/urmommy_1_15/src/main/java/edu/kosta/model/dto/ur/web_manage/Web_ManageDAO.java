package edu.kosta.model.dto.ur.web_manage;

import java.util.List;

public interface Web_ManageDAO {

	void logoInsert(Web_ManageDTO web_manageDTO);

	Web_ManageDTO getMainLogo();

	List<Web_ManageDTO> getLogos();

}
