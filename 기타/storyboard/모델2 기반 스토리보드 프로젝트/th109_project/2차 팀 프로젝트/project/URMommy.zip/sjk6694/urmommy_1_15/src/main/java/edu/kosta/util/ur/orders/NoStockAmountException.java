package edu.kosta.util.ur.orders;

public class NoStockAmountException extends RuntimeException{

	private String item_size;
	private int item_amount;
	
	public NoStockAmountException(String item_size, int item_amount) {
		super("사이즈가 " + item_size + " 인 상품재고가 " + item_amount + "(개) 없습니다.");
		this.item_size = item_size;
		this.item_amount = item_amount;
	}

	public String getItem_size() {
		return item_size;
	}

	public void setItem_size(String item_size) {
		this.item_size = item_size;
	}

	public int getItem_amount() {
		return item_amount;
	}

	public void setItem_amount(int item_amount) {
		this.item_amount = item_amount;
	}
}
