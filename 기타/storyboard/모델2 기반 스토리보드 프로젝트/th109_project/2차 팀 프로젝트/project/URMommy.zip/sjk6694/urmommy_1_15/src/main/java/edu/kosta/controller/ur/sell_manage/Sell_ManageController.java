package edu.kosta.controller.ur.sell_manage;

import java.util.List;
import java.util.Locale;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import edu.kosta.model.dto.ur.sell_manage.Sell_ManageDTO;
import edu.kosta.service.ur.sell_manage.Sell_ManageService;

/* 
 * @author (Seung Mo)
 * 
 * 이 컨트롤러는 재무관리의 판매관리에 관련된 컨트롤러이다.
 * */

@Controller
public class Sell_ManageController {
	@Resource
	Sell_ManageService sell_manageService;
	
	/*
	 * 이 메소드는 재무목록에서 출금관리를 처음 누렀을때 들어온다.
	 * 오늘 출금된 금액의 리스트를 보내준다.
	 * @see sell_manage.jsp
	*/
	@RequestMapping(value = "/getSell_manage_day_list.do", method = RequestMethod.GET)
	public String getSell_manage_day_list(Locale locale, Model model) {
		List<Sell_ManageDTO> sell_manage_list = sell_manageService.getSell_manage_day_list();
		int count = sell_manageService.getSell_deliver_today_count();
		
		model.addAttribute("sell_manage_list", sell_manage_list);
		model.addAttribute("count", count);
		model.addAttribute("title", "오늘");
		
		return "sell_manage/sell_manage";
	}
	
	/*
	 * 이 메소드는 출금관리페이지에서 일변/월별/년도별을 클릭하고 날짜를 클릭하고 검색을 눌렀을 때 
	 * 해당하는 일별/월별/년도별의 리스트를 보내준다.
	 * @Param date					선택된 날짜
	 * @see sell_manage.jsp
	*/
	@RequestMapping(value= "/sell_calendar.do", method = RequestMethod.POST)
	public String sell_calendar(Locale locale, HttpServletRequest request, Model model){
		String temp = request.getParameter("date");
		
		List<Sell_ManageDTO> sell_manage_list = null;
		String day ="";
		int count = 0;
		
		if(request.getParameter("calendar").equals("day")){
			day = temp;
			sell_manage_list = sell_manageService.getSell_manage_day_search(day);
			count = sell_manageService.getSell_deliver_daySearch_count(day);
			model.addAttribute("title", day);
		}else if(request.getParameter("calendar").equals("month")){
			day = temp.substring(0, 7);
			sell_manage_list = sell_manageService.getSell_manage_month_list(day);
			count = sell_manageService.getSell_deliver_month_count(day);
			model.addAttribute("title", day);
		}else if(request.getParameter("calendar").equals("year")){
			day = temp.substring(0, 4);
			sell_manage_list = sell_manageService.getSell_manage_year_list(day);
			count = sell_manageService.getSell_deliver_year_count(day);
			model.addAttribute("title", day);
		}
		
		model.addAttribute("sell_manage_list", sell_manage_list);
		model.addAttribute("count", count);
		
		return "sell_manage/sell_manage";
	}
	
	/*
	 * 이 메소드는 highChart의 barChart를 그려주는 메소드이다.
	 * 이 메소드는 sell_manage.jsp에 들어가 페이지가 그려질때 Ajax로 호출되어서 
	 * 각 일별/월별/년도별의 출금된 제품의 금액을 합해서 barChart를 그려주는 데이터를 JSON형태로 반환해준다.
	*/
	@Async
	@ResponseBody
	@RequestMapping(value = "/sell_bar_chart.do", method = RequestMethod.POST, produces = "application/json; charset=utf8")
	public String sell_bar_chart(Locale locale, Model model,HttpServletRequest request) {
		String day = request.getParameter("day");
		JSONObject jsonObject = new JSONObject();
		List<Sell_ManageDTO> sell_manage_list = null;
		
		/* 일별/월별/년도별을 구분해서 해당하는 리스트를 DB에서 검색 */
		if(day.equals("오늘")){
			sell_manage_list = sell_manageService.getBarChart_sell_day_list();
		}else if(day.length() == 10){
			sell_manage_list = sell_manageService.getBarChart_sell_day_search(day);
		}else if(day.length() == 7){
			sell_manage_list = sell_manageService.getBarChart_sell_month_list(day);
		}else{
			sell_manage_list = sell_manageService.getBarChart_sell_year_list(day);
		}
        int[] total = new int[sell_manage_list.size()];
        String[] item = new String[sell_manage_list.size()];
        try {
        	for(int i=0; i<sell_manage_list.size();i++){
        		item[i] = sell_manage_list.get(i).getItem_name();
        		total[i] = (sell_manage_list.get(i).getTotal())/1000;
        	}
        	
        	jsonObject.put("data",total);
        	jsonObject.put("item",item);
           
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return jsonObject.toString();
	}
		
}
