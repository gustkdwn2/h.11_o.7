package edu.kosta.service.ur.wishlist;

import java.util.HashMap;
import java.util.List;

import edu.kosta.model.dto.ur.wishlist.WishlistDTO;

public interface WishlistService {
	public int Wishlist_insert(WishlistDTO dto);//위시리스트 입력
	public List<WishlistDTO> Wishlist_list(HashMap<String,Object> map);//위시리스트 리스트 뽑기
	public int Wishlist_delete(WishlistDTO dto);//위시리스트 삭제
	
	/* 아이템 디테일에서 위시리스트 삭제 추가 */
	public int wishlist_itemDetail_delete(HashMap<String,Object> map);//itemDetail에서 위시리스트 삭제
	public int wishlist_getCount(String user_id);//위시리스트의 전체 게시물 수를 가져온다.
	public List<WishlistDTO> Wishlist_list_page(HashMap<String,Object> map);//위시리스트 리스트 뽑기
}
