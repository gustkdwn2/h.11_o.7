package edu.kosta.model.dto.ur.sell_manage;

import java.util.List;

public interface Sell_ManageDAO {
	public List<Sell_ManageDTO> getSell_manage_day_list();
	//오늘 판매량

	public List<Sell_ManageDTO> getSell_manage_month_list(String day);
	//월별 판매량

	public List<Sell_ManageDTO> getSell_manage_year_list(String day);
	//년별 판매량
	
	public List<Sell_ManageDTO> getSell_manage_day_search(String day);
	//날짜 검색 판매량
	
	public int getSell_deliver_today_count();
	//오늘 50000원 이상 주문 갯수
	
	public int getSell_deliver_daySearch_count(String day);
	//날짜 검색 50000원 이상 주문 갯수
	
	public int getSell_deliver_month_count(String day);
	//월별 50000원 이상 주문 갯수
	
	public int getSell_deliver_year_count(String day);
	//년별 50000원 이상 주문 갯수

	public List<Sell_ManageDTO> getBarChart_sell_day_list();
	//오늘 상품별 판매량(BarChar에서 사용된다.)
	
	public List<Sell_ManageDTO> getBarChart_sell_day_search(String day);
	//날짜별 상품별 판매량(BarChar에서 사용된다.)
	
	public List<Sell_ManageDTO> getBarChart_sell_month_list(String day);
	//월별 상품별 판매량(BarChar에서 사용된다.)
	
	public List<Sell_ManageDTO> getBarChart_sell_year_list(String day);
	//년별 상품별 판매량(BarChar에서 사용된다.)

}
