package edu.kosta.model.dto.ur.trade;

import java.sql.Date;

public class TradeDTO {
	private int trade_num;
	private String user_id;
	private String trade_title;
	private int trade_hit;
	private String trade_phone;
	private String trade_category;
	private String trade_content;
	private Date trade_DATE;
	private String trade_pic;
	private int trade_success;
	private String which_board;
	public int getTrade_num() {
		return trade_num;
	}
	public void setTrade_num(int trade_num) {
		this.trade_num = trade_num;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getTrade_title() {
		return trade_title;
	}
	public void setTrade_title(String trade_title) {
		this.trade_title = trade_title;
	}
	public int getTrade_hit() {
		return trade_hit;
	}
	public void setTrade_hit(int trade_hit) {
		this.trade_hit = trade_hit;
	}
	public String getTrade_phone() {
		return trade_phone;
	}
	public void setTrade_phone(String trade_phone) {
		this.trade_phone = trade_phone;
	}
	public String getTrade_category() {
		return trade_category;
	}
	public void setTrade_category(String trade_category) {
		this.trade_category = trade_category;
	}
	public String getTrade_content() {
		return trade_content;
	}
	public void setTrade_content(String trade_content) {
		this.trade_content = trade_content;
	}
	public Date getTrade_DATE() {
		return trade_DATE;
	}
	public void setTrade_DATE(Date trade_DATE) {
		this.trade_DATE = trade_DATE;
	}
	public String getTrade_pic() {
		return trade_pic;
	}
	public void setTrade_pic(String trade_pic) {
		this.trade_pic = trade_pic;
	}
	public int getTrade_success() {
		return trade_success;
	}
	public void setTrade_success(int trade_success) {
		this.trade_success = trade_success;
	}
	public String getWhich_board() {
		return which_board;
	}
	public void setWhich_board(String which_board) {
		this.which_board = which_board;
	}
	@Override
	public String toString() {
		return "TradeDTO [trade_num=" + trade_num + ", user_id=" + user_id + ", trade_title=" + trade_title
				+ ", trade_hit=" + trade_hit + ", trade_phone=" + trade_phone + ", trade_category=" + trade_category
				+ ", trade_content=" + trade_content + ", trade_DATE=" + trade_DATE + ", trade_pic=" + trade_pic
				+ ", trade_success=" + trade_success + ", which_board=" + which_board + "]";
	}

	
	
}
