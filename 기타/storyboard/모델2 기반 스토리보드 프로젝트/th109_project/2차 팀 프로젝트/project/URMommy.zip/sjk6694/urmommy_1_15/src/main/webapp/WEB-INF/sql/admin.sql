SELECT * FROM ADMIN 

DROP TABLE ADMIN CASCADE CONSTRAINTS

create table ADMIN(
   admin_id VARCHAR2(50) NOT NULL PRIMARY KEY,
   admin_pwd VARCHAR2(50) NOT NULL,
   admin_name VARCHAR2(20) NOT NULL,
   admin_hiredate VARCHAR2(50) NOT NULL,
   admin_department VARCHAR2(30) NOT NULL
);

DELETE FROM ADMIN WHERE admin_id='admin'

--최상위 admin은 직접 INSERT 시켜주기!!
INSERT INTO ADMIN(admin_id, admin_pwd, admin_name, admin_hiredate, admin_department)
VALUES('admin','1234','유보나','2015-10-30','admin')

-- admin1 : 유승모(재무)
-- admin2 : 조일혜(재고)
-- admin3 : 김도협(고객센터)
-- admin4 : 이동재(웹페이지)
-- admin5 : 김승관(회원)