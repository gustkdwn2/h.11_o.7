package edu.kosta.model.dto.ur.QnA;

import java.sql.Date;

public class QnaCommentDTO {
	private int q_com_num, q_num;
	private String admin_id, q_com_contents;
	private Date q_com_date;

	
	public QnaCommentDTO() {}
	public QnaCommentDTO(int q_com_num, int q_num, String admin_id, String q_com_contents, Date q_com_date) {
		this.q_com_num = q_com_num;
		this.q_num = q_num;
		this.admin_id = admin_id;
		this.q_com_contents = q_com_contents;
		this.q_com_date = q_com_date;
	}
	
	public int getQ_com_num() {
		return q_com_num;
	}
	public void setQ_com_num(int q_com_num) {
		this.q_com_num = q_com_num;
	}
	public int getQ_num() {
		return q_num;
	}
	public void setQ_num(int q_num) {
		this.q_num = q_num;
	}
	public String getAdmin_id(){
		return admin_id;
	}
	public void setAdmin_id(String admin_id) {
		this.admin_id = admin_id;
	}
	public String getQ_com_contents() {
		return q_com_contents;
	}
	public void setQ_com_contents(String q_com_contents) {
		this.q_com_contents = q_com_contents;
	}
	public Date getQ_com_date() {
		return q_com_date;
	}
	public void setQ_com_date(Date q_com_date) {
		this.q_com_date = q_com_date;
	}
	
}
