package edu.kosta.model.dto.ur.item;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import edu.kosta.model.dto.ur.stock.StockDTO;

public interface ItemDAO {
   public List<ItemDTO> getItemMainList(HashMap<String,Object> map);   
   public int getItemMainCount();

   public List<ItemDTO> getItemBoyList(HashMap<String,Object> map);
   public int getItemBoyCount();

   public List<ItemDTO> getItemGirlList(HashMap<String,Object> map);
   public int getItemGirlCount();
   
   public List<ItemDTO> getUrmomList(HashMap<String,Object> map, @Param("it") String it);
   public int getUrmomCount(@Param("it") String it);
   public List<ItemDTO> getItemTopDetailList(HashMap<String,Object> map, @Param("itd") String itd);
   public int getItemTopDetailCount(@Param("itd") String itd);
   public List<ItemDTO> getItemBotDetailList(HashMap<String,Object> map, @Param("itd") String itd);
   public int getItemBotDetailCount(@Param("itd") String itd);
   
   public List<ItemDTO> getBoyList(HashMap<String,Object> map, @Param("it") String it);
   public int getBoyCount(@Param("it") String it);
   public List<ItemDTO> getItemBoyTopDetailList(HashMap<String,Object> map, @Param("itd") String itd);
   public int getItemBoyTopDetailCount(@Param("itd") String itd);
   
   public List<ItemDTO> getGirlList(HashMap<String,Object> map, @Param("it") String it);
   public int getGirlCount(@Param("it") String it);
   public List<ItemDTO> getItemGirlTopDetailList(HashMap<String,Object> map, @Param("itd") String itd);
   public int getItemGirlTopDetailCount(@Param("itd") String itd);
   public List<ItemDTO> getItemGirlBotDetailList(HashMap<String,Object> map, @Param("itd") String itd);
   public int getItemGirlBotDetailCount(@Param("itd") String itd);
   
   public ItemDTO getItemDetail(String item_num);   
   public List<StockDTO> getItemStockLeft(String item_num);
   public int itemValid(ItemDTO itemDTO);
   public void itemInsert(ItemDTO itemDTO);   
   public void itemUpdate(ItemDTO itemDTO);
   public void itemDelete(String item_num);
   
   public ItemDTO findByItemNum(String item_num);

}