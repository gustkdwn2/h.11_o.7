package edu.kosta.controller.ur.review;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import edu.kosta.model.dto.ur.review.ReviewDTO;
import edu.kosta.model.dto.ur.review.Review_CommentDTO;
import edu.kosta.model.dto.user.UserDTO;
import edu.kosta.service.ur.review.ReviewService;


/* 
 * @author (Seung Mo)
 * 
 * 이 컨트롤러는 리뷰(Review)에 관련된 컨트롤러이다.
 * */
@Controller
public class ReviewController {
	
	@Resource
	ReviewService reviewService;
	
	/*
	 * 리뷰작성은 회원이 가능하다.
	 * 이 메소드는 review_list.jsp에서 리뷰에서 글쓰기버튼을 누르면 실행된다.
	 * review를 작성하는 페이지로 이동하는 메소드이다. 
	 * @see review_insert.jsp
	*/
	@RequestMapping(value = "/review_insert_form.do", method = RequestMethod.GET)
	public String home(Locale locale, Model model, ReviewDTO dto, HttpServletRequest request) {
		request.setAttribute("item_num", dto.getItem_num());	
		
		return "review/review_insert";
	}
	
	
	/*
	 * 이 메소드는 review_list.jsp에서 리뷰제목을 클릭해면 리뷰의 상세 내용을 보여주는 메소드이다.
	 * @see review_read.jsp
	*/
	@RequestMapping("/review_read.do")
	public String read(int num,int pg,Model model,HttpSession session){
		ReviewDTO dto = reviewService.getReview(num);
		HashMap<String,Object> map = new HashMap<String,Object>();
		map.put("review_num", num);
		List<Review_CommentDTO> list = reviewService.getReview_Comment_List(map);
		
	    UserDTO loginUser = (UserDTO) session.getAttribute("loginUser");
	
	    model.addAttribute("loginUser", loginUser);
		model.addAttribute("list", list);
		model.addAttribute("Review", dto);
		model.addAttribute("pg", pg);
		return "review/review_read";
		
	}
		
	/*
	 * 이 메소드는 review_insert.jsp에서 리뷰글쓰기를 완료후 
	 * 쓰기 버튼을 눌렀을때 해당 글을 DB에 저장하는 메소드이다.
	 * @see itemDetail.jsp
	*/
	@RequestMapping(value = "/review_insert.do", method = RequestMethod.POST)
	public String review_insert(Locale locale,Model model, HttpServletRequest request,ReviewDTO dto){
		reviewService.Review_insert(dto);
		
		String item_num = request.getParameter("item_num");
		
		return "redirect:/itemDetail.do?item_num="+item_num;
	}
	
	/*
	 * 이 메소드는 review_list.jsp에서 리뷰를 삭제하는 버튼을 클릭했을때 해당 리뷰를 삭제하는 메소드이다.
	 * @see itemDetail.jsp
	*/
	@RequestMapping("/review_delete.do")
	public String review_delete(ReviewDTO dto,int pg){
		reviewService.Review_delete(dto); 
		return "redirect:/itemDetail.do?item_num="+dto.getItem_num();
	}
	
	/*
	 * 이 메소드는 review_list.jsp에서 리뷰를 수정하는 버튼을 클릭했을때 수정 페이지로 이동하는 메소드이다.
	 * @see itemDetail.jsp
	*/
	@RequestMapping("/review_update_form.do")
	public String review_update_form(HttpServletRequest request, int pg){
		request.setAttribute("review_num",request.getParameter("review_num"));
		request.setAttribute("pg",pg);
		return "review/review_update_form";
	}
	
	/*
	 * 이 메소드는 review_update_form.jsp에서 리뷰를 수정 완료했을때 수정된 내용을 DB에서 수정하는 메소드이다.
	 * @see itemDetail.jsp
	*/
	@RequestMapping("/review_update.do")
	public String review_update(HttpServletRequest request,ReviewDTO dto, int pg){
		reviewService.Review_update(dto);
		return "redirect:review_list.do?pg="+pg;
	}
	
	/*
	 * 리뷰의 댓글은 Admin만 가능하다.
	 * 이 메소드는 리뷰의 댓글을 DB에 저장하는 메소드이다.
	 * @see itemDetail.jsp
	*/
	@RequestMapping(value = "/review_Comment_insert.do", method = RequestMethod.POST)
	public String review_comment_insert(HttpServletRequest request){
		Review_CommentDTO dto = new Review_CommentDTO();
	    String item_num = request.getParameter("item_num");

	    dto.setAdmin_id(request.getParameter("admin_id"));
	    dto.setReview_num(Integer.parseInt(request.getParameter("review_num")));
	    dto.setR_com_contents(request.getParameter("r_com_contents"));
		reviewService.Review_Comment_insert(dto);
		
		return "redirect:/itemDetail.do?item_num="+item_num;
	}
	
	/*
	 * 이 메소드는 리뷰의 댓글을 DB에 삭제하는 메소드이다.
	 * @see itemDetail.jsp
	*/
	@RequestMapping("/Review_comment_delete.do")
	public String Review_comment_delete(Review_CommentDTO dto,HttpServletRequest request, int pg){
		reviewService.Review_comment_delete(dto);
		String item_num = request.getParameter("item_num");
		return "redirect:/itemDetail.do?item_num="+item_num;
	}
}
