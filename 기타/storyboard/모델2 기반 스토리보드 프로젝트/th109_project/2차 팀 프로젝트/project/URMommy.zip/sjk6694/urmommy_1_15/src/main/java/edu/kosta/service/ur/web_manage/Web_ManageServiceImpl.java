package edu.kosta.service.ur.web_manage;

import java.io.File;
import java.util.Iterator;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import edu.kosta.model.dto.ur.web_manage.Web_ManageDAO;
import edu.kosta.model.dto.ur.web_manage.Web_ManageDTO;

@Component
public class Web_ManageServiceImpl implements Web_ManageService {

	@Autowired
	private SqlSession sqlsession;
	
	@Override
	public String getFileName(MultipartHttpServletRequest mul) {
		String saveFileName= null;
        Iterator<String> dodo = mul.getFileNames();
        String uploadPath=mul.getSession().getServletContext().getRealPath("/resources/images/logo")+"/";
        while(dodo.hasNext()){
           String uploadFileName = dodo.next();

              MultipartFile mFile = mul.getFile(uploadFileName);

              String originalFileName = mFile.getOriginalFilename();

              saveFileName = originalFileName;
              //file upload부분
              
              
              //겹치는 부분 있을때 조건
              if(saveFileName != null && !saveFileName.equals("")) { //file exists

                 if(new File(uploadPath + saveFileName).exists()) {
                    saveFileName = System.currentTimeMillis() + "_" + saveFileName;
                 }
                 //예외 처리 transferTo(임시저장값)을 지정한 경로로 이동을 하게 함.
                 try {

                    mFile.transferTo(new File(uploadPath + saveFileName));

                 } catch (Exception e) {
                    e.printStackTrace();
                   
                 }
              } // if end
        }
        return saveFileName;
	}

	@Override
	public void logoInsert(Web_ManageDTO web_manageDTO) {
		Web_ManageDAO web_manageDAO = sqlsession.getMapper(Web_ManageDAO.class);
		web_manageDAO.logoInsert(web_manageDTO);
	}

	@Override
	public Web_ManageDTO getMainLogo() {
		Web_ManageDAO web_manageDAO = sqlsession.getMapper(Web_ManageDAO.class);
		return web_manageDAO.getMainLogo();
	}

	@Override
	public List<Web_ManageDTO> getLogos() {
		Web_ManageDAO web_manageDAO = sqlsession.getMapper(Web_ManageDAO.class);
		return web_manageDAO.getLogos();
	}

}
