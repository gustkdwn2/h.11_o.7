package edu.kosta.model.dto.salary_payment;

import java.util.ArrayList;

public interface SalaryPaymentDAO {
	void insertSalaryPaymentList(SalaryPaymentDTO spDTO);

	ArrayList<SalaryPaymentDTO> selectSalaryPaymentList();
}
