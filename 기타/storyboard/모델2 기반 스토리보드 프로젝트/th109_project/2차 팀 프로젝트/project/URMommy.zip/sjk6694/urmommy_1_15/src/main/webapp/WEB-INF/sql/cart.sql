create table cart(
   cart_num NUMBER(10) NOT NULL,      --sequence
   user_id VARCHAR2(50) NOT NULL,      --아이디(user_account)
   cart_size VARCHAR2(50) NOT NULL,   --선택 사이즈
   cart_amount NUMBER(10) NOT NULL,   --선택 수량
   unit_price NUMBER(10) NOT NULL,      --상품 원가(item)
   sell_price NUMBER(10) NOT NULL,      --상품 판매가(item)
   total_price NUMBER(10) NOT NULL,   --각 상품 최종가격(수량 * 낱개가격)
   item_num VARCHAR2(50) NOT NULL,      --상품 번호(item)
   item_name VARCHAR2(50) NOT NULL,   --상품 이름(item)
   pic_url VARCHAR2(50) NOT NULL,      --상품 대표사진(item)
   CONSTRAINT pk_cart PRIMARY KEY (cart_num)
)SEGMENT CREATION IMMEDIATE;

ALTER TABLE cart
ADD CONSTRAINT fk_cart FOREIGN KEY (item_num)
REFERENCES stock (item_num);

create sequence seq_cart_num start with 1 increment by 1;

create table cart_price(
   user_id VARCHAR2(50) NOT NULL,   --아이디(user_account)
   totals_price NUMBER(10) NOT NULL,   --배송비 제외한 상품 총가격 
   deli_price NUMBER(10) NOT NULL,      --배송비
   last_price NUMBER(10) NOT NULL,      --최종 결제가격 (배송비 + 합계)
   updateTime date default SYSDATE      --시간
);
------------------------------------------------------------------------------------

SELECT * FROM 
(SELECT * FROM CART_PRICE ORDER BY UPDATETIME DESC)
WHERE ROWNUM=1 AND USER_ID='user'


insert into cart values (seq_cart_num.NEXTVAL,'')

INSERT INTO CART
VALUES (seq_cart_num.NEXTVAL,'test','s',1,10000,19500,2500,4000,'g0001t','test','test.jpg')
'g0001t',10000,19500
--(item_num,item_name,unit_price,sell_price,pic_url)


drop table cart;
drop sequence seq_cart_num;
drop table cart_price;
select * from cart_price;
select * from cart;
select * from seq_cart_num;


DELETE FROM CART WHERE USER_ID='user'
DELETE FROM CART_PRICE WHERE USER_ID='user'

DELETE FROM CART
DELETE FROM CART_PRICE
