package edu.kosta.controller.ur.receiving;

import java.util.List;
import java.util.Locale;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import edu.kosta.model.dto.ur.receiving.ReceivingDTO;
import edu.kosta.service.ur.receiving.receivingService;

/* 
 * @author (Seung Mo)
 * 
 * 이 컨트롤러는 재무관리의 판매관리에 관련된 컨트롤러이다.
 * */

@Controller
public class ReceivingController {
	
	@Resource
	receivingService ReceivingService;
	
	/*
	 * 이 메소드는 재무목록에서 입금관리를 처음 누렀을때 들어온다.
	 * 오늘 입금된 금액의 리스트를 보내준다.
	 * @see ReceivingList.jsp
	*/
	@RequestMapping(value = "/getReceiving_list.do", method = RequestMethod.GET)
	public String getReceiving_list(Locale locale, Model model) {
		List<ReceivingDTO> receiving_list = ReceivingService.getReceiving_day_list();
		
		
		model.addAttribute("receiving_list", receiving_list);
		model.addAttribute("title", "오늘");
		return "sell_manage/ReceivingList";
	}
	
	/*
	 * 이 메소드는 입금관리페이지에서 일변/월별/년도별을 클릭하고 날짜를 클릭하고 검색을 눌렀을 때 
	 * 해당하는 일별/월별/년도별의 리스트를 보내준다.
	 * @Param date					선택된 날짜
	 * @see ReceivingList.jsp
	*/
	@RequestMapping(value= "/receiving_calendar.do", method = RequestMethod.POST)
	public String receiving_calendar(Locale locale, HttpServletRequest request, Model model){
		String temp = request.getParameter("date");
		List<ReceivingDTO> receiving_list = null;
		String day = "";
		
		/* 일별/월별/년도별을 구분해서 해당하는 리스트를 DB에서 검색 */
		if(request.getParameter("calendar").equals("day")){
			day = temp;
			receiving_list = ReceivingService.getReceiving_day_search(day);
			model.addAttribute("title", day);
		}else if(request.getParameter("calendar").equals("month")){
			day = temp.substring(0, 7);
			receiving_list = ReceivingService.getReceiving_month_list(day);
			model.addAttribute("title", day);
		}else if(request.getParameter("calendar").equals("year")){
			day = temp.substring(0, 4);
			receiving_list = ReceivingService.getReceiving_year_list(day);
			model.addAttribute("title", day);
		}
		
		model.addAttribute("receiving_list", receiving_list);
		
		  return "sell_manage/ReceivingList";
	}
	
	/*
	 * 이 메소드는 highChart의 barChart를 그려주는 메소드이다.
	 * 이 메소드는 ReceivingList.jsp에 들어가 페이지가 그려질때 Ajax로 호출되어서 
	 * 각 일별/월별/년도별의 입금된 제품의 금액을 합해서 barChart를 그려주는 데이터를 JSON형태로 반환해준다.
	*/
	@Async
	@ResponseBody
	@RequestMapping(value = "/receiving_bar_chart.do", method = RequestMethod.POST, produces = "application/json; charset=utf8")
	public String receiving_bar_chart(Locale locale, Model model,HttpServletRequest request) {
		String day = request.getParameter("day");
		JSONObject jsonObject = new JSONObject();
		List<ReceivingDTO> receiving_list = null;
		
		
		if(day.equals("오늘")){
			receiving_list = ReceivingService.getBarChart_day_list();
		}else if(day.length() == 10){
			receiving_list = ReceivingService.getBarChart_day_search(day);
		}else if(day.length() == 7){
			receiving_list = ReceivingService.getBarChart_month_list(day);
		}else{
			receiving_list = ReceivingService.getBarChart_year_list(day);
		}
        
        int[] total = new int[receiving_list.size()];
        String[] item = new String[receiving_list.size()];
        try {
        	for(int i=0; i<receiving_list.size();i++){
        		if(receiving_list.get(i).getTotal() != 0){
        			item[i] = receiving_list.get(i).getItem_name();
        			total[i] = (receiving_list.get(i).getTotal())/1000;
        		}
        	}
        	
        	jsonObject.put("data",total);
        	jsonObject.put("item",item);
           
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return jsonObject.toString();
	}
}
