package edu.kosta.model.dto.ur.review;

import java.util.Date;

public class ReviewDTO {
	private int review_num;// NUMBER(10) primary key, 리뷰 글번호
	private String user_id;// VARCHAR2(50) NOT NULL, 회원 아이디
	private String review_title;// VARCHAR2(200) NOT NULL, 리뷰 제목
	private String review_contents;// VARCHAR2(500) NOT NULL, 리뷰 내용
	private int review_like;//  number(10)   NOT NULL, 리뷰 좋아요
	private String review_img;//  VARCHAR2(500) NOT NULL, 리뷰 이미지
	private Date review_date;//    DATE default SYSDATE NOT NULL, 리뷰 작성 날짜 
	private int rating;//  number(10) NOT NULL, 리뷰 별점
	private String item_num;

	  
	public int getReview_num() {
		return review_num;
	}
	public void setReview_num(int review_num) {
		this.review_num = review_num;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getReview_title() {
		return review_title;
	}
	public void setReview_title(String review_title) {
		this.review_title = review_title;
	}
	public String getReview_contents() {
		return review_contents;
	}
	public void setReview_contents(String review_contents) {
		this.review_contents = review_contents;
	}
	public int getReview_like() {
		return review_like;
	}
	public void setReview_like(int review_like) {
		this.review_like = review_like;
	}
	public String getReview_img() {
		return review_img;
	}
	public void setReview_img(String review_img) {
		this.review_img = review_img;
	}
	public Date getReview_date() {
		return review_date;
	}
	public void setReview_date(Date review_date) {
		this.review_date = review_date;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	
	public String getItem_num() {
		return item_num;
	}
	public void setItem_num(String item_num) {
		this.item_num = item_num;
	}
	@Override
	public String toString() {
		return "ReviewDTO [review_num=" + review_num + ", user_id=" + user_id + ", review_title=" + review_title
				+ ", review_contents=" + review_contents + ", review_like=" + review_like + ", review_img=" + review_img
				+ ", review_date=" + review_date + ", rating=" + rating + ", item_num=" + item_num + "]";
	}

}
