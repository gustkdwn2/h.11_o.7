package edu.kosta.service.ur.receiving;

import java.util.List;

import edu.kosta.model.dto.ur.receiving.ReceivingDTO;

public interface receivingService {
	public List<ReceivingDTO> getReceiving_day_list();
	public List<ReceivingDTO> getReceiving_month_list(String day);
	public List<ReceivingDTO> getReceiving_year_list(String day);
	public List<ReceivingDTO> getReceiving_day_search(String day);
	
	
	public List<ReceivingDTO> getBarChart_day_list();
	public List<ReceivingDTO> getBarChart_day_search(String day);
	public List<ReceivingDTO> getBarChart_month_list(String day);
	public List<ReceivingDTO> getBarChart_year_list(String day);
}
