create table orders(
	user_id VARCHAR2(50) NOT NULL,
	o_order_items VARCHAR2(2000) NOT NULL,
	o_seq NUMBER(10) NOT NULL,
	o_num NUMBER(20) NOT NULL,
	o_name VARCHAR2(50) NOT NULL,
	o_phone VARCHAR2(50) NOT NULL,
	o_email VARCHAR2(50) NOT NULL,
	o_address VARCHAR2(150) NOT NULL,
	o_message VARCHAR2(50) NULL,
	o_time date default SYSDATE,
	o_totals_price NUMBER(10) NOT NULL,
	o_deli_price NUMBER(10) NOT NULL,
	o_last_price NUMBER(10) NOT NULL,
	o_state NUMBER(5) NOT NULL,
	CONSTRAINT pk_orders PRIMARY KEY (o_num)
)SEGMENT CREATION IMMEDIATE;

create table ordersItem(
	o_num NUMBER(20) NOT NULL,
	o_time date default SYSDATE,
	cart_num NUMBER(10) NOT NULL,
	item_num VARCHAR2(50) NOT NULL,
	o_pic VARCHAR2(50) NOT NULL,
	o_item_name VARCHAR2(50) NOT NULL,
	o_size VARCHAR2(50) NOT NULL,
	o_amount NUMBER(10) NOT NULL,
	o_sell_price NUMBER(10) NOT NULL,
	o_total_price NUMBER(10) NOT NULL
);
ALTER TABLE ordersItem
ADD CONSTRAINT fk_o_item_num FOREIGN KEY(item_num)
REFERENCES stock(item_num) ON DELETE CASCADE

ALTER TABLE ordersItem
ADD CONSTRAINT fk_o_num FOREIGN KEY(o_num)
REFERENCES orders(o_num) ON DELETE CASCADE

create sequence seq_o_seq start with 1 increment by 1;

-----------------------------------------------------------------------------

SELECT * FROM ORDERS 
SELECT * FROM ORDERSITEM

SELECT COUNT(*) FROM ORDERS WHERE USER_ID='eelhea' AND O_STATE=0

drop table orders CASCADE CONSTRAINTS
drop table ordersItem CASCADE CONSTRAINTS
drop sequence seq_o_seq;

select * from orders;
select * from ordersItem;

DELETE FROM ORDERS;
DELETE FROM ORDERSITEM;