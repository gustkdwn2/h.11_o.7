package edu.kosta.controller.ur.item;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
/* 
 * @author (SEUNGMO YU)
 * 
 * 이 컨트롤러는 스마트에디터에서 이미지 파일을 업로드하면 Ajax로 출되어 이미지파일을 저장하고
 * 해당 JSP페이지에 업로드된 이미지가 바로 볼수 있게하는 메소드를 담고 있다.
 * */
@Controller
public class EditorController {
	/*
	 * 스마트에디터 단일 파일업로드의 컨트롤러이다.
	 * IE10번전 이하번전에서는 단일 파일업로드가 실행된다.
	 * */
	@RequestMapping(value = "/photoUpload.do")
	public String photoUpload(HttpServletRequest request, @RequestParam("Filedata") MultipartFile file_data,
			@RequestParam("callback") String callback, @RequestParam("callback_func") String callback_func) {
		String file_result = "";
		try {
			if (file_data != null && file_data.getOriginalFilename() != null) {
				// 파일이 존재하면
				String original_name = file_data.getOriginalFilename();// 파일 이름
				String filename_extension = original_name.substring(original_name.lastIndexOf(".") + 1);// 파일
																										// 확장자
				filename_extension = filename_extension.toLowerCase();// 확장자를
																		// 소문자로
																		// 변경
				// 파일 기본경로
				String defaultPath = request.getSession().getServletContext().getRealPath("/");// 서버기본경로(프로젝트폴더까지:
																								// 서버내의
																								// 해당경로에
																								// 저장되는
																								// 것임)
				// 파일 기본경로 _ 상세경로
				String path = defaultPath + "resource" + File.separator + "photo_upload" + File.separator; // 파일
																											// 저장
																											// 경로

				File file = new File(path);
				// 디렉토리 존재하지 않을경우 디렉토리 생성
				if (!file.exists()) {
					file.mkdirs();
				}
				SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");
				String today = formatter.format(new java.util.Date());

				//
				String modify_name = today + "-" + UUID.randomUUID().toString().substring(20) + "."
						+ filename_extension;
						// 서버에 업로드 할 파일명(한글문제로 인해 원본파일은 올리지 않는것이 좋음)

				// 서버에 이미지 저장(쓰기)
				///////////////// 서버에 파일쓰기 /////////////////
				file_data.transferTo(new File(path + modify_name));
				file_result += "&bNewLine=true&sFileName=" + original_name
						+ "&sFileURL=/controller/resource/photo_upload/" + modify_name;

			} else {
				file_result += "&errstr=error";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "redirect:" + callback + "?callback_func=" + callback_func + file_result;
	}

	/*
	 * HTML5 멀티파일업로드 컨트롤러
	 * HTML5 드래그앤드롭 기능을 이용한 스마트에디터 파일업로드 관련 컨트롤러 이다.
	 * 
	 **/
	@RequestMapping(value = "/multiplePhotoUpload.do")
	public void multiplePhotoUpload(HttpServletRequest request, HttpServletResponse response) {
		try {
			// 파일정보
			String sFileInfo = "";
			// 파일명을 받는다 - 일반 원본파일명
			String filename = request.getHeader("file-name");
			// 파일 확장자
			String filename_extension = filename.substring(filename.lastIndexOf(".") + 1);
			// 확장자를소문자로 변경
			filename_extension = filename_extension.toLowerCase();
			// 파일 기본경로
			String defaultPath = request.getSession().getServletContext().getRealPath("/");
			// 파일 기본경로 _ 상세경로
			String path = defaultPath + "resource" + File.separator + "photo_upload" + File.separator;
			File file = new File(path);
			if (!file.exists()) {
				file.mkdirs();
			}
			SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");
			String today = formatter.format(new java.util.Date());

			// 서버에 업로드할 파일명 변경(한글문제로 인해 원본파일은 올리지 않는것이 좋음)
			String modify_name = today + "-" + UUID.randomUUID().toString().substring(20) + "." + filename_extension;

			///////////////// 서버에 파일쓰기 /////////////////
			InputStream is = request.getInputStream();
			OutputStream os = new FileOutputStream(path + modify_name);
			int numRead;
			byte b[] = new byte[Integer.parseInt(request.getHeader("file-size"))];
			while ((numRead = is.read(b, 0, b.length)) != -1) {
				os.write(b, 0, numRead);
			}
			if (is != null) {
				is.close();
			}
			os.flush();
			os.close();
			///////////////// 서버에 파일쓰기 /////////////////
			// 정보 출력
			sFileInfo += "&bNewLine=true";
			// img 태그의 title 속성을 원본파일명으로 적용시켜주기 위함
			sFileInfo += "&sFileName=" + filename;
			;
			sFileInfo += "&sFileURL=" + "/controller/resource/photo_upload/" + modify_name;
			PrintWriter print = response.getWriter();
			print.print(sFileInfo);
			print.flush();
			print.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
