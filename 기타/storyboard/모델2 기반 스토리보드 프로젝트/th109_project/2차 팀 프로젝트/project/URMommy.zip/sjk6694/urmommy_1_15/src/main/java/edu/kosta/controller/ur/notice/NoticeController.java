package edu.kosta.controller.ur.notice;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;

import edu.kosta.model.dto.admin.AdminDTO;
import edu.kosta.model.dto.ur.notice.NoticeDTO;
import edu.kosta.model.dto.ur.web_manage.Web_ManageDTO;
import edu.kosta.service.ur.notice.NoticeService;
import edu.kosta.service.ur.web_manage.Web_ManageService;

@Controller
public class NoticeController {
	//공지사항 controller
		@Resource
		private NoticeService noticeService;
		@Resource
		private Web_ManageService web_manageService;
	   
	   @RequestMapping("/notice_writeform.do")   
	   public ModelAndView writeform(HttpSession session){
		   ModelAndView mav = new ModelAndView();

			AdminDTO loginAdmin = (AdminDTO) session.getAttribute("loginAdmin");
			Web_ManageDTO mainlogo = web_manageService.getMainLogo();
			
			mav.addObject("mainlogo", mainlogo);
			mav.addObject("loginAdmin", loginAdmin);

			mav.setViewName("notice/noticeWriteForm");
			return mav;
	   }
	   @RequestMapping("/notice_write.do")
	   public String write(MultipartHttpServletRequest request){
	      Map<String, Object> map = new HashMap<String,Object>();
	      map.put("admin_id", request.getParameter("admin_id"));
	      map.put("notice_title", request.getParameter("title"));
	      map.put("notice_contents", request.getParameter("content"));
	      
	      noticeService.insertNotice(map);
	      return "redirect:/notice_list.do";
	   }
	   
	   @RequestMapping("/notice_list.do")
	   public String list(HttpServletRequest request){
	      int pg=1;
	      String strPg = request.getParameter("pg"); 
	      if(strPg!=null){
	         pg = Integer.parseInt(strPg);         
	      }
	      int rowSize = 5;
	      int start = (pg*rowSize)-(rowSize -1);
	      int end = pg*rowSize;
	      
	      int total = noticeService.getNoticeCount(); //총 게시물수
	      int allPage = (int) Math.ceil(total/(double)rowSize); //페이지수
	      
	      int block = 10; 
	      int fromPage = ((pg-1)/block*block)+1;  //보여줄 페이지의 시작
	      int toPage = ((pg-1)/block*block)+block; //보여줄 페이지의 끝
	      if(toPage> allPage){ // 예) 20>17
	         toPage = allPage;
	      }
	      
	      HashMap<String,Object> map = new HashMap<String,Object>();
	      
	      map.put("start", start);
	      map.put("end", end);
	      
	      List<NoticeDTO> list = noticeService.getNoticeList(map);
	      List<NoticeDTO> noticeList = noticeService.getNotice_rolling();	// 공지사항 rolling 가지고 오기.
		
	      Web_ManageDTO mainlogo = web_manageService.getMainLogo();
	      request.setAttribute("mainlogo", mainlogo);
	      
	      request.setAttribute("noticeList", noticeList);
			
	      request.setAttribute("list", list);
	      request.setAttribute("pg",pg);
	      request.setAttribute("allPage",allPage);
	      request.setAttribute("block",block);
	      request.setAttribute("fromPage",fromPage);
	      request.setAttribute("toPage",toPage);   
	      
	      return "/notice/noticeList"; //list.jsp
	   }
	   
	   @RequestMapping("/notice_view.do")		//공지사항 상세보기
	   public String read(int num,int pg, Model model){ //@RequestParam(
	      
	      noticeService.updateHit(num); //조회수 증가
	      NoticeDTO dto = noticeService.getNotice(num); //글 읽기
	      Web_ManageDTO mainlogo = web_manageService.getMainLogo();
	      model.addAttribute("mainlogo", mainlogo);
	      model.addAttribute("b", dto);  //모델앤 뷰중에서 모델
	      model.addAttribute("pg", pg); 
	      return "notice/noticeView"; //noticeView.jsp
	      
	   }
	   @RequestMapping("/notice_updateform.do")
	   public String upadteform(int num, int pg, Model model){
	      NoticeDTO dto = noticeService.getNotice(num);
	      Web_ManageDTO mainlogo = web_manageService.getMainLogo();
	      model.addAttribute("mainlogo", mainlogo);
	      model.addAttribute("b", dto);   
	      model.addAttribute("pg", pg);
	      return "notice/noticeUpdateForm"; //noticeUpdateForm.jsp
	   }
	   
	   @RequestMapping("/notice_update.do")
	   public String upadte(int num ,int pg, String title,String content){
	      
	      NoticeDTO dto = new NoticeDTO();
	      dto.setNotice_title(title);
	      dto.setNotice_contents(content);
	      dto.setNotice_num(num);
	
	      noticeService.updateNotice(dto); 
	      String res = "redirect:/notice_list.do?pg="+pg; //리다이렉트는 URL를 재지정. 주소가 바뀜
	      return res;
	   }
	   
	   @RequestMapping("/notice_delete.do")
	   public String delete(int num, int pg){
	      noticeService.deleteNotice(num);
	      
	      String res = "redirect:/notice_list.do?pg="+pg;
	      return res;
	   } 
}
