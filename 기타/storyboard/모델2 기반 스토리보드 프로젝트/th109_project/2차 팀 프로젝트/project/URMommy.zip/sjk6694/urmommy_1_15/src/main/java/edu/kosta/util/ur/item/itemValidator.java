package edu.kosta.util.ur.item;

import org.springframework.util.StringUtils;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import edu.kosta.model.dto.ur.item.ItemDTO;

public class itemValidator implements Validator {

	@Override
	public boolean supports(Class<?> c) {
		return ItemDTO.class.isAssignableFrom(c);
	}

	@Override
	public void validate(Object command, Errors errors) {
		ItemDTO itemDTO = (ItemDTO)command;
		
		//상품번호
		if(StringUtils.isEmpty(itemDTO.getItem_num())){
			errors.rejectValue("item_num", "required");
		}
		//상품이름
		if(StringUtils.isEmpty(itemDTO.getItem_name())){
			errors.rejectValue("item_name", "required");
		}
		//상품성별
		if(StringUtils.isEmpty(itemDTO.getItem_gender())){
			errors.rejectValue("item_gender", "required");
		}
		//상품타입
		if(StringUtils.isEmpty(itemDTO.getItem_type())){
			errors.rejectValue("item_type", "required");
		}
		//상품상세타입
		if(StringUtils.isEmpty(itemDTO.getItem_type_detail())){
			errors.rejectValue("item_type_detail", "required");
		}
		//단가
		if(StringUtils.isEmpty(itemDTO.getUnit_price())){
			errors.rejectValue("unit_price", "required");
		}
		//판매가
		if(StringUtils.isEmpty(itemDTO.getSell_price())){
			errors.rejectValue("sell_price", "required");
		}
		//상품이미지URL
		if(StringUtils.isEmpty(itemDTO.getPic_url())){
			errors.rejectValue("pic_url", "required");
		}
		//상품설명
		if(StringUtils.isEmpty(itemDTO.getContents())){
			errors.rejectValue("contents", "lengthsize");
		}
		//입력정보 오류
		if(errors.hasErrors()){
			errors.reject("error.input.item");
		}
	}

}
