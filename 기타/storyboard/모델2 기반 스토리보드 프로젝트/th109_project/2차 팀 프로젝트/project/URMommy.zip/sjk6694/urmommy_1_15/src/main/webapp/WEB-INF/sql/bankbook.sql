create table bankbook(
	bankdate date default SYSDATE,	-- 날짜
	outcome_title varchar2(500) not null,	--지출항목
	outcome number(10) not null,	--지출금액
	income_title varchar2(500) not null,	--수익항목
	income number(10) not null,	--수익금액
	remain_price number(10) not null	--남은 자산
)SEGMENT CREATION IMMEDIATE;

select * from (
   select A.*,ROWNUM r from 
      (select * from bankbook order by bankdate desc) A
   )
   where r=1;
   
create sequence seq_bankbook start with 1 increment by 1;

select*from bankbook;
drop table bankbook;
select * from stockInfo;
select * from stock;
select*from orders;

select to_char(UPDATE_TIME,'YYYY-MM-dd') 날짜, ITEM_NUM 항목, NVL(IN_AMOUNT,0) 입고, NVL(OUT_AMOUNT,0) 출고
from stockInfo
where to_char(UPDATE_TIME,'YYYY-MM-dd') = '2015-11-16' and (IN_AMOUNT is not null or OUT_AMOUNT is not null)
order by to_char(UPDATE_TIME,'YYYY-MM-dd')

select to_char(o.o_time, 'YYYY-MM-dd') day,'',0,o_order_items,o_totals_price,o_total_price+b.remain_price 
from orders o, bankbook b
where i.item_name = o.o_item_name and (to_char(o_time,'YYYY-MM') = '2015-11')
group by to_char(o.o_time, 'YYYY-MM-dd'),i.item_num,i.item_name,o.o_sell_price,o_item_name,i.item_gender,i.item_type,item_type_detail,o_sell_price


select time, 
substr(TO_CHAR(TIME),9,2) as K, 
round(SUM_NOI/replace(CNT_NOI, 0, 1),2) as RESULT 
from TBL_ENV_STAT_HOUR where time like (select /*+index_desc(a,idx_time)*/substr(TO_CHAR(TIME,1,8) from TBL_ENV_STAT_HOUR a where rownum<=1)  || '%'








----------------------------------------------------------------

INSERT INTO bankbook
	VALUES (sysdate,'',0,'g100',10000,);

select remain_price from (
   select A.*,ROWNUM r from 
      (select * from bankbook order by bankdate desc) A
   )
   where r=1;

   
   --------------------------------------------------
INSERT INTO bankbook
	VALUES (sysdate,'g100',10000,' ',0,(select remain_price from (
   select A.remain_price,ROWNUM r from 
      (select * from bankbook order by bankdate desc) A
   )where r=1)-10000);

select * from bankbook;
   
insert into bankbook VALUES(sysdate,' ',0,'자본금',100000000,100000000);

select bankdate,outcome_title,outcome,income_title,income,remain_price from bankbook;

delete from bankbook;
---------------------------------------------------------------

INSERT INTO bankbook
	VALUES (sysdate,' ',0,'자본금',10000,(select remain_price from (
   select A.remain_price,ROWNUM r from 
      (select * from bankbook order by bankdate desc) A
   )where r=1)+10000)
   
   
   
   select * from stockinfo where to_char(update_time,'YYYY-MM') = to_char(sysdate,'YYYY-MM-dd')
   
   
   select to_char(bankdate,'YYYY-MM-dd'),outcome_title,outcome,income_title,income,remain_price from bankbook where (to_char(bankdate,'YYYY-MM-dd') = to_char(sysdate,'YYYY-MM-dd')) order by bankdate desc
   select to_char(bankdate,'YYYY-MM-dd'),outcome_title,outcome,income_title,income,remain_price from bankbook where (to_char(bankdate,'YYYY-MM-dd') = to_char(sysdate,'YYYY-MM-dd')) order by bankdate desc
   select to_char(bankdate,'YYYY-MM-dd'),outcome_title,outcome,income_title,income,remain_price from bankbook where (to_char(bankdate,'YYYY-MM') = to_char(sysdate,'YYYY-MM')) order by bankdate desc
   select to_char(bankdate,'YYYY-MM-dd'),outcome_title,outcome,income_title,income,remain_price from bankbook where (to_char(bankdate,'YYYY') = to_char(sysdate,'YYYY')) order by bankdate desc
   
   
  		select s.item_num, s.item_name, sum(i.in_amount)*s.unit_price total 
		from stockInfo i, stock s
		where s.item_num = i.item_num and (to_char(i.update_time,'YYYY-MM-dd') = to_char(sysdate,'YYYY-MM-dd'))
		group by s.item_num, s.item_name ,s.unit_price
   
