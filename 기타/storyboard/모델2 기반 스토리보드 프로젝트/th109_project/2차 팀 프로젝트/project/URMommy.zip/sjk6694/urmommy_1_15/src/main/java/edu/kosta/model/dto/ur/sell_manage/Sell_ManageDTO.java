package edu.kosta.model.dto.ur.sell_manage;

public class Sell_ManageDTO {
	private String day;
	private String item_num;
	private String item_name;
	private String item_gender; 
	private String item_type;
	private String item_type_detail;
	private int sell_price;
	private int amount;
	private int total;
	
	public String getDay() {
		return day;
	}
	public void setDay(String day) {
		this.day = day;
	}
	public String getItem_num() {
		return item_num;
	}
	public void setItem_num(String item_num) {
		this.item_num = item_num;
	}
	public String getItem_name() {
		return item_name;
	}
	public void setItem_name(String item_name) {
		this.item_name = item_name;
	}
	public String getItem_gender() {
		return item_gender;
	}
	public void setItem_gender(String item_gender) {
		this.item_gender = item_gender;
	}
	public String getItem_type() {
		return item_type;
	}
	public void setItem_type(String item_type) {
		this.item_type = item_type;
	}
	public String getItem_type_detail() {
		return item_type_detail;
	}
	public void setItem_type_detail(String item_type_detail) {
		this.item_type_detail = item_type_detail;
	}
	public int getSell_price() {
		return sell_price;
	}
	public void setSell_price(int sell_price) {
		this.sell_price = sell_price;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	
	@Override
	public String toString() {
		return "Sell_ManageDTO [day=" + day + ", item_num=" + item_num + ", item_name=" + item_name + ", item_gender="
				+ item_gender + ", item_type=" + item_type + ", item_type_detail=" + item_type_detail + ", sell_price="
				+ sell_price + ", amount=" + amount + ", total=" + total + "]";
	}
	
	
	
}
