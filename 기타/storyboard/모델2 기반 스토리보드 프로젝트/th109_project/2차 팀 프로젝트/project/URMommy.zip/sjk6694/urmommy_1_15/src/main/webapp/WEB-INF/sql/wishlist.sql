
create table WishList(
	w_list_num NUMBER(10) NOT NULL PRIMARY KEY,--위시 리스트 넘버
	user_id VARCHAR2(50) NOT NULL,--유저 아이디
	pic_url VARCHAR2(50) NOT NULL,--아이템 사진
	item_name varchar2(50) NOT NULL,--아이템 넘버
	item_num varchar2(50) not null,--아이템 넘버
  	unit_price number(10) not null,--아이템 단가
  	sell_price number(10) not null--아이템 가격
);
ALTER TABLE WishList
ADD CONSTRAINT fk_WishList FOREIGN KEY (item_num)
REFERENCES stock (item_num) ON DELETE CASCADE

ALTER TABLE WishList
ADD CONSTRAINT fk_WishList_userId FOREIGN KEY (user_id)
REFERENCES User_Account(user_id) ON DELETE CASCADE


drop table WishList CASCADE CONSTRAINTS

select * from WishList;
