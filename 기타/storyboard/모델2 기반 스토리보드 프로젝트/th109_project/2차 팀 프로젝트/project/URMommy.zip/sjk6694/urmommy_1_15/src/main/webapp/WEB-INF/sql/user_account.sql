------------------------------------------------------------------------------------------------

SELECT * FROM User_Account

create table User_Account(
   user_id VARCHAR2(50) NOT NULL PRIMARY KEY,
   user_pwd VARCHAR2(50) NOT NULL,
   m_name VARCHAR2(50) NOT NULL,
   b_name VARCHAR2(50) NULL,
   m_birthday VARCHAR2(50) NOT NULL,
   b_birthday DATE NULL,
   phone VARCHAR2(50) NOT NULL,
   email VARCHAR2(50) NOT NULL,
   address VARCHAR2(150) NOT NULL,
   b_gender VARCHAR2(10) NULL
);

DROP TABLE User_Account CASCADE CONSTRAINTS

select * from user_account