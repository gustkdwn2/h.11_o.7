package edu.kosta.service.ur.stock;

import java.util.HashMap;
import java.util.List;

import edu.kosta.model.dto.ur.stock.StockDAO;
import edu.kosta.model.dto.ur.stock.StockDTO;

public interface StockService {

   public List<StockDTO> getStockList(HashMap<String,Object> map);
   public List<StockDAO> getSearchStockList(HashMap<String,Object> map, String searchValue, String searchBox);
   
   //재고 관리
   public void stockInsert(StockDTO stockDTO);
   public void stockUpdate(StockDTO stockDTO);
   public void stockDelete(StockDTO stockDTO);
   public int getItemBoyCount();   
   public int getItemGirlCount();   
   public int getUrmomCount(String it);
   public int getItemDetailCount(String itd);
   
   //입고 관리
   public List<StockDTO> getStockShow(String item_num);
   public void stockAdd(HashMap<String,Object> stockAddMap);
   public List<StockDTO> getExistSize(String item_num);
   public void itemInfoAddSize(HashMap<String,Object> stockSizeAddMap);
   public void stockAddSize(HashMap<String, Object> stockSizeAddMap);
   public int countNoStock(String item_num);
   public int stockSizeCount(String item_num);
   public int stockInItem(String item_num); 
   
   //입고 통계
   public List<StockDTO> inList(HashMap<String,Object> map);
   public int inListCount();
   public List<StockDTO> searchInList(HashMap<String,Object> map);
   public int searchInListCount(String day);
   
   //출고 통계
   public List<StockDTO> outList(HashMap<String,Object> map);
   public int outListCount();
   
   public List<StockDTO> searchOutList(HashMap<String,Object> map);
   public int searchOutListCount(String day);
   
   //입고차트
   public List<StockDTO> inGenderChart();               		//오늘
   public List<StockDTO> searchInGenderChart(String day);      //선택 별

   public List<StockDTO> inTypeChart();
   public List<StockDTO> searchInTypeChart(String day);

   public List<StockDTO> inDetailChart();
   public List<StockDTO> searchInDetailChart(String day);
   
   //출고차트
   public List<StockDTO> outGenderChart();
   public List<StockDTO> searchOutGenderChart(String day);

   public List<StockDTO> outTypeChart();
   public List<StockDTO> searchOutTypeChart(String day);


   public List<StockDTO> outDetailChart();
   public List<StockDTO> searchOutDetailChart(String day);

   
   //베스트 가져오기
   public List<StockDTO> getBestItem(HashMap<String,Object> map);

}