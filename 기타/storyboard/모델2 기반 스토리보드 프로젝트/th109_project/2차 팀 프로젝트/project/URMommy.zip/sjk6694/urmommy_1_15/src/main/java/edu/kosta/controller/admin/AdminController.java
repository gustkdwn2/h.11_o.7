package edu.kosta.controller.admin;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import edu.kosta.model.dto.admin.AdminDTO;
import edu.kosta.model.dto.humanResource.HumanResourceDTO;
import edu.kosta.model.dto.ur.web_manage.Web_ManageDTO;
import edu.kosta.service.admin.AdminService;
import edu.kosta.service.humanResource.HumanResourceService;
import edu.kosta.service.ur.web_manage.Web_ManageService;
import edu.kosta.service.user.UserService;

/* 
 * @author (BONA RYU)
 * 
 * 이 컨트롤러는 관리자 회원가입에 관련된 메소드와
 * 관리자 로그인에 관련된 메소드를 담고 있다.
 * */

@Controller
public class AdminController {
	
	@Autowired
	private AdminService adminService;
	@Autowired
	private HumanResourceService hrService;
	@Autowired
	private UserService userService;
	@Resource
	private Web_ManageService web_manageService;
	
	/*
	 *  이 메소드는 관리자 회원가입 버튼을 누르면
	 *  adminJoinWriteForm.jsp 페이지로 이동시켜준다.
	 *  
	 *  @see adminJoinWriteForm.jsp
	 */
	@RequestMapping("adminJoinWriteForm.do")
	public String adminJoinWriteForm(){
		return "admin/adminJoinWriteForm";
	}
	
	/*
	 *  이 메소드는 관리자 회원가입 폼을 작성하고 완료를 누르면
	 *  @Param admin_id					관리자 아이디
	 *  @Param admin_pwd				관리자 비밀번호
	 *  @Param admin_name			관리자 이름
	 *  @Param admin_hiredate 		관리자 입사일
	 *  admin_id, admin_pwd, admin_name, admin_hiredate, admin_department 를 adminDB에 저장한다.
	 *  관리자 회원가입을 하면 최상위 관리자는 인사관리를 직접할수 있어야하기에
	 *  관리자의 비밀번호를 제외한 나머지 컬럼을 human_resourceDB에 저장한다.
	 */
	@RequestMapping("/adminJoinWrite.do")
	public ModelAndView adminJoin(HttpServletRequest request) throws Exception{
        
		AdminDTO adminDTO = new AdminDTO();
		
		adminDTO.setAdmin_id(request.getParameter("admin_id"));
		adminDTO.setAdmin_pwd(request.getParameter("admin_pwd"));
		adminDTO.setAdmin_name(request.getParameter("admin_name"));
		adminDTO.setAdmin_hiredate(request.getParameter("admin_hiredate"));
		adminDTO.setAdmin_department(request.getParameter("admin_department"));
		
		this.adminService.insertAdminJoin(adminDTO);
        
		HumanResourceDTO hrDTO = new HumanResourceDTO();
		
		hrDTO.setAdmin_id(adminDTO.getAdmin_id());
		hrDTO.setAdmin_name(adminDTO.getAdmin_name());
		hrDTO.setAdmin_hiredate(adminDTO.getAdmin_hiredate());
		hrDTO.setAdmin_department(adminDTO.getAdmin_department());
		
		this.hrService.insertHRList(hrDTO);
	
        ModelAndView mav = new ModelAndView();
        mav.setViewName("redirect:/start.jsp");	//성공하면 index 페이지로 이동
        return mav;
    }
	
	/*
	 * 관리자 회원가입시 아이디 중복체크 버튼을 누르면 이 메소드가 실행된다.
	 * 
	 * @Param admin_id		관리자 아이디
	 * 입력한 아이디가 존재하면 입력한 아이디의 관련 정보를 'loginAdmin'라는 이름으로
	 * adminJoinConfirmId.jsp 로 넘겨진다.
	 * 입력한 아이디가 존재하지 않으면 'emptyloginAdmin'라는 이름으로
	 * adminJoinConfirmId.jsp 로 넘겨진다.
	 * 
	 * @see adminJoinConfirmId.jsp
	 */
	@RequestMapping("/adminConfirmId.do")
	public ModelAndView confirmId(HttpServletRequest request) throws Exception{
		ModelAndView mav = new ModelAndView();
		AdminDTO adminDTO = new AdminDTO();
		adminDTO.setAdmin_id(request.getParameter("admin_id"));
	
		try{    
			AdminDTO loginAdmin = this.adminService.adminConfirmId(adminDTO);
			if(loginAdmin!=null){	//입력한 아이디가 존재하면
			mav.addObject("loginAdmin",loginAdmin);
			mav.setViewName("admin/adminJoinConfirmId"); 
			return mav;
			}else{	//입력한 아이디가 존재하지 않으면
				mav.addObject("emptyloginAdmin",adminDTO.getAdmin_id());
				mav.setViewName("admin/adminJoinConfirmId");
				return mav;
			}
		}catch(Exception e){
			e.printStackTrace();
			return mav;
		}
	}
	
	////////////////////////////////////////////////////////////////////////////////
	
	/*
	 * 이 메소드는 관리자 로그인 버튼을 누르면
	 * 관리자 로그인 폼으로 이동시켜준다.
	 * @see adminLoginForm.jsp
	 */
	@RequestMapping("/adminLoginForm.do")
	public String adminLoginForm() {
		return "admin/adminLoginForm";
	}
	
	/*
	 * 관리자가 로그인폼에 정보를 입력하면 입력받은 정보가
	 *	adminDB의 정보와 일치하는지 확인하는 메소드이다.
	 *	@Param admin_id			관리자 아이디
	 *	@Param admin_pwd		관리자 비밀번호
	 *	입력받은 아이디와 비밀번호와 일치하는 정보가 있다면 'loginAdmin'에 담고 첫페이지로 돌아간다
	 *	일치하는 정보가 없다면 로그인 실패 페이지로 이동한다
	 *	@see loginFail.jsp
	 */
	@RequestMapping("/adminLogin.do")	//관리자 로그인
	public ModelAndView adminLogin(HttpSession session, HttpServletRequest request) {
		ModelAndView mav = new ModelAndView();

		AdminDTO adminDTO = new AdminDTO();

		adminDTO.setAdmin_id(request.getParameter("admin_id"));
		adminDTO.setAdmin_pwd(request.getParameter("admin_pwd"));
		System.out.println(adminDTO);
		try {
			AdminDTO loginAdmin = this.userService.getAdminLoginCheck(adminDTO); //
			System.out.println(loginAdmin);
			if (loginAdmin != null) {
				session.setAttribute("loginAdmin", loginAdmin);
				mav.addObject("loginAdmin", loginAdmin);
				mav.setViewName("redirect:/start.jsp");
				return mav;
			} else {
				Web_ManageDTO mainlogo = web_manageService.getMainLogo();
				mav.addObject("mainlogo", mainlogo);
				mav.setViewName("login/loginFail");
				return mav;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return mav;
		}
	}
}
