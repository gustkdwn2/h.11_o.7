package edu.kosta.service.admin;

import java.util.ArrayList;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import edu.kosta.model.dto.admin.AdminDAO;
import edu.kosta.model.dto.admin.AdminDTO;

@Component
public class AdminServiceImpl implements AdminService {
	
	@Autowired
	private SqlSession sqlsession;
	
	@Override
	public void insertAdminJoin(AdminDTO adminDTO) {
		AdminDAO adminDAO = sqlsession.getMapper(AdminDAO.class);
		adminDAO.insertAdminJoin(adminDTO);
	}

	@Override
	public AdminDTO adminConfirmId(AdminDTO adminDTO) {
		AdminDTO result = new AdminDTO();
		AdminDAO adminDAO = sqlsession.getMapper(AdminDAO.class);
		result = adminDAO.adminConfirmId(adminDTO);
		return result;
	}

	@Override
	public ArrayList<AdminDTO> adminAllSelect() {
		AdminDAO adminDAO = sqlsession.getMapper(AdminDAO.class);
		ArrayList<AdminDTO> adminList = new ArrayList<AdminDTO>();
		adminList = adminDAO.adminAllSelect();
		return adminList;
	}

	@Override
	public void adminDelete(String admin_id) {
		AdminDAO adminDAO = sqlsession.getMapper(AdminDAO.class);
		adminDAO.adminDelete(admin_id);
		
	}

}
