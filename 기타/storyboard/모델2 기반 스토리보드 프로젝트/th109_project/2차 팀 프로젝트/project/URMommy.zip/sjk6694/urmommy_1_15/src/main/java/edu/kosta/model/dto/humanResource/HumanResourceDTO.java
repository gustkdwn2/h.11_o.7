package edu.kosta.model.dto.humanResource;

public class HumanResourceDTO {
	private String admin_id;
	private String admin_name;
	private String admin_department;
	private String admin_hiredate;
	private int admin_pay;
	private double admin_bonus;
	private double admin_paycut;

	public String getAdmin_id() {
		return admin_id;
	}

	public void setAdmin_id(String admin_id) {
		this.admin_id = admin_id;
	}

	public String getAdmin_name() {
		return admin_name;
	}

	public void setAdmin_name(String admin_name) {
		this.admin_name = admin_name;
	}

	public String getAdmin_department() {
		return admin_department;
	}

	public void setAdmin_department(String admin_department) {
		this.admin_department = admin_department;
	}

	public String getAdmin_hiredate() {
		return admin_hiredate;
	}

	public void setAdmin_hiredate(String admin_hiredate) {
		this.admin_hiredate = admin_hiredate;
	}

	public int getAdmin_pay() {
		return admin_pay;
	}

	public void setAdmin_pay(int admin_pay) {
		this.admin_pay = admin_pay;
	}

	public double getAdmin_bonus() {
		return admin_bonus;
	}

	public void setAdmin_bonus(double admin_bonus) {
		this.admin_bonus = admin_bonus;
	}

	public double getAdmin_paycut() {
		return admin_paycut;
	}

	public void setAdmin_paycut(double admin_paycut) {
		this.admin_paycut = admin_paycut;
	}

	@Override
	public String toString() {
		return "HumanResourceDTO [admin_id=" + admin_id + ", admin_name=" + admin_name + ", admin_department="
				+ admin_department + ", admin_hiredate=" + admin_hiredate + ", admin_pay=" + admin_pay
				+ ", admin_bonus=" + admin_bonus + ", admin_paycut=" + admin_paycut + "]";
	}

	
}
