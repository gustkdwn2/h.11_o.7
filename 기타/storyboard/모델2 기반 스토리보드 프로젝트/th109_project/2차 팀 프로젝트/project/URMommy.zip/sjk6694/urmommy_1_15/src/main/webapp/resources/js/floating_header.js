$(document).ready($(function() {
		$.ajax({ //위의 ajax가 실행되고 나면 이 ajax를 실행한다.
			type : "POST", //타입은 post
			url : "floating_list.do", //servlet jjim.jjim을 실행, 해당 페이지로 jjim리스트를 발송한다.
			dataType : 'html',//데이터 타입은 html
			success : function(html) {//해당페이지로 jjim리스트가 발송되면
				jQuery('.floating').html(jQuery.trim(html));//jjimlist div에 html을 불러온다.
			}
		})//ajax
	}))