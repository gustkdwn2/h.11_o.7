package edu.kosta.service.ur.bankbook;

import java.util.HashMap;
import java.util.List;

import edu.kosta.model.dto.ur.bankbook.BankBookDTO;

public interface BankBookService {
   
   public List<BankBookDTO> getBankBookList(HashMap<String,Object> map);
   //오늘 입출고 리스트
   public List<BankBookDTO> getBankBook_Day_Search(HashMap<String,Object> map);
   //선택 날짜 입출고 리스트
   public List<BankBookDTO> getBankBook_Month_Search(HashMap<String,Object> map);
   //월별 입출고 리스트
   public List<BankBookDTO> getBankBook_Year_Search(HashMap<String,Object> map);
   //년별 입출고 리스트
   public void BankBook_outcome_insert(HashMap<String,Object> map);
   //지출 입력
   //public void BankBook_income_insert(HashMap<String,Object> map);
   //입금 입력
   public int getBank_book_Count();
   //선택 날짜 입출고 수
   public int getBank_book_day_count(String day);
   //입출고 날짜별 수
   public int getBank_book_month_count(String day);
   //입출고 월별 수
   public int getBank_book_year_count(String day);
   //입출고 년별 수
   
   public List<BankBookDTO> getBankBook_total_list();
   //입출고 자본금의 모든 리스트(LineChart에서 사용)
}