package edu.kosta.controller.ur.item;

import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import edu.kosta.model.dto.ur.QnA.QnADTO;
import edu.kosta.model.dto.ur.QnA.QnaCommentDTO;
import edu.kosta.model.dto.ur.item.ItemDTO;
import edu.kosta.model.dto.ur.review.ReviewDTO;
import edu.kosta.model.dto.ur.stock.StockDTO;
import edu.kosta.model.dto.ur.web_manage.Web_ManageDTO;
import edu.kosta.model.dto.ur.wishlist.WishlistDTO;
import edu.kosta.model.dto.user.UserDTO;
import edu.kosta.service.ur.QnA.QnAService;
import edu.kosta.service.ur.item.ItemService;
import edu.kosta.service.ur.review.ReviewService;
import edu.kosta.service.ur.web_manage.Web_ManageService;
import edu.kosta.service.ur.wishlist.WishlistService;

/* 
 * @author (EELHEA CHO)
 * 
 * 이 컨트롤러는 상품 상세보기(상품설명,Q&A,REVIEW), 상품 수정, 상품 삭제관련 메소드를 담고 있다.
 * */

@Controller
public class ItemDetailController {
	
	@Resource
	private Web_ManageService web_manageService;
	@Resource
	private ItemService itemService;
	@Resource
	private ReviewService reviewService;
	@Resource
	private QnAService qnaService;
	@Resource
	private WishlistService wishlistService;

	/*
	 * 이 메소드는 하나의 상품를 클릭했을 때 상세보기 화면을 실행하도록 한다.
	 * 
	 * 로그인 세션에 유지되어있는 아이디를 불러온다.
	 * itemDB에서 상품의 상세내용을 불러온다.
	 * 상품코드에 해당하는 각 사이즈의 재고개수를 받아와서 품절사이즈 여부를 jsp페이지에서 처리한다.
	 * (상품의 각 사이즈 옆에 [품절]이라는 글자가 나타난다.)
	 * 
	 * 상품상세페이지 아래에는 각 상품의 후기목록이 출력된다.
	 * review DB에서 해당 상품에 해당하는 후기들을 불러오고 페이징 처리가 된다.
	 * 
	 * 후기 목록아래에는 각 상품의 Q&A목록이 출력된다.
	 * QNA DB에서 해당 상품에 해당하는 후기들을 불러오고 페이징 처리가 된다.
	 * QNA_COMMENT DB에서 각 질문에 해당되는 댓글 또한 불러온다.
	 * 
	 * 관심상품으로 클릭을 하면 해당 아이디의 관심상품목록에 추가된다.
	 */
	@RequestMapping(value="/itemDetail.do", method=RequestMethod.GET)
	public String list(HttpServletRequest request, String item_num, HttpSession session) {

		UserDTO loginUser = (UserDTO)session.getAttribute("loginUser");
		
		Web_ManageDTO mainlogo = web_manageService.getMainLogo();
		ItemDTO listDetail = (ItemDTO)itemService.getItemDetail(item_num);
		List<StockDTO> itemStockLeft = itemService.getItemStockLeft(item_num);
		
		//REVIEW
		int review_pg = 1;
		String strPg = request.getParameter("pg");
		if (strPg != null) {
			review_pg = Integer.parseInt(strPg);
		}
		int review_rowSize = 5;
		int review_start = (review_pg * review_rowSize) - (review_rowSize - 1);
		int review_end = review_pg * review_rowSize;

		int review_total = reviewService.getReview_Count(item_num);
		int review_allPage = (int) Math.ceil(review_total / (double) review_rowSize);

		int review_block = 10;
		int review_fromPage = ((review_pg - 1) / review_block * review_block) + 1;
		int review_toPage = ((review_pg - 1) / review_block * review_block) + review_block;
		if (review_toPage > review_allPage) {
			review_toPage = review_allPage;
		}

		HashMap<String, Object> review_map = new HashMap<String, Object>();
		review_map.put("start", review_start);
		review_map.put("end", review_end);
		review_map.put("item_num", item_num);

		List<ReviewDTO> review_list = reviewService.getReview_List(review_map);
		
		//Q&A
		int qnapage = 1;
		String strPage = request.getParameter("page");
		if (strPage != null) {
			qnapage = Integer.parseInt(strPage);
		}
		int qnaRowSize = 5;
		int qnaStart = (qnapage * qnaRowSize) - (qnaRowSize - 1);
		int qnaEnd = qnapage * qnaRowSize;

		int qnaTotal = qnaService.getQnACount(item_num);
		int qnaAllPage = (int) Math.ceil(qnaTotal / (double) qnaRowSize);

		int qnaBlock = 5;
		int qnaFromPage = ((qnapage - 1) / qnaBlock * qnaBlock) + 1;
		int qnaToPage = ((qnapage - 1) / qnaBlock * qnaBlock) + qnaBlock;
		if (qnaToPage > qnaAllPage) {
			qnaToPage = qnaAllPage;
		}

		HashMap<String,Object> map = new HashMap<String,Object>();
		map.put("start", qnaStart);
		map.put("end", qnaEnd);
		map.put("item_num", item_num);

		List<QnADTO> qnalist = qnaService.getQnAList(map);
		List<QnaCommentDTO> qnaCommentList = qnaService.selectReply(); 
		
		//WISHLIST
		if(loginUser != null){
			HashMap<String,Object> wishlist_map = new HashMap<String,Object>();
			wishlist_map.put("user_id", loginUser.getUser_id());
			List<WishlistDTO> wishlist = wishlistService.Wishlist_list(wishlist_map);
			request.setAttribute("wishlist",wishlist);
		}
		
		request.setAttribute("mainlogo", mainlogo);	
		
		request.setAttribute("item_num", item_num);
		request.setAttribute("listDetail", listDetail);
		request.setAttribute("itemStockLeft", itemStockLeft);
		
		request.setAttribute("review_list", review_list);
		request.setAttribute("review_pg",review_pg);
		request.setAttribute("review_allPage",review_allPage);
		request.setAttribute("review_block",review_block);
		request.setAttribute("review_fromPage",review_fromPage);
		request.setAttribute("review_toPage",review_toPage);
		
		request.setAttribute("list", qnalist);
		request.setAttribute("page", qnapage);
		request.setAttribute("allPage", qnaAllPage);
		request.setAttribute("block", qnaBlock);
		request.setAttribute("fromPage", qnaFromPage);
		request.setAttribute("toPage", qnaToPage);
		request.setAttribute("comment", qnaCommentList);

		return "item/itemDetail";
	}
	
	/*
	 * 상품상세보기 내에서 상품수정 버튼을 누르면 실행되는 메소드이다.
	 * 상품코드에 해당되는 상품수정 폼을 불러온다.
	 */
	@RequestMapping(value="/itemUpdateForm.do", method=RequestMethod.GET)
	public String itemUpdateForm(HttpServletRequest request, String item_num){
		ItemDTO itemDTO = itemService.getItemDetail(item_num);
		request.setAttribute("itemDTO", itemDTO);
		request.setAttribute("item_num", item_num);
		return "item/itemUpdateForm";
	}
	/*
	 * 성공적으로 상품수정이 되었다면 메인으로 돌아가게된다.
	 */
	@RequestMapping(value="/itemUpdate.do", method=RequestMethod.POST)
	public String itemUpdate(ItemDTO itemDTO){
		itemService.itemUpdate(itemDTO);
		return "redirect:/mainList.do";
	}
	
	/*
	 * 상품상세보기 내에서 상품삭제 버튼을 누르면 실행되는 메소드이다.
	 */
	@RequestMapping(value="/itemDelete.do", method=RequestMethod.GET)
	public String itemDelete(String item_num){
		itemService.itemDelete(item_num);
		return "redirect:/mainList.do";
	}
	
}
