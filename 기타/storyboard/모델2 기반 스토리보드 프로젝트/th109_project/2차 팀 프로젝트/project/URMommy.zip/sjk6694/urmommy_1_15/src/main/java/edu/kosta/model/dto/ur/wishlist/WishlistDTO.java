package edu.kosta.model.dto.ur.wishlist;

public class WishlistDTO {
	private int w_list_num; //NUMBER(10) NOT NULL PRIMARY KEY,--위시 리스트 넘버
	private String user_id; //VARCHAR2(50) NOT NULL,--유저 아이디
	private String pic_url; //VARCHAR2(50) NOT NULL,--아이템 사진
	private String item_name;//VARCHAR2(50) --아이템 이름
	private String item_num; //varchar2(50) not null,--아이템 넘버
	private int unit_price; //number(10) not null,--아이템 단가
	private int sell_price; //number(10) not null--아이템 가격
	
	
	public int getW_list_num() {
		return w_list_num;
	}
	public void setW_list_num(int w_list_num) {
		this.w_list_num = w_list_num;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getPic_url() {
		return pic_url;
	}
	public void setPic_url(String pic_url) {
		this.pic_url = pic_url;
	}
	public String getItem_name() {
		return item_name;
	}
	public void setItem_name(String item_name) {
		this.item_name = item_name;
	}
	public String getItem_num() {
		return item_num;
	}
	public void setItem_num(String item_num) {
		this.item_num = item_num;
	}
	public int getUnit_price() {
		return unit_price;
	}
	public void setUnit_price(int unit_price) {
		this.unit_price = unit_price;
	}
	public int getSell_price() {
		return sell_price;
	}
	public void setSell_price(int sell_price) {
		this.sell_price = sell_price;
	}
	
	@Override
	public String toString() {
		return "WishlistDTO [w_list_num=" + w_list_num + ", user_id=" + user_id + ", pic_url=" + pic_url
				+ ", item_name=" + item_name + ", item_num=" + item_num + ", unit_price=" + unit_price + ", sell_price="
				+ sell_price + "]";
	}
	
	
}
