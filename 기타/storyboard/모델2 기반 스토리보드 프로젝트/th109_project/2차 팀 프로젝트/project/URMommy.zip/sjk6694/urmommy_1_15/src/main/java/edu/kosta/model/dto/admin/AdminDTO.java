package edu.kosta.model.dto.admin;


public class AdminDTO {
	private String admin_id;
	private String admin_pwd;
	private String admin_name;
	private String admin_hiredate;
	private String admin_department;

	
	public String getAdmin_id() {
		return admin_id;
	}

	public void setAdmin_id(String admin_id) {
		this.admin_id = admin_id;
	}



	public String getAdmin_pwd() {
		return admin_pwd;
	}



	public void setAdmin_pwd(String admin_pwd) {
		this.admin_pwd = admin_pwd;
	}



	public String getAdmin_name() {
		return admin_name;
	}



	public void setAdmin_name(String admin_name) {
		this.admin_name = admin_name;
	}



	public String getAdmin_hiredate() {
		return admin_hiredate;
	}



	public void setAdmin_hiredate(String admin_hiredate) {
		this.admin_hiredate = admin_hiredate;
	}



	public String getAdmin_department() {
		return admin_department;
	}



	public void setAdmin_department(String admin_department) {
		this.admin_department = admin_department;
	}



	@Override
	public String toString() {
		return "AdminDTO [admin_id=" + admin_id + ", admin_pwd=" + admin_pwd + ", admin_name=" + admin_name
				+ ", admin_hiredate=" + admin_hiredate + ", admin_department=" + admin_department + "]";
	}
	
	
}
