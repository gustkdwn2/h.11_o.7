package edu.kosta.service.ur.web_manage;

import java.util.List;

import org.springframework.web.multipart.MultipartHttpServletRequest;

import edu.kosta.model.dto.ur.web_manage.Web_ManageDTO;

public interface Web_ManageService {

	String getFileName(MultipartHttpServletRequest mul);

	void logoInsert(Web_ManageDTO web_manageDTO);

	Web_ManageDTO getMainLogo();

	List<Web_ManageDTO> getLogos();

}
