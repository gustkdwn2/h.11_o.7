package edu.kosta.controller.ur.item;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import edu.kosta.model.dto.ur.item.ItemDTO;
import edu.kosta.model.dto.ur.stock.StockDAO;
import edu.kosta.model.dto.ur.stock.StockDTO;
import edu.kosta.model.dto.ur.web_manage.Web_ManageDTO;
import edu.kosta.service.ur.item.ItemService;
import edu.kosta.service.ur.stock.StockService;
import edu.kosta.service.ur.web_manage.Web_ManageService;

/* 
 * @author (EELHEA CHO)
 * 
 * 이 컨트롤러는 상품을 등록할 때 실행되는 메소드를 담고 있다.
 * */

@Controller
public class ItemInsertController {
	@Resource
	private ItemService itemService;
	@Resource
	private StockService stockService;
	@Resource
	private Web_ManageService web_manageService;

	public void callCommonMethod(HttpServletRequest request){
		Web_ManageDTO mainlogo = web_manageService.getMainLogo();
		request.setAttribute("mainlogo", mainlogo);	
	}
	
	/*
	 * 상품등록을 클릭하면 실행되는 메소드이다.
	 * 화면의 좌측에는 재고 리스트가 출력이 되고, 우측에는 상품등록 폼이 나오게 된다.
	 */
	@RequestMapping(value = "/itemInsertForm.do", method = RequestMethod.GET)
	public String itemInsertForm(HttpServletRequest request, Model model) {
		
		callCommonMethod(request);
		
		int pg=1;
		String strPg = request.getParameter("pg"); 
		if(strPg!=null){
			pg = Integer.parseInt(strPg);			
		}
		//행 개수
		int rowSize = 10;
		int start = (pg*rowSize)-(rowSize -1);
		int end = pg*rowSize;
		//총 게시물수
		int total = itemService.getItemMainCount(); 
		//페이지수 = 총 게시물수/행 개수
		int allPage = (int) Math.ceil(total/(double)rowSize); 
		//한페이지에 보여줄  범위
		int block = 10; 
		//보여줄 페이지의 시작
		int fromPage = ((pg-1)/block*block)+1;
		//보여줄 페이지의 끝
		int toPage = ((pg-1)/block*block)+block; 
			if(toPage> allPage){
				toPage = allPage;
			}//end if
		
		HashMap<String,Object> map = new HashMap<String,Object>();
		map.put("start", start);
		map.put("end", end);
		
		List<StockDTO> stockList = stockService.getStockList(map);
		for (int i = 0; i < stockList.size(); i++) {
			int count = stockService.countNoStock(stockList.get(i).getItem_num());// 재고수가 0인 사이즈 개수

			// 상품 사이즈 개수
			int stockSizeCount = stockService.stockSizeCount(stockList.get(i).getItem_num());
				if (stockSizeCount != 5) {
					count += (5 - stockSizeCount);
				}
			stockList.get(i).setCountNoStock(count);
			
			int stockInItem = stockService.stockInItem(stockList.get(i).getItem_num());
			
			if(stockInItem == 1){
				stockList.get(i).setIn_item("Y");
			}
		} // end for
		request.setAttribute("stockList", stockList);
		request.setAttribute("pg",pg);
		request.setAttribute("allPage",allPage);
		request.setAttribute("block",block);
		request.setAttribute("fromPage",fromPage);
		request.setAttribute("toPage",toPage);	
		
		model.addAttribute("itemDTO", new ItemDTO());
		
		return "item/itemInsertForm";
	}
	
	/*
	 * 등록할 상품을 재고목록에서 선택하는 메소드이다.
	 * 
	 * 상품등록폼에서 좌측에 있는 재고 리스트의 재고명을 누르면 
	 * 우측의 상품등록 폼에 등록된 기본 상품정보가 자동으로 입력된다.
	 * 
	 * 자동으로 입력되는 기본상품정보내용은 다음과 같다.
	 * (상품코드, 상품명, 상품성별, 상품타입, 상품상세타입, 단가, 판매가)
	 * 폼에서 등록해야 하는 정보는 상품대표사진,대표사진설명,상품상세사진 이다.
	 * 
	 * 대표사진 설명은 상품목록에서 사진 위에 마우스오버할 때 호버효과에 출력 될 간략한 상품설명을 의미한다.
	 */
	@RequestMapping(value="itemStockInsert.do", method=RequestMethod.POST)
	public String itemStockShow(StockDTO stockDTO,HttpServletRequest request, Model model) throws Exception{

		callCommonMethod(request);
		
		String searchValue = request.getParameter("searchValue");
		String searchBox = request.getParameter("searchBox");
		
		if(!searchBox.equals("")){
			searchStock(request, searchValue, searchBox);
		} else if (searchBox.equals("")){
			itemInsertForm(request,model);
		}
		
		request.setAttribute("stockDTO", stockDTO);
		request.setAttribute("searchValue", searchValue);
		request.setAttribute("searchBox", searchBox);
		
		return "item/itemInsertForm";
	}
	
	/*
	 * 재고에서 등록할 상품을 선택할 때, 재고를 검색해서 선택할 시 실행되는 메소드이다.
	 * 검색할 때 마다 페이징 처리가 된다.
	 */
	@RequestMapping(value="/searchItemInsert.do", method=RequestMethod.POST)
	public String searchStock(HttpServletRequest request, String searchValue, String searchBox){

		callCommonMethod(request);

		int pg = 1;
		String strPg = request.getParameter("pg");
		if (strPg != null) {
			pg = Integer.parseInt(strPg);
		}
		int rowSize = 10;
		int start = (pg * rowSize) - (rowSize - 1);
		int end = pg * rowSize;
		int total = 0;

		int allPage = (int) Math.ceil(total / (double) rowSize);
		int block = 10;
		int fromPage = ((pg - 1) / block * block) + 1;

		int toPage = ((pg - 1) / block * block) + block;
		if (toPage > allPage) {
			toPage = allPage;
		}

		if (searchValue.equals("item_gender")) {
			if (searchBox.equals("boy") || searchBox.equals("BOY")) {
				total = stockService.getItemBoyCount();
			}
			if (searchBox.equals("girl") || searchBox.equals("GIRL")) {
				total = stockService.getItemGirlCount();
			}
		}
		if (searchValue.equals("item_type")) {
			if (searchBox.equals("out") || searchBox.equals("OUT")) {
				total = stockService.getUrmomCount("item_type");
			}
			if (searchBox.equals("top") || searchBox.equals("TOP")) {
				total = stockService.getUrmomCount("item_type");
			}
			if (searchBox.equals("bot") || searchBox.equals("BOT")) {
				total = stockService.getUrmomCount("item_type");
			}
			if (searchBox.equals("dre") || searchBox.equals("DRE")) {
				total = stockService.getUrmomCount("item_type");
			}
		}
		if (searchValue.equals("item_type_detail")) {
			if (searchBox.equals("tee") || searchBox.equals("TEE")) {
				total = stockService.getItemDetailCount("item_type_detail");
			}
			if (searchBox.equals("blou") || searchBox.equals("BLOU")) {
				total = stockService.getItemDetailCount("item_type_detail");
			}
			if (searchBox.equals("knit") || searchBox.equals("KNIT")) {
				total = stockService.getItemDetailCount("item_type_detail");
			}
			if (searchBox.equals("pant") || searchBox.equals("PANT")) {
				total = stockService.getItemDetailCount("item_type_detail");
			}
			if (searchBox.equals("skir") || searchBox.equals("SKIR")) {
				total = stockService.getItemDetailCount("item_type_detail");
			}
		}
		if (searchBox.equals("")) {
			return "redirect:/itemInsertForm.do";
		}

		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("start", start);
		map.put("end", end);

		List<StockDAO> searchStock = stockService.getSearchStockList(map, searchValue, searchBox);
		request.setAttribute("stockList", searchStock);
		request.setAttribute("pg", pg);
		request.setAttribute("allPage", allPage);
		request.setAttribute("block", block);
		request.setAttribute("fromPage", fromPage);
		request.setAttribute("toPage", toPage);
		request.setAttribute("searchValue", searchValue);
		request.setAttribute("searchBox", searchBox);

		return "item/itemInsertForm";
	}
	
	/*
	 * 상품정보를 모두 입력 한 후, 상품을 itemDB에 저장하여 등록하는 메소드이다.
	 * 등록이 되면 메인 화면으로 돌아가서 등록된 상품의 대표사진이 출력된다.
	 */
	@RequestMapping(value = "/itemInsert.do", method = RequestMethod.POST)
    public String itemInsert(@ModelAttribute("itemDTO") @Valid ItemDTO itemDTO, BindingResult bindingResult, MultipartHttpServletRequest mul, HttpServletResponse response) throws IOException {
		
		int validItem = itemService.itemValid(itemDTO);
		
		if(validItem>0){
			response.setCharacterEncoding("EUC-KR");
			PrintWriter writer = response.getWriter();
			writer.println("<script type='text/javascript'>");
			writer.println("alert('이미 등록한 상품입니다.');");
			writer.println("history.back();");
			writer.println("</script>");
			writer.flush();
			return null;
		}
		else{
			itemDTO.setPic_url(itemService.getFileName(mul));
			itemService.itemInsert(itemDTO);
			return "redirect:/mainList.do";
		}
    }
	

}
