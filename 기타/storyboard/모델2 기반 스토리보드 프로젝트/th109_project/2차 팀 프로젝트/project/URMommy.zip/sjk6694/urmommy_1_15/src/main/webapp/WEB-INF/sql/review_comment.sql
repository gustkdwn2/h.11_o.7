 --review_comment(후기DB (댓)) - 상품테이블DB의 ITEM_ID를 FOREIGN KEY로 설정
create table Review_Comment(
	r_com_num NUMBER(10) NOT NULL PRIMARY KEY,--리뷰 댓글 번호
	review_num NUMBER(10) NOT NULL,--REFERENCE KEY 리뷰 번호
	admin_id VARCHAR2(50) NOT NULL,--REFERENCE KEY 유저 아이디
	r_com_date DATE default SYSDATE NOT NULL,--리뷰 댓글 작성 날짜
	r_com_contents VARCHAR2(100) NOT NULL--리뷰 댓글 내용
	--CONSTRAINT fk_review_comment FOREIGN KEY(user_id) REFERENCE User_Account(user_id),
	--CONSTRAINT fk_review_comment FOREIGN KEY(review_num) REFERENCE Review(review_num)
);
ALTER TABLE Review_Comment
ADD CONSTRAINT fk_review_comment FOREIGN KEY (review_num)
REFERENCES Review (review_num) ON DELETE CASCADE

ALTER TABLE Review_Comment
ADD CONSTRAINT fk_review_comment_adminId FOREIGN KEY(admin_id)
REFERENCES Admin(admin_id) ON DELETE CASCADE

drop table Review_Comment
select * from Review_Comment;
