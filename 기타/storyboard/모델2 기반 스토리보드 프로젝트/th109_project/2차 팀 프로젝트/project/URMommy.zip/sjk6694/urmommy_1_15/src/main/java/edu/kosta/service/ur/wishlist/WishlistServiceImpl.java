package edu.kosta.service.ur.wishlist;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import edu.kosta.model.dto.ur.wishlist.WishlistDAO;
import edu.kosta.model.dto.ur.wishlist.WishlistDTO;

@Component
public class WishlistServiceImpl implements WishlistService {

	@Autowired
	private SqlSession sqlsession; //SqlSessionTemplate
	
	/* 위시리스트 등록 */
	@Override
	public int Wishlist_insert(WishlistDTO dto) {
		WishlistDAO wishlistdao = sqlsession.getMapper(WishlistDAO.class);
		return wishlistdao.Wishlist_insert(dto);
	}
	/* 위시리스트 리스트 뽑기 */
	@Override
	public List<WishlistDTO> Wishlist_list(HashMap<String,Object> map) {
		WishlistDAO wishlistdao = sqlsession.getMapper(WishlistDAO.class);
		return wishlistdao.Wishlist_list(map);
	}
	/* 위시리스트에서 삭제할때 */
	@Override
	public int Wishlist_delete(WishlistDTO dto) {
		WishlistDAO wishlistdao = sqlsession.getMapper(WishlistDAO.class);
		return wishlistdao.Wishlist_delete(dto);
	}
	/* 아이템 디테일에서 위시리스트 삭제를 할때 */
	@Override
	public int wishlist_itemDetail_delete(HashMap<String,Object> map) {
		WishlistDAO wishlistdao = sqlsession.getMapper(WishlistDAO.class);
		return wishlistdao.wishlist_itemDetail_delete(map);
	}
	
	/* 위시리스트 로그인한 유저가 등록한 위시리스트 전체 수를 가져온다. */
	@Override
	public int wishlist_getCount(String user_id) {
		WishlistDAO wishlistdao = sqlsession.getMapper(WishlistDAO.class);
		return wishlistdao.wishlist_getCount(user_id);
	}
	/* 위시리스트 페이징해서 가져온다. */
	@Override
	public List<WishlistDTO> Wishlist_list_page(HashMap<String,Object> map) {
		WishlistDAO wishlistdao = sqlsession.getMapper(WishlistDAO.class);
		return wishlistdao.Wishlist_list_page(map);
	}
	
	
}
