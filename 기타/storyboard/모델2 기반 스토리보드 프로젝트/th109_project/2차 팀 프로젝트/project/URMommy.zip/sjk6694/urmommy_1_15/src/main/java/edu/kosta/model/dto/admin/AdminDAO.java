package edu.kosta.model.dto.admin;

import java.util.ArrayList;

public interface AdminDAO {
	//관리자 회원가입
	public void insertAdminJoin(AdminDTO adminDTO);
	
	//관리자 아이디 중복체크
	public AdminDTO adminConfirmId(AdminDTO adminDTO);	

	//관리자 리스트
	public ArrayList<AdminDTO> adminAllSelect();
	
	//관리자 삭제
	public void adminDelete(String admin_id);

}
