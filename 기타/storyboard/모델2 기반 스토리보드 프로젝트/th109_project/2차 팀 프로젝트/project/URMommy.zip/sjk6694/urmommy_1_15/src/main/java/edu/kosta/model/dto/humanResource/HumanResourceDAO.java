package edu.kosta.model.dto.humanResource;

import java.util.ArrayList;

import org.apache.ibatis.annotations.Param;

public interface HumanResourceDAO {
	
	//관리자 리스트
	public ArrayList<HumanResourceDTO> adminList();

	//하위 관리자 정보 수정
	public void lowAdminUpdate(HumanResourceDTO hrDTO);
	
	//관리자 리스트에 추가하기
	public void insertHRList(HumanResourceDTO hrDTO);

	//관리자 한명 선택해서 정보 출력
	public HumanResourceDTO adminSelect(String admin_id);
	
	//관리자 월급 수정
	public void adminPayModify(@Param("admin_id") String admin_id,@Param("admin_pay") int admin_pay);
	
	//관리자 삭제
	public void hrAdminDelete(String admin_id);

	public ArrayList<HumanResourceDTO> adminPaymentList();
}
