package edu.kosta.model.dto.ur.item;

import java.io.Serializable;

/*
 * 상품관련 변수선언
 */
public class ItemDTO implements Serializable {

   private static final long serialVersionUID = 1L;
   
   private String item_num;         // 아이템 번호(g0001t,g0002t...)
   private String item_name;          // 아이템 이름
   private String item_gender;       // 아이템에 대한 성별구분(boy, girl)
   private String item_type;          // 아이템 타입(out, top, bot, dre)
   private String item_type_detail;    // 아이템 상세타입 (top-tee,blou,knit)/(bot-pant,skir)
   private int unit_price;          // 단가
   private int sell_price;          // 판매가
   private String pic_url;          // 대표 이미지
   private String description;         // 대표 이미지 설명
   private String contents;         // 상품 상세설명(editor)
   private int item_amount;          // 상품 수량
   private String item_size;          // 상품 사이즈
   private int countNoStock;         // 상품 품절여부
   
   public String getItem_num() {
      return item_num;
   }
   public void setItem_num(String item_num) {
      this.item_num = item_num;
   }
   public String getItem_name() {
      return item_name;
   }
   public void setItem_name(String item_name) {
      this.item_name = item_name;
   }
   public String getItem_gender() {
      return item_gender;
   }
   public void setItem_gender(String item_gender) {
      this.item_gender = item_gender;
   }
   public String getItem_type() {
      return item_type;
   }
   public void setItem_type(String item_type) {
      this.item_type = item_type;
   }
   public String getItem_type_detail() {
      return item_type_detail;
   }
   public void setItem_type_detail(String item_type_detail) {
      this.item_type_detail = item_type_detail;
   }
   public int getUnit_price() {
      return unit_price;
   }
   public void setUnit_price(int unit_price) {
      this.unit_price = unit_price;
   }
   public int getSell_price() {
      return sell_price;
   }
   public void setSell_price(int sell_price) {
      this.sell_price = sell_price;
   }
   public String getPic_url() {
      return pic_url;
   }
   public void setPic_url(String pic_url) {
      this.pic_url = pic_url;
   }
   public String getDescription() {
      return description;
   }
   public void setDescription(String description) {
      this.description = description;
   }
   public String getContents() {
      return contents;
   }
   public void setContents(String contents) {
      this.contents = contents;
   }
   public int getItem_amount() {
      return item_amount;
   }
   public void setItem_amount(int item_amount) {
      this.item_amount = item_amount;
   }
   public String getItem_size() {
      return item_size;
   }
   public void setItem_size(String item_size) {
      this.item_size = item_size;
   }
   public int getCountNoStock() {
      return countNoStock;
   }
   public void setCountNoStock(int countNoStock) {
      this.countNoStock = countNoStock;
   }
   
   @Override
   public String toString() {
      return "ItemDTO [item_num=" + item_num + ", item_name=" + item_name + ", item_gender=" + item_gender
            + ", item_type=" + item_type + ", item_type_detail=" + item_type_detail + ", unit_price=" + unit_price
            + ", sell_price=" + sell_price + ", pic_url=" + pic_url + ", description=" + description + ", contents="
            + contents + ", item_amount=" + item_amount + ", item_size=" + item_size + ", countNoStock="
            + countNoStock + "]";
   }
}