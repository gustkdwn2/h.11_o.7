package edu.kosta.service.humanResource;

import java.util.ArrayList;

import edu.kosta.model.dto.humanResource.HumanResourceDTO;
import edu.kosta.model.dto.ur.orders.OrdersDTO;

public interface HumanResourceService {
	
	public ArrayList<HumanResourceDTO> adminList();

	public void lowAdminUpdate(HumanResourceDTO hrDTO);

	public void insertHRList(HumanResourceDTO hrDTO);
	

	HumanResourceDTO adminSelect(String admin_id);	//아이디에 따른 관리자 정보

	public void adminPayModify(String admin_id, int admin_pay);
	
	public void hrAdminDelete(String admin_id);	//관리자 삭제

	public ArrayList<HumanResourceDTO> adminPaymentList();

	public void changeOrderState(OrdersDTO ordersDTO);	//배송상태 변경


}
