package edu.kosta.model.dto.ur.bankbook;

public class BankBookDTO {
   private String day;
   private String outcome_title;
   private int outcome;
   private String income_title;
   private int income;
   private int remain_price;
   
	public String getBankdate() {
		return day;
	}
	public void setBankdate(String bankdate) {
		this.day = bankdate;
	}
	public String getOutcome_title() {
		return outcome_title;
	}
	public void setOutcome_title(String outcome_title) {
		this.outcome_title = outcome_title;
	}
	public int getOutcome() {
		return outcome;
	}
	public void setOutcome(int outcome) {
		this.outcome = outcome;
	}
	public String getIncome_title() {
		return income_title;
	}
	public void setIncome_title(String income_title) {
		this.income_title = income_title;
	}
	public int getIncome() {
		return income;
	}
	public void setIncome(int income) {
		this.income = income;
	}
	public int getRemain_price() {
		return remain_price;
	}
	public void setRemain_price(int remain_price) {
		this.remain_price = remain_price;
	}
	@Override
	public String toString() {
		return "BankBookDTO [day=" + day + ", outcome_title=" + outcome_title + ", outcome=" + outcome
				+ ", income_title=" + income_title + ", income=" + income + ", remain_price=" + remain_price + "]";
	}
	   
 
   
}