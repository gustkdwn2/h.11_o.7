package edu.kosta.service.user;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import edu.kosta.model.dto.admin.AdminDTO;
import edu.kosta.model.dto.user.UserDAO;
import edu.kosta.model.dto.user.UserDTO;


@Component
public class UserServiceImpl implements UserService {
	@Autowired
	private SqlSession sqlsession; // SqlSessionTemplate

	@Override
	public void insertJoin(UserDTO userDTO) {
		UserDAO userDAO = sqlsession.getMapper(UserDAO.class);
		userDAO.insertJoin(userDTO);
	}

	@Override
	public UserDTO getLoginCheck(UserDTO userDTO) {
		UserDTO result = new UserDTO();
		UserDAO userDAO = sqlsession.getMapper(UserDAO.class);
		result = userDAO.getLoginCheck(userDTO);
		return result;
	}

	@Override
	public UserDTO confirmId(UserDTO userDTO) {	//아이디중복
		UserDTO result = new UserDTO();
		UserDAO userDAO = sqlsession.getMapper(UserDAO.class);
		result = userDAO.confirmId(userDTO);
		return result;
	}

	@Override
	public void userUpdate(UserDTO userDTO) {
		UserDAO userDAO = sqlsession.getMapper(UserDAO.class);
		userDAO.userUpdate(userDTO);
	}

	@Override
	public List<UserDTO> userAllSelect() {
		UserDAO userDAO = sqlsession.getMapper(UserDAO.class);
		return userDAO.userAllSelect();
	}

	/*@Override
	public void userDelete(UserDTO userDTO) {	//회원삭제
		UserDAO userDAO = sqlsession.getMapper(UserDAO.class);
		userDAO.userDelete(userDTO);
		
	}*/
	@Override
	public void userDelete(String user_id) {	//회원삭제
		UserDAO userDAO = sqlsession.getMapper(UserDAO.class);
		userDAO.userDelete(user_id);
		
	}

	@Override
	public AdminDTO getAdminLoginCheck(AdminDTO adminDTO) {
		UserDAO userDAO = sqlsession.getMapper(UserDAO.class);
		return userDAO.getAdminLoginCheck(adminDTO);
	}

	@Override
	public UserDTO userSelect(String user_id) {	//아이디에 따른 회원정보
		UserDAO userDAO = sqlsession.getMapper(UserDAO.class);
		return userDAO.userSelect(user_id);
	}

	@Override
	public int getNewOrderCount(String user_id) {
		UserDAO userDAO = sqlsession.getMapper(UserDAO.class);
		return userDAO.getNewOrderCount(user_id);
	}

	@Override
	public int getCancelOrderCount(String user_id) {
		UserDAO userDAO = sqlsession.getMapper(UserDAO.class);
		return userDAO.getCancelOrderCount(user_id);
	}

}
