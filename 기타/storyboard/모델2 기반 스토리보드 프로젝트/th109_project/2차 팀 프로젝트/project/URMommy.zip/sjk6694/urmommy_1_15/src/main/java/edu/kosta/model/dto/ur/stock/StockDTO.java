package edu.kosta.model.dto.ur.stock;

import java.util.Date;

/*
 * 재고관리 변수
 */
public class StockDTO {
	private String item_num; // 상품코드
	private String item_name; // 상품명
	private String item_gender; // 상품성별
	private String item_type; // 상품타입
	private String item_type_detail; // 상품상세타입
	private int unit_price; // 상품원가
	private int sell_price; // 상품판매가
	private String item_size; // 상품사이즈
	private int item_amount; // 상품수량
	private int ori_amount; // 상품 기존 수량
	private int in_amount; // 상품 입고 수량
	private int out_amount; // 상품 출고 수량
	private int last_amount; // 최종 수량
	private Date update_time; // 수정 날짜
	private String o_pic; // 상품 대표사진
	private int countNoStock; // 상품 품절여부
	private String in_item; // 상품 추가 여부
	private String day; // 통계 검색 날짜

	public String getItem_num() {
		return item_num;
	}

	public void setItem_num(String item_num) {
		this.item_num = item_num;
	}

	public String getItem_name() {
		return item_name;
	}

	public void setItem_name(String item_name) {
		this.item_name = item_name;
	}

	public String getItem_gender() {
		return item_gender;
	}

	public void setItem_gender(String item_gender) {
		this.item_gender = item_gender;
	}

	public String getItem_type() {
		return item_type;
	}

	public void setItem_type(String item_type) {
		this.item_type = item_type;
	}

	public String getItem_type_detail() {
		return item_type_detail;
	}

	public void setItem_type_detail(String item_type_detail) {
		this.item_type_detail = item_type_detail;
	}

	public int getUnit_price() {
		return unit_price;
	}

	public void setUnit_price(int unit_price) {
		this.unit_price = unit_price;
	}

	public int getSell_price() {
		return sell_price;
	}

	public void setSell_price(int sell_price) {
		this.sell_price = sell_price;
	}

	public String getItem_size() {
		return item_size;
	}

	public void setItem_size(String item_size) {
		this.item_size = item_size;
	}

	public int getItem_amount() {
		return item_amount;
	}

	public void setItem_amount(int item_amount) {
		this.item_amount = item_amount;
	}

	public int getOri_amount() {
		return ori_amount;
	}

	public void setOri_amount(int ori_amount) {
		this.ori_amount = ori_amount;
	}

	public int getIn_amount() {
		return in_amount;
	}

	public void setIn_amount(int in_amount) {
		this.in_amount = in_amount;
	}

	public int getOut_amount() {
		return out_amount;
	}

	public void setOut_amount(int out_amount) {
		this.out_amount = out_amount;
	}

	public int getLast_amount() {
		return last_amount;
	}

	public void setLast_amount(int last_amount) {
		this.last_amount = last_amount;
	}

	public Date getUpdate_time() {
		return update_time;
	}

	public void setUpdate_time(Date update_time) {
		this.update_time = update_time;
	}

	public int getCountNoStock() {
		return countNoStock;
	}

	public void setCountNoStock(int countNoStock) {
		this.countNoStock = countNoStock;
	}

	public String getIn_item() {
		return in_item;
	}

	public void setIn_item(String in_item) {
		this.in_item = in_item;
	}

	public String getDay() {
		return day;
	}

	public void setDay(String day) {
		this.day = day;
	}

	public String getO_pic() {
		return o_pic;
	}

	public void setO_pic(String o_pic) {
		this.o_pic = o_pic;
	}

	@Override
	public String toString() {
		return "StockDTO [item_num=" + item_num + ", item_name=" + item_name + ", item_gender=" + item_gender
				+ ", item_type=" + item_type + ", item_type_detail=" + item_type_detail + ", unit_price=" + unit_price
				+ ", sell_price=" + sell_price + ", item_size=" + item_size + ", item_amount=" + item_amount
				+ ", ori_amount=" + ori_amount + ", in_amount=" + in_amount + ", out_amount=" + out_amount
				+ ", last_amount=" + last_amount + ", update_time=" + update_time + ", o_pic=" + o_pic
				+ ", countNoStock=" + countNoStock + ", in_item=" + in_item + ", day=" + day + "]";
	}

	
}