package edu.kosta.service.ur.notice;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import edu.kosta.model.dto.ur.notice.NoticeDTO;

public interface NoticeService {
	public void insertNotice(Map<String,Object> map); //����
	public List<NoticeDTO> getNoticeList(HashMap<String,Object> map); //����Ʈ
	public NoticeDTO getNotice(int num); //�б�
	
	public int updateNotice(NoticeDTO dto); //����
	public void deleteNotice(int num); //����
	
	public void updateHit(int num); //��ȸ�� ����
	public int getNoticeCount(); //���Ǽ�
	public List<NoticeDTO> getNotice_rolling();
}
