package edu.kosta.model.dto.ur.trade;

import java.sql.Date;

public class TradeReplyDTO {
	private int trade_com_num;
	private String user_id;
	private String trade_com_title;
	private String trade_com_content;
	private Date trade_com_date;
	private int reply_num_fk;
	private String trade_com_phone;
	private String trade_com_pic;
	
	
	
	public String getTrade_com_title() {
		return trade_com_title;
	}
	public void setTrade_com_title(String trade_com_title) {
		this.trade_com_title = trade_com_title;
	}
	public String getTrade_com_pic() {
		return trade_com_pic;
	}
	public void setTrade_com_pic(String trade_com_pic) {
		this.trade_com_pic = trade_com_pic;
	}
	public String getTrade_com_phone() {
		return trade_com_phone;
	}
	public void setTrade_com_phone(String trade_com_phone) {
		this.trade_com_phone = trade_com_phone;
	}
	public String getuser_id() {
		return user_id;
	}
	public void setuser_id(String user_id) {
		this.user_id = user_id;
	}
	
	public int gettrade_com_num() {
		return trade_com_num;
	}
	public void settrade_com_num(int trade_com_num) {
		this.trade_com_num = trade_com_num;
	}
	public String gettrade_com_content() {
		return trade_com_content;
	}
	public void settrade_com_content(String trade_com_content) {
		this.trade_com_content = trade_com_content;
	}
	public Date gettrade_com_date() {
		return trade_com_date;
	}
	public void settrade_com_date(Date trade_com_date) {
		this.trade_com_date = trade_com_date;
	}
	public int getReply_num_fk() {
		return reply_num_fk;
	}
	public void setReply_num_fk(int reply_num_fk) {
		this.reply_num_fk = reply_num_fk;
	}
	
}
