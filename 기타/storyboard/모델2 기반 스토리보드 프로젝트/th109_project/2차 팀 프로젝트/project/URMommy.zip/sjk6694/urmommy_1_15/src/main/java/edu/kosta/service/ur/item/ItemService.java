package edu.kosta.service.ur.item;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import edu.kosta.model.dto.ur.item.ItemDTO;
import edu.kosta.model.dto.ur.stock.StockDTO;

public interface ItemService {
   public List<ItemDTO> getItemMainList(HashMap<String,Object> map);   
   public int getItemMainCount();   

   public List<ItemDTO> getItemBoyList(HashMap<String,Object> map);
   public int getItemBoyCount();   
   
   public List<ItemDTO> getItemGirlList(HashMap<String,Object> map);
   public int getItemGirlCount();   
   
   public ItemDTO getItemDetail(String item_num);   
   public List<StockDTO> getItemStockLeft(String item_num); 
   
   //----------전체----------
   public List<ItemDTO> getUrmomList(HashMap<String,Object> map, String it);
   public int getUrmomCount(String it);
   public List<ItemDTO> getItemTopDetailList(HashMap<String,Object> map, String itd);
   public int getItemTopDetailCount(String itd);
   public List<ItemDTO> getItemBotDetailList(HashMap<String,Object> map, String itd);
   public int getItemBotDetailCount(String itd);
   
   //----------남자----------
   public List<ItemDTO> getBoyList(HashMap<String,Object> map, String it);
   public int getBoyCount(String it);
   public List<ItemDTO> getItemBoyTopDetailList(HashMap<String,Object> map, String itd);
   public int getItemBoyTopDetailCount(String itd);
   
   //----------여자----------
   public List<ItemDTO> getGirlList(HashMap<String,Object> map, @Param("it") String it);
   public int getGirlCount(@Param("it") String it);
   public List<ItemDTO> getItemGirlTopDetailList(HashMap<String,Object> map, @Param("itd") String itd);
   public int getItemGirlTopDetailCount(@Param("itd") String itd);
   public List<ItemDTO> getItemGirlBotDetailList(HashMap<String,Object> map, @Param("itd") String itd);
   public int getItemGirlBotDetailCount(@Param("itd") String itd);
   
   public int itemValid(ItemDTO itemDTO);
   public void itemInsert(ItemDTO itemDTO);   
   public void itemUpdate(ItemDTO itemDTO);
   public void itemDelete(String item_num);
   public String getFileName(MultipartHttpServletRequest mul);

   
}