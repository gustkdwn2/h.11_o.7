package edu.kosta.service.ur.trade;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartHttpServletRequest;

import edu.kosta.model.dto.ur.trade.TradeDTO;
import edu.kosta.model.dto.ur.trade.TradeReplyDTO;

public interface TradeService {
	public void insertmom(HashMap<String,Object> map); 
	public List<TradeDTO> getList(HashMap<String,Object> map); 
	public List<TradeDTO> getDonateList(HashMap<String,Object> map);

	
	public void deleteMOM(int trade_num); 	
	public void updateHit(int num); 
	public int getMOMCount();
	public int getDonateCount();
	public void insertreply(Map<String,Object> Map);
	public ArrayList<TradeReplyDTO> replylist(int reply_num_fk);
	public List<TradeReplyDTO> replylist(HashMap<String,Object> map);
	public void deletereply(int num);

	public void readCountDown(int trade_num);

	public String Upload(MultipartHttpServletRequest mRequest);


	
	public TradeDTO updateform(int trade_num);
	public int updatemom(HashMap<String,Object> map); 
	
	
	public TradeReplyDTO updaterep(int trade_com_num);
	public int updatereply(HashMap<String,Object> map);
	
	
	public List<TradeReplyDTO> getreMOMList(HashMap<String,Object> map);
	public int getreMOMCount(int trade_num);
	public List<TradeDTO> gettitleList(HashMap<String,Object> map); 
	public List<TradeDTO> getidList(HashMap<String,Object> map); 
	public List<TradeDTO> getcategoryList(HashMap<String,Object> map); 
	
	
	
	public int getidListCount(HashMap<String,Object> map);
	public int getcategoryListCount(HashMap<String,Object> map);
	public int gettitleListCount(HashMap<String,Object> map);
	public void updateSuccess(int trade_num);
	public void updateDonate();
	

	
	
}
