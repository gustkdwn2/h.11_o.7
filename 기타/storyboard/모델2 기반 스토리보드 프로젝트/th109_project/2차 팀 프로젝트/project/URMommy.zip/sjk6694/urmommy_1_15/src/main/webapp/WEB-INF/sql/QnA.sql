select*from QnA

drop table QnA CASCADE CONSTRAINTS

CREATE TABLE QnA
  (
  q_num number(10) primary key, 
  user_id VARCHAR2(100), 
  q_contents VARCHAR2(100),
  q_pwd VARCHAR2(50), 
  q_date date,
  item_num varchar2(50) not null
  );
  ALTER TABLE QnA
ADD CONSTRAINT fk_QnA FOREIGN KEY (item_num)
REFERENCES stock (item_num) ON DELETE CASCADE

ALTER TABLE QnA
ADD CONSTRAINT fk_QnA_userId FOREIGN KEY (user_id)
REFERENCES User_Account (user_id) ON DELETE CASCADE
  
  create sequence QnA_seq;
  drop sequence QnA_seq;
