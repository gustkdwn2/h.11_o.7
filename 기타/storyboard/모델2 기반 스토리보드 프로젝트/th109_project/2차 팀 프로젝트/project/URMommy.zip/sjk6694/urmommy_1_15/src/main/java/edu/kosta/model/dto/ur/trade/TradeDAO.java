package edu.kosta.model.dto.ur.trade;

import java.util.HashMap;
import java.util.List;

public interface TradeDAO {
	public void insertmom(HashMap<String,Object> map); 
	public List<TradeDTO> getMOMList(HashMap<String,Object> map); 
	public List<TradeDTO> getDonateList(HashMap<String,Object> map);
	public TradeDTO getupdate(int trade_num); 
	public int updatemom(HashMap<String,Object> map); 
	public void deleteMOM(int num); 	
	public void updateHit(int trade_num); 
	public int getMOMCount();
	public int getDonateCount();
	public void readCountDown(int trade_num);
	public void updatedonate(int trade_num);
	
	public List<TradeReplyDTO> getreMOMList(HashMap<String,Object> map);
	public int getreMOMCount();

	public List<TradeDTO> gettitleList(HashMap<String,Object> map); 
	public List<TradeDTO> getidList(HashMap<String,Object> map); 
	public List<TradeDTO> getcategoryList(HashMap<String,Object> map);
	
	
	public int getidListCount(HashMap<String,Object> map);
	public int getcategoryListCount(HashMap<String,Object> map);
	public int gettitleListCount(HashMap<String,Object> map);
	
	
	public void updateSuccess(int trade_num);
	public void updateDonate();
	
	
}
