package edu.kosta.model.dto.ur.orders;

import java.util.Date;

/*
 * 구매내역 변수
 */
public class OrdersDTO {
   private String user_id;
   private String o_order_items;
   private int cart_num;
   //주문자,배송자 정보
   private int o_seq,o_num;
   private String o_name, o_phone, o_email, o_address, o_message;
   private Date o_time;
   //주문상품정보
   private String item_num,o_pic,o_item_name,o_size;
   private int o_amount,o_sell_price,o_total_price,
            o_totals_price,o_deli_price,o_last_price;
   private int countItems;
   private int o_state;

   public String getUser_id() {
      return user_id;
   }
   public void setUser_id(String user_id) {
      this.user_id = user_id;
   }
   public String getO_order_items() {
      return o_order_items;
   }
   public void setO_order_items(String o_order_items) {
      this.o_order_items = o_order_items;
   }
   public int getCart_num() {
      return cart_num;
   }
   public void setCart_num(int cart_num) {
      this.cart_num = cart_num;
   }
   public int getO_seq() {
      return o_seq;
   }
   public void setO_seq(int o_seq) {
      this.o_seq = o_seq;
   }
   public int getO_num() {
      return o_num;
   }
   public void setO_num(int o_num) {
      this.o_num = o_num;
   }
   public String getO_name() {
      return o_name;
   }
   public void setO_name(String o_name) {
      this.o_name = o_name;
   }
   public String getO_phone() {
      return o_phone;
   }
   public void setO_phone(String o_phone) {
      this.o_phone = o_phone;
   }
   public String getO_email() {
      return o_email;
   }
   public void setO_email(String o_email) {
      this.o_email = o_email;
   }
   public String getO_address() {
      return o_address;
   }
   public void setO_address(String o_address) {
      this.o_address = o_address;
   }
   public String getO_message() {
      return o_message;
   }
   public void setO_message(String o_message) {
      this.o_message = o_message;
   }
   public Date getO_time() {
      return o_time;
   }
   public void setO_time(Date o_time) {
      this.o_time = o_time;
   }
   public String getItem_num() {
      return item_num;
   }
   public void setItem_num(String item_num) {
      this.item_num = item_num;
   }
   public String getO_pic() {
      return o_pic;
   }
   public void setO_pic(String o_pic) {
      this.o_pic = o_pic;
   }
   public String getO_item_name() {
      return o_item_name;
   }
   public void setO_item_name(String o_item_name) {
      this.o_item_name = o_item_name;
   }
   public String getO_size() {
      return o_size;
   }
   public void setO_size(String o_size) {
      this.o_size = o_size;
   }
   public int getO_amount() {
      return o_amount;
   }
   public void setO_amount(int o_amount) {
      this.o_amount = o_amount;
   }
   public int getO_sell_price() {
      return o_sell_price;
   }
   public void setO_sell_price(int o_sell_price) {
      this.o_sell_price = o_sell_price;
   }
   public int getO_total_price() {
      return o_total_price;
   }
   public void setO_total_price(int o_total_price) {
      this.o_total_price = o_total_price;
   }
   public int getO_totals_price() {
      return o_totals_price;
   }
   public void setO_totals_price(int o_totals_price) {
      this.o_totals_price = o_totals_price;
   }
   public int getO_deli_price() {
      return o_deli_price;
   }
   public void setO_deli_price(int o_deli_price) {
      this.o_deli_price = o_deli_price;
   }
   public int getO_last_price() {
      return o_last_price;
   }
   public void setO_last_price(int o_last_price) {
      this.o_last_price = o_last_price;
   }
   public int getCountItems() {
      return countItems;
   }
   public void setCountItems(int countItems) {
      this.countItems = countItems;
   }
   
   public int getO_state() {
	return o_state;
	}
	public void setO_state(int o_state) {
		this.o_state = o_state;
	}
	
	@Override
	public String toString() {
		return "OrdersDTO [user_id=" + user_id + ", o_order_items=" + o_order_items + ", cart_num=" + cart_num
				+ ", o_seq=" + o_seq + ", o_num=" + o_num + ", o_name=" + o_name + ", o_phone=" + o_phone + ", o_email="
				+ o_email + ", o_address=" + o_address + ", o_message=" + o_message + ", o_time=" + o_time
				+ ", item_num=" + item_num + ", o_pic=" + o_pic + ", o_item_name=" + o_item_name + ", o_size=" + o_size
				+ ", o_amount=" + o_amount + ", o_sell_price=" + o_sell_price + ", o_total_price=" + o_total_price
				+ ", o_totals_price=" + o_totals_price + ", o_deli_price=" + o_deli_price + ", o_last_price="
				+ o_last_price + ", countItems=" + countItems + ", o_state=" + o_state + "]";
	}

}
