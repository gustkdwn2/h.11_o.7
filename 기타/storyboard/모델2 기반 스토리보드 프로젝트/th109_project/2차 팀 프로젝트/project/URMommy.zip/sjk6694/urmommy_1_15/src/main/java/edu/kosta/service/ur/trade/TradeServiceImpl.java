package edu.kosta.service.ur.trade;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import edu.kosta.model.dto.ur.trade.TradeDAO;
import edu.kosta.model.dto.ur.trade.TradeDTO;
import edu.kosta.model.dto.ur.trade.TradeReplyDAO;
import edu.kosta.model.dto.ur.trade.TradeReplyDTO;

@Service
public class TradeServiceImpl implements TradeService {
	@Autowired
	private SqlSession sqlsession;

	@Override
	public void insertmom(HashMap<String, Object> map) {
		TradeDAO NDAO = sqlsession.getMapper(TradeDAO.class);
		NDAO.insertmom(map);
	}

	@Override
	public List<TradeDTO> getList(HashMap<String, Object> map) {
		TradeDAO NDAO = sqlsession.getMapper(TradeDAO.class);
		return NDAO.getMOMList(map);
	}

	@Override
	public List<TradeDTO> getDonateList(HashMap<String, Object> map) {
		TradeDAO NDAO = sqlsession.getMapper(TradeDAO.class);
		return NDAO.getDonateList(map);
	}

	@Override
	public void deleteMOM(int num) {
		TradeDAO NDAO = sqlsession.getMapper(TradeDAO.class);
		NDAO.deleteMOM(num);
	}

	@Override
	public void updateHit(int trade_num) {
		TradeDAO NDAO = sqlsession.getMapper(TradeDAO.class);
		NDAO.updateHit(trade_num);
	}

	@Override
	public int getMOMCount() {
		TradeDAO NDAO = sqlsession.getMapper(TradeDAO.class);
		return NDAO.getMOMCount();
	}

	@Override
	public int getDonateCount() {
		TradeDAO NDAO = sqlsession.getMapper(TradeDAO.class);
		return NDAO.getDonateCount();
	}

	@Override
	public int getreMOMCount(int trade_num) {
		TradeReplyDAO NDAO = sqlsession.getMapper(TradeReplyDAO.class);
		return NDAO.getreMOMCount(trade_num);
	}

	@Override
	public void insertreply(Map<String, Object> rpm) {
		TradeReplyDAO MreDAO = sqlsession.getMapper(TradeReplyDAO.class);
		MreDAO.insertreply(rpm);
	}

	@Override
	public ArrayList<TradeReplyDTO> replylist(int num) {
		TradeReplyDAO NReplyDAO = sqlsession.getMapper(TradeReplyDAO.class);
		return NReplyDAO.replylist(num);
	}

	@Override
	public void readCountDown(int trade_num) {
		TradeDAO NDAO = sqlsession.getMapper(TradeDAO.class);
		NDAO.readCountDown(trade_num);
	}

	@Override
	public void deletereply(int trade_num) {
		TradeReplyDAO NReplyDAO = sqlsession.getMapper(TradeReplyDAO.class);
		NReplyDAO.deletereply(trade_num);
	}

	@Override
	public String Upload(MultipartHttpServletRequest mRequest) {
		boolean isSuccess = false;
		String saveFileName = "";
		String realPath = mRequest.getSession().getServletContext().getRealPath("resources/view");
		String uploadPath = realPath + "/";
		Iterator<String> iter = mRequest.getFileNames();

		while (iter.hasNext()) {

			String uploadFileName = iter.next();
			MultipartFile mFile = mRequest.getFile(uploadFileName);
			String originalFileName = mFile.getOriginalFilename();
			saveFileName = originalFileName;

			if (saveFileName != null && !saveFileName.equals("")) { // file
																	// exists
				if (new File(uploadPath + saveFileName).exists()) {
					saveFileName = saveFileName + "_" + System.currentTimeMillis();
				} // inner if end
				try {
					mFile.transferTo(new File(uploadPath + saveFileName));
					isSuccess = true;
				} catch (Exception e) {
					e.printStackTrace();
					isSuccess = false;
				} // try catch end
			} // if end
		} // while end
		return saveFileName;
	}

	@Override
	public TradeDTO updateform(int trade_num) {
		TradeDAO NDAO = sqlsession.getMapper(TradeDAO.class);
		return NDAO.getupdate(trade_num);
	}

	@Override
	public TradeReplyDTO updaterep(int trade_com_num) {
		TradeReplyDAO NDAO = sqlsession.getMapper(TradeReplyDAO.class);
		return NDAO.updaterep(trade_com_num);
	}

	@Override
	public int updatemom(HashMap<String, Object> map) {
		TradeDAO NDAO = sqlsession.getMapper(TradeDAO.class);
		return NDAO.updatemom(map);
	}

	@Override
	public int updatereply(HashMap<String, Object> map) {
		TradeReplyDAO NDAO = sqlsession.getMapper(TradeReplyDAO.class);
		return NDAO.updatereply(map);
	}

	@Override
	public List<TradeReplyDTO> getreMOMList(HashMap<String, Object> map) {
		TradeReplyDAO NDAO = sqlsession.getMapper(TradeReplyDAO.class);

		return NDAO.getreMOMList(map);
	}

	@Override
	public List<TradeReplyDTO> replylist(HashMap<String, Object> map) {
		TradeReplyDAO NDAO = sqlsession.getMapper(TradeReplyDAO.class);
		return NDAO.replylist1(map);
	}

	@Override
	public List<TradeDTO> gettitleList(HashMap<String, Object> map) {
		TradeDAO NDAO = sqlsession.getMapper(TradeDAO.class);
		return NDAO.gettitleList(map);
	}

	@Override
	public List<TradeDTO> getidList(HashMap<String, Object> map) {
		TradeDAO NDAO = sqlsession.getMapper(TradeDAO.class);
		return NDAO.getidList(map);
	}

	@Override
	public List<TradeDTO> getcategoryList(HashMap<String, Object> map) {
		TradeDAO NDAO = sqlsession.getMapper(TradeDAO.class);
		return NDAO.getcategoryList(map);
	}

	@Override
	public int getidListCount(HashMap<String, Object> map) {
		TradeDAO NDAO = sqlsession.getMapper(TradeDAO.class);
		return NDAO.getidListCount(map);
	}

	@Override
	public int getcategoryListCount(HashMap<String, Object> map) {
		TradeDAO NDAO = sqlsession.getMapper(TradeDAO.class);
		return NDAO.getcategoryListCount(map);
	}

	@Override
	public int gettitleListCount(HashMap<String, Object> map) {
		TradeDAO NDAO = sqlsession.getMapper(TradeDAO.class);
		return NDAO.gettitleListCount(map);
	}

	@Override
	public void updateSuccess(int trade_num) {
		TradeDAO NDAO = sqlsession.getMapper(TradeDAO.class);
		NDAO.updateSuccess(trade_num);

	}

	@Override
	public void updateDonate() {
		TradeDAO NDAO = sqlsession.getMapper(TradeDAO.class);
		NDAO.updateDonate();

	}

}