package edu.kosta.service.humanResource;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import edu.kosta.model.dto.humanResource.HumanResourceDAO;
import edu.kosta.model.dto.humanResource.HumanResourceDTO;
import edu.kosta.model.dto.ur.bankbook.BankBookDAO;
import edu.kosta.model.dto.ur.orders.OrdersDAO;
import edu.kosta.model.dto.ur.orders.OrdersDTO;
import edu.kosta.model.dto.ur.stock.StockDAO;
import edu.kosta.model.dto.ur.stock.StockDTO;

@Component
public class HumanResourceServiceImpl implements HumanResourceService {

	@Autowired
	private SqlSession sqlsession; // SqlSessionTemplate

	@Override
	public ArrayList<HumanResourceDTO> adminList() {
		HumanResourceDAO hrDAO = sqlsession.getMapper(HumanResourceDAO.class);
		ArrayList<HumanResourceDTO> adminList = new ArrayList<HumanResourceDTO>();
		adminList = hrDAO.adminList();

		return adminList;
	}

	@Override
	public void lowAdminUpdate(HumanResourceDTO hrDTO) {
		HumanResourceDAO hrDAO = sqlsession.getMapper(HumanResourceDAO.class);
		hrDAO.lowAdminUpdate(hrDTO);
	}

	@Override
	public void insertHRList(HumanResourceDTO hrDTO) {
		HumanResourceDAO hrDAO = sqlsession.getMapper(HumanResourceDAO.class);
		hrDAO.insertHRList(hrDTO);
	}

	@Override
	public HumanResourceDTO adminSelect(String admin_id) {	//아이디에 따른 관리자 정보 
		HumanResourceDAO hrDAO = sqlsession.getMapper(HumanResourceDAO.class);
		return hrDAO.adminSelect(admin_id);
	}

	@Override
	public void adminPayModify(String admin_id, int admin_pay) {
		HumanResourceDAO hrDAO = sqlsession.getMapper(HumanResourceDAO.class);
		hrDAO.adminPayModify(admin_id, admin_pay);
	}

	@Override
	public void hrAdminDelete(String admin_id) {
		HumanResourceDAO hrDAO = sqlsession.getMapper(HumanResourceDAO.class);
		hrDAO.hrAdminDelete(admin_id);
	}

	@Override
	public ArrayList<HumanResourceDTO> adminPaymentList() {
		HumanResourceDAO hrDAO = sqlsession.getMapper(HumanResourceDAO.class);
		ArrayList<HumanResourceDTO> adminPaymentList = new ArrayList<HumanResourceDTO>();
		adminPaymentList = hrDAO.adminPaymentList();

		return adminPaymentList;
	}

	/*
	 * @see edu.kosta.service.humanResource.HumanResourceService#changeOrderState(edu.kosta.model.dto.ur.orders.OrdersDTO)
	 * 
	 * ordersDB에서 o_state(주문상태)를 1증가할 때 마다 주문 상황이 바뀐다.
	 * o_state : 0- 입금확인중/ 1- 상품준비중/ 2-배송중/ 3-배송완료/ 4-취소확인중/ 5-취소완료
	 * 
	 * o_state가 5인 취소가 완료된 시점에서는 stock DB(재고)에 감소됬던 재고가 다시 추가되고
	 * 입금으로 확인 된 재무부분도 출금<환불>으로 재처리 된다.
	 * 또한, orders DB(주문내역)에는 유지가 되지만
	 * ordersItem DB(주문상품내역)에서는 삭제가 된다.
	 */
	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = SQLException.class)
	public void changeOrderState(OrdersDTO ordersDTO) {
		OrdersDAO ordersDAO = sqlsession.getMapper(OrdersDAO.class);
		StockDAO stockDAO = sqlsession.getMapper(StockDAO.class);
		BankBookDAO bankbookDAO = sqlsession.getMapper(BankBookDAO.class);
		
		ordersDTO.setO_state(ordersDTO.getO_state() + 1);

		ordersDAO.updateO_state(ordersDTO);

		//취소 했다면, 
		if(ordersDTO.getO_state() == 5){
			String user_id = ordersDTO.getUser_id();
			int o_num = ordersDTO.getO_num();
			
			//stock DB에 재고 재추가
			List<OrdersDTO> getMultiOrders = ordersDAO.getOrderDetail(ordersDTO.getO_num());
			
			List<StockDTO> stockMultiSizeAmount = new ArrayList<StockDTO>();
			for(int i=0; i<getMultiOrders.size(); i++){
				String item_num = getMultiOrders.get(i).getItem_num();
				String o_size = getMultiOrders.get(i).getO_size();
				StockDTO stockSizeAmount = stockDAO.getStockSizeAmount(item_num,o_size);
				stockMultiSizeAmount.add(stockSizeAmount);
			}
			
			for(int j=0; j<stockMultiSizeAmount.size(); j++){
				int ori_amount = stockMultiSizeAmount.get(j).getItem_amount();
				int item_amount = ori_amount + getMultiOrders.get(j).getO_amount();
				
				HashMap<String, Object> returnStockMap = new HashMap<String, Object>();

				returnStockMap.put("item_num", getMultiOrders.get(j).getItem_num());
				returnStockMap.put("item_size", getMultiOrders.get(j).getO_size());
				returnStockMap.put("ori_amount", ori_amount);
				returnStockMap.put("in_amount", getMultiOrders.get(j).getO_amount());
				returnStockMap.put("item_amount", item_amount);
				
				stockDAO.returnCancelStock(returnStockMap);
			}
			
			//Bankbook DB 재무부분 환불처리
			OrdersDTO orderInfo = ordersDAO.getReceiver(ordersDTO.getO_num());
			
			HashMap<String, Object> map = new HashMap<String, Object>();
			map.put("outcome_title", "<환불>"+orderInfo.getO_order_items());
			map.put("outcome", orderInfo.getO_last_price());
			bankbookDAO.BankBook_outcome_insert(map);
			
			//ordersItem DB에서 주문한 상품내역 삭제
			int orderCount = ordersDAO.getOrderCount(user_id, o_num);
			for(int i=0; i<orderCount; i++){
				ordersDAO.cancelOrderItems(o_num);
			}
		}
	}
}
