$(document).ready($(function() {
   var save = [];
   $.ajax({ //위의 ajax가 실행되고 나면 이 ajax를 실행한다.
      type : "POST", //타입은 post
      url : "sell_bar_chart.do", //servlet jjim.jjim을 실행, 해당 페이지로 jjim리스트를 발송한다.
      data:{"day" : "${title }"},
     async: true,
      dataType : 'json',//데이터 타입은 html
      success : function(point) {//해당페이지로 jjim리스트가 발송되면
         for(var i=0;i<point.data.length;i++){
            var value = [point.data[i]];
            var item = point.item[i];
            var obj = [item,point.data[i]];
            save[i]=obj;
         }
         getShownTab(save);
      },
      error: function(e) {
         alert("error");
      }
   })//ajax
}))