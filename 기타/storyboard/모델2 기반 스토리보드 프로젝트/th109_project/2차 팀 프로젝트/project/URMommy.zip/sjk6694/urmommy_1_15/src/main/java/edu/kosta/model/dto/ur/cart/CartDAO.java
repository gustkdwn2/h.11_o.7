package edu.kosta.model.dto.ur.cart;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.annotations.Param;

public interface CartDAO {
   void getCartAdd(@Param("user_id") String user_id, @Param("unit_price") int up, @Param("sell_price") int sp,
         @Param("item_num") String iNum, @Param("item_name") String iName, @Param("pic_url") String pu,
         @Param("cart_size") String cart_size, @Param("cart_amount") int cart_amount, 
         @Param ("total_price") int total_price);

   int getCartListInumCount(@Param("user_id") String user_id, @Param("item_num") String item_num);
      
   void addQuantity(@Param("user_id") String user_id, @Param("cart_amount_add") int cart_amount_add, 
               @Param("total_price") int total_price, @Param("item_num") String item_num);
   
   List<CartDTO> getCartList(HashMap<String,Object> cartMap, @Param("user_id") String user_id);

   int getCartListCount(@Param("user_id") String user_id);
   void putLastTotals(@Param("user_id") String user_id, @Param("totals_price") int totals_p,
               @Param("deli_price") int deli_p, @Param("last_price") int last_p);
   
   CartDTO getLastTotals(String user_id);
   
   void cartAmountSub(@Param("cart_amount") int cart_amount,@Param("cart_num") int cart_num,
               @Param("total_price") int total_price,@Param("user_id") String user_id);
   void cartAmountAdd(@Param("cart_amount") int cart_amount,@Param("cart_num") int cart_num,
               @Param("total_price") int total_price,@Param("user_id") String user_id);

   int cartOneDelete(@Param("cart_num") int cart_num, @Param("user_id") String user_id);
   
   void deleteAllCart(@Param("user_id") String user_id);
   void deleteAllCartPrice(@Param("user_id") String user_id);

   CartDTO cartOneSelect(@Param("cart_num") int cart_num, @Param("user_id") String user_id);
   //List<CartDTO> cartAllSelect(String user_id);
}