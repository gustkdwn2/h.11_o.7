function review_update(){
	//alert("수정");
	location.href="review_update_form.do?review_num=${Review.review_num}&pg=${pg}";
}
function review_delete(){
	//alert("삭제");
	location.href="review_delete.do?review_num=${Review.review_num}&pg=${pg}&item_num=${Review.item_num}";
}
function board_reply(){
	//alert("답변");
	location.href="replyform.htm?num=${b.num}&pg=${pg}";
}