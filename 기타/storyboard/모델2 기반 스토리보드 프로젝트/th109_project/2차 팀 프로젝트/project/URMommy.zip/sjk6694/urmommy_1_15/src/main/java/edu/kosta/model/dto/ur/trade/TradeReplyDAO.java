package edu.kosta.model.dto.ur.trade;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public interface TradeReplyDAO {
	public void insertreply(Map<String,Object> rpm);
	public ArrayList<TradeReplyDTO> replylist(int reply_num_fk);
	public void deletereply(int num);
	
	public TradeReplyDTO updaterep(int trade_com_num);
	public int updatereply(HashMap<String,Object> map);
	public int getreMOMCount(int trade_num);
	
	public List<TradeReplyDTO> getreMOMList(HashMap<String,Object> map);
	public List<TradeReplyDTO> replylist1(HashMap<String,Object> map);
	
}
