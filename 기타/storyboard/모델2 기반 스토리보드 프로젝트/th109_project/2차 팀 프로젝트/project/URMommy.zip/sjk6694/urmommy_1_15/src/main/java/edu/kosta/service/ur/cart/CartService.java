package edu.kosta.service.ur.cart;

import java.util.HashMap;
import java.util.List;


import edu.kosta.model.dto.ur.cart.CartDTO;
import edu.kosta.model.dto.ur.item.ItemDTO;

public interface CartService {

   void getCartAdd(String user_id, ItemDTO item_cart, String cart_size, int cart_amount);
   int getTotalsPrice(String user_id);

   List<CartDTO> getCartList(HashMap<String,Object> cartMap, String user_id);
   int getCartListCount(String user_id);
   void putLastTotals(String user_id,int totals_p,int deli_p,int last_p);
   CartDTO getLastTotals(String user_id);
   
   void cartAmountSub(int cart_amount,int cart_num,int total_price,String user_id);
   void cartAmountAdd(int cart_amount,int cart_num,int total_price,String user_id);
   void cartOneDelete(int cart_num, String user_id);
   void deleteAllCart(String user_id);
   void deleteAllCartPrice(String user_id);

   CartDTO cartOneSelect(int cart_num, String user_id);
   List<CartDTO> cartAllSelect(String user_id);
}