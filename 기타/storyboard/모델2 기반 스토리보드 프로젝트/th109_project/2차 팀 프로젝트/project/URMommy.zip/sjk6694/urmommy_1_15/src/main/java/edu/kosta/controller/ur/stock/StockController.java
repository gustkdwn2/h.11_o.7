package edu.kosta.controller.ur.stock;

import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import edu.kosta.model.dto.ur.stock.StockDAO;
import edu.kosta.model.dto.ur.stock.StockDTO;
import edu.kosta.service.ur.bankbook.BankBookService;
import edu.kosta.service.ur.item.ItemService;
import edu.kosta.service.ur.stock.StockService;

/* 
 * @author (EELHEA CHO)
 * 이 컨트롤러는 재고관리에서 실행되는 모든 메소드를 담고 있다.
 * */
@Controller
public class StockController {
	@Resource
	private StockService stockService;
	@Resource
	private ItemService itemService;
	@Resource
	private BankBookService bankbookservice;

	/*
	 * 이 메소드를 재고관리 폼과 재고 목록을 출력해준다.
	 * 10개의 ROW로 구성되어있는 paging으로 목록이 출력된다.
	 * 시작 페이지와 끝 페이지를 hashMap에 담아서 재고 리스트 출력하는 xml로 보내준다.
	 * 재고가 없는 사이즈가 있으면 재고목록의 비고란에 재고가 없는 사이즈 수가 출력된다.
	 * 
	 * @see stock/itemStockList.jsp
	 */
	@RequestMapping(value="/itemStock.do", method=RequestMethod.GET)
	public String stockList(HttpServletRequest request){
		
		int pg=1;
		String strPg = request.getParameter("pg"); 
			if(strPg!=null){
				pg = Integer.parseInt(strPg);			
			}
		//행 개수
		int rowSize = 10;
		int start = (pg*rowSize)-(rowSize -1);
		int end = pg*rowSize;
		//총 게시물수
		int total = itemService.getItemMainCount();
		//페이지수 = 총 게시물수/행 개수
		int allPage = (int) Math.ceil(total/(double)rowSize); 
		//한페이지에 보여줄  범위
		int block = 10; 
		//보여줄 페이지의 시작
		int fromPage = ((pg-1)/block*block)+1;
		//보여줄 페이지의 끝
		int toPage = ((pg-1)/block*block)+block;
			if(toPage> allPage){ 
				toPage = allPage;
			}//end if
		
		HashMap<String,Object> map = new HashMap<String,Object>();
		map.put("start", start);
		map.put("end", end);
		
		List<StockDTO> stockList = stockService.getStockList(map);
		for(int i=0; i<stockList.size(); i++){
			
			int count = stockService.countNoStock(stockList.get(i).getItem_num());//재고수가 0인 사이즈 개수
			
			//상품 사이즈 개수
			int stockSizeCount = stockService.stockSizeCount(stockList.get(i).getItem_num());
			if(stockSizeCount != 5){
				count += (5 - stockSizeCount);
			}
			
			stockList.get(i).setCountNoStock(count);
			
			int stockInItem = stockService.stockInItem(stockList.get(i).getItem_num());
			
			if(stockInItem == 1){
				stockList.get(i).setIn_item("Y");
			}
		}//end for
		
		request.setAttribute("stockList", stockList);
		request.setAttribute("pg",pg);
		request.setAttribute("allPage",allPage);
		request.setAttribute("block",block);
		request.setAttribute("fromPage",fromPage);
		request.setAttribute("toPage",toPage);	
		
		return "stock/itemStockList";
	}
	
	/*
	 * 재고목록을 카테고리별로 검색했을 때 실행되는 메소드이다.
	 * 카테고리는 '상품성별','상품타입','상품상세타입'이 있다.
	 * 각 카테고리에 해당되는 검색어를 만났을 때 개수를 세고, 그 개수에 따라서 paging이 된다.
	 */
	@RequestMapping(value="/searchStock.do", method=RequestMethod.POST)
	public String searchStock(HttpServletRequest request, String searchValue, String searchBox){

		int pg=1;
		String strPg = request.getParameter("pg"); 
		if(strPg!=null){
			pg = Integer.parseInt(strPg);			
		}
		int rowSize = 13;
		int start = (pg*rowSize)-(rowSize -1);
		int end = pg*rowSize;
		int total = 0;
		
		if(searchValue.equals("item_gender")){
			if(searchBox.equals("boy")||searchBox.equals("BOY")){
				total = stockService.getItemBoyCount();
			}
			if(searchBox.equals("girl")||searchBox.equals("GIRL")){
				total = stockService.getItemGirlCount();
			}
		}//end outer if
		if(searchValue.equals("item_type")){
			if(searchBox.equals("out")||searchBox.equals("OUT")){
				total = stockService.getUrmomCount("item_type");
			}
			if(searchBox.equals("top")||searchBox.equals("TOP")){
				total = stockService.getUrmomCount("item_type");
			}
			if(searchBox.equals("bot")||searchBox.equals("BOT")){
				total = stockService.getUrmomCount("item_type");
			}
			if(searchBox.equals("dre")||searchBox.equals("DRE")){
				total = stockService.getUrmomCount("item_type");
			}
		}//end outer if
		if(searchValue.equals("item_type_detail")){
			if(searchBox.equals("tee")||searchBox.equals("TEE")){
				total = stockService.getItemDetailCount("item_type_detail");
			}
			if(searchBox.equals("blou")||searchBox.equals("BLOU")){
				total = stockService.getItemDetailCount("item_type_detail");
			}
			if(searchBox.equals("knit")||searchBox.equals("KNIT")){
				total = stockService.getItemDetailCount("item_type_detail");
			}
			if(searchBox.equals("pant")||searchBox.equals("PANT")){
				total = stockService.getItemDetailCount("item_type_detail");
			}
			if(searchBox.equals("skir")||searchBox.equals("SKIR")){
				total = stockService.getItemDetailCount("item_type_detail");
			}
		}//end outer if
		if(searchBox.equals("")){
			return "redirect:/itemStock.do";
		}//end if
		
		int allPage = (int) Math.ceil(total/(double)rowSize);
		
		int block = 10; 
		int fromPage = ((pg-1)/block*block)+1; 
		int toPage = ((pg-1)/block*block)+block;
		if(toPage> allPage){ 
			toPage = allPage;
		}
		
		HashMap<String,Object> map = new HashMap<String,Object>();
		map.put("start", start);
		map.put("end", end);
		
		List<StockDAO> searchStock = stockService.getSearchStockList(map, searchValue, searchBox);
		request.setAttribute("stockList", searchStock);
		request.setAttribute("pg",pg);
		request.setAttribute("allPage",allPage);
		request.setAttribute("block",block);
		request.setAttribute("fromPage",fromPage);
		request.setAttribute("toPage",toPage);	
		request.setAttribute("searchValue", searchValue);
		request.setAttribute("searchBox", searchBox);
		
		return "stock/itemStockList";
	}
	
	/*
	 * 재고를 등록하는 폼을 출력하는 메소드이다.
	 * 폼 출력하기 전, 재고목록 출력하는 메소드를 호출해준다.
	 * @see stock/stockInsertForm.jsp 
	 */
	@RequestMapping(value="stockInsertForm.do", method = RequestMethod.GET)
	public String stockInsertForm(Model model, HttpServletRequest request){
		stockList(request);
		model.addAttribute("stockDTO", new StockDTO());
		return "stock/itemStockList";
	}
	/*
	 * 재고를 등록하는 메소드이다.
	 */
	@RequestMapping(value="stockInsert.do", method = RequestMethod.POST)
	public String stockInsert(StockDTO stockDTO){
		stockService.stockInsert(stockDTO);
		return "redirect:/stockInsertForm.do";
	}
	/*
	 * 재고 정보를 수정하는 메소드이다.
	 * 수정하는 폼은 등록하는 폼과 동일하다.
	 */
	@RequestMapping(value="stockUpdate.do", method = RequestMethod.POST)
	public String stockUpdate(StockDTO stockDTO) throws Exception{
		stockService.stockUpdate(stockDTO);
		return "redirect:/itemStock.do";
	}
	/*
	 * 재고를 삭제하는 메소드이다.
	 */
	@RequestMapping(value="stockDelete.do", method = RequestMethod.POST)
	public String stockDelete(StockDTO stockDTO){
		stockService.stockDelete(stockDTO);
		return "redirect:/itemStock.do";
	}
	
	/*
	 * @Param searchValue	검색 카테고리
	 * @Param searchBox 	검색어	
	 * @see stock/itemStockIn.jsp
	 * 
	 * 재고 리스트에서 재고를 클릭하면 현재 재고 수 테이블과, 재고의 사이즈와 개수를 추가 할 수 있는 테이블이 함께 나온다.
	 * 검색카테고리와 검색어를 받아오는 이유는 검색 된 재고를 클릭했을 때, 
	 * 목록에서 다시 검색했던 목록을 보여주기 위함이다.
	 */
	@RequestMapping(value="itemStockShow.do", method=RequestMethod.POST)
	public String itemStockShow(StockDTO stockDTO,HttpServletRequest request) throws Exception{
		
		String searchValue = request.getParameter("searchValue");
		String searchBox = request.getParameter("searchBox");
		
		if(!searchBox.equals("")){
			searchStock(request, searchValue, searchBox);
		} else if (searchBox.equals("")){
			stockList(request);
		}//end if
		
		List<StockDTO> stockShow = stockService.getStockShow(stockDTO.getItem_num());

		request.setAttribute("stockShow", stockShow);
		request.setAttribute("stockDTO", stockDTO);
		request.setAttribute("searchValue", searchValue);
		request.setAttribute("searchBox", searchBox);
		
		return "stock/itemStockList";
	}
	
	/*
	 * 각 재고에 존재하는 사이즈에 재고수를 추가하는 메소드이다.
	 * @Param ori_amount	원래있던 재고수
	 * @Param in_amount		추가하는 재고수
	 * 
	 * 원래 있던 재고수에 추가하는 재고수를 더해줘서 item_amount를 update한다.
	 * bankbook_outcome 메소드를 호출해서 재무관리에 출금처리를 한다.
	 * itemStockShow 메소드를 호출해서 리스트 출력해주고 수정된 재고수를 보여준다.
	 */
	@RequestMapping(value="stockAdd.do", method=RequestMethod.POST)
	public String stockAdd(StockDTO stockDTO,HttpServletRequest request) throws Exception{
		
		int item_amount = Integer.parseInt(request.getParameter("ori_amount")) + Integer.parseInt(request.getParameter("in_amount"));
		
		HashMap<String,Object> stockAddMap = new HashMap<String,Object>();
		stockAddMap.put("item_num", stockDTO.getItem_num());
		stockAddMap.put("item_size", stockDTO.getItem_size());
		stockAddMap.put("ori_amount", stockDTO.getOri_amount());
		stockAddMap.put("in_amount", stockDTO.getIn_amount());
		stockAddMap.put("item_amout", item_amount);
		
		stockService.stockAdd(stockAddMap);
		
		bankbook_outcome(stockDTO,stockDTO.getIn_amount());
		itemStockShow(stockDTO,request);
		
		return "stock/itemStockList";
	}
	
	/*
	 * 재고의 사이즈와 개수를 추가해주는 메소드이다.
	 * @Param item_size		추가하는 사이즈
	 * @Param item_amount	추가하는 수량
	 * @see itemStockIn.jsp
	 * 
	 * 행추가로 여러개의 사이즈와 수량을 한번에 받아와서 String배열에 저장한다.
	 * 추가하는 수량배열을 Int배열로 변경해서 item_amountInt배열에 저장해준다.
	 * 현재 item_num에 해당하는 존재하는 사이즈를 가지고 온다.
	 * for문을 이용해서 존재하는 사이즈의 수만큼 검색한다.
	 * 만약 존재하는 사이즈를 추가했다면 alert창이 뜨고 추가가 되지 않는다.
	 * 그렇지 않으면, '상품코드','추가사이즈','원래 재고수량','추가 수량'을 hashMap에 담아서 추가를 실행한다.
	 * itemStockShow 메소드를 호출해서 리스트 출력해주고 수정된 재고정보를 보여준다.
	 * 
	 */
	@RequestMapping(value="stockAddSize.do", method=RequestMethod.POST)
	public String stockAddSize(StockDTO stockDTO, HttpServletRequest request,HttpServletResponse response) throws Exception{
		String[] item_size = request.getParameterValues("item_size");	
		String[] item_amount = request.getParameterValues("item_amount");
		
		int[] item_amountInt = new int[item_amount.length];
		for(int i=0; i < item_amount.length; i++){
			item_amountInt[i] = Integer.parseInt(item_amount[i]);
		}
		
		List<StockDTO> existSize = stockService.getExistSize(stockDTO.getItem_num());
		
		for(int j=0; j < item_size.length; j++){			
			for(int k=0; k<existSize.size(); k++){			
				String size = existSize.get(k).getItem_size();
				
				if(size.equals(item_size[j])){				
					response.setCharacterEncoding("EUC-KR");
					PrintWriter writer = response.getWriter();
					writer.println("<script type='text/javascript'>");
					writer.println("alert('이미 존재하는 사이즈를 추가하셨습니다.');");
					writer.println("history.back();");
					writer.println("</script>");
					writer.flush();
					return null;
				}//end if
			}//end inner for

			HashMap<String,Object> stockSizeAddMap = new HashMap<String, Object>();
			stockSizeAddMap.put("item_size", item_size[j]);	
			stockSizeAddMap.put("item_amount", item_amountInt[j]);	
			stockSizeAddMap.put("in_amount", item_amountInt[j]);
			stockSizeAddMap.put("item_num", stockDTO.getItem_num());		
			stockService.stockAddSize(stockSizeAddMap);
			
			bankbook_outcome(stockDTO,item_amountInt[j]);
		}//end outer for

		itemStockShow(stockDTO,request);
		
		return "stock/itemStockList";
	}
		
	/*
	 * 재고관리의 입고, 출고통계에서 사용하는 paging 메소드이다.
	 */
	public ModelAndView paging(ModelAndView mav, HashMap<String,Object> map, int total, HttpServletRequest request){
		int pg=1;
		String strPg = request.getParameter("pg"); 
			if(strPg!=null){
				pg = Integer.parseInt(strPg);			
			}
		int rowSize = 7;
		int start = (pg*rowSize)-(rowSize -1);
		int end = pg*rowSize;
		
		int allPage = (int) Math.ceil(total/(double)rowSize);
		
		int block = 10;
		int fromPage = ((pg-1)/block*block)+1;
		int toPage = ((pg-1)/block*block)+block;
			if(toPage> allPage){ 
				toPage = allPage;
			}
		
		map.put("start", start);
		map.put("end", end);
		
		mav.addObject("pg",pg);
		mav.addObject("allPage",allPage);
		mav.addObject("block",block);
		mav.addObject("fromPage",fromPage);
		mav.addObject("toPage",toPage);	
		
		return mav;
	}
	/*
	 * 오늘의 입고 통계량을 보여주는 메소드이다.
	 * 입고량 개수를 센 후, 페이징 처리를 해주고
	 * 리스트를 출력해준다.
	 */
	@RequestMapping(value = "inStats.do", method = RequestMethod.GET)
	public ModelAndView getStock_day_list(Locale locale, HttpServletRequest request) {
		ModelAndView mav = new ModelAndView();
		HashMap<String,Object> map = new HashMap<String,Object>();
		int total = stockService.inListCount();
		
		paging(mav, map, total,request); 

		List<StockDTO> inStatsList = stockService.inList(map);
		mav.addObject("day",inStatsList.get(0).getDay());
		mav.addObject("inStatsList", inStatsList);
		mav.addObject("title", "오늘 입고량");
		mav.setViewName("stock/inStats");
		
		return mav;
	}
	/*
	 * 아래의 세개 메소드는 재고관리-입고통계에서 오늘의 입고통계량을 보여줄때 차트를 출력한다.
	 * 차트는 파이차트로 출력이 된다.
	 * (1) 성별별 오늘 입고량 (boy/girl)
	 * (2) 재고타입별 오늘 입고량 (outer, top, bottom, dress/set)
	 * (3) 재고상세타입별 오늘 입고량 (out/top-tee,blouse,knit/bottom-pant,skirt/dress)
	 */
	@RequestMapping(value = "GenderChart.do", method = RequestMethod.GET)
	public ModelAndView genderChart(){
		ModelAndView mav = new ModelAndView();
		
		List<StockDTO> genderChart = stockService.inGenderChart();
		mav.addObject("inGenderChart", genderChart);
		mav.setViewName("stock/inGenderChart");
		return mav;
	}
	@RequestMapping(value = "TypeChart.do", method = RequestMethod.GET)
	public ModelAndView typeChart(){
		ModelAndView mav = new ModelAndView();
		
		List<StockDTO> typeChart = stockService.inTypeChart();
		mav.addObject("inTypeChart", typeChart);
		mav.setViewName("stock/inTypeChart");
		return mav;
	}
	@RequestMapping(value = "DetailChart.do", method = RequestMethod.GET)
	public ModelAndView detailChart(){
		ModelAndView mav = new ModelAndView();
		
		List<StockDTO> detailChart = stockService.inDetailChart();
		mav.addObject("inDetailChart", detailChart);
		mav.setViewName("stock/inDetailChart");
		return mav;
	}
	/*
	 * 입고통계에서 달력을 사용하며 일별, 월별, 년별 "검색"을 하였을 때 목록출력 메소드이다.
	 * 검색된 결과 별로 목록이 출력되고 페이징처리 된다.
	 * @Param date		String형태의 검색결과 (형식 : 2015-11-16)
	 * @Param calendar	체크박스에서 선택한 카테고리 (일별,월별,년별)
	 * 체크박스로 일별을 선택하였다면 date의 형태를 2015-11-16으로 받아와서 day에 저장,
	 * 월별을 선택하였다면 date형태를 substring으로 0번째에서 7번째의 수까지 2015-11으로 받아와서 day에 저장,
	 * 년별을 선택하였다면 date형태를 substring으로 0번째에서 4번째의 수까지 2015로 받아와서 day에 저장한다.
	 * 각 카테고리의 if문에서 개수를 검색해서 페이징처리를 한 후, 리스트로 출력한다.
	 */
	@RequestMapping(value= "StockCalendar.do", method = RequestMethod.GET)
	public ModelAndView In_calendar(Locale locale, HttpServletRequest request){
		ModelAndView mav = new ModelAndView();
		HashMap<String,Object> map = new HashMap<String,Object>();
		String temp = request.getParameter("date");			
		String day=null;
		if(request.getParameter("calendar").equals("day")){	
			day = temp;								
			mav.addObject("title", "[ "+day+" ] 입고량");	
		}else if(request.getParameter("calendar").equals("month")){	
			day = temp.substring(0, 7);	
			mav.addObject("title", "[ "+day+" ] 월 입고량");
		}else if(request.getParameter("calendar").equals("year")){	
			day = temp.substring(0, 4);
			mav.addObject("title", "[ " + day+" ] 년 입고량");
		}//end if
		int total = stockService.searchInListCount(day);
		paging(mav, map, total,request);	
		map.put("day", day);				
		List<StockDTO> inStatsList = stockService.searchInList(map);
		mav.addObject("inStatsList", inStatsList);
		mav.addObject("calendar",request.getParameter("calendar"));
		mav.addObject("date", temp);
		mav.setViewName("stock/inSearchStats");
		return mav;
	}
	
	/*
	 * 아래의 세개 메소드는 재고관리-입고통계에서 검색 결과에 따라(일별,월별,년별) 차트를 출력한다.
	 * 차트는 파이차트로 출력이 된다.
	 * 세부적으로는 세개의 차트가 출력이 되는데, 분류는 아래와 같다.
	 * (1) 성별별 입고량 (boy/girl)
	 * (2) 재고타입별 입고량 (outer, top, bottom, dress/set)
	 * (3) 재고상세타입별 입고량 (out/top-tee,blouse,knit/bottom-pant,skirt/dress)
	 */
	@RequestMapping(value="inGenderChart.do", method = RequestMethod.GET)
	public ModelAndView inGenderChart(Locale locale, HttpServletRequest request){
		ModelAndView mav = new ModelAndView();
		
		String temp = request.getParameter("date");	
		String day = null;
		if(request.getParameter("calendar").equals("day")){	
			day = temp;							
		}else if(request.getParameter("calendar").equals("month")){
			day = temp.substring(0, 7);
		}else if(request.getParameter("calendar").equals("year")){ 
			day = temp.substring(0, 4);
		}
		List<StockDTO> inGenderChart = stockService.searchInGenderChart(day);
		mav.addObject("inGenderChart", inGenderChart);
		mav.setViewName("stock/inGenderChart");
		return mav;
	}
	@RequestMapping(value="inTypeChart.do", method = RequestMethod.GET)
	public ModelAndView inTypeChart(Locale locale, HttpServletRequest request){
		ModelAndView mav = new ModelAndView();
		
		String temp = request.getParameter("date");
		String day=null;
		if(request.getParameter("calendar").equals("day")){
			day = temp;
		}else if(request.getParameter("calendar").equals("month")){
			day = temp.substring(0, 7);
		}else if(request.getParameter("calendar").equals("year")){
			day = temp.substring(0, 4);
		}
		List<StockDTO> inTypeChart = stockService.searchInTypeChart(day);
		mav.addObject("inTypeChart", inTypeChart);
		mav.setViewName("stock/inTypeChart");
		return mav;
	}
	@RequestMapping(value="inDetailChart.do", method = RequestMethod.GET)
	public ModelAndView inDetailChart(Locale locale, HttpServletRequest request){
		ModelAndView mav = new ModelAndView();
		
		String temp = request.getParameter("date");
		String day=null;
		if(request.getParameter("calendar").equals("day")){
			day = temp;
		}else if(request.getParameter("calendar").equals("month")){
			day = temp.substring(0, 7);
		}else if(request.getParameter("calendar").equals("year")){
			day = temp.substring(0, 4);
		}
		List<StockDTO> inDetailChart = stockService.searchInDetailChart(day);
		mav.addObject("inDetailChart", inDetailChart);
		mav.setViewName("stock/inDetailChart");
		return mav;
	}
	
	////////////////////////////////////////재고관리-출고통계////////////////////////////////////////////////
	/*
	 * 오늘의 출고 통계량을 보여주는 메소드이다.
	 * 출고량 개수를 센 후, 페이징 처리를 해주고
	 * 리스트를 출력해준다.
	 */
	@RequestMapping(value = "outStats.do", method = RequestMethod.GET)
	public ModelAndView getOutStock_day_list(Locale locale, HttpServletRequest request) {
		
		ModelAndView mav = new ModelAndView();
		HashMap<String,Object> map = new HashMap<String,Object>();
		int total = stockService.outListCount();
		
		paging(mav, map, total,request); 
		
		List<StockDTO> outStatsList = stockService.outList(map);
		
		mav.addObject("day",outStatsList.get(0).getDay());
		mav.addObject("outStatsList", outStatsList);
		mav.addObject("title", "오늘 출고량");
		mav.setViewName("stock/outStats");
		
		return mav;
	}
	
	/*
	 * 아래의 세개 메소드는 재고관리-출고통계에서 오늘의 출고통계량을 보여줄때 차트를 출력한다.
	 * 차트는 파이차트로 출력이 된다.
	 * (1) 성별별 오늘 출고량 (boy/girl)
	 * (2) 재고타입별 오늘 출고량 (outer, top, bottom, dress/set)
	 * (3) 재고상세타입별 오늘 출고량 (out/top-tee,blouse,knit/bottom-pant,skirt/dress)
	 */
	@RequestMapping(value = "outNowGenderChart.do", method = RequestMethod.GET)
	public ModelAndView outNowgenderChart() {
		ModelAndView mav = new ModelAndView();

		List<StockDTO> genderChart = stockService.outGenderChart();

		mav.addObject("outGenderChart", genderChart);
		mav.setViewName("stock/outGenderChart");

		return mav;
	}
	@RequestMapping(value = "outNowTypeChart.do", method = RequestMethod.GET)
	public ModelAndView outNowtypeChart() {
		ModelAndView mav = new ModelAndView();

		List<StockDTO> typeChart = stockService.outTypeChart();

		mav.addObject("outTypeChart", typeChart);
		mav.setViewName("stock/outTypeChart");

		return mav;
	}
	@RequestMapping(value = "outNowDetailChart.do", method = RequestMethod.GET)
	public ModelAndView outNowdetailChart() {
		ModelAndView mav = new ModelAndView();

		List<StockDTO> detailChart = stockService.outDetailChart();

		mav.addObject("outDetailChart", detailChart);
		mav.setViewName("stock/outDetailChart");

		return mav;
	}
	
	/*
	 * 출고통계에서 달력을 사용하며 일별, 월별, 년별 "검색"을 하였을 때 목록출력 메소드이다.
	 * 검색된 결과 별로 목록이 출력되고 페이징처리 된다.
	 * @Param date		String형태의 검색결과 (형식 : 2015-11-16)
	 * @Param calendar	체크박스에서 선택한 카테고리 (일별,월별,년별)
	 * 체크박스로 일별을 선택하였다면 date의 형태를 2015-11-16으로 받아와서 day에 저장,
	 * 월별을 선택하였다면 date형태를 substring으로 0번째에서 7번째의 수까지 2015-11으로 받아와서 day에 저장,
	 * 년별을 선택하였다면 date형태를 substring으로 0번째에서 4번째의 수까지 2015로 받아와서 day에 저장한다.
	 * 각 카테고리의 if문에서 개수를 검색해서 페이징처리를 한 후, 리스트로 출력한다.
	 */
	@RequestMapping(value= "StockOutCalendar.do", method = RequestMethod.GET)
	public ModelAndView Out_calendar(Locale locale, HttpServletRequest request){
		ModelAndView mav = new ModelAndView();
		HashMap<String,Object> map = new HashMap<String,Object>();
		String temp = request.getParameter("date");
		String day=null;
		if(request.getParameter("calendar").equals("day")){
			day = temp;
			mav.addObject("title", day+"일 출고량");
		}else if(request.getParameter("calendar").equals("month")){
			day = temp.substring(0, 7);
			mav.addObject("title", day+"월 출고량");
		}else if(request.getParameter("calendar").equals("year")){
			day = temp.substring(0, 4);
			mav.addObject("title", day+"년 출고량");
		}//end if
		int total = stockService.searchOutListCount(day);
		paging(mav, map, total,request);
		map.put("day", day);
		List<StockDTO> outStatsList = stockService.searchOutList(map);
		mav.addObject("outStatsList", outStatsList);
		mav.addObject("calendar",request.getParameter("calendar"));
		mav.addObject("date", temp);
		mav.setViewName("stock/outSearchStats");
		return mav;
	}
	
	/*
	 * 아래의 세개 메소드는 재고관리-출고통계에서 검색 결과에 따라(일별,월별,년별) 차트를 출력한다.
	 * 차트는 파이차트로 출력이 된다.
	 * 세부적으로는 세개의 차트가 출력이 되는데, 분류는 아래와 같다.
	 * (1) 성별별 출고량 (boy/girl)
	 * (2) 재고타입별 출고량 (outer, top, bottom, dress/set)
	 * (3) 재고상세타입별 출고량 (out/top-tee,blouse,knit/bottom-pant,skirt/dress)
	 */
	@RequestMapping(value = "outGenderChart.do", method = RequestMethod.GET)
	public ModelAndView outGenderChart(Locale locale, HttpServletRequest request) {
		ModelAndView mav = new ModelAndView();

		String temp = request.getParameter("date");
		String day=null;
		if (request.getParameter("calendar").equals("day")) {
			day = temp;
		} else if (request.getParameter("calendar").equals("month")) {
			day = temp.substring(0, 7);
		} else if (request.getParameter("calendar").equals("year")) {
			day = temp.substring(0, 4);
		}
		List<StockDTO> searchOutGenderChart = stockService.searchOutGenderChart(day);
		mav.addObject("outGenderChart", searchOutGenderChart);
		mav.setViewName("stock/outGenderChart");
		return mav;
	}
	@RequestMapping(value = "outTypeChart.do", method = RequestMethod.GET)
	public ModelAndView outTypeChart(Locale locale, HttpServletRequest request) {
		ModelAndView mav = new ModelAndView();

		String temp = request.getParameter("date");
		String day=null;
		if (request.getParameter("calendar").equals("day")) {
			day = temp;
		} else if (request.getParameter("calendar").equals("month")) {
			day = temp.substring(0, 7);
		} else if (request.getParameter("calendar").equals("year")) {
			day = temp.substring(0, 4);
		}
		List<StockDTO> searchOutTypeChart = stockService.searchOutTypeChart(day);
		mav.addObject("outTypeChart", searchOutTypeChart);
		mav.setViewName("stock/outTypeChart");
		return mav;
	}
	@RequestMapping(value = "outDetailChart.do", method = RequestMethod.GET)
	public ModelAndView outDetailChart(Locale locale, HttpServletRequest request) {
		ModelAndView mav = new ModelAndView();

		String temp = request.getParameter("date");
		String day=null;
		if (request.getParameter("calendar").equals("day")) {
			day = temp;
		} else if (request.getParameter("calendar").equals("month")) {
			day = temp.substring(0, 7);
		} else if (request.getParameter("calendar").equals("year")) {
			day = temp.substring(0, 4);
		}
		List<StockDTO> searchOutDetailChart = stockService.searchOutDetailChart(day);
		mav.addObject("outDetailChart", searchOutDetailChart);
		mav.setViewName("stock/outDetailChart");
		return mav;
	}

	/* 
	 * stock에서 재고가 추가됨에 따라 자본금에 금액만큼 빼주는 메소드이다. 
	 * bankbook에 추가된 재고의 상품명과 추가된 개수와 단가를 곱해서 
	 * bankbook의 상품명은 outcome_title, 합계 금액은 outcome에 저장한다.
	 * 
	 * 재고가 추가되는 방법이 2가지이다. 
	 * 한번에 여러개의 재고를 추고하는 것(stockAddSize.do로 매핑)과 
	 * 단일 재고를 추가하는 것(stockAdd.do로 매핑)이 있다.
	 */
	public void bankbook_outcome(StockDTO dto, int amount) {
		if (dto.getIn_amount() == 0) {
			HashMap<String,Object> map = new HashMap<String,Object>();
			map.put("outcome_title", dto.getItem_name());
			map.put("outcome", dto.getUnit_price() * amount);
			bankbookservice.BankBook_outcome_insert(map);
		} else {
			HashMap<String,Object> map = new HashMap<String,Object>();
			map.put("outcome_title", dto.getItem_name());
			map.put("outcome", dto.getUnit_price() * amount);
			bankbookservice.BankBook_outcome_insert(map);
		}//end if
	}

}
