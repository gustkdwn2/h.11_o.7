SELECT * FROM NOTICE 

create table Notice(
   notice_num NUMBER(10) NOT NULL PRIMARY KEY,
   admin_id VARCHAR2(50) NOT NULL,
   write_date DATE default SYSDATE NOT NULL,
   notice_hit NUMBER(10) NOT NULL,
   notice_title VARCHAR2(100) NOT NULL,
   notice_contents VARCHAR2(500) NOT NULL

   );   
 create sequence notice_seq start with 1 increment by 1;  
 
 ALTER TABLE NOTICE MODIFY notice_contents VARCHAR2(3000)
 
ALTER TABLE NOTICE 
ADD CONSTRAINT fk_notice FOREIGN KEY(admin_id) REFERENCES Admin(admin_id)


DROP TABLE NOTICE CASCADE CONSTRAINTS