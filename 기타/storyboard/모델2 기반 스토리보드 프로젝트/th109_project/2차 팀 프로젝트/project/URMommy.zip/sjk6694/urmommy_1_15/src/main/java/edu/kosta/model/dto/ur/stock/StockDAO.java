package edu.kosta.model.dto.ur.stock;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.annotations.Param;

public interface StockDAO {
   public List<StockDTO> getStockList(HashMap<String,Object> map);
   public List<StockDAO> getSearchStockList(@Param("start") int start, @Param("end") int end,
         @Param("searchValue") String searchValue, @Param("searchBox") String searchBox);
   
   public void stockInsert(StockDTO stockDTO);
   public void stockUpdate(StockDTO stockDTO);
   public void itemDelete(StockDTO stockDTO);
   public void cartDelete(StockDTO stockDTO);
   public void orderItemDelete(StockDTO stockDTO);
   public void stockInfoDelete(StockDTO stockDTO);
   public void stockDelete(StockDTO stockDTO);
   public int getItemBoyCount();
   public int getItemGirlCount();
   public int getUrmomCount(@Param("it") String it);
   public int getItemDetailCount(@Param("itd") String itd);
   
   public List<StockDTO> getStockShow(@Param("item_num") String item_num);
   public StockDAO getStockDetail(String item_num);
   public void stockAdd(HashMap<String,Object> stockAddMap);
   public List<StockDTO> getExistSize(String item_num);
   public void itemInfoAddSize(HashMap<String,Object> stockSizeAddMap);
   public void stockAddSize(HashMap<String, Object> stockSizeAddMap);
   public int countNoStock(String item_num);
   public int stockSizeCount(String item_num);
   public int stockInItem(String item_num); 
   
   //입고통계
   public List<StockDTO> inList(HashMap<String,Object> map);
   public int inListCount();
   
   public List<StockDTO> searchInList(HashMap<String,Object> map);
   public int searchInListCount(@Param("day") String day);

   //출고통계
   public List<StockDTO> outList(HashMap<String,Object> map);
   public int outListCount();
   
   public List<StockDTO> searchOutList(HashMap<String,Object> map);
   public int searchOutListCount(@Param("day") String day);

   //입고차트
   public List<StockDTO> inGenderChart();
   public List<StockDTO> searchInGenderChart(@Param("day") String day);

   public List<StockDTO> inTypeChart();
   public List<StockDTO> searchInTypeChart(@Param("day") String day);

   public List<StockDTO> inDetailChart();
   public List<StockDTO> searchInDetailChart(@Param("day") String day);
   
   //출고차트
   public List<StockDTO> outGenderChart();
   public List<StockDTO> searchOutGenderChart(@Param("day") String day);

   public List<StockDTO> outTypeChart();
   public List<StockDTO> searchOutTypeChart(@Param("day") String day);

   public List<StockDTO> outDetailChart();
   public List<StockDTO> searchOutDetailChart(@Param("day") String day);
    
   //베스트
   public List<StockDTO> getBestItem(HashMap<String,Object> map);
   
   StockDTO getStockSizeAmount(@Param("item_num") String item_num, @Param("item_size") String item_size);
   void delStockAmount(HashMap<String, Object> delStockMap);
   //취소한 재고 돌려놓기
   public void returnCancelStock(HashMap<String, Object> delStockMap);


}