package edu.kosta.service.ur.bankbook;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import edu.kosta.model.dto.ur.bankbook.BankBookDAO;
import edu.kosta.model.dto.ur.bankbook.BankBookDTO;

@Component
public class BankBookServiceImpl implements BankBookService {
   
   @Autowired
   private SqlSession sqlsession;

   /* 입출금 금액 관리 */
   /* 오늘 입출고 리스트 */
   @Override
   public List<BankBookDTO> getBankBookList(HashMap<String,Object> map) {
      BankBookDAO bankbookDAO = sqlsession.getMapper(BankBookDAO.class);
      return bankbookDAO.getBankBookList(map);
   }
   /* 선택 날짜 입출고 리스트 */
   @Override
   public List<BankBookDTO> getBankBook_Day_Search(HashMap<String,Object> map) {
      BankBookDAO bankbookDAO = sqlsession.getMapper(BankBookDAO.class);
      return bankbookDAO.getBankBook_Day_Search(map);
   }
   /* 월별 입출고 리스트 */
   @Override
   public List<BankBookDTO> getBankBook_Month_Search(HashMap<String,Object> map) {
      BankBookDAO bankbookDAO = sqlsession.getMapper(BankBookDAO.class);
      return bankbookDAO.getBankBook_Month_Search(map);
   }
   /* 년별 입출고 리스트 */
   @Override
   public List<BankBookDTO> getBankBook_Year_Search(HashMap<String,Object> map) {
      BankBookDAO bankbookDAO = sqlsession.getMapper(BankBookDAO.class);
      return bankbookDAO.getBankBook_Year_Search(map);
   }
   
   
   /* 지출 입력 */
   @Override
   public void BankBook_outcome_insert(HashMap<String,Object> map) {
      BankBookDAO bankbookDAO = sqlsession.getMapper(BankBookDAO.class);
      bankbookDAO.BankBook_outcome_insert(map);
   }
   /* 입금 입력 */
/*   @Override
   public void BankBook_income_insert(HashMap<String,Object> map) {
      BankBookDAO bankbookDAO = sqlsession.getMapper(BankBookDAO.class);
      bankbookDAO.BankBook_income_insert(map);
   }*/


   /* 오늘 입출고 수 */
   @Override
   public int getBank_book_Count() {
      BankBookDAO bankbookDAO = sqlsession.getMapper(BankBookDAO.class);
      return bankbookDAO.getBank_book_Count();
   }
   /* 선택 날짜 입출고 수 */
   @Override
   public int getBank_book_day_count(String day) {
      BankBookDAO bankbookDAO = sqlsession.getMapper(BankBookDAO.class);
      return bankbookDAO.getBank_book_day_count(day);
   }
   /* 입출고 월별 수*/
   @Override
   public int getBank_book_month_count(String day) {
      BankBookDAO bankbookDAO = sqlsession.getMapper(BankBookDAO.class);
      return bankbookDAO.getBank_book_month_count(day);
   }
   /* 입출고 년별 수 */
   @Override
   public int getBank_book_year_count(String day) {
      BankBookDAO bankbookDAO = sqlsession.getMapper(BankBookDAO.class);
      return bankbookDAO.getBank_book_year_count(day);
   }
   
   /* 입출고 자본금의 모든 리스트(LineChart에서 사용) */
	@Override
	public List<BankBookDTO> getBankBook_total_list() {
		 BankBookDAO bankbookDAO = sqlsession.getMapper(BankBookDAO.class);
	      return bankbookDAO.getBankBook_total_list();
	}
   
   
   
}