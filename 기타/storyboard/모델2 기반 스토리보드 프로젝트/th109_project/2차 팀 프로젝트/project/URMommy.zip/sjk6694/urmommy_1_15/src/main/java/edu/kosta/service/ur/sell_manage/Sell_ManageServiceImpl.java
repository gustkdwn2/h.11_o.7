package edu.kosta.service.ur.sell_manage;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import edu.kosta.model.dto.ur.sell_manage.Sell_ManageDAO;
import edu.kosta.model.dto.ur.sell_manage.Sell_ManageDTO;

@Component
public class Sell_ManageServiceImpl implements Sell_ManageService {

	@Autowired
	private SqlSession sqlsession;
	//상품 출금 금액 관리
	//오늘 날짜 출금 리스트 출력
	@Override
	public List<Sell_ManageDTO> getSell_manage_day_list() {
		Sell_ManageDAO sell_managedao = sqlsession.getMapper(Sell_ManageDAO.class);
		return sell_managedao.getSell_manage_day_list();
	}
	//월별 출금 리스트 출력
	@Override
	public List<Sell_ManageDTO> getSell_manage_month_list(String day) {
		Sell_ManageDAO sell_managedao = sqlsession.getMapper(Sell_ManageDAO.class);
		return sell_managedao.getSell_manage_month_list(day);
	}
	//년별 출금 리스트 출력
	@Override
	public List<Sell_ManageDTO> getSell_manage_year_list(String day) {
		Sell_ManageDAO sell_managedao = sqlsession.getMapper(Sell_ManageDAO.class);
		return sell_managedao.getSell_manage_year_list(day);
	}
	//선택 날짜 출금 리스트 출력
	@Override
	public List<Sell_ManageDTO> getSell_manage_day_search(String day) {
		Sell_ManageDAO sell_managedao = sqlsession.getMapper(Sell_ManageDAO.class);
		return sell_managedao.getSell_manage_day_search(day);
	}
	//오늘 날짜 택배비 지출 출력
	@Override
	public int getSell_deliver_today_count() {
		Sell_ManageDAO sell_managedao = sqlsession.getMapper(Sell_ManageDAO.class);
		return sell_managedao.getSell_deliver_today_count();
	}
	//선택 날짜 택배비 지출 출력
	@Override
	public int getSell_deliver_daySearch_count(String day) {
		Sell_ManageDAO sell_managedao = sqlsession.getMapper(Sell_ManageDAO.class);
		return sell_managedao.getSell_deliver_daySearch_count(day);
	}
	//월별 택배비 지출 출력
	@Override
	public int getSell_deliver_month_count(String day) {
		Sell_ManageDAO sell_managedao = sqlsession.getMapper(Sell_ManageDAO.class);
		return sell_managedao.getSell_deliver_month_count(day);
	}
	//년별 택배비 지출 출력
	@Override
	public int getSell_deliver_year_count(String day) {
		Sell_ManageDAO sell_managedao = sqlsession.getMapper(Sell_ManageDAO.class);
		return sell_managedao.getSell_deliver_year_count(day);
	}
	
	/*/////////////////////////////////////////////////////////// */
	
	/* 상품별 출금 오늘 날짜 리스트 출력 */
	@Override
	public List<Sell_ManageDTO> getBarChart_sell_day_list() {
		Sell_ManageDAO sell_managedao = sqlsession.getMapper(Sell_ManageDAO.class);
		return sell_managedao.getBarChart_sell_day_list();
	}
	/* 상품별 출금 선택 날짜 리스트 출력 */
	@Override
	public List<Sell_ManageDTO> getBarChart_sell_day_search(String day) {
		Sell_ManageDAO sell_managedao = sqlsession.getMapper(Sell_ManageDAO.class);
		return sell_managedao.getBarChart_sell_day_search(day);
	}
	/* 상품별 출금 월별 날짜 리스트 출력 */
	@Override
	public List<Sell_ManageDTO> getBarChart_sell_month_list(String day) {
		Sell_ManageDAO sell_managedao = sqlsession.getMapper(Sell_ManageDAO.class);
		return sell_managedao.getBarChart_sell_month_list(day);
	}
	/* 상품별 출금 년별 날짜 리스트 출력 */
	@Override
	public List<Sell_ManageDTO> getBarChart_sell_year_list(String day) {
		Sell_ManageDAO sell_managedao = sqlsession.getMapper(Sell_ManageDAO.class);
		return sell_managedao.getBarChart_sell_year_list(day);
	}
	
	
}
