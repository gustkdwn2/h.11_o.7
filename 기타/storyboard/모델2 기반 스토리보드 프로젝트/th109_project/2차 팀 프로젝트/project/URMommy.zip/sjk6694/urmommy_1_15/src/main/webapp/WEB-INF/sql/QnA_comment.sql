 CREATE TABLE QnA_comment
  (
  q_com_num number(10) primary key,
  admin_id VARCHAR2(100),
  q_num number(10),
  q_com_date date,
  q_com_contents VARCHAR2(100)
  );
ALTER TABLE QnA_comment
ADD CONSTRAINT fk_QnA_comment FOREIGN KEY (q_num)
REFERENCES QnA (q_num) ON DELETE CASCADE

ALTER TABLE QnA_comment
ADD CONSTRAINT fk_QnA_comment_userId FOREIGN KEY (admin_id)
REFERENCES Admin (admin_id) ON DELETE CASCADE

  create sequence QnA_com_seq;
  drop sequence QnA_com_seq;
 
  select*from QnA_comment
  drop table QnA_comment