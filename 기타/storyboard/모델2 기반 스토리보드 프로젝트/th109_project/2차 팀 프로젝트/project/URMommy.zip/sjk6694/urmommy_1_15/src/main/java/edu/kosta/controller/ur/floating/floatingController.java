package edu.kosta.controller.ur.floating;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import edu.kosta.model.dto.ur.wishlist.WishlistDTO;
import edu.kosta.model.dto.user.UserDTO;
import edu.kosta.service.ur.wishlist.WishlistService;

/* 
 * @author (Seung Mo)
 * 
 * 이 컨트롤러는 각각의 페이지에서 사이드 바에 관심목록(wishlist)을 출력해 주는 컨트롤러 이다.
 * */

@Controller
public class floatingController {
	
	@Resource
	WishlistService wishlistService;
	
	@RequestMapping(value = "/floating_list.do", method = RequestMethod.POST)
	
	/* 이 메소드는 로그인한 회원이 등록한 관심상품 목록을 paging처리후 보내준다.
	 * 관심상품 목록을 화면의 사이(오른쪽)에 붙어서 스크롤의 움익임에 따라 같이 움직이면서 리스트 보여준다.
	 * @see floating.jsp
	 * */
	
	public String floating_list(Locale locale, Model model, WishlistDTO dto,HttpSession session, HttpServletRequest request) {
		/* 로그인한 유저의 아이디를 세션으로 부터 받아온다. 
		 * @Param admin_id					로그인 아이디
		 * */
		UserDTO loginUser = (UserDTO)session.getAttribute("loginUser");
		/* 
		 * floating은 유저가 회원 가입이 안되어 있으면 리스트를 화면에 보여주지 않는다.
		 *  */
		if(loginUser != null){
			/*  페이징 부분   */
			int float_pg=1;
			String float_strPg = request.getParameter("float_pg"); 
			if(float_strPg!=null){
				float_pg = Integer.parseInt(float_strPg);			
			}
			int float_rowSize = 3;
			int float_start = (float_pg*float_rowSize)-(float_rowSize -1);
			int float_end = float_pg*float_rowSize;
			
			int float_total = wishlistService.wishlist_getCount(loginUser.getUser_id());

			int float_allPage = (int) Math.ceil(float_total/(double)float_rowSize);
			
			int float_block = 3; 
			int float_fromPage = ((float_pg-1)/float_block*float_block)+1; 
			
			int float_toPage = ((float_pg-1)/float_block*float_block)+float_block; 
			if(float_toPage> float_allPage){
				float_toPage = float_allPage;
			}
			
			HashMap<String,Object> floating_map = new HashMap<String,Object>();
			floating_map.put("start", float_start);
			floating_map.put("end", float_end);
			floating_map.put("user_id", loginUser.getUser_id());
			
			List<WishlistDTO> floating_list = wishlistService.Wishlist_list_page(floating_map);
			
			request.setAttribute("float_pg",float_pg);
			request.setAttribute("float_allPage",float_allPage);
			request.setAttribute("float_block",float_block);
			request.setAttribute("float_fromPage",float_fromPage);
			request.setAttribute("float_toPage",float_toPage);
			
			request.setAttribute("floating", floating_list);
		}
		return "floating/floating";
	}
}
