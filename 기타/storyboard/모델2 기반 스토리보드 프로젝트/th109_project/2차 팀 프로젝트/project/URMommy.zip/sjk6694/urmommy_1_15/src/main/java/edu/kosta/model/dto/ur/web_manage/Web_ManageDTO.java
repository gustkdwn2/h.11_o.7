package edu.kosta.model.dto.ur.web_manage;

import java.util.Date;

public class Web_ManageDTO {
	private String mainlogo;
	private Date updateTime;
	
	public String getMainlogo() {
		return mainlogo;
	}
	public void setMainlogo(String mainlogo) {
		this.mainlogo = mainlogo;
	}
	public Date getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	
	@Override
	public String toString() {
		return "Web_ManageDTO [mainlogo=" + mainlogo + ", updateTime=" + updateTime + "]";
	}
}
