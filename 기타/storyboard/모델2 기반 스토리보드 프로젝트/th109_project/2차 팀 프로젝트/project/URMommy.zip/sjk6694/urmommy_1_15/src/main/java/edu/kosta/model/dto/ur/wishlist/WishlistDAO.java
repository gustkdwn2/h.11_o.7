package edu.kosta.model.dto.ur.wishlist;

import java.util.HashMap;
import java.util.List;

public interface WishlistDAO {
	public int Wishlist_insert(WishlistDTO dto);
	//위시리스트 등록
	
	public List<WishlistDTO> Wishlist_list(HashMap<String,Object> map);
	//위시리스트 리스트 뽑기
	
	public int Wishlist_delete(WishlistDTO dto);
	//위시리스트 삭제할떄
	
	public int wishlist_itemDetail_delete(HashMap<String,Object> map);
	// 아이템 디테일에서 위시리스트 삭제할때
	
	public int wishlist_getCount(String user_id);
	// 위시리스트 로그인한 유저가 등록한 위시리스트 전체 수를 가져온다.
	
	public List<WishlistDTO> Wishlist_list_page(HashMap<String,Object> map);
	//위시리스트를 페이징해서 가져온다.
	
}
