package edu.kosta.model.dto.ur.QnA;
import java.util.HashMap;


import java.util.List;

public interface QnADAO {
	public List<QnADTO> getQnAList(HashMap<String,Object> map);
	//QnA전체 리스트 출력
	public void insertQnA(QnADTO dto);
	//QnA 게시글 입력
	public QnADTO getQnADTO(int num);
	//QnA에서 페이징 할때 사용 
	public int getQnACount(String item_num);
	//QnA 게시글 수 확인
	public int updateQnA(QnADTO dto);
	//QnA 게시글 수정
	public void deleteQnA(QnADTO dto);
	//QnA 게시글 삭제
	public void insertReply(QnaCommentDTO qnaVo);
	//QnA 댓글 입력
	public List<QnaCommentDTO> selectReply();
	//QnA 댓글 리스트 출력

	
}
