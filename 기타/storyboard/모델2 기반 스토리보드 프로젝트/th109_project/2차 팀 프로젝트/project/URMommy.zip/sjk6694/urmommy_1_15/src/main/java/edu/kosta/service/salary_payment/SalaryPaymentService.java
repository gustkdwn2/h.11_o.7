package edu.kosta.service.salary_payment;

import java.util.ArrayList;

import edu.kosta.model.dto.salary_payment.SalaryPaymentDTO;

public interface SalaryPaymentService {
	void insertSalaryPaymentList(SalaryPaymentDTO spDTO);

	ArrayList<SalaryPaymentDTO> selectSalaryPaymentList();
}
