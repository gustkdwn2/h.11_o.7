package edu.kosta.model.dto.ur.QnA;

import java.util.Date;

public class QnADTO {
	private int q_num;
	private String user_id;
	private String q_title;
	private String q_contents;
	private String q_pwd;
	private Date q_date;
	private String item_num;
	
	public String getItem_num() {
		return item_num;
	}
	public void setItem_num(String item_num) {
		this.item_num = item_num;
	}
	
	public int getQ_num() {
		return q_num;
	}
	public void setQ_num(int q_num) {
		this.q_num = q_num;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getQ_title() {
		return q_title;
	}
	public void setQ_title(String q_title) {
		this.q_title = q_title;
	}
	public String getQ_contents() {
		return q_contents;
	}
	public void setQ_contents(String q_contents) {
		this.q_contents = q_contents;
	}
	public String getQ_pwd() {
		return q_pwd;
	}
	public void setQ_pwd(String q_pwd) {
		this.q_pwd = q_pwd;
	}
	public Date getQ_date() {
		return q_date;
	}
	public void setQ_date(Date q_date) {
		this.q_date = q_date;
	}
	
	@Override
	public String toString() {
		return "QnADTO [q_num=" + q_num + ", user_id=" + user_id + ", q_title=" + q_title + ", q_contents=" + q_contents
				+ ", q_pwd=" + q_pwd + ", q_date=" + q_date + ", item_num=" + item_num + "]";
	}
		
	
}
