package edu.kosta.model.dto.user;

public class UserDTO {
	private String user_id, user_pwd, m_name, b_name, phone, email, postcode, address1, address2, b_gender;
	private String m_birthday;
	String b_birthday;

	private int newOrder;
	private int cancelOrder;
	
	public UserDTO() {}
	public UserDTO(String user_id, String user_pwd, String m_name, String b_name, String phone, String email,
			String postcode, String address1, String address2, String b_gender, String m_birthday, String b_birthday,
			int newOrder, int cancelOrder) {
		super();
		this.user_id = user_id;
		this.user_pwd = user_pwd;
		this.m_name = m_name;
		this.b_name = b_name;
		this.phone = phone;
		this.email = email;
		this.postcode = postcode;
		this.address1 = address1;
		this.address2 = address2;
		this.b_gender = b_gender;
		this.m_birthday = m_birthday;
		this.b_birthday = b_birthday;
		this.newOrder = newOrder;
		this.cancelOrder = cancelOrder;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getUser_pwd() {
		return user_pwd;
	}
	public void setUser_pwd(String user_pwd) {
		this.user_pwd = user_pwd;
	}
	public String getM_name() {
		return m_name;
	}
	public void setM_name(String m_name) {
		this.m_name = m_name;
	}
	public String getB_name() {
		return b_name;
	}
	public void setB_name(String b_name) {
		this.b_name = b_name;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPostcode() {
		return postcode;
	}
	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}
	public String getAddress1() {
		return address1;
	}
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	public String getAddress2() {
		return address2;
	}
	public void setAddress2(String address2) {
		this.address2 = address2;
	}
	public String getB_gender() {
		return b_gender;
	}
	public void setB_gender(String b_gender) {
		this.b_gender = b_gender;
	}
	public String getM_birthday() {
		return m_birthday;
	}
	public void setM_birthday(String m_birthday) {
		this.m_birthday = m_birthday;
	}
	public String getB_birthday() {
		return b_birthday;
	}
	public void setB_birthday(String b_birthday) {
		this.b_birthday = b_birthday;
	}
	public int getNewOrder() {
		return newOrder;
	}
	public void setNewOrder(int newOrder) {
		this.newOrder = newOrder;
	}
	public int getCancelOrder() {
		return cancelOrder;
	}
	public void setCancelOrder(int cancelOrder) {
		this.cancelOrder = cancelOrder;
	}
}
