package edu.kosta.service.ur.item;

import java.io.File;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import edu.kosta.model.dto.ur.item.ItemDAO;
import edu.kosta.model.dto.ur.item.ItemDTO;
import edu.kosta.model.dto.ur.stock.StockDTO;

@Component
public class ItemServiceImpl implements ItemService {

   @Autowired
   private SqlSession sqlsession;
   
   //전체
   @Override
   public List<ItemDTO> getItemMainList(HashMap<String,Object> map) {
      ItemDAO itemDAO = sqlsession.getMapper(ItemDAO.class);
      return itemDAO.getItemMainList(map);
   }
   @Override
   public int getItemMainCount() {
      ItemDAO itemDAO = sqlsession.getMapper(ItemDAO.class);
      return itemDAO.getItemMainCount();
   }
   
   //남자옷
   @Override
   public List<ItemDTO> getItemBoyList(HashMap<String,Object> map) {
      ItemDAO itemDAO = sqlsession.getMapper(ItemDAO.class);
      return itemDAO.getItemBoyList(map);
   }
   @Override
   public int getItemBoyCount() {
      ItemDAO itemDAO = sqlsession.getMapper(ItemDAO.class);
      return itemDAO.getItemBoyCount();
   }
   
   //여자옷
   @Override
   public List<ItemDTO> getItemGirlList(HashMap<String,Object> map) {
      ItemDAO itemDAO = sqlsession.getMapper(ItemDAO.class);
      return itemDAO.getItemGirlList(map);
   }
   @Override
   public int getItemGirlCount() {
      ItemDAO itemDAO = sqlsession.getMapper(ItemDAO.class);
      return itemDAO.getItemGirlCount();
   }
   
   //전체
   @Override
   public List<ItemDTO> getUrmomList(HashMap<String,Object> map, String it) {
      ItemDAO itemDAO = sqlsession.getMapper(ItemDAO.class);
      return itemDAO.getUrmomList(map, it);
   }
   @Override
   public int getUrmomCount(String it) {
      ItemDAO itemDAO = sqlsession.getMapper(ItemDAO.class);
      return itemDAO.getUrmomCount(it);
   }
   @Override
   public List<ItemDTO> getItemTopDetailList(HashMap<String,Object> map, String itd) {
      ItemDAO itemDAO = sqlsession.getMapper(ItemDAO.class);
      return itemDAO.getItemTopDetailList(map, itd);
   }
   @Override
   public int getItemTopDetailCount(String itd) {
      ItemDAO itemDAO = sqlsession.getMapper(ItemDAO.class);
      return itemDAO.getItemTopDetailCount(itd);
   }
   @Override
   public List<ItemDTO> getItemBotDetailList(HashMap<String,Object> map, String itd) {
      ItemDAO itemDAO = sqlsession.getMapper(ItemDAO.class);
      return itemDAO.getItemBotDetailList(map, itd);
   }
   @Override
   public int getItemBotDetailCount(String itd) {
      ItemDAO itemDAO = sqlsession.getMapper(ItemDAO.class);
      return itemDAO.getItemBotDetailCount(itd);
   }

   @Override
   public List<ItemDTO> getBoyList(HashMap<String,Object> map, String it) {
      ItemDAO itemDAO = sqlsession.getMapper(ItemDAO.class);
      return itemDAO.getBoyList(map, it);
   }
   @Override
   public int getBoyCount(String it) {
      ItemDAO itemDAO = sqlsession.getMapper(ItemDAO.class);
      return itemDAO.getBoyCount(it);
   }
   
   @Override
   public List<ItemDTO> getItemBoyTopDetailList(HashMap<String,Object> map, String itd) {
      ItemDAO itemDAO = sqlsession.getMapper(ItemDAO.class);
      return itemDAO.getItemBoyTopDetailList(map, itd);
   }
   @Override
   public int getItemBoyTopDetailCount(String itd) {
      ItemDAO itemDAO = sqlsession.getMapper(ItemDAO.class);
      return itemDAO.getItemBoyTopDetailCount(itd);
   }

   @Override
   public List<ItemDTO> getGirlList(HashMap<String,Object> map, String it) {
      ItemDAO itemDAO = sqlsession.getMapper(ItemDAO.class);
      return itemDAO.getGirlList(map, it);
   }
   @Override
   public int getGirlCount(String it) {
      ItemDAO itemDAO = sqlsession.getMapper(ItemDAO.class);
      return itemDAO.getGirlCount(it);
   }
   @Override
   public List<ItemDTO> getItemGirlTopDetailList(HashMap<String,Object> map, String itd) {
      ItemDAO itemDAO = sqlsession.getMapper(ItemDAO.class);
      return itemDAO.getItemGirlTopDetailList(map, itd);
   }
   @Override
   public int getItemGirlTopDetailCount(String itd) {
      ItemDAO itemDAO = sqlsession.getMapper(ItemDAO.class);
      return itemDAO.getItemGirlTopDetailCount(itd);
   }
   @Override
   public List<ItemDTO> getItemGirlBotDetailList(HashMap<String,Object> map, String itd) {
      ItemDAO itemDAO = sqlsession.getMapper(ItemDAO.class);
      return itemDAO.getItemGirlBotDetailList(map, itd);
   }
   @Override
   public int getItemGirlBotDetailCount(String itd) {
      ItemDAO itemDAO = sqlsession.getMapper(ItemDAO.class);
      return itemDAO.getItemGirlBotDetailCount(itd);
   }

   @Override
   public ItemDTO getItemDetail(String item_num) {
      ItemDAO itemDAO = sqlsession.getMapper(ItemDAO.class);
      return (ItemDTO)itemDAO.getItemDetail(item_num);
   }
   @Override
   public List<StockDTO> getItemStockLeft(String item_num) {
      ItemDAO itemDAO = sqlsession.getMapper(ItemDAO.class);
      return itemDAO.getItemStockLeft(item_num);
   }
   
   @Override
   public int itemValid(ItemDTO itemDTO) {
	   ItemDAO itemDAO = sqlsession.getMapper(ItemDAO.class);
	   return itemDAO.itemValid(itemDTO);
   }
   
   @Override
   public void itemInsert(ItemDTO itemDTO) {
      ItemDAO itemDAO = sqlsession.getMapper(ItemDAO.class);
      itemDAO.itemInsert(itemDTO);
   }
   @Override
   public void itemUpdate(ItemDTO itemDTO) {
      ItemDAO itemDAO = sqlsession.getMapper(ItemDAO.class);
      itemDAO.itemUpdate(itemDTO);
   }
   @Override
   public void itemDelete(String item_num) {
      ItemDAO itemDAO = sqlsession.getMapper(ItemDAO.class);
      itemDAO.itemDelete(item_num);
   }
   
   //상품등록 대표이미지
   @Override
   public String getFileName(MultipartHttpServletRequest mul) {
      String saveFileName= null;
        Iterator<String> dodo = mul.getFileNames();
        String uploadPath=mul.getSession().getServletContext().getRealPath("/resources/images/item")+"/";
        while(dodo.hasNext()){
           String uploadFileName = dodo.next();

              MultipartFile mFile = mul.getFile(uploadFileName);

              String originalFileName = mFile.getOriginalFilename();

              saveFileName = originalFileName;
              //file upload부분
              
              
              //겹치는 부분 있을때 조건
              if(saveFileName != null && !saveFileName.equals("")) { //file exists

                 if(new File(uploadPath + saveFileName).exists()) {
                    saveFileName = System.currentTimeMillis() + "_" + saveFileName;
                 }
                 //예외 처리 transferTo(임시저장값)을 지정한 경로로 이동을 하게 함.
                 try {

                    mFile.transferTo(new File(uploadPath + saveFileName));

                 } catch (Exception e) {
                    e.printStackTrace();
                   
                 }
              } // if end
        }
        return saveFileName;
   }

}