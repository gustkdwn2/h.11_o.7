package edu.kosta.model.dto.ur.bankbook;

import java.util.HashMap;
import java.util.List;

public interface BankBookDAO {
   public List<BankBookDTO> getBankBookList(HashMap<String,Object> map);
   //오늘 입출고 리스트
   
   public List<BankBookDTO> getBankBook_Day_Search(HashMap<String,Object> map);
   //날짜별 입출고 리스트
   
   public List<BankBookDTO> getBankBook_Month_Search(HashMap<String,Object> map);
   //월별 입출고 리스트
   
   public List<BankBookDTO> getBankBook_Year_Search(HashMap<String,Object> map);
   //년별 입출고 리스트
   
   public void BankBook_outcome_insert(HashMap<String,Object> map);
   //지출 금액 리스트
   
   public void BankBook_income_insert(HashMap<String,Object> map);
   //입금 금액 리스트
   
   public int getBank_book_Count();
   //입출고 전체 수
   
   public int getBank_book_day_count(String day);
   //입출고 날짜별 수
   
   public int getBank_book_month_count(String day);
   //입출고 월별 수
   
   public int getBank_book_year_count(String day);
   //입출고 년별 수
   
   public List<BankBookDTO> getBankBook_total_list();
   //입출고 통합 리스트
}