SELECT * FROM HUMAN_RESOURCE

DROP TABLE HUMAN_RESOURCE;

create table human_resource(
   admin_id VARCHAR2(50) NOT NULL,
   admin_name VARCHAR2(50) NOT NULL,
   admin_department VARCHAR2(50) NOT NULL,
   admin_hiredate DATE NOT NULL,
   admin_pay NUMBER(10),
   admin_bonus NUMBER(10),
   admin_paycut NUMBER(10)
);

ALTER TABLE human_resource
ADD CONSTRAINT fk_human_resource FOREIGN KEY (admin_id)
REFERENCES Admin(admin_id)


--INSERT INTO HUMAN_RESOURCE(admin_name, admin_department, admin_hiredate, admin_pay)
--VALUES('김도협','재무','2015-11-01','2000000');
--INSERT INTO HUMAN_RESOURCE(admin_name, admin_department, admin_hiredate, admin_pay)
--VALUES('조일혜','재고','2015-11-01','2000000');
--INSERT INTO HUMAN_RESOURCE(admin_name, admin_department, admin_hiredate, admin_pay)
--VALUES('유승모','웹페이지관리','2015-11-01','2000000');
--INSERT INTO HUMAN_RESOURCE(admin_name, admin_department, admin_hiredate, admin_pay)
--VALUES('이동재','고객센터관리','2015-11-01','2000000');
--INSERT INTO HUMAN_RESOURCE(admin_name, admin_department, admin_hiredate, admin_pay)
--VALUES('김승관','회원관리','2015-11-01','2000000');

