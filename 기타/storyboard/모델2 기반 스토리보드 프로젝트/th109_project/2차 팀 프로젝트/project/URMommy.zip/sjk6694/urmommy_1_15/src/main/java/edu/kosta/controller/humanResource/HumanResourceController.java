package edu.kosta.controller.humanResource;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import edu.kosta.model.dto.humanResource.HumanResourceDTO;
import edu.kosta.model.dto.ur.orders.OrdersDTO;
import edu.kosta.model.dto.user.UserDTO;
import edu.kosta.service.admin.AdminService;
import edu.kosta.service.humanResource.HumanResourceService;
import edu.kosta.service.ur.cart.CartService;
import edu.kosta.service.ur.orders.OrdersService;
import edu.kosta.service.ur.stock.StockService;
import edu.kosta.service.user.UserService;

@Controller
public class HumanResourceController {

	@Resource
	private HumanResourceService hrService;
	@Resource
	private AdminService adminService;
	@Resource
	private UserService userService;
	@Resource
	private OrdersService ordersService;
	@Resource
	private CartService cartService;
	@Resource
	private StockService stockService;

	/*
	 * 관리자 페이지로 이동시 제일먼저 회원리스트가 뿌려져서 나온다
	 * 
	 * @see userList.jsp
	 */
	@RequestMapping("/adminPage.do")
	public String userAllSelect(HttpServletRequest request) {
		List<UserDTO> userList = userService.userAllSelect();

		for(int i=0; i<userList.size(); i++){
			int newOrder = userService.getNewOrderCount(userList.get(i).getUser_id());
			userList.get(i).setNewOrder(newOrder);
			
			int cancelOrder = userService.getCancelOrderCount(userList.get(i).getUser_id());
			userList.get(i).setCancelOrder(cancelOrder);
		}
		
		request.setAttribute("userList", userList);
		return "admin/userList";
	}

	/*
	 * 최상위 관리자와 회원관리 관리자는 회원의 정보에 관여할 수 있다 관리자 페이지중 회원관리 페이지에서 회원리스트가 나오는데 회원리스트
	 * 중 회원 아이디또는 회원 이름을 누르면 회원 정보가 상세히 나오게 된다
	 * 
	 * @Param user_id 회원 아이디
	 * 
	 * @see userInfo.jsp
	 */
	@RequestMapping("/userSelect.do") // 한사람의 정보만 가져오기
	public String userSelect(HttpServletRequest request) {

		String user_id = request.getParameter("user_id");
		if (user_id == "" || user_id == null) {
			userAllSelect(request);
			return "admin/userInfo";
		} else {
			userAllSelect(request);
			UserDTO userInfo = userService.userSelect(user_id);
			request.setAttribute("userInfo", userInfo);
			return "admin/userInfo";
		}
	}

	@RequestMapping("/adminList.do") // 모든 관리자 리스트 출력
	public String adminList(HttpServletRequest request) {
		ArrayList<HumanResourceDTO> adminList = hrService.adminList();
		if (adminList != null) {
			request.setAttribute("adminList", adminList);
		} else {
			System.out.println("인사관리 리스트가 존재하지 않습니다.");
		}
		return "admin/adminList";
	}

	/*
	 * 최상위 관리자는 하위관리자 리스트중 이름을 선택하면 하위관리자의 정보를 모두 볼수 있다
	 * 
	 * @Param admin_id 관리자 아이디 관리자 아이디를 넘겨받아 Human_ResourceDB에서 정보를 가져온다 가져온정보를
	 * HumanResource 타입의 adminInfo 객체로 받아서 adminInfo라는 이름으로 adminInfo.jsp로 넘겨준다
	 * 
	 * @see adminInfo.jsp
	 */
	@RequestMapping("/adminSelect.do") // 한사람(관리자)의 정보만 가져오기
	public String adminSelect(HttpServletRequest request) {
		String admin_id = request.getParameter("admin_id");
		if (admin_id == "" || admin_id == null) {
			adminList(request);
			return "admin/adminInfo";
		} else {
			adminList(request);
			HumanResourceDTO adminInfo = hrService.adminSelect(admin_id);
			request.setAttribute("adminInfo", adminInfo);
			return "admin/adminInfo";
		}
	}

	/*
	 * @RequestMapping("/adminPayManage.do") public String
	 * adminPayManage(HttpServletRequest request) { String admin_id =
	 * request.getParameter("admin_id"); adminSelect(request);
	 * adminList(request);
	 * 
	 * String admin_pay = request.getParameter("admin_pay");
	 * request.setAttribute("admin_id", admin_id);
	 * request.setAttribute("admin_pay", admin_pay); return "admin/adminInfo"; }
	 */

	/*
	 * 최상위 관리자는 하위 관리자의 월급을 관리한다
	 * 
	 * @Param admin_id 관리자 아이디
	 * 
	 * @Param admin_pay 관리자 월급
	 * 
	 * @Param admin_bonus 월급 보너스
	 * 
	 * @Param admin_paycut 월급 삭감 입력받은 월급보너스 혹은 월급 삭감은 퍼센트로 입력받아 월급이 수정된다
	 */
	@RequestMapping("/adminPayModify.do")
	public String adminPayModify(HttpServletRequest request, HttpSession session) {
		String admin_id = request.getParameter("admin_id");

		int admin_pay = Integer.parseInt(request.getParameter("admin_pay"));
		double admin_bonus = Double.parseDouble(request.getParameter("admin_bonus"));
		double admin_paycut = Double.parseDouble(request.getParameter("admin_paycut"));

		if (admin_bonus != 0.0 && admin_paycut == 0.0) {
			admin_pay = (int) (admin_pay * (100 + admin_bonus) * 0.01);
			hrService.adminPayModify(admin_id, admin_pay);
		} else if (admin_bonus == 0.0 && admin_paycut != 0.0) {
			admin_pay = (int) (admin_pay * (100 - admin_paycut) * 0.01);
			hrService.adminPayModify(admin_id, admin_pay);
		} else if (admin_bonus != 0.0 && admin_paycut != 0.0) {
			admin_pay = (int) (admin_pay * (100 + (admin_bonus - admin_paycut)) * 0.01);
			hrService.adminPayModify(admin_id, admin_pay);
		} else {
			hrService.adminPayModify(admin_id, admin_pay);
		}
		adminSelect(request);
		adminList(request);
		return "admin/adminInfo";
	}

	/*
	 * 최상위 관리자와 회원관리담당 관리자는 회원을 탈퇴시킬수 있다
	 * 
	 * @Param user_id 회원 아이디 아이디를 넘겨받아 User_AccountDB에서 삭제한다 또, 그아이디의 주문내역과
	 * 카트내역을 삭제시켜야 하기 때문에 cartDB와 cartPriceDB, ordersDB에서 그 아이디의 관련된 정보를 모두
	 * 삭제시켜준다
	 */

	@RequestMapping("/memberDelete.do") // 회원정보삭제(관리자에 의한 탈퇴)
	public ModelAndView userDelete(HttpSession session, HttpServletRequest request) {
		String user_id = request.getParameter("user_id");
		ModelAndView mav = new ModelAndView();
		userService.userDelete(user_id);
		// 추가!!!
		cartService.deleteAllCart(user_id);
		cartService.deleteAllCartPrice(user_id);
		ordersService.deleteOrders(user_id);

		mav.setViewName("redirect:/start.jsp");
		return mav;
	}

	/*
	 * 최상위 관리자가 하위관리자의 강제탈퇴 시키는 메소드이다
	 * 
	 * @Param admin_id 관리자 아이디 관리자 아이디를 넘겨받아 adminDB와 Human_ResourceDB에서 삭제시킨다
	 */
	@RequestMapping("/adminDelete.do") // 관리자 정보삭제(관리자에 의한 탈퇴)
	public ModelAndView adminDelete(HttpSession session, HttpServletRequest request) {

		String admin_id = request.getParameter("admin_id");

		ModelAndView mav = new ModelAndView();
		adminService.adminDelete(admin_id);
		hrService.hrAdminDelete(admin_id);
		mav.setViewName("redirect:/start.jsp");
		return mav;
	}

	/*
	 * 관리자가 선택한 회원의 주문내역 목록을 보여주는 메소드이다.
	 * 
	 * 선택한 user_id가 없다면, 즉 회원관리 첫 화면이라면 회원 목록을 보여준다.
	 * 
	 * 선택된 uesr_id가 있다면 해당 회원에 대한 정보와 주문내역을 출력한다.
	 * 
	 */
	@RequestMapping(value = "/selectUserOrderedList.do", method = { RequestMethod.POST, RequestMethod.GET })
	public String orderedList(OrdersDTO ordersDTO, HttpServletRequest request) throws Exception {

		String user_id = request.getParameter("user_id");
		if (user_id == "" || user_id == null) {
			userAllSelect(request);
			userSelect(request);
			return "admin/userOrderedList";
		} else {
			userAllSelect(request);
			userSelect(request);
			List<OrdersDTO> orderedList = ordersService.getOrderedList(user_id);

			for (int i = 0; i < orderedList.size(); i++) {
				String o_order_items = orderedList.get(i).getO_order_items();
				String[] orderItems = o_order_items.split(", ");

				for (int j = 0; j < orderItems.length; j++) {
					if (orderItems.length > 1) {
						int countItems = orderItems.length - 1;
						orderedList.get(i).setCountItems(countItems);
						orderedList.get(i).setO_order_items(orderItems[0]);
					}
				}
			}
			request.setAttribute("orderedList", orderedList);
			request.setAttribute("user_id", user_id);

			return "admin/userOrderedList";
		}
	}

	/*
	 * 주문상태를 변경하는 메소드이다.
	 * changeOrderState 메소드를 호출해서 트랜잭션 처리를 한다.
	 */
	@RequestMapping(value = "/changeOrderState.do", method = RequestMethod.POST)
	public String changeOrderState(OrdersDTO ordersDTO, HttpServletRequest request) {
		hrService.changeOrderState(ordersDTO);
		return "redirect:/selectUserOrderedList.do?user_id=" + ordersDTO.getUser_id();
	}

	/*
	 * 관리자가 선택한 회원의 특정 주문의 상세내역을 보여주는 메소드이다.
	 * user_account DB에서 회원정보를 가져오고
	 * orders DB에서 배송자 정보를 가져오고
	 * ordersItem DB에서 주문내역을 불러온다.
	 */
	@RequestMapping(value = "/selectUserOrderedDetail.do", method = RequestMethod.GET)
	public String selectUserOrderedDetail(HttpServletRequest request) {

		String user_id = request.getParameter("user_id");
		int o_num = Integer.parseInt(request.getParameter("o_num"));

		UserDTO orderedUser = ordersService.getOrdererInfo(user_id); 
		OrdersDTO receiver = ordersService.getReceiver(o_num); 
		List<OrdersDTO> orderDetail = ordersService.getOrderDetail(o_num); 
		
		request.setAttribute("orderedUser", orderedUser);
		request.setAttribute("receiver", receiver);
		request.setAttribute("orderDetail", orderDetail);

		return "admin/userOrderedDetail";
	}
}
