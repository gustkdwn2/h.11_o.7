package edu.kosta.service.ur.stock;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import edu.kosta.model.dto.ur.stock.StockDAO;
import edu.kosta.model.dto.ur.stock.StockDTO;

@Component
public class StockServiceImpl implements StockService {

   @Autowired
   private SqlSession sqlsession;
   
   //전체 재고 리스트 출력
   @Override
   public List<StockDTO> getStockList(HashMap<String,Object> map) {
      StockDAO stockDAO = sqlsession.getMapper(StockDAO.class);
      return stockDAO.getStockList(map);
   }
   //카테고리별 재고 리스트 출력(검색기능)
   @Override
   public List<StockDAO> getSearchStockList(HashMap<String,Object> map,String searchValue, String searchBox) {
      int start = (Integer) map.get("start");
      int end = (Integer) map.get("end");
      StockDAO stockDAO = sqlsession.getMapper(StockDAO.class);
      return stockDAO.getSearchStockList(start,end,searchValue,searchBox);
   }
   
   //재고 관리
   @Override
   public void stockInsert(StockDTO stockDTO) {
      StockDAO stockDAO = sqlsession.getMapper(StockDAO.class);
      stockDAO.stockInsert(stockDTO);
   }
   @Override
   public void stockUpdate(StockDTO stockDTO) {
      StockDAO stockDAO = sqlsession.getMapper(StockDAO.class);
      stockDAO.stockUpdate(stockDTO);
   }
   @Override
   public void stockDelete(StockDTO stockDTO) {
      StockDAO stockDAO = sqlsession.getMapper(StockDAO.class);
      stockDAO.itemDelete(stockDTO);
      stockDAO.cartDelete(stockDTO);
      stockDAO.orderItemDelete(stockDTO);
      stockDAO.stockInfoDelete(stockDTO);
      stockDAO.stockDelete(stockDTO);
   }
   //남자옷 리스트 개수
   @Override
   public int getItemBoyCount() {
      StockDAO stockDAO = sqlsession.getMapper(StockDAO.class);
      return stockDAO.getItemBoyCount();
   }
   //여자옷 리스트 개수
   @Override
   public int getItemGirlCount() {
      StockDAO stockDAO = sqlsession.getMapper(StockDAO.class);
      return stockDAO.getItemGirlCount();
   }
   @Override
   public int getUrmomCount(String it) {
      StockDAO stockDAO = sqlsession.getMapper(StockDAO.class);
      return stockDAO.getUrmomCount(it);
   }
   @Override
   public int getItemDetailCount(String itd) {
      StockDAO stockDAO = sqlsession.getMapper(StockDAO.class);
      return stockDAO.getItemDetailCount(itd);
   }
   
   //입고 관리
   @Override
   public List<StockDTO> getStockShow(String item_num) {
      StockDAO stockDAO = sqlsession.getMapper(StockDAO.class);
      return stockDAO.getStockShow(item_num);
   }
   @Override
   public void stockAdd(HashMap<String,Object> stockAddMap) {
      StockDAO stockDAO = sqlsession.getMapper(StockDAO.class);
      stockDAO.stockAdd(stockAddMap);
   }
   @Override
   public List<StockDTO> getExistSize(String item_num) {
      StockDAO stockDAO = sqlsession.getMapper(StockDAO.class);
      return stockDAO.getExistSize(item_num);
   }
   @Override
   public void itemInfoAddSize(HashMap<String,Object> stockSizeAddMap) {
      StockDAO stockDAO = sqlsession.getMapper(StockDAO.class);
      stockDAO.itemInfoAddSize(stockSizeAddMap);
   }
   @Override
   public void stockAddSize(HashMap<String, Object> stockSizeAddMap) {
      StockDAO stockDAO = sqlsession.getMapper(StockDAO.class);
      stockDAO.stockAddSize(stockSizeAddMap);
   }
   @Override
   public int countNoStock(String item_num) {
      StockDAO stockDAO = sqlsession.getMapper(StockDAO.class);
      return stockDAO.countNoStock(item_num);
   }
   
   @Override
	public int stockSizeCount(String item_num) {
	   StockDAO stockDAO = sqlsession.getMapper(StockDAO.class);
		return stockDAO.stockSizeCount(item_num);
	}
   
   @Override
	public int stockInItem(String item_num) {
	   StockDAO stockDAO = sqlsession.getMapper(StockDAO.class);
		return stockDAO.stockInItem(item_num);
	}
   
   //입고 통계
   @Override
   public List<StockDTO> inList(HashMap<String,Object> map) {
      StockDAO stockDAO = sqlsession.getMapper(StockDAO.class);
      return stockDAO.inList(map);
   }
   @Override
   public int inListCount() {
      StockDAO stockDAO = sqlsession.getMapper(StockDAO.class);
      return stockDAO.inListCount();
   }
   @Override
   public List<StockDTO> searchInList(HashMap<String,Object> map) {
      StockDAO stockDAO = sqlsession.getMapper(StockDAO.class);
      return stockDAO.searchInList(map);
   }
   @Override
   public int searchInListCount(String day) {
      StockDAO stockDAO = sqlsession.getMapper(StockDAO.class);
      return stockDAO.searchInListCount(day);
   }

   //출고 통계
   @Override
   public List<StockDTO> outList(HashMap<String,Object> map) {
   StockDAO stockDAO = sqlsession.getMapper(StockDAO.class);
   return stockDAO.outList(map);
   }
   @Override
   public int outListCount() {
      StockDAO stockDAO = sqlsession.getMapper(StockDAO.class);
      return stockDAO.outListCount();
   }
   
   @Override
   public List<StockDTO> searchOutList(HashMap<String,Object> map) {
      StockDAO stockDAO = sqlsession.getMapper(StockDAO.class);
      return stockDAO.searchOutList(map);
   }
   @Override
   public int searchOutListCount(String day) {
      StockDAO stockDAO = sqlsession.getMapper(StockDAO.class);
      return stockDAO.searchOutListCount(day);
   }

   //입고 차트
   @Override
   public List<StockDTO> inGenderChart() {
      StockDAO stockDAO = sqlsession.getMapper(StockDAO.class);
      return stockDAO.inGenderChart();
   }
   @Override
   public List<StockDTO> searchInGenderChart(String day) {
      StockDAO stockDAO = sqlsession.getMapper(StockDAO.class);
      return stockDAO.searchInGenderChart(day);
   }

   @Override
   public List<StockDTO> inTypeChart() {
      StockDAO stockDAO = sqlsession.getMapper(StockDAO.class);
      return stockDAO.inTypeChart();
   }
   @Override
   public List<StockDTO> searchInTypeChart(String day) {
      StockDAO stockDAO = sqlsession.getMapper(StockDAO.class);
      return stockDAO.searchInTypeChart(day);
   }

   @Override
   public List<StockDTO> inDetailChart() {
      StockDAO stockDAO = sqlsession.getMapper(StockDAO.class);
      return stockDAO.inDetailChart();
   }
   @Override
   public List<StockDTO> searchInDetailChart(String day) {
      StockDAO stockDAO = sqlsession.getMapper(StockDAO.class);
      return stockDAO.searchInDetailChart(day);
   }
   
   //출고 차트
   @Override
   public List<StockDTO> outGenderChart() {
      StockDAO stockDAO = sqlsession.getMapper(StockDAO.class);
      return stockDAO.outGenderChart();
   }
   @Override
   public List<StockDTO> searchOutGenderChart(String day) {
      StockDAO stockDAO = sqlsession.getMapper(StockDAO.class);
      return stockDAO.searchOutGenderChart(day);
   }

   @Override
   public List<StockDTO> outTypeChart() {
      StockDAO stockDAO = sqlsession.getMapper(StockDAO.class);
      return stockDAO.outTypeChart();
   }
   @Override
   public List<StockDTO> searchOutTypeChart(String day) {
      StockDAO stockDAO = sqlsession.getMapper(StockDAO.class);
      return stockDAO.searchOutTypeChart(day);
   }


   @Override
   public List<StockDTO> outDetailChart() {
      StockDAO stockDAO = sqlsession.getMapper(StockDAO.class);
      return stockDAO.outDetailChart();
   }
   @Override
   public List<StockDTO> searchOutDetailChart(String day) {
      StockDAO stockDAO = sqlsession.getMapper(StockDAO.class);
      return stockDAO.searchOutDetailChart(day);
   }

   
   //베스트
   @Override
   public List<StockDTO> getBestItem(HashMap<String,Object> map) {
     StockDAO stockDAO = sqlsession.getMapper(StockDAO.class);
     return stockDAO.getBestItem(map);
   }	
	
}