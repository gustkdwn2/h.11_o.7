package edu.kosta.model.dto.user;

import java.util.ArrayList;

import edu.kosta.model.dto.admin.AdminDTO;

public interface UserDAO {
	//회원가입
	public void insertJoin(UserDTO userDTO);

	//회원 로그인시 아이디와 비밀번호일치 여부
	public UserDTO getLoginCheck(UserDTO userDTO);
	
	//회원 가입 아이디 중복	
	public UserDTO confirmId(UserDTO userDTO);
	
	//회원정보 수정
	public void userUpdate(UserDTO userDTO);	
	
	//회원삭제
	public void userDelete(String user_id);
	
	//모든 회원정보 출력
	public ArrayList<UserDTO> userAllSelect();	
	
	//관리자 로그인시 아이디와 비밀번호일치 여부
	public AdminDTO getAdminLoginCheck(AdminDTO adminDTO);

	//아이디에 따른 회원정보 출력
	public UserDTO userSelect(String user_id);

	public int getNewOrderCount(String user_id);
	public int getCancelOrderCount(String user_id);	
}
