create table item(
	item_num VARCHAR2(50) NOT NULL, -- Item_num (g0001t, g0002t, ...)
	item_name VARCHAR2(50) NOT NULL, -- Item_name
	item_gender VARCHAR2(10) NOT NULL, --Item_gender (boy, girl)
	item_type VARCHAR2(10) NOT NULL, -- Item_type (out, top, bot, dre)
	item_type_detail VARCHAR2(10) NOT NULL, --Item_type_detail (top-tee,blou,knit)/(bot-pant,skir)
	unit_price number(10) NOT NULL, -- unit_price
	sell_price number(10) NOT NULL, -- sell_price
	pic_url VARCHAR2(50) NOT NULL,  -- pic_url
	description VARCHAR2(200) NULL,
	contents VARCHAR2(4000) NOT NULL
);

ALTER TABLE item 
ADD CONSTRAINT fk_item_num FOREIGN KEY (item_num)
REFERENCES stock(item_num)

--create table item_info(
--	item_num VARCHAR2(50) NOT NULL,
--	unit_price number(10) NOT NULL, -- unit_price
--	sell_price number(10) NOT NULL, -- sell_price
--	item_amount number(10), -- Item_amount
--	item_size VARCHAR2(50) -- Item_size (xs, s, m, l, xl, xxl)
--);
--ALTER TABLE item_info
--ADD CONSTRAINT fk_item_info FOREIGN KEY(item_num,unit_price,sell_price)
--REFERENCES item(item_num,unit_price,sell_price);

delete from item_info where item_amount>=0

DROP TABLE item;

select * from item where item_gender='girl';
SELECT COUNT(*) FROM ITEM WHERE ITEM_GENDER='girl'

delete from item where unit_price>0

insert into item values('g0001t',10000,19500,'�뒪�듃�씪�씠�봽 �떚','girl','top','tee','g0001t.jpg','g0001t');
insert into item values('g0002t',10000,19500,'1986留⑦닾留�','girl','top','tee','g0002t.jpg','g0002t');
insert into item values('g0003t',25000,30000,'�뒳�젞 �닔�닠 �떚','girl','top','tee','g0003t.jpg','g0003t');
insert into item values('g0004t',5000,9000,'怨⑥� �븯�봽�꽖 �떚','girl','top','tee','g0004t.jpg','g0004t');
insert into item values('g0005t',25000,39000,'耳�誘몃땲�듃吏쒖엫','girl','top','knit','g0005t.jpg','g0005t');

insert into item values('g0001b',20000,27000,'�겕�윭�돩怨⑤뜶�뙩痢�','girl','bot','pant','g0001b.jpg','g0001b');
insert into item values('g0002b',25000,34500,'�븸�븸�씠硫쒕묠�뙩痢�','girl','bot','pant','g0002b.jpg','g0002b');

insert into item values('g0001d',15000,20500,'�뿕�궗�뀛留곸썝�뵾�뒪','girl','dre','dre','g0001d.jpg','g0001d');
insert into item values('g0002d',18000,24000,'�쎂�뵒苑껋썝�뵾�뒪','girl','dre','dre','g0002d.jpg','g0002d');

delete from item where item_num='test'

insert into item_info values ('g0001t',10000,19500,5,'xs');
insert into item_info values ('g0001t',10000,19500,10,'s');
insert into item_info values ('g0001t',10000,19500,20,'m');
insert into item_info values ('g0001t',10000,19500,10,'l');

insert into item_info values ('g0002t',10000,19500,34,'xs');
insert into item_info values ('g0002t',10000,19500,2,'s');
insert into item_info values ('g0002t',10000,19500,3,'m');
insert into item_info values ('g0002t',10000,19500,56,'l');

	SELECT ITEM_NUM,ITEM_NAME,SELL_PRICE,PIC_URL FROM ITEM WHERE (ITEM_GENDER='boy' AND ITEM_TYPE='out') ORDER BY ITEM_NUM DESC

	SELECT info.ITEM_NUM, item.ITEM_NAME, info.ITEM_AMOUNT, info.ITEM_SIZE 
	FROM ITEM_INFO info, ITEM item
	WHERE info.ITEM_NUM=item.ITEM_NUM
	AND info.ITEM_NUM='g0001t'

	UPDATE ITEM_INFO SET ITEM_AMOUNT=15
	WHERE ITEM_NUM='g0002t' AND ITEM_SIZE='xs'
	
	SELECT * FROM
	(SELECT A.*,ROWNUM R FROM 
	(SELECT * FROM ITEM ORDER BY ITEM_NUM DESC) A )
 	WHERE R >= 1 AND R <= 11
 	
 	SELECT ITEM_NUM,ITEM_NAME,SELL_PRICE,PIC_URL FROM ITEM 
	WHERE (ITEM_TYPE='top' AND ITEM_TYPE_DETAIL='tee')
	ORDER BY ITEM_NUM DESC
	
	INSERT INTO ITEM_INFO VALUES ('g0001t',10000,19500, 10,'m')
	
	SELECT * FROM ITEM WHERE ITEM_NUM='g0001t'