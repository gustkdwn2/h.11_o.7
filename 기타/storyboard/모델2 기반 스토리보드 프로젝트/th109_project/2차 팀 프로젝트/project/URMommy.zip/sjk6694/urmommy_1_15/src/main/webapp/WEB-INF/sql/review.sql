  
  drop table review;

DROP TABLE review CASCADE CONSTRAINTS

CREATE TABLE review
  (
  review_num NUMBER(10) primary key,--리뷰 넘버
  user_id VARCHAR2(50) NOT NULL,--REFERENCE KEY 유저 아이디
  review_title VARCHAR2(200) NOT NULL,--리뷰 타이틀
  review_contents VARCHAR2(500) NOT NULL,--리뷰 내용
  review_like  number(10)   NOT NULL, --리뷰 좋아요
  review_img  VARCHAR2(500) NOT NULL, -- 리뷰 이미지
  review_date    DATE default SYSDATE NOT NULL, --리뷰 작성 날짜
  rating  number(10) NOT NULL,--리뷰 별점
  item_num varchar2(50) not null
  );
    ALTER TABLE review
ADD CONSTRAINT fk_review FOREIGN KEY (item_num)
REFERENCES stock (item_num) ON DELETE CASCADE

ALTER TABLE review
ADD CONSTRAINT fk_review_userId FOREIGN KEY(user_id)
REFERENCES User_Account(user_id) ON DELETE CASCADE

  select*from REVIEW;
  
  


