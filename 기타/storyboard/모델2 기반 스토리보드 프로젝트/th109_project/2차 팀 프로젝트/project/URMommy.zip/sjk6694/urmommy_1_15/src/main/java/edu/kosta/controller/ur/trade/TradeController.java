package edu.kosta.controller.ur.trade;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import edu.kosta.model.dto.ur.notice.NoticeDTO;
import edu.kosta.model.dto.ur.trade.TradeDTO;
import edu.kosta.model.dto.ur.trade.TradeReplyDTO;
import edu.kosta.model.dto.ur.web_manage.Web_ManageDTO;
import edu.kosta.model.dto.user.UserDTO;
import edu.kosta.service.ur.notice.NoticeService;
import edu.kosta.service.ur.trade.TradeService;
import edu.kosta.service.ur.web_manage.Web_ManageService;

/* 
 * @author (SeungKwan Kim)
 * 
 * 이 컨트롤러는 물물교환 게시판이 실행되는 메소드를 담고 있다.
 * 
 * */
@Controller
public class TradeController {

	@Resource
	private TradeService tradeService;
	@Resource
	private NoticeService noticeService;
	@Resource
	private Web_ManageService web_manageService;
	
	public void callCommonMethod(HttpServletRequest request){
		Web_ManageDTO mainlogo = web_manageService.getMainLogo();
		request.setAttribute("mainlogo", mainlogo);	
	}
	
	/* 
	 * 이 메소드는 UserDTO에 있는 회원정보를 세션을 사용하여 유지시키고 정보를 
	 * loginUser라는 변수에 setAttribute를 사용하여 담아놓고 글쓰기 게시판인 tradeWriteForm.jsp로 이동한다.
	 *  
	 * */
	@RequestMapping("/tradeWriteForm.do")
	public String writeform(HttpServletRequest request, HttpSession session) {
		UserDTO loginUser = (UserDTO) session.getAttribute("loginUser");
		callCommonMethod(request);
		request.setAttribute("loginUser", loginUser);
		return "/trade/tradeWriteForm";
	}

	/* 
	 * 
	 * 이 메소드는 "글쓰기"를 누를때 회원이 입력한 데이터들을 Hash Map에 담아 데이터를 등록하는 메소드이다.
	 * 완료되면 tradeList.do로 redirect된다.
	 * 
	 * */
	@RequestMapping("/tradeWrite.do")
	public String traderWrite(MultipartHttpServletRequest request) {

		String mul_name = tradeService.Upload(request);
		HashMap<String, Object> map = new HashMap<String, Object>();
		
		map.put("user_id", request.getParameter("user_id"));
		map.put("trade_title", request.getParameter("trade_title"));
		map.put("trade_phone", request.getParameter("phone"));
		map.put("trade_content", request.getParameter("trade_content"));
		map.put("trade_category", request.getParameter("trade_category"));
		map.put("trade_pic", mul_name);
		
		tradeService.insertmom(map);
		return "redirect:/tradeList.do";
	}

	
	/* 
	 * 
	 * 이 메소드는 물물교환 게시판 리스트글을 검색하는 메소드이다.	
	 * 검색을 원하는 select 전체를 searchName이라는 변수로 잡고, 검색할 카테고리 변수 user_id,trade_category,trade_title로 각각 잡은 후,
	 * searchValue로 직접 입력하여 검색한다.
	 * Ex)searchName이 user_id일때 searchValue = 본인이 입력한 값을 id라는 변수에 넣고 map에 넣는다.
	 * 검색결과 초기값은 0으로 잡고 검색 결과 갯수를 getListCount로 잡아 출력한다.
	 * 그리고 맵에 본인이 입력한 값과 start(시작하는 첫번째 게시글) , end(마지막에 등록된 게시글)를 map에 넣고 검색 리스트를 출력한다.
	 * 
	 * */
	@RequestMapping("/tradeSearch.do")
	public String tradeSearch(HttpServletRequest request) {
		List<TradeDTO> list = new ArrayList<TradeDTO>();
		String searchName = request.getParameter("searchName");
		String searchValue = request.getParameter("searchValue");
		HashMap<String,Object> map = new HashMap<String,Object>();
		
		callCommonMethod(request);
		
		int pg = 1;
		String strPg = request.getParameter("pg");
		if (strPg != null) {
			pg = Integer.parseInt(strPg);
		}
		int rowSize = 5;
		int start = (pg * rowSize) - (rowSize - 1);
		int end = pg * rowSize;
		int total = 0;

		if (searchName.equals("user_id")) { 
			map.put("id",searchValue);
			total = tradeService.getidListCount(map);
			
		} else if (searchName.equals("trade_category")) {
			map.put("trade_category", searchValue);
			total = tradeService.getcategoryListCount(map);
		} else {
			map.put("trade_title", searchValue);
			total = tradeService.gettitleListCount(map);
		}

		int allPage = (int) Math.ceil(total / (double) rowSize);

		int block = 10;
		int fromPage = ((pg - 1) / block * block) + 1;

		int toPage = ((pg - 1) / block * block) + block;
		if (toPage > allPage) {
			toPage = allPage;
		}

		map.put("start", start);
		map.put("end", end);

		if (searchName.equals("user_id")) {
			
			list = tradeService.getidList(map);
			
		} else if (searchName.equals("trade_category")) {

			list = tradeService.getcategoryList(map);
	
		} else {
		
			list = tradeService.gettitleList(map);
		}
		
		request.setAttribute("list", list);
		request.setAttribute("pg", pg);
		request.setAttribute("allPage", allPage);
		request.setAttribute("block", block);
		request.setAttribute("fromPage", fromPage);
		request.setAttribute("toPage", toPage);
		return "trade/tradeList";
	}

	
	/* 
	 * 
	 * 이 메소드는 trade_list와 같은 메소드이며,
	 * 회원끼리 거래가 완료되면 해당 물물교환 해당 게시글에 success.jsp를 띄우는 메소드이다.	
	 * 
	 */
	@RequestMapping("/tradeSuccessList.do")
	public String tradeSuccessList(HttpServletRequest request, int trade_num) {
		tradeService.updateSuccess(trade_num);
		callCommonMethod(request);
		
		int pg = 1;
		String strPg = request.getParameter("pg");
		if (strPg != null) {
			pg = Integer.parseInt(strPg);
		}
		int rowSize = 5;
		int start = (pg * rowSize) - (rowSize - 1);
		int end = pg * rowSize;
		int total = tradeService.getMOMCount();
		int allPage = (int) Math.ceil(total / (double) rowSize);
		int block = 10;
		int fromPage = ((pg - 1) / block * block) + 1;

		int toPage = ((pg - 1) / block * block) + block;
		if (toPage > allPage) {
			toPage = allPage;
		}

		HashMap<String,Object> map = new HashMap<String,Object>();

		map.put("start", start);
		map.put("end", end);

		List<TradeDTO> list = tradeService.getList(map);

		request.setAttribute("list", list);
		request.setAttribute("pg", pg);
		request.setAttribute("allPage", allPage);
		request.setAttribute("block", block);
		request.setAttribute("fromPage", fromPage);
		request.setAttribute("toPage", toPage);

		return "trade/tradeList"; // list.jsp
	}
	
	/*
	 * 이 메소드는 물물교환 게시판 페이징 메소드이다.
	 * 댓글 페이지 첫 댓글 페이지를 1로 잡고 rowsize=5 한 페이지에 보여줄 글 갯수를 5로 잡은 후 ,
	 * 총 게시물수를 int total로 지정, 화면에 보여줄 페이지 범위를 10개씩 잡아 1~10, 11~20으로 출력,
	 * tPage = 보여줄 페이지의 끝 fPage = 보여줄 페이지의 시작
	 * 시작하는 첫번째 게시글을 start , 마지막 게시글을 end로 지정하고 HashMap을 사용하여 Map에 담는다.
	 * tradeService.getList(map)를 통해 trade_num으로 페이징된 모든 정보를 가져온 후 배열 List<TradeDTO> list 에 담는다.
	 * 가져온 데이터들을 가지고 list.jsp로 이동
	 * 
	 */
	@RequestMapping("/tradeList.do")
	public String tradeList(HttpServletRequest request) {

		callCommonMethod(request);
		
		int pg = 1;
		String strPg = request.getParameter("pg");
		if (strPg != null) {
			pg = Integer.parseInt(strPg);
		}
		int rowSize = 5;
		int start = (pg * rowSize) - (rowSize - 1);
		int end = pg * rowSize;
		int total = tradeService.getMOMCount();
		int allPage = (int) Math.ceil(total / (double) rowSize);
		int block = 10;
		int fromPage = ((pg - 1) / block * block) + 1;

		int toPage = ((pg - 1) / block * block) + block;
		if (toPage > allPage) {
			toPage = allPage;
		}

		HashMap<String,Object> map = new HashMap<String,Object>();

		map.put("start", start);
		map.put("end", end);

		List<TradeDTO> list = tradeService.getList(map);
		List<NoticeDTO> noticeList = noticeService.getNotice_rolling();	// 공지사항 rolling 가지고 오기.
		
		request.setAttribute("noticeList", noticeList);
		request.setAttribute("list", list);
		request.setAttribute("pg", pg);
		request.setAttribute("allPage", allPage);
		request.setAttribute("block", block);
		request.setAttribute("fromPage", fromPage);
		request.setAttribute("toPage", toPage);

		return "trade/tradeList"; // list.jsp
	}
	
	/*
	 * 이 메소드는 기부 게시판 페이징 메소드이다.
	 * 
	 * */
	@RequestMapping("/donateList.do")
	public String donateList(HttpServletRequest request) {

		callCommonMethod(request);
		
		int pg = 1;
		String strPg = request.getParameter("pg");
		if (strPg != null) {
			pg = Integer.parseInt(strPg);
		}
		int rowSize = 5;
		int start = (pg * rowSize) - (rowSize - 1);
		int end = pg * rowSize;
		int total = tradeService.getDonateCount();
		int allPage = (int) Math.ceil(total / (double) rowSize);
		int block = 10;
		int fromPage = ((pg - 1) / block * block) + 1;

		int toPage = ((pg - 1) / block * block) + block;
		if (toPage > allPage) {
			toPage = allPage;
		}

		HashMap<String,Object> map = new HashMap<String,Object>();

		map.put("start", start);
		map.put("end", end);

		List<TradeDTO> list = tradeService.getDonateList(map);
		List<NoticeDTO> noticeList = noticeService.getNotice_rolling();	// 공지사항 rolling 가지고 오기.
		request.setAttribute("noticeList", noticeList);
		
		request.setAttribute("list", list);
		request.setAttribute("pg", pg);
		request.setAttribute("allPage", allPage);
		request.setAttribute("block", block);
		request.setAttribute("fromPage", fromPage);
		request.setAttribute("toPage", toPage);

		return "trade/donateList"; // donateList.jsp
	}

	
	/*
	 * 이 메소드는 물물교환 게시글 리스트중 하나를 클릭하여 자세히 보는 메소드이다.
	 * updateHit으로 해당글 번호 trade_num을 받아와 조회수가 1 올라가며,updateform(수정)은 해당글을 trade_num으로 
	 * TradeDTO에서 모두 가져오면,회원이 입력한 정보가 보여지고 tradeUpdateForm.do로 이동한다.
	 * 
	 */

	@RequestMapping("/tradeView.do")
	public String read(HttpServletRequest request, int trade_num, int pg, Model model) {

		tradeService.updateHit(trade_num);
		
		callCommonMethod(request);
		
		TradeDTO dto = tradeService.updateform(trade_num);

		model.addAttribute("b", dto);
		model.addAttribute("pg", pg);

		int page = 1;
		String strPage = request.getParameter("rpg");
		if (strPage != null) {
			page = Integer.parseInt(strPage);
		}
		int rowSize = 2;
		int start = (page * rowSize) - (rowSize - 1);
		int end = page * rowSize;
		int total = tradeService.getreMOMCount(trade_num);
		int aPage = (int) Math.ceil(total / (double) rowSize);
		int block = 10;
		int fPage = ((pg - 1) / block * block) + 1;

		int tPage = ((pg - 1) / block * block) + block;
		if (tPage > aPage) {
			tPage = aPage;
		}

		HashMap<String,Object> map = new HashMap<String,Object>();

		map.put("start", start);
		map.put("end", end);
		map.put("trade_num", trade_num);

		model.addAttribute("reviewList", tradeService.replylist(map));

		request.setAttribute("page", page);
		request.setAttribute("aPage", aPage);
		request.setAttribute("block", block);
		request.setAttribute("fPage", fPage);
		request.setAttribute("tPage", tPage);

		return "trade/tradeView"; // tradeView.jsp
	}
	
	/*
	 * 이 메소드는 물물교환 게시판 글을 수정하는 메소드이다.
	 * trade_num으로 TradeDTO에서 해당글 정보를 가져온 후, dto에 담고 key값인 b에 넣고 해당글 페이지와 데이터를 가지고 tradeUpdateForm.jsp로 이동한다.
	 */
	@RequestMapping("/tradeUpdateForm.do")
	public String tradeUpdateForm(int trade_num, int pg, Model model) {
		TradeDTO dto = tradeService.updateform(trade_num);
		Web_ManageDTO mainlogo = web_manageService.getMainLogo();
		model.addAttribute("mainlogo", mainlogo);
		model.addAttribute("b", dto);
		model.addAttribute("pg", pg);

		return "trade/tradeUpdateForm"; // tradeUpdateForm.jsp
	}

	
	/*
	 * 이 메소드는 사용자가 수정할 데이터들을 가져오는 메소드이다.
	 * 사용자가 수정할 데이터들을 HashMap에 담고 update한 후 완료되면 리스트를 볼수 있도록,
	 * tradeList.do로 redirect된다.
	 */
	@RequestMapping("/tradeUpdate.do")
	public String tradeUpdate(MultipartHttpServletRequest request) {
		String mul_name = tradeService.Upload(request);
		String pg = request.getParameter("pg");
		HashMap<String,Object> map = new HashMap<String,Object>();
		map.put("trade_num", request.getParameter("trade_num"));
		map.put("trade_title", request.getParameter("trade_title"));
		map.put("trade_phone", request.getParameter("trade_phone"));
		map.put("trade_category", request.getParameter("trade_category"));
		map.put("trade_pic", mul_name);
		map.put("trade_content", request.getParameter("trade_content"));

		tradeService.updatemom(map);

		return "redirect:/tradeList.do?pg=" + pg;

	}

	/*
	 * 이 메소드는 물물교환 게시판 댓글을 수정하는 메소드이다.
	 * trade_com_num으로 TradeReplyDTO에서 해당글 정보를 가져온 후, dto에 담고  key값인 b에 넣고 해당글 페이지와 데이터를 가지고 updateReplyForm.jsp로 이동한다.
	 */
	@RequestMapping("/tradeReplyUpdate.do")
	public String tradeReplyUpdate(int trade_com_num, Model model) {
		TradeReplyDTO dto = tradeService.updaterep(trade_com_num);
		Web_ManageDTO mainlogo = web_manageService.getMainLogo();
		model.addAttribute("mainlogo", mainlogo);
		model.addAttribute("b", dto);
		return "trade/updateReplyForm"; // updateReplyForm.jsp
	}
	/*
	 * 이 메소드는 사용자가 수정할 댓글 데이터들을 가져오는 메소드이다.
	 * 사용자가 수정할 데이터들을 Hashmap에 담고 update한 후 완료되면 리스트를 볼수 있도록, 
	 * tradeList.do로 redirect된다.
	 * 
	 */
	@RequestMapping("/tradeReplyUpdateForm.do")
	public String tradeReplyUpdateForm(MultipartHttpServletRequest request) {
		HashMap<String,Object> map = new HashMap<String,Object>();
		String mul_name = tradeService.Upload(request);
		map.put("trade_com_num", request.getParameter("trade_com_num"));
		map.put("user_id", request.getParameter("user_id"));
		map.put("trade_com_content", request.getParameter("trade_com_content"));
		map.put("trade_com_phone", request.getParameter("trade_com_phone"));
		map.put("trade_com_pic", mul_name);

		tradeService.updatereply(map);

		return "redirect:/tradeList.do";

	}

	/*
	 * 물물교환 게시판 글중 하나의 글을 삭제하는 메소드이다.
	 * 해당글을 자세히 본 후 삭제하기 버튼을 누르면 실행된다.
	 */
	@RequestMapping("/tradeDelete.do")
	public String tradeDelete(int trade_num, int pg) {
		tradeService.deleteMOM(trade_num);
		String res = "redirect:/tradeList.do?pg=" + pg;
		return res;
	}

	/*
	 * 물물교환 게시글에 댓글을 등록하는 메소드이다.
	 * 해당글을 자세히 본 후 "댓글등록"을 누르면 실행된다.
	 */
	@RequestMapping("/tradeReplyForm.do")
	public String tradeReplyForm(TradeDTO dto, HttpServletRequest request, int pg){
		callCommonMethod(request);
		request.setAttribute("trade_num", dto.getTrade_num());
		request.setAttribute("pg",pg);
		return "trade/tradeReplyForm";
	}
	
	/*
	 * 물물교환 게시글에 사용자가 입력한 댓글의 내용을 가져오는 메소드이다.
	 * 해당글을 자세히 본 후 "댓글등록"을 누르면 실행된다.
	 * readCountDown은 해당댓글을 등록해도 조회수가 올라가지 않도록 하는 메소드이며,
	 * 
	 */
	
	@RequestMapping("/tradeReplyWrite.do")
	public String tradeReplyWrite(MultipartHttpServletRequest request, HttpSession session) throws Exception {

		this.tradeService.readCountDown(Integer.parseInt(request.getParameter("trade_num")));

		String mul_name = tradeService.Upload(request);

		HashMap<String,Object> Map = new HashMap<String,Object>();
		Map.put("trade_com_title", request.getParameter("trade_com_title"));
		Map.put("trade_com_content", request.getParameter("trade_com_content"));
		Map.put("user_id", request.getParameter("user_id"));
		Map.put("trade_num", request.getParameter("trade_num"));
		Map.put("trade_com_phone", request.getParameter("trade_com_phone"));
		Map.put("trade_com_pic", mul_name);

		tradeService.insertreply(Map);

		return "redirect:tradeView.do?trade_num=" + request.getParameter("trade_num") + "&pg=" + request.getParameter("pg");
	}

	@RequestMapping("/tradeReplyDelete.do")
	public String tradeReplyDelete(int trade_com_num, int trade_num, int pg) {

		tradeService.deletereply(trade_com_num);
		tradeService.readCountDown(trade_num);

		return "redirect:tradeView.do?trade_num=" + trade_num + "&pg=" + pg;
	}// end delete


	@RequestMapping("go.do")
	public String go() {
		tradeService.updateDonate();
		return "redirect:donateList.do";
	}
	
}
