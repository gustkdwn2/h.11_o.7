package edu.kosta.controller.ur.wishlist;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import edu.kosta.model.dto.ur.web_manage.Web_ManageDTO;
import edu.kosta.model.dto.ur.wishlist.WishlistDTO;
import edu.kosta.model.dto.user.UserDTO;
import edu.kosta.service.ur.web_manage.Web_ManageService;
import edu.kosta.service.ur.wishlist.WishlistService;

/* 
 * @author (Seung Mo)
 * 
 * 이 컨트롤러는 관심상품(wishlist)에 관련된 컨트롤러이다.
 * */
@Controller
public class WishlistController {
	
	@Resource
	WishlistService wishlistService;
	@Resource
	private Web_ManageService web_manageService;
	
	/*
	 * 이 메소드는 관심상품(Wishlist)을 눌렀을때 로그인한 회원이 등록한 관심상품(Wishlist)의 목록을 보여준다.
	 * @Param loginUser					로그인한 유저의 아이디
	 * @see wishlist_list.jsp
	*/
	
	@RequestMapping(value = "/wishlist_list.do", method = RequestMethod.GET)
	public String wishlist_form(Locale locale, Model model,WishlistDTO dto, HttpSession session) {
		UserDTO loginUser = (UserDTO) session.getAttribute("loginUser");
		Web_ManageDTO mainlogo = web_manageService.getMainLogo();
		
		HashMap<String,Object> map = new HashMap<String,Object>();
		map.put("user_id", loginUser.getUser_id());
		
		List<WishlistDTO> list = wishlistService.Wishlist_list(map);
		
		model.addAttribute("mainlogo", mainlogo);
		model.addAttribute("wishlist",list);
		
		return "wishlist/wishlist_list";
	}
	
	
	/*
	 * 이 메소드는 itemDetail.jsp에서 하트모양이미지를 클릭해서 관심상품을 등록하는 메소드이다. 
	 * @Param loginUser					로그인한 유저의 아이디
	 * @see wishlist_list.jsp
	*/
	@RequestMapping(value = "/wishlist_insert.do", method = RequestMethod.POST)
	public String wishlist_insert(Locale locale, Model model,WishlistDTO dto, HttpSession session) {
		
	    UserDTO loginUser = (UserDTO) session.getAttribute("loginUser");
	    dto.setUser_id(loginUser.getUser_id());
	    Web_ManageDTO mainlogo = web_manageService.getMainLogo();
	    model.addAttribute("mainlogo", mainlogo);
		model.addAttribute("loginUser", loginUser);
		wishlistService.Wishlist_insert(dto);
		
		return "wishlist/wishlist_list";
	}
	
	/*
	 * 이 메소드는 itemDetail.jsp에서 하트모양이미지를 클릭해서 관심상품을 해제하는 메소드이다. 
	 * @see wishlist_list.jsp
	*/
	@RequestMapping(value = "/wishlist_delete.do", method = RequestMethod.GET)
	public String wishlist_delete(Locale locale, Model model,WishlistDTO dto) {
		wishlistService.Wishlist_delete(dto);
		
		return "redirect:/wishlist_list.do";
	}
	
	/*
	 * 이 메소드는 wishlist_list.jsp에서 X를 클릭해서 관심상품을 해제하는 메소드이다. 
	 * @see wishlist_list.jsp
	*/
	@RequestMapping(value = "/wishlist_itemDetail_delete.do", method = RequestMethod.POST)
	public String wishlist_itemDetail_delete(Locale locale, Model model,HttpServletRequest request , WishlistDTO dto) {
		String item_num = request.getParameter("item_num");
		String user_id = request.getParameter("loginUser");
		
		HashMap<String,Object> map = new HashMap<String,Object>();
		map.put("item_num", item_num);
		map.put("user_id", user_id);
		
		wishlistService.wishlist_itemDetail_delete(map);
		
		return "redirect:/itemDetail.do?item_num="+item_num;
	}
	
}
