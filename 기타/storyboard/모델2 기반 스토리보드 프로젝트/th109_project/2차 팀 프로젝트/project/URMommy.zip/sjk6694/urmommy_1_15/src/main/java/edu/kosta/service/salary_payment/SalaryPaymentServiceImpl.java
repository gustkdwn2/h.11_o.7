package edu.kosta.service.salary_payment;

import java.util.ArrayList;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import edu.kosta.model.dto.salary_payment.SalaryPaymentDAO;
import edu.kosta.model.dto.salary_payment.SalaryPaymentDTO;

@Component
public class SalaryPaymentServiceImpl implements SalaryPaymentService {
	@Autowired
	private SqlSession sqlsession; // SqlSessionTemplate
	
	@Override
	public void insertSalaryPaymentList(SalaryPaymentDTO spDTO) {
		SalaryPaymentDAO spDAO = sqlsession.getMapper(SalaryPaymentDAO.class);
		spDAO.insertSalaryPaymentList(spDTO);
		
	}

	@Override
	public ArrayList<SalaryPaymentDTO> selectSalaryPaymentList() {
		SalaryPaymentDAO spDAO = sqlsession.getMapper(SalaryPaymentDAO.class);
		ArrayList<SalaryPaymentDTO> salaryPaymentList = new ArrayList<SalaryPaymentDTO>();
		salaryPaymentList = spDAO.selectSalaryPaymentList();

		return salaryPaymentList;
	}

}
