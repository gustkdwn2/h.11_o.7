package board.model;

import java.io.Serializable;
import java.sql.Timestamp;

public class BoardVO implements Serializable {

	private int qa_num, ref, re_step, re_level, no_num;
	private String qa_writer, qa_passwd, qa_title, qa_content;
	private String no_title, no_content, no_img;
	private Timestamp qa_date, no_date;

	public int getQa_num() {
		return qa_num;
	}

	public void setQa_num(int qa_num) {
		this.qa_num = qa_num;
	}

	public int getRef() {
		return ref;
	}

	public void setRef(int ref) {
		this.ref = ref;
	}

	public int getRe_step() {
		return re_step;
	}

	public void setRe_step(int re_step) {
		this.re_step = re_step;
	}

	public int getRe_level() {
		return re_level;
	}

	public void setRe_level(int re_level) {
		this.re_level = re_level;
	}

	public int getNo_num() {
		return no_num;
	}

	public void setNo_num(int no_num) {
		this.no_num = no_num;
	}

	public String getQa_writer() {
		return qa_writer;
	}

	public void setQa_writer(String qa_writer) {
		this.qa_writer = qa_writer;
	}

	public String getQa_passwd() {
		return qa_passwd;
	}

	public void setQa_passwd(String qa_passwd) {
		this.qa_passwd = qa_passwd;
	}

	public String getQa_title() {
		return qa_title;
	}

	public void setQa_title(String qa_title) {
		this.qa_title = qa_title;
	}

	public String getQa_content() {
		return qa_content;
	}

	public void setQa_content(String qa_content) {
		this.qa_content = qa_content;
	}

	public String getNo_title() {
		return no_title;
	}

	public void setNo_title(String no_title) {
		this.no_title = no_title;
	}

	public String getNo_content() {
		return no_content;
	}

	public void setNo_content(String no_content) {
		this.no_content = no_content;
	}

	public String getNo_img() {
		return no_img;
	}

	public void setNo_img(String no_img) {
		this.no_img = no_img;
	}

	public Timestamp getQa_date() {
		return qa_date;
	}

	public void setQa_date(Timestamp qa_date) {
		this.qa_date = qa_date;
	}

	public Timestamp getNo_date() {
		return no_date;
	}

	public void setNo_date(Timestamp no_date) {
		this.no_date = no_date;
	}

}
