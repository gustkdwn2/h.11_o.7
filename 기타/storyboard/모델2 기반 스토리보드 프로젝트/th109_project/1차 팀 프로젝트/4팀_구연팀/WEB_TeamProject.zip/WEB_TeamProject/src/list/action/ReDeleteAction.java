package list.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import project.action.CommandAction;

public class ReDeleteAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		request.setCharacterEncoding("UTF-8");
		
		String mr_email = request.getParameter("mr_email");
		String pageNum = request.getParameter("pageNum");

		request.setAttribute("mr_email", mr_email);
		request.setAttribute("pageNum", new Integer(pageNum));

		return "/list/memDeleteForm_re.jsp";
	}

}
