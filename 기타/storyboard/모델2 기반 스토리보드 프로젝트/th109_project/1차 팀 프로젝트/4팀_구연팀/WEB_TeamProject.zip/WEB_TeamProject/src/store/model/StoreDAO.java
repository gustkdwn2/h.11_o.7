package store.model;

import java.sql.*;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import dbclose.util.CloseUtil;

public class StoreDAO {

	private static StoreDAO instance = new StoreDAO();

	public StoreDAO() {

	}

	public static StoreDAO getInstance() {
		return instance;
	}

	public Connection getConnection() throws Exception {

		Context ctx = new InitialContext();
		DataSource ds = (DataSource) ctx.lookup("java:comp/env/jdbc:ProjectDB");

		return ds.getConnection();
	}

	public int getListAllCount() throws Exception {

		int count = 0;

		Connection conn = getConnection();
		PreparedStatement pstmt = conn.prepareStatement("SELECT COUNT(*) FROM MEMBERS_RE");
		ResultSet rs = pstmt.executeQuery();

		if (rs.next())
			count = rs.getInt(1);

		CloseUtil.close(rs);
		CloseUtil.close(pstmt);
		CloseUtil.close(conn);

		return count;
	}

	public int getListAllCount(String btn_type) throws Exception {

		int count = 0;

		Connection conn = getConnection();

		PreparedStatement pstmt = conn.prepareStatement("SELECT COUNT(*) FROM MEMBERS_RE WHERE MR_TYPE = ?");
		pstmt.setString(1, btn_type);

		ResultSet rs = pstmt.executeQuery();

		if (rs.next())
			count = rs.getInt(1);

		CloseUtil.close(rs);
		CloseUtil.close(pstmt);
		CloseUtil.close(conn);

		return count;
	}

	public List<StoreVO> getSelectAll(int start, int end) throws Exception {

		List list = null;
		StringBuffer sb = new StringBuffer();

		sb.append("SELECT MR_NUM, MR_EMAIL, MR_TYPE, MR_NAME, MR_IMG, MR_PHONE, MR_LOCATE, MR_CONTENT, MR_INFO, R ");
		sb.append(
				"FROM (SELECT MR_NUM, MR_EMAIL, MR_TYPE, MR_NAME, MR_IMG, MR_PHONE, MR_LOCATE, MR_CONTENT, MR_INFO, ROWNUM R ");
		sb.append("FROM (SELECT MR_NUM, MR_EMAIL, MR_TYPE, MR_NAME, MR_IMG, MR_PHONE, MR_LOCATE, MR_CONTENT, MR_INFO ");
		sb.append("FROM MEMBERS_RE ORDER BY MR_NUM DESC) ORDER BY MR_NUM DESC) WHERE R >= ? AND R <= ?");

		Connection conn = getConnection();

		PreparedStatement pstmt = conn.prepareStatement(sb.toString());
		pstmt.setInt(1, start);
		pstmt.setInt(2, end);
		ResultSet rs = pstmt.executeQuery();

		if (rs.next()) {

			list = new ArrayList(end);

			do {
				StoreVO vo = new StoreVO();

				vo.setMr_num(rs.getInt("mr_num"));
				vo.setMr_email(rs.getString("mr_email"));
				vo.setMr_type(rs.getString("mr_type"));
				vo.setMr_name(rs.getString("mr_name"));
				vo.setMr_img(rs.getString("mr_img"));
				vo.setMr_phone(rs.getString("mr_phone"));
				vo.setMr_locate(rs.getString("mr_locate"));
				vo.setMr_content(rs.getString("mr_content"));
				vo.setMr_info(rs.getString("mr_info"));

				list.add(vo);

			} while (rs.next());
		}

		CloseUtil.close(rs);
		CloseUtil.close(pstmt);
		CloseUtil.close(conn);

		return list;
	}

	public List<StoreVO> getSelectAll(String btn_type, int start, int end) throws Exception {

		List list = null;
		StringBuffer sb = new StringBuffer();

		sb.append("SELECT MR_NUM, MR_EMAIL, MR_TYPE, MR_NAME, MR_IMG, MR_PHONE, MR_LOCATE, MR_CONTENT, MR_INFO, R ");
		sb.append(
				"FROM (SELECT MR_NUM, MR_EMAIL, MR_TYPE, MR_NAME, MR_IMG, MR_PHONE, MR_LOCATE, MR_CONTENT, MR_INFO, ROWNUM R ");
		sb.append("FROM (SELECT MR_NUM, MR_EMAIL, MR_TYPE, MR_NAME, MR_IMG, MR_PHONE, MR_LOCATE, MR_CONTENT, MR_INFO ");
		sb.append("FROM MEMBERS_RE WHERE MR_TYPE = ? ORDER BY MR_NUM DESC) ORDER BY MR_NUM DESC) ");
		sb.append("WHERE R >= ? AND R <= ?");

		Connection conn = getConnection();

		PreparedStatement pstmt = conn.prepareStatement(sb.toString());
		pstmt.setString(1, btn_type);
		pstmt.setInt(2, start);
		pstmt.setInt(3, end);
		ResultSet rs = pstmt.executeQuery();

		if (rs.next()) {

			list = new ArrayList(end);

			do {
				StoreVO vo = new StoreVO();

				vo.setMr_num(rs.getInt("mr_num"));
				vo.setMr_email(rs.getString("mr_email"));
				vo.setMr_type(rs.getString("mr_type"));
				vo.setMr_name(rs.getString("mr_name"));
				vo.setMr_img(rs.getString("mr_img"));
				vo.setMr_phone(rs.getString("mr_phone"));
				vo.setMr_locate(rs.getString("mr_locate"));
				vo.setMr_content(rs.getString("mr_content"));
				vo.setMr_info(rs.getString("mr_info"));

				list.add(vo);

			} while (rs.next());
		}

		CloseUtil.close(rs);
		CloseUtil.close(pstmt);
		CloseUtil.close(conn);

		return list;
	}
	
	public int insert(StoreVO vo) throws Exception {

		StringBuffer sb = new StringBuffer();
		sb.append("INSERT INTO REVIEW VALUES (?, ?, ?, ?, ?, ?, ?)");
		
		Connection conn = getConnection();
		PreparedStatement pstmt = conn.prepareStatement(sb.toString());
		
		pstmt.setInt(1, vo.getMr_num());
		pstmt.setString(2, vo.getV_grade());
		pstmt.setString(3, vo.getV_writer());
		pstmt.setString(4, vo.getV_content());
		pstmt.setString(5, vo.getV_img());
		pstmt.setTimestamp(6, vo.getV_date());
		pstmt.setInt(7, vo.getV_type());

		pstmt.executeUpdate();
		
		CloseUtil.close(pstmt);
		CloseUtil.close(conn);

		return 0;
	}

	public int getReviewCount(int num) throws Exception {

		int count = 0;

		Connection conn = getConnection();
		
		PreparedStatement pstmt = conn.prepareStatement("SELECT COUNT(*) FROM REVIEW WHERE MR_NUM = ?");
		
		pstmt.setInt(1, num);
		ResultSet rs = pstmt.executeQuery();

		if (rs.next())
			count = rs.getInt(1);

		CloseUtil.close(rs);
		CloseUtil.close(pstmt);
		CloseUtil.close(conn);

		return count;
	}

	public List<StoreVO> getReview(int num, int start, int end) throws Exception {
		
		List list = null;
		StringBuffer sb = new StringBuffer();

		sb.append("SELECT V_GRADE, V_WRITER, V_CONTENT, V_IMG, V_DATE, V_TYPE, R ");
		sb.append("FROM (SELECT V_GRADE, V_WRITER, V_CONTENT, V_IMG, V_DATE, V_TYPE, ROWNUM R ");
		sb.append("FROM (SELECT V_GRADE, V_WRITER, V_CONTENT, V_IMG, V_DATE, V_TYPE ");
		sb.append("FROM REVIEW WHERE MR_NUM = ? ORDER BY V_DATE DESC) ORDER BY V_DATE DESC) ");
		sb.append("WHERE R >= ? AND R <= ?");

		Connection conn = getConnection();

		PreparedStatement pstmt = conn.prepareStatement(sb.toString());
		pstmt.setInt(1, num);
		pstmt.setInt(2, start);
		pstmt.setInt(3, end);
		
		ResultSet rs = pstmt.executeQuery();

		if (rs.next()) {

			list = new ArrayList();

			do {
				StoreVO vo = new StoreVO();
				
				vo.setV_grade(rs.getString("v_grade"));
				vo.setV_writer(rs.getString("v_writer"));
				vo.setV_content(rs.getString("v_content"));
				vo.setV_img(rs.getString("v_img"));
				vo.setV_date(rs.getTimestamp("v_date"));
				vo.setV_type(rs.getInt("v_type"));
				
				list.add(vo);
				
			} while (rs.next());
		}

		CloseUtil.close(rs);
		CloseUtil.close(pstmt);
		CloseUtil.close(conn);

		return list;
	}
	
	public double avg(int num) throws Exception {
		
		double temp = 0.0;

		Connection conn = getConnection();
		PreparedStatement pstmt =
				conn.prepareStatement("SELECT AVG(V_GRADE) FROM REVIEW WHERE MR_NUM = ?");
		pstmt.setInt(1, num);

		ResultSet rs = pstmt.executeQuery();

		if (rs.next())
			temp = rs.getDouble(1);

		CloseUtil.close(rs);
		CloseUtil.close(pstmt);
		CloseUtil.close(conn);

		return temp;
	}
	
	public int addPoint(String id) throws Exception {
		
		StringBuffer sb = new StringBuffer();
		sb.append("UPDATE MEMBERS SET M_POINT = M_POINT + 50 WHERE M_EMAIL = ?");

		Connection conn = getConnection();
		
		PreparedStatement pstmt = conn.prepareStatement(sb.toString());
		pstmt.setString(1, id);
		
		pstmt.executeUpdate();
		
		int point = 0;
		
		sb = new StringBuffer();
		sb.append("SELECT M_POINT FROM MEMBERS WHERE M_EMAIL = ?");
		
		pstmt = conn.prepareStatement(sb.toString());
		pstmt.setString(1, id);
		
		ResultSet rs = pstmt.executeQuery();
		
		while (rs.next())
			point = rs.getInt("m_point");

		CloseUtil.close(pstmt);
		CloseUtil.close(conn);
		
		return point;
	}
	
	public int topRank() throws Exception {

		int mr_num = 0;
		
		String sql = "SELECT MR_NUM, AVG(V_GRADE) FROM REVIEW GROUP BY MR_NUM HAVING AVG(V_GRADE) "
				+ "= (SELECT MAX(AVG(V_GRADE)) FROM REVIEW GROUP BY MR_NUM)";

		Connection conn = getConnection();
		
		PreparedStatement pstmt = conn.prepareStatement(sql);
		ResultSet rs = pstmt.executeQuery();

		while (rs.next())
			mr_num = rs.getInt(1);

		CloseUtil.close(rs);
		CloseUtil.close(pstmt);
		CloseUtil.close(conn);

		return mr_num;
	}
	
	public int topRank(String type) throws Exception {

		int mr_num = 0;
		String sql = "SELECT MR_NUM FROM REVIEW GROUP BY MR_NUM HAVING AVG(V_GRADE)=(SELECT MAX(AVG(V_GRADE))"
				+ " FROM REVIEW GROUP BY MR_NUM HAVING MR_NUM IN (SELECT MR_NUM FROM MEMBERS_RE WHERE MR_TYPE = ?))";

		Connection conn = getConnection();

		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, type);
		
		ResultSet rs = pstmt.executeQuery();

		while (rs.next())
			mr_num = Integer.parseInt(rs.getString("mr_num"));

		CloseUtil.close(rs);
		CloseUtil.close(pstmt);
		CloseUtil.close(conn);

		return mr_num;
	}

}
