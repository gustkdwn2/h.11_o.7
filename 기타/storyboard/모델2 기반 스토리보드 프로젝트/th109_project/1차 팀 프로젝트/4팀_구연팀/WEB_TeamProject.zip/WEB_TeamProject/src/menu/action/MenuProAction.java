package menu.action;

import java.sql.Timestamp;

import javax.servlet.http.*;

import menu.model.*;
import project.action.CommandAction;

public class MenuProAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		request.setCharacterEncoding("UTF-8");
		
		HttpSession session = request.getSession();
		String id = (String) session.getAttribute("memID_re");
		
		MenuVO vo = new MenuVO();
		MenuDAO dao = MenuDAO.getInstance();
		
		int num = dao.getMr_num(id);
		
		vo.setMr_num(num);
		vo.setMenu_item(request.getParameter("menu"));
		vo.setMenu_price(Integer.parseInt(request.getParameter("price")));
		vo.setMenu_date(new Timestamp(System.currentTimeMillis()));
		
		dao.insert(vo);

		return "/menu/menuPro.jsp";
	}
}
