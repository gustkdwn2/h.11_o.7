package order.action;

import java.util.List;

import javax.servlet.http.*;

import order.model.OrderDAO;
import project.action.CommandAction;
import store.model.StoreVO;

public class OrderProAction implements CommandAction {
	
	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		request.setCharacterEncoding("UTF-8");
		
		int qty = 0;
		int total = 0;
		
		for( int i = 1; i < 11; i++ ) {
			
			if( Integer.parseInt(request.getParameter("qty")) == i )
				qty = i;
		}
		
		HttpSession session = request.getSession();
		
		int num = Integer.parseInt(request.getParameter("num"));
		String email = (String) session.getAttribute("memID");
		
		StoreVO vo = new StoreVO();
		OrderDAO dao = OrderDAO.getInstance();
		
		vo.setMr_num(num);
		vo.setOr_item(request.getParameter("item"));
		vo.setOr_price(Integer.parseInt(request.getParameter("price")));
		vo.setOr_qty(qty);
		vo.setOr_email(email);
		
		total = dao.addOder(vo);
		
		int count = dao.getOrderCount(num, email);
		int menu_count = dao.getMenuCount(num);
		
		List list = dao.getMenu(num);
		List order_list = dao.getOrder(num, email);
		
		vo = dao.getDetail(num);
		
		request.setAttribute("vo", vo);
		request.setAttribute("list", list);
		request.setAttribute("order_list", order_list);
		request.setAttribute("num", num);
		request.setAttribute("count", count);
		request.setAttribute("menu_count", menu_count);
		request.setAttribute("total", total);

		return "/store/order.jsp";
	}

}
