package menu.action;

import java.util.List;

import javax.servlet.http.*;

import menu.model.MenuDAO;
import project.action.CommandAction;

public class MenuListAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		request.setCharacterEncoding("UTF-8");
		
		HttpSession session = request.getSession();
		String id = (String) session.getAttribute("memID_re");
		
		List list = null;
		MenuDAO dao = MenuDAO.getInstance();
		
		int num = dao.getMr_num(id);
		int count = dao.getListAllCount(num);
		
		if( count > 0 )
			list = dao.getSelectAll( count, num );
		
		request.setAttribute("list", list);
		request.setAttribute("count", count);

		return "/menu/menuList.jsp";
	}
}
