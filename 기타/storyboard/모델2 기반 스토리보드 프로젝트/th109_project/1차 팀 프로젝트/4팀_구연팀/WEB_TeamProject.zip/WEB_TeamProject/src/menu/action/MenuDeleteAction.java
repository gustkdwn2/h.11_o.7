package menu.action;

import javax.servlet.http.*;

import menu.model.*;
import project.action.CommandAction;

public class MenuDeleteAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		request.setCharacterEncoding("UTF-8");
		
		HttpSession session = request.getSession();
		String id = (String) session.getAttribute("memID_re");
		
		MenuVO vo = new MenuVO();
		MenuDAO dao = MenuDAO.getInstance();
		
		int num = dao.getMr_num(id);
		
		vo.setMr_num(num);
		vo.setMenu_item(request.getParameter("menu"));
		
		dao.delete(vo);

		return "/menu/menuPro.jsp";
	}
}
