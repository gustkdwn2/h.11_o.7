package join.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import join.model.JoinDAO;
import project.action.CommandAction;

public class ConfirmNameAction implements CommandAction {
	
	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		request.setCharacterEncoding("UTF-8");
		
	    String name = request.getParameter("name");
	    
	    JoinDAO dao = JoinDAO.getInstance();
        int check = dao.confirmName(name);
        
        request.setAttribute("name", name);
        request.setAttribute("check", new Integer(check));
        
		return "/join/confirmName.jsp";
	}

}
