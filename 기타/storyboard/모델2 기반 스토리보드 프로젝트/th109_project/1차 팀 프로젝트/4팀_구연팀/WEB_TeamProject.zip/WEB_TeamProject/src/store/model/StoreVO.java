package store.model;

import java.io.Serializable;
import java.sql.Timestamp;

public class StoreVO implements Serializable {

	private int mr_num;
	private String mr_email, mr_type, mr_name, mr_img, mr_phone, mr_locate, mr_content, mr_info, mr_img1, mr_img2,
			mr_img3;

	private int menu_price, or_price, or_qty, v_type;
	private String menu_item, or_item, or_email, v_grade, v_writer, v_content, v_img;

	private Timestamp menu_date, v_date;

	public int getMr_num() {
		return mr_num;
	}

	public void setMr_num(int mr_num) {
		this.mr_num = mr_num;
	}

	public String getMr_email() {
		return mr_email;
	}

	public void setMr_email(String mr_email) {
		this.mr_email = mr_email;
	}

	public String getMr_type() {
		return mr_type;
	}

	public void setMr_type(String mr_type) {
		this.mr_type = mr_type;
	}

	public String getMr_name() {
		return mr_name;
	}

	public void setMr_name(String mr_name) {
		this.mr_name = mr_name;
	}

	public String getMr_img() {
		return mr_img;
	}

	public void setMr_img(String mr_img) {
		this.mr_img = mr_img;
	}

	public String getMr_phone() {
		return mr_phone;
	}

	public void setMr_phone(String mr_phone) {
		this.mr_phone = mr_phone;
	}

	public String getMr_locate() {
		return mr_locate;
	}

	public void setMr_locate(String mr_locate) {
		this.mr_locate = mr_locate;
	}

	public String getMr_content() {
		return mr_content;
	}

	public void setMr_content(String mr_content) {
		this.mr_content = mr_content;
	}

	public String getMr_info() {
		return mr_info;
	}

	public void setMr_info(String mr_info) {
		this.mr_info = mr_info;
	}

	public int getMenu_price() {
		return menu_price;
	}

	public void setMenu_price(int menu_price) {
		this.menu_price = menu_price;
	}

	public String getOr_email() {
		return or_email;
	}

	public void setOr_email(String or_email) {
		this.or_email = or_email;
	}

	public int getOr_price() {
		return or_price;
	}

	public void setOr_price(int or_price) {
		this.or_price = or_price;
	}

	public int getOr_qty() {
		return or_qty;
	}

	public void setOr_qty(int or_qty) {
		this.or_qty = or_qty;
	}

	public String getMenu_item() {
		return menu_item;
	}

	public void setMenu_item(String menu_item) {
		this.menu_item = menu_item;
	}

	public String getOr_item() {
		return or_item;
	}

	public void setOr_item(String or_item) {
		this.or_item = or_item;
	}

	public String getV_grade() {
		return v_grade;
	}

	public void setV_grade(String v_greade) {
		this.v_grade = v_greade;
	}

	public String getV_writer() {
		return v_writer;
	}

	public void setV_writer(String v_writer) {
		this.v_writer = v_writer;
	}

	public String getV_content() {
		return v_content;
	}

	public void setV_content(String v_content) {
		this.v_content = v_content;
	}

	public String getV_img() {
		return v_img;
	}

	public void setV_img(String v_img) {
		this.v_img = v_img;
	}

	public Timestamp getMenu_date() {
		return menu_date;
	}

	public void setMenu_date(Timestamp menu_date) {
		this.menu_date = menu_date;
	}

	public Timestamp getV_date() {
		return v_date;
	}

	public void setV_date(Timestamp v_date) {
		this.v_date = v_date;
	}

	public String getMr_img1() {
		return mr_img1;
	}

	public void setMr_img1(String mr_img1) {
		this.mr_img1 = mr_img1;
	}

	public String getMr_img2() {
		return mr_img2;
	}

	public void setMr_img2(String mr_img2) {
		this.mr_img2 = mr_img2;
	}

	public String getMr_img3() {
		return mr_img3;
	}

	public void setMr_img3(String mr_img3) {
		this.mr_img3 = mr_img3;
	}

	public int getV_type() {
		return v_type;
	}

	public void setV_type(int v_type) {
		this.v_type = v_type;
	}

}
