package join.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import join.model.JoinDAO;
import project.action.CommandAction;

public class ReConfirmIdAction implements CommandAction {
	
	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {

		request.setCharacterEncoding("UTF-8");
		
		String email1 = request.getParameter("email1");
		String email2 = request.getParameter("email2");
		
		String id = email1 + "@" + email2;
		
		JoinDAO dao = JoinDAO.getInstance();
		
		int check = dao.confirmId_re(id);
		int check2 = dao.confirmId(id);

		request.setAttribute("id", id);
		request.setAttribute("check", new Integer(check));
		request.setAttribute("check2", new Integer(check2));
		request.setAttribute("email1", email1);
		request.setAttribute("email2", email2);

		return "/join/confirmId_re.jsp";
	}

}
