package login.action;

import javax.servlet.http.*;

import project.action.CommandAction;

public class LogoutProAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		request.setCharacterEncoding("UTF-8");
		
		HttpSession session = request.getSession();
		
		session.removeAttribute("id");
		session.removeAttribute("passwd");

		session.invalidate();

		return "/login/logout.jsp";
	}

}
