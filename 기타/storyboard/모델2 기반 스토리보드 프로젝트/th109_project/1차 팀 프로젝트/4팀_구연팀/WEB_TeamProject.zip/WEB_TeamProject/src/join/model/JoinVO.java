package join.model;

import java.io.Serializable;
import java.sql.Timestamp;

public class JoinVO implements Serializable {

	private int m_point, mr_num;
	private String m_email, m_passwd, m_name, m_grade, m_pwq, m_pwa, mr_info, mr_img1, mr_img2, mr_img3;
	private String mr_email, mr_passwd, mr_pwq, mr_pwa, mr_type, mr_name, mr_img, mr_phone, mr_locate, mr_content;
	private Timestamp m_date, mr_date;

	public int getM_point() {
		return m_point;
	}

	public void setM_point(int m_point) {
		this.m_point = m_point;
	}

	public int getMr_num() {
		return mr_num;
	}

	public void setMr_num(int mr_num) {
		this.mr_num = mr_num;
	}

	public String getM_email() {
		return m_email;
	}

	public void setM_email(String m_email) {
		this.m_email = m_email;
	}

	public String getM_passwd() {
		return m_passwd;
	}

	public void setM_passwd(String m_passwd) {
		this.m_passwd = m_passwd;
	}

	public String getM_name() {
		return m_name;
	}

	public void setM_name(String m_name) {
		this.m_name = m_name;
	}

	public String getM_grade() {
		return m_grade;
	}

	public void setM_grade(String m_grade) {
		this.m_grade = m_grade;
	}

	public String getM_pwq() {
		return m_pwq;
	}

	public void setM_pwq(String m_pwq) {
		this.m_pwq = m_pwq;
	}

	public String getM_pwa() {
		return m_pwa;
	}

	public void setM_pwa(String m_pwa) {
		this.m_pwa = m_pwa;
	}

	public String getMr_email() {
		return mr_email;
	}

	public void setMr_email(String mr_email) {
		this.mr_email = mr_email;
	}

	public String getMr_passwd() {
		return mr_passwd;
	}

	public void setMr_passwd(String mr_passwd) {
		this.mr_passwd = mr_passwd;
	}

	public String getMr_pwq() {
		return mr_pwq;
	}

	public void setMr_pwq(String mr_pwq) {
		this.mr_pwq = mr_pwq;
	}

	public String getMr_pwa() {
		return mr_pwa;
	}

	public void setMr_pwa(String mr_pwa) {
		this.mr_pwa = mr_pwa;
	}

	public String getMr_type() {
		return mr_type;
	}

	public void setMr_type(String mr_type) {
		this.mr_type = mr_type;
	}

	public String getMr_name() {
		return mr_name;
	}

	public void setMr_name(String mr_name) {
		this.mr_name = mr_name;
	}

	public String getMr_img() {
		return mr_img;
	}

	public void setMr_img(String mr_img) {
		this.mr_img = mr_img;
	}

	public String getMr_phone() {
		return mr_phone;
	}

	public void setMr_phone(String mr_phone) {
		this.mr_phone = mr_phone;
	}

	public String getMr_locate() {
		return mr_locate;
	}

	public void setMr_locate(String mr_locate) {
		this.mr_locate = mr_locate;
	}

	public String getMr_content() {
		return mr_content;
	}

	public String getMr_info() {
		return mr_info;
	}

	public void setMr_info(String mr_info) {
		this.mr_info = mr_info;
	}

	public void setMr_content(String mr_content) {
		this.mr_content = mr_content;
	}

	public Timestamp getM_date() {
		return m_date;
	}

	public void setM_date(Timestamp m_date) {
		this.m_date = m_date;
	}

	public Timestamp getMr_date() {
		return mr_date;
	}

	public void setMr_date(Timestamp mr_date) {
		this.mr_date = mr_date;
	}

	public String getMr_img1() {
		return mr_img1;
	}

	public void setMr_img1(String mr_img1) {
		this.mr_img1 = mr_img1;
	}

	public String getMr_img2() {
		return mr_img2;
	}

	public void setMr_img2(String mr_img2) {
		this.mr_img2 = mr_img2;
	}

	public String getMr_img3() {
		return mr_img3;
	}

	public void setMr_img3(String mr_img3) {
		this.mr_img3 = mr_img3;
	}

}
