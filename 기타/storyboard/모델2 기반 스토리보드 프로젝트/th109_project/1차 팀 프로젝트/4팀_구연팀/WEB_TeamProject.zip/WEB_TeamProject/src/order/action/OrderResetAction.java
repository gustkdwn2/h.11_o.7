package order.action;

import javax.servlet.http.*;

import order.model.OrderDAO;
import project.action.CommandAction;
import store.model.StoreVO;

public class OrderResetAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {

		request.setCharacterEncoding("UTF-8");
		
		HttpSession session = request.getSession();
		
		StoreVO vo = new StoreVO();
		OrderDAO dao = OrderDAO.getInstance();

		int num = Integer.parseInt(request.getParameter("num"));
		
		vo.setMr_num(num);
		vo.setOr_email((String) session.getAttribute("memID"));
		
		dao.allDelete(vo);
		
		session.removeAttribute("memPoint");
		session.setAttribute("memPoint", dao.subPoint(vo.getOr_email()));

		request.setAttribute("num", num);

		return "/store/orderFinish.jsp";
	}
	
}
