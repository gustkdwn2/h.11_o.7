package store.action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import order.model.OrderDAO;
import project.action.CommandAction;
import store.model.*;

public class MenuAction implements CommandAction {
	
	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		request.setCharacterEncoding("UTF-8");
		
		OrderDAO dao = OrderDAO.getInstance();
		String num = request.getParameter("num");
		
		int count = dao.getMenuCount(Integer.parseInt(num));
		double avg = StoreDAO.getInstance().avg(Integer.parseInt(num));
		
		List list = dao.getMenu(Integer.parseInt(num));
		StoreVO vo = dao.getDetail(Integer.parseInt(num));
		
		request.setAttribute("vo", vo);
		request.setAttribute("list", list);
		request.setAttribute("count", count);
		request.setAttribute("avg", avg);

		return "/store/menu.jsp";
	}

}
