package store.action;

import java.util.List;

import javax.servlet.http.*;

import order.model.OrderDAO;
import project.action.CommandAction;
import store.model.*;

public class OrderAction implements CommandAction {
	
	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		request.setCharacterEncoding("UTF-8");
		
		OrderDAO dao = OrderDAO.getInstance();
		HttpSession session = request.getSession();
		
		int num = Integer.parseInt(request.getParameter("num"));
		String email = (String) session.getAttribute("memID");
		
		int count = dao.getOrderCount(num, email);
		int menu_count = dao.getMenuCount(num);
		double avg = StoreDAO.getInstance().avg(num);
		
		List list = dao.getMenu(num);
		List order_list = dao.getOrder(num, email);
		
		StoreVO vo = dao.getDetail(num);
		
		request.setAttribute("vo", vo);
		request.setAttribute("list", list);
		request.setAttribute("order_list", order_list);
		request.setAttribute("num", num);
		request.setAttribute("count", count);
		request.setAttribute("menu_count", menu_count);
		request.setAttribute("avg", avg);

		return "/store/order.jsp";
	}

}
