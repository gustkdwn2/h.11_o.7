package login.action;

import java.io.File;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import join.model.JoinDAO;
import join.model.JoinVO;
import login.model.LoginDAO;
import project.action.CommandAction;

public class LogImgUpdateAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {

		request.setCharacterEncoding("UTF-8");
		
		JoinVO vo = new JoinVO();
		JoinDAO dao = JoinDAO.getInstance();

		HttpSession session = request.getSession();
		String id = (String) session.getAttribute("memID_re");

		int sizeLimit = 10 * 1024 * 1024;
		String savePath = request.getSession().getServletContext().getRealPath("/upload");

		MultipartRequest multi = new MultipartRequest(request, savePath, sizeLimit, "UTF-8",
				new DefaultFileRenamePolicy());

		String filename = multi.getFilesystemName("uploadfile");
		File files = multi.getFile("uploadfile");
		String upfile = multi.getParameter("upfile");

		dao.ImgUpdate(id, filename, upfile);

		int i = 1;
		request.setAttribute("success", i);

		return "/login/logImagePro.jsp";
	}

}
