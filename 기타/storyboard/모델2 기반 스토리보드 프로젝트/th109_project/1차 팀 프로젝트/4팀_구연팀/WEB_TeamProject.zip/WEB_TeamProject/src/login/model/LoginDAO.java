package login.model;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import dbclose.util.CloseUtil;
import join.model.JoinVO;

public class LoginDAO {

	private static LoginDAO instance = new LoginDAO();

	public LoginDAO() {

	}

	public static LoginDAO getInstance() {
		return instance;
	}

	public Connection getConnection() throws Exception {

		Context ctx = new InitialContext();
		DataSource ds = (DataSource) ctx.lookup("java:comp/env/jdbc:ProjectDB");

		return ds.getConnection();
	}

	public int userCheck(String id, String pwd) throws Exception {

		int result = -1;

		String sql = "SELECT M_PASSWD FROM MEMBERS WHERE M_EMAIL = ?";
		String dbpw = "";

		Connection conn = getConnection();

		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, id);

		ResultSet rs = pstmt.executeQuery();

		if (rs.next()) {

			dbpw = rs.getString("m_passwd");

			if (dbpw.equals(pwd))
				result = 1;
			else
				result = 0;
		}
		else
			result = -1;

		CloseUtil.close(rs);
		CloseUtil.close(pstmt);
		CloseUtil.close(conn);

		return result;
	}

	public int userCheck_re(String id, String pwd) throws Exception {

		int result = -1;

		String sql = "SELECT MR_PASSWD FROM MEMBERS_RE WHERE MR_EMAIL = ?";
		String dbpw = "";

		Connection conn = getConnection();

		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, id);

		ResultSet rs = pstmt.executeQuery();

		if (rs.next()) {

			dbpw = rs.getString("mr_passwd");

			if (dbpw.equals(pwd))
				result = 1;
			else
				result = 0;
		}
		else
			result = -1;

		CloseUtil.close(rs);
		CloseUtil.close(pstmt);
		CloseUtil.close(conn);

		return result;
	}

	public JoinVO getMember(String id) throws Exception {

		JoinVO vo = null;

		Connection conn = getConnection();
		
		PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM MEMBERS WHERE M_EMAIL= ?");
		pstmt.setString(1, id);
		
		ResultSet rs = pstmt.executeQuery();

		if (rs.next()) {

			vo = new JoinVO();

			vo.setM_email(rs.getString("m_email"));
			vo.setM_passwd(rs.getString("m_passwd"));
			vo.setM_name(rs.getString("m_name"));
			vo.setM_pwq(rs.getString("m_pwq"));
			vo.setM_pwa(rs.getString("m_pwa"));
		}

		CloseUtil.close(rs);
		CloseUtil.close(pstmt);
		CloseUtil.close(conn);

		return vo;
	}

	public JoinVO getMember_re(String id) throws Exception {

		JoinVO vo = null;

		Connection conn = getConnection();
		
		PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM MEMBERS_RE WHERE MR_EMAIL= ?");
		pstmt.setString(1, id);
		
		ResultSet rs = pstmt.executeQuery();

		if (rs.next()) {

			vo = new JoinVO();

			vo.setMr_email(rs.getString("mr_email"));
			vo.setMr_passwd(rs.getString("mr_passwd"));
			vo.setMr_type(rs.getString("mr_type"));
			vo.setMr_name(rs.getString("mr_name"));
			vo.setMr_img(rs.getString("mr_img"));
			vo.setMr_phone(rs.getString("mr_phone"));
			vo.setMr_locate(rs.getString("mr_locate"));
			vo.setMr_content(rs.getString("mr_content"));
			vo.setMr_info(rs.getString("mr_info"));
			vo.setMr_pwq(rs.getString("mr_pwq"));
			vo.setMr_pwa(rs.getString("mr_pwa"));
		}

		CloseUtil.close(rs);
		CloseUtil.close(pstmt);
		CloseUtil.close(conn);

		return vo;
	}

	public void updateMember(JoinVO vo) throws Exception {

		Connection conn = getConnection();

		StringBuffer sb = new StringBuffer();
		sb.append("UPDATE MEMBERS SET M_NAME = ?, M_PWQ = ? , M_PWA = ? WHERE M_EMAIL = ?");

		PreparedStatement pstmt = conn.prepareStatement(sb.toString());

		pstmt.setString(1, vo.getM_name());
		pstmt.setString(2, vo.getM_pwq());
		pstmt.setString(3, vo.getM_pwa());
		pstmt.setString(4, vo.getM_email());

		pstmt.executeUpdate();

		CloseUtil.close(pstmt);
		CloseUtil.close(conn);
	}

	public void updateMember_re(JoinVO vo) throws Exception {

		StringBuffer sb = new StringBuffer();
		
		Connection conn = getConnection();
		
		sb.append("UPDATE MEMBERS_RE SET MR_TYPE = ?, MR_NAME = ?, MR_PHONE = ?, MR_LOCATE = ?, ");
		sb.append("MR_CONTENT = ?, MR_INFO = ?, MR_PWQ = ?, MR_PWA = ? WHERE MR_EMAIL = ?");

		PreparedStatement pstmt = conn.prepareStatement(sb.toString());

		pstmt.setString(1, vo.getMr_type());
		pstmt.setString(2, vo.getMr_name());
		pstmt.setString(3, vo.getMr_phone());
		pstmt.setString(4, vo.getMr_locate());
		pstmt.setString(5, vo.getMr_content());
		pstmt.setString(6, vo.getMr_info());
		pstmt.setString(7, vo.getMr_pwq());
		pstmt.setString(8, vo.getMr_pwa());
		pstmt.setString(9, vo.getMr_email());

		pstmt.executeUpdate();

		CloseUtil.close(pstmt);
		CloseUtil.close(conn);
	}

	public void deleteMember(String id) throws Exception {
		
		Connection conn = getConnection();
		
		PreparedStatement pstmt = conn.prepareStatement("DELETE FROM MEMBERS WHERE M_EMAIL = ?");
		pstmt.setString(1, id);
		
		pstmt.executeUpdate();

		CloseUtil.close(pstmt);
		CloseUtil.close(conn);
	}

	public void deleteMember_re(String id) throws Exception {
		
		Connection conn = getConnection();
		
		PreparedStatement pstmt = conn.prepareStatement("DELETE FROM MEMBERS_RE WHERE MR_EMAIL = ?");
		pstmt.setString(1, id);
		
		pstmt.executeUpdate();

		CloseUtil.close(pstmt);
		CloseUtil.close(conn);
	}
	
	public String getName(String id) throws Exception {

		String name = "";

		Connection conn = getConnection();
		String sql = "SELECT M_NAME FROM MEMBERS WHERE M_EMAIL = ?";

		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, id);

		ResultSet rs = pstmt.executeQuery();

		if (rs.next())
			name = rs.getString("m_name");

		CloseUtil.close(rs);
		CloseUtil.close(pstmt);
		CloseUtil.close(conn);

		return name;
	}
	
	public String getName_re(String id) throws Exception {

		String name = "";

		Connection conn = getConnection();
		String sql = "SELECT MR_NAME FROM MEMBERS_RE WHERE MR_EMAIL = ?";

		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, id);

		ResultSet rs = pstmt.executeQuery();

		if (rs.next())
			name = rs.getString("mr_name");

		CloseUtil.close(rs);
		CloseUtil.close(pstmt);
		CloseUtil.close(conn);

		return name;
	}
	
	public int getPoint(String id) throws Exception {
		
		int point = 0;

		Connection conn = getConnection();
		String sql = "SELECT M_POINT FROM MEMBERS WHERE M_EMAIL = ?";

		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, id);

		ResultSet rs = pstmt.executeQuery();

		if (rs.next())
			point = rs.getInt("m_point");
		
		CloseUtil.close(rs);
		CloseUtil.close(pstmt);
		CloseUtil.close(conn);
		
		return point;
	}
	
	public int getMemListAllCount() throws Exception {

		int count = 0;

		Connection conn = getConnection();
		PreparedStatement pstmt = conn.prepareStatement("SELECT COUNT(*) FROM MEMBERS");
		ResultSet rs = pstmt.executeQuery();

		if (rs.next())
			count = rs.getInt(1);

		CloseUtil.close(rs);
		CloseUtil.close(pstmt);
		CloseUtil.close(conn);

		return count;
	}
	
	public List<JoinVO> getMemSelectAll(int start, int end) throws Exception {

		List list = null;
		String sql = "SELECT M_EMAIL, M_NAME, M_DATE FROM (SELECT M_EMAIL, M_NAME, M_DATE, ROWNUM R FROM MEMBERS) WHERE R >= ? AND R <= ?";
		
		Connection conn = getConnection();
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setInt(1, start);
		pstmt.setInt(2, end);
		ResultSet rs = pstmt.executeQuery();

		if (rs.next()) {
			
			list = new ArrayList(end);

			do {
				
				JoinVO vo = new JoinVO();
				
				vo.setM_email(rs.getString("m_email"));
				vo.setM_name(rs.getString("m_name"));
				vo.setM_date(rs.getTimestamp("m_date"));
				list.add(vo);
				
			} while (rs.next());
		}

		CloseUtil.close(rs);
		CloseUtil.close(pstmt);

		return list;
	}
	
	public int memDelete(JoinVO vo) throws Exception {

		Connection conn = getConnection();
		PreparedStatement pstmt = conn.prepareStatement("DELETE FROM MEMBERS WHERE M_EMAIL = ?");
		pstmt.setString(1, vo.getM_email());
		pstmt.executeUpdate();

		CloseUtil.close(pstmt);
		CloseUtil.close(conn);

		return 0;
	}
	
	public JoinVO getImg(String id) throws Exception {

		JoinVO vo = new JoinVO();

		Connection conn = getConnection();
		String sql = "SELECT MR_IMG,MR_IMG1, MR_IMG2, MR_IMG3 FROM MEMBERS_RE WHERE MR_EMAIL=?";

		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, id);

		ResultSet rs = pstmt.executeQuery();

		if (rs.next()) {
			vo.setMr_img(rs.getString("mr_img"));
			System.out.println(rs.getString("mr_img"));
			vo.setMr_img1(rs.getString("mr_img1"));
			System.out.println(rs.getString("mr_img1"));
			vo.setMr_img2(rs.getString("mr_img2"));
			System.out.println(rs.getString("mr_img2"));
			vo.setMr_img3(rs.getString("mr_img3"));
			System.out.println(rs.getString("mr_img3"));
		}

		CloseUtil.close(rs);
		CloseUtil.close(pstmt);
		CloseUtil.close(conn);

		return vo;
	}

}
