package join.model;

import java.sql.*;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import dbclose.util.CloseUtil;

public class JoinDAO {

	private static JoinDAO instance = new JoinDAO();

	public JoinDAO() {
		
	}

	public static JoinDAO getInstance() {
		return instance;
	}

	public Connection getConnection() throws Exception {

		Context ctx = new InitialContext();
		DataSource ds = (DataSource) ctx.lookup("java:comp/env/jdbc:ProjectDB");

		return ds.getConnection();
	}
	
	public int confirmId(String id) throws Exception {
		
		int result = -1;
		String sql = "SELECT M_EMAIL FROM MEMBERS WHERE M_EMAIL = ?";

		Connection conn = getConnection();
		
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, id);
		
		ResultSet rs = pstmt.executeQuery();

		if (rs.next())
			result = 1;
		else
			result = -1;
		
		CloseUtil.close(pstmt);
		CloseUtil.close(rs);
		CloseUtil.close(conn);

		return result;
	}
	
	public int confirmId_re(String id) throws Exception {

		int result = -1;
		String sql = "SELECT MR_EMAIL FROM MEMBERS_RE WHERE MR_EMAIL = ?";

		Connection conn = getConnection();
		
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, id);
		
		ResultSet rs = pstmt.executeQuery();

		if (rs.next())
			result = 1;
		else
			result = -1;
		
		CloseUtil.close(pstmt);
		CloseUtil.close(rs);
		CloseUtil.close(conn);

		return result;
	}
	
	public int confirmName(String name) throws Exception {
		
		int result = -1;
		String sql = "SELECT M_NAME FROM MEMBERS WHERE M_NAME = ?";

		Connection conn = getConnection();
		
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, name);
		
		ResultSet rs = pstmt.executeQuery();

		if (rs.next())
			result = 1;
		else
			result = -1;
		
		CloseUtil.close(pstmt);
		CloseUtil.close(rs);
		CloseUtil.close(conn);

		return result;
	}

	public void insertMember(JoinVO vo) throws Exception {
		
		Connection conn = getConnection();
		String sql =
				"INSERT INTO MEMBERS (M_EMAIL, M_PASSWD, M_NAME, M_DATE, M_PWQ, M_PWA) VALUES (?, ?, ?, ?, ?, ?)";
		
		PreparedStatement pstmt = conn.prepareStatement(sql);
		
		pstmt.setString(1, vo.getM_email());
		pstmt.setString(2, vo.getM_passwd());
		pstmt.setString(3, vo.getM_name());
		pstmt.setTimestamp(4, vo.getM_date());
		pstmt.setString(5, vo.getM_pwq());
		pstmt.setString(6, vo.getM_pwa());
			
		pstmt.executeUpdate();

		CloseUtil.close(pstmt);
		CloseUtil.close(conn);
	}
	
	public void insertMember_re(JoinVO vo) throws Exception {
		
		Connection conn = getConnection();
		String sql =
				"INSERT INTO MEMBERS_RE VALUES (RE_NUM.NEXTVAL, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		
		PreparedStatement pstmt = conn.prepareStatement(sql);
		
		pstmt.setString(1, vo.getMr_email());
		pstmt.setString(2, vo.getMr_passwd());
		pstmt.setString(3, vo.getMr_type());
		pstmt.setString(4, vo.getMr_name());
		pstmt.setString(5, vo.getMr_img());
		pstmt.setString(6, vo.getMr_phone());
		pstmt.setString(7, vo.getMr_locate());
		pstmt.setString(8, vo.getMr_content());
		pstmt.setString(9, vo.getMr_info());
		pstmt.setTimestamp(10, vo.getMr_date());
		pstmt.setString(11, vo.getMr_pwq());
		pstmt.setString(12, vo.getMr_pwa());
		pstmt.setString(13, vo.getMr_img1());
		pstmt.setString(14, vo.getMr_img2());
		pstmt.setString(15, vo.getMr_img3());
		
		pstmt.executeUpdate();
		
		CloseUtil.close(pstmt);
		CloseUtil.close(conn);
	}

	public int confirmQA(String q, String a) throws Exception {

		int result = -1;

		Connection conn = getConnection();
		String sql = "SELECT M_PWQ, M_PWA FROM MEMBERS WHERE M_PWQ = ? AND M_PWA = ?";
		
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, q);
		pstmt.setString(2, a);
		
		ResultSet rs = pstmt.executeQuery();

		if (rs.next())
			result = 1;

		else
			result = -1;

		CloseUtil.close(rs);
		CloseUtil.close(pstmt);
		CloseUtil.close(conn);

		return result;
	}

	public int confirmQA_re(String q, String a) throws Exception {
		
		int result = -1;

		Connection conn = getConnection();
		String sql = "SELECT MR_PWQ, MR_PWA FROM MEMBERS_RE WHERE MR_PWQ = ? AND MR_PWA = ?";
		
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, q);
		pstmt.setString(2, a);
		
		ResultSet rs = pstmt.executeQuery();

		if (rs.next())
			result = 1;

		else
			result = -1;

		CloseUtil.close(rs);
		CloseUtil.close(pstmt);
		CloseUtil.close(conn);

		return result;
	}

	public JoinVO getPasswd(String id, String q, String a) throws Exception {
		
		JoinVO vo = null;

		Connection conn = getConnection();
		String sql = "SELECT M_PASSWD FROM MEMBERS WHERE M_EMAIL= ? AND M_PWQ = ? AND M_PWA=?";
		
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, id);
		pstmt.setString(2, q);
		pstmt.setString(3, a);

		ResultSet rs = pstmt.executeQuery();

		if (rs.next()) {
			vo = new JoinVO();
			vo.setM_passwd(rs.getString("m_passwd"));
		}

		CloseUtil.close(rs);
		CloseUtil.close(pstmt);
		CloseUtil.close(conn);

		return vo;
	}

	public JoinVO getPasswd_re(String id, String q, String a) throws Exception {
		
		JoinVO vo = null;

		Connection conn = getConnection();
		String sql = "SELECT MR_PASSWD FROM MEMBERS_RE WHERE MR_EMAIL= ? AND MR_PWQ = ? AND MR_PWA=?";
		
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, id);
		pstmt.setString(2, q);
		pstmt.setString(3, a);

		ResultSet rs = pstmt.executeQuery();

		if (rs.next()) {
			vo = new JoinVO();
			vo.setM_passwd(rs.getString("mr_passwd"));
		}

		CloseUtil.close(rs);
		CloseUtil.close(pstmt);
		CloseUtil.close(conn);

		return vo;
	}
	
	public void ImgUpdate(String id, String filename, String upfile) throws Exception {

		Connection conn = getConnection();
		PreparedStatement pstmt = null;
		String sql = "";

		if (upfile.equals("img")) {
			sql = "update members_re set mr_img=? where mr_email=?";
		} else if (upfile.equals("img1")) {
			sql = "update members_re set mr_img1=? where mr_email=?";
		} else if (upfile.equals("img2")) {
			sql = "update members_re set mr_img2=? where mr_email=?";
		} else if (upfile.equals("img3")) {
			sql = "update members_re set mr_img3=? where mr_email=?";
		}
		pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, filename);
		pstmt.setString(2, id);

		pstmt.executeUpdate();

		CloseUtil.close(pstmt);
		CloseUtil.close(conn);

	}

}
