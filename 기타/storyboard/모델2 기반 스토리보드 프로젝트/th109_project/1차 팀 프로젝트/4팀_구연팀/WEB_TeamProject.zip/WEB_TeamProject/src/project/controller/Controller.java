package project.controller;

import java.io.*;
import java.util.*;

import javax.servlet.*;
import javax.servlet.http.*;

import project.action.CommandAction;

public class Controller extends HttpServlet {

	private Map commandMap = new HashMap();

	@Override
	public void init(ServletConfig config) throws ServletException {

		String conf = config.getInitParameter("projectConfig");

		Properties prop = new Properties();
		FileInputStream fist = null;

		try {
			fist = new FileInputStream(conf);
			prop.load(fist);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			if (fist != null) {
				try {
					fist.close();
				}
				catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		
		Iterator key = prop.keySet().iterator();

		while (key.hasNext()) {
			
			String command = (String) key.next();
			String className = prop.getProperty(command);
			
			try {
				Class commandClass = Class.forName(className);
				Object commandInstance = commandClass.newInstance();

				commandMap.put(command, commandInstance);
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	private void process(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String view = null;
		CommandAction cp = null;

		try {
			String command = request.getRequestURI();
			
			System.out.println("command = " + command);
			System.out.println("request.getContextPath() = " + request.getContextPath());
			
			if (command.indexOf(request.getContextPath()) == 0) {
				command = command.substring(request.getContextPath().length() + 1);
				System.out.println("if command = " + command);
			}
			
			cp = (CommandAction) commandMap.get(command);
			System.out.println("cp = " + cp);
			
			view = cp.process(request, response);
			System.out.println("view = " + view);
		}
		catch (Exception e) {
			e.printStackTrace();
		}

		if (view.equals("/join/confirmId.jsp")) {
			request.setAttribute("CONFIRM", view);

			RequestDispatcher dp = request.getRequestDispatcher("/join/confirm.jsp");
			dp.forward(request, response);
		}
		
		else if (view.equals("/join/confirmId_re.jsp")) {
			request.setAttribute("CONFIRM", view);

			RequestDispatcher dp = request.getRequestDispatcher("/join/confirm.jsp");
			dp.forward(request, response);
		}
		
		else if (view.equals("/join/confirmName.jsp")) {
			request.setAttribute("CONFIRM", view);

			RequestDispatcher dp = request.getRequestDispatcher("/join/confirm.jsp");
			dp.forward(request, response);
		}
		
		else if (view.equals("/login/logImagePro.jsp")) {
			request.setAttribute("CONFIRM", view);

			RequestDispatcher dp = request.getRequestDispatcher("/join/confirm.jsp");
			dp.forward(request, response);
		}
		
		else {
			request.setAttribute("CENTER", view);

			RequestDispatcher dp = request.getRequestDispatcher("/template/template.jsp");
			dp.forward(request, response);
		}
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		process(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		process(request, response);
	}
}
