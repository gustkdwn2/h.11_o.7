package list.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import project.action.CommandAction;

public class DeleteAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		request.setCharacterEncoding("UTF-8");
		
		String m_email = request.getParameter("m_email");
		String pageNum = request.getParameter("pageNum");

		request.setAttribute("m_email", m_email);
		request.setAttribute("pageNum", new Integer(pageNum));

		return "/list/memDeleteForm.jsp";
	}

}
