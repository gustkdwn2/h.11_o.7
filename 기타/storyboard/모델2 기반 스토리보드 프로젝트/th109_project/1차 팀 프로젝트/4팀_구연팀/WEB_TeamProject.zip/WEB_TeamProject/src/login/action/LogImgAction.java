package login.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import join.model.JoinVO;
import login.model.LoginDAO;
import project.action.CommandAction;

public class LogImgAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {

		request.setCharacterEncoding("UTF-8");

		LoginDAO dao = LoginDAO.getInstance();
		HttpSession session = request.getSession();

		String email = (String) session.getAttribute("memID_re");
		JoinVO vo = dao.getImg(email);

		request.setAttribute("vo", vo);

		return "/login/logImage.jsp";
	}

}
