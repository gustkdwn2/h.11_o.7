package login.action;

import javax.servlet.http.*;

import join.model.JoinVO;
import login.model.LoginDAO;
import project.action.CommandAction;

public class DeleteProAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		request.setCharacterEncoding("UTF-8");
		
		HttpSession session = request.getSession();
		
		String g_id = (String) session.getAttribute("memID");
		String b_id = (String) session.getAttribute("memID_re");
		
		JoinVO vo = new JoinVO();
		LoginDAO dao = LoginDAO.getInstance();
		
		int check = -1;

		if (g_id != null) {
			String passwd = request.getParameter("passwd");
			check = dao.userCheck(g_id, passwd);
			if (check == 1)
				dao.deleteMember(g_id);
			session.removeAttribute("memID");
			session.removeAttribute("passwd");
			session.invalidate();
		}
		else if (b_id != null){
			String passwd = request.getParameter("passwd");
			check = dao.userCheck_re(b_id, passwd);
			if (check == 1)
				dao.deleteMember_re(b_id);
			session.removeAttribute("memID_re");
			session.removeAttribute("passwd");
			session.invalidate();
		}

		request.setAttribute("check", check);
		
		return "/login/logDeletePro.jsp";
	}

}
