package store.action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import project.action.CommandAction;
import store.model.StoreDAO;

public class TypeListAction  implements CommandAction {

	public String getTypeName(String type) throws Exception {

		String typeName = "";

		if (type.equals("kor"))
			typeName = "한식";
		else if (type.equals("chn"))
			typeName = "중식";
		else if (type.equals("jap"))
			typeName = "일식";
		else if (type.equals("cafe"))
			typeName = "카페";
		else if (type.equals("fast"))
			typeName = "패스트푸드";
		else if (type.equals("soju"))
			typeName = "술집";

		return typeName;
	}
	
	public String getSubTitle(String type) throws Exception {

		String typeName = "";

		if (type.equals("kor"))
			typeName = "한 식";
		else if (type.equals("chn"))
			typeName = "중 식";
		else if (type.equals("jap"))
			typeName = "일 식";
		else if (type.equals("fast"))
			typeName = "패 스 트 푸 드";
		else if (type.equals("cafe"))
			typeName = "카 페";
		else if (type.equals("soju"))
			typeName = "술 집";

		return typeName;

	}
	
	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		request.setCharacterEncoding("UTF-8");
		
		int pageSize = 5;
		String pageNum = request.getParameter("pageNum");

		if (pageNum == null)
			pageNum = "1";

		int currentPage = Integer.parseInt(pageNum);
		int startRow = (currentPage * pageSize) - (pageSize - 1);
		int endRow = (currentPage * pageSize);
		int count = 0, number = 0;

		List list = null;
		String btn_type = getTypeName(request.getParameter("btn_type"));
		
		StoreDAO dao = StoreDAO.getInstance();
		count = dao.getListAllCount(btn_type);

		if (count > 0)
			list = dao.getSelectAll(btn_type, startRow, endRow);

		number = count - (currentPage - 1) * pageSize;

		request.setAttribute("currentPage", new Integer(currentPage));
		request.setAttribute("startRow", new Integer(startRow));
		request.setAttribute("endRow", new Integer(endRow));
		request.setAttribute("count", new Integer(count));
		request.setAttribute("pageSize", new Integer(pageSize));
		request.setAttribute("number", new Integer(number));
		request.setAttribute("list", list);
		request.setAttribute("subtitle", getSubTitle(request.getParameter("btn_type")));
		request.setAttribute("btn_type", request.getParameter("btn_type"));

		return "/store/typeList.jsp";
	}

}
