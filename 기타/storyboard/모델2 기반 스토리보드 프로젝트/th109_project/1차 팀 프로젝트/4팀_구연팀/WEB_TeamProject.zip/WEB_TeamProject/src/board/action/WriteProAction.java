package board.action;

import java.sql.Timestamp;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import board.model.*;
import project.action.CommandAction;

public class WriteProAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		request.setCharacterEncoding("UTF-8");

		BoardVO vo = new BoardVO();
		BoardDAO dao = BoardDAO.getInstance();

		vo.setQa_num(Integer.parseInt(request.getParameter("num")));
		vo.setQa_writer(request.getParameter("writer"));
		vo.setQa_passwd(request.getParameter("passwd"));
		vo.setQa_title(request.getParameter("title"));
		vo.setQa_content(request.getParameter("content"));
		vo.setQa_date(new Timestamp(System.currentTimeMillis()));
		vo.setRef(Integer.parseInt(request.getParameter("ref")));
		vo.setRe_level(Integer.parseInt(request.getParameter("re_level")));
		vo.setRe_step(Integer.parseInt(request.getParameter("re_step")));

		dao.insert(vo);

		return "/board_qa/writePro.jsp";
	}

}
