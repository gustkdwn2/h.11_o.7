package menu.model;

import java.sql.*;
import java.util.*;

import javax.naming.*;
import javax.sql.DataSource;

import dbclose.util.CloseUtil;

public class MenuDAO {

	private static MenuDAO instance = new MenuDAO();

	public MenuDAO() {

	}

	public static MenuDAO getInstance() {

		return instance;
	}

	public Connection getConnection() throws Exception {

		Context ctx = new InitialContext();
		DataSource ds = (DataSource) ctx.lookup("java:comp/env/jdbc:ProjectDB");

		return ds.getConnection();
	}
	
	public int getMr_num(String id) {
		
		int num = 0;
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = getConnection();

			pstmt = conn.prepareStatement("SELECT MR_NUM FROM MEMBERS_RE WHERE MR_EMAIL = ?");
			pstmt.setString(1, id);
			
			rs = pstmt.executeQuery();

			if (rs.next())
				num = rs.getInt(1);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		
		return num;
	}
	
	public void insert(MenuVO vo) {

		Connection conn = null;
		PreparedStatement pstmt = null;

		StringBuffer sb = new StringBuffer();

		try {
			conn = getConnection();

			sb.append("INSERT INTO MENU VALUES ( ?, ?, ?, ? )");

			pstmt = conn.prepareStatement(sb.toString());
			
			pstmt.setInt(1, vo.getMr_num());
			pstmt.setString(2, vo.getMenu_item());
			pstmt.setInt(3, vo.getMenu_price());
			pstmt.setTimestamp(4, vo.getMenu_date());
			
			pstmt.executeUpdate();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
	}
	
	public int delete(MenuVO vo) {

		Connection conn = null;
		PreparedStatement pstmt = null;

		StringBuffer sb = new StringBuffer();

		try {
			conn = getConnection();
			
			sb.append("DELETE MENU WHERE MR_NUM = ? AND MENU_ITEM = ?");

			pstmt = conn.prepareStatement(sb.toString());
			
			pstmt.setInt(1, vo.getMr_num());
			pstmt.setString(2, vo.getMenu_item());
			
			pstmt.executeUpdate();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		return 0;
	}


	public int getListAllCount(int num) {
		
		int count = 0;

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = getConnection();

			pstmt = conn.prepareStatement("SELECT COUNT(*) FROM MENU WHERE MR_NUM = ?");
			pstmt.setInt(1, num);
			
			rs = pstmt.executeQuery();

			if (rs.next())
				count = rs.getInt(1);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		return count;
	}
	
	public List<MenuVO> getSelectAll(int cnt, int num) {

		List list = null;
		StringBuffer sb = new StringBuffer();

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = getConnection();
			
			sb.append("SELECT * FROM MENU WHERE MR_NUM = ?");
			
			pstmt = conn.prepareStatement(sb.toString());
			pstmt.setInt(1, num);
			
			rs = pstmt.executeQuery();

			if (rs.next()) {
				
				list = new ArrayList(cnt);

				do {
					MenuVO vo = new MenuVO();
					
					vo.setMr_num(rs.getInt("mr_num"));
					vo.setMenu_item(rs.getString("menu_item"));
					vo.setMenu_price(rs.getInt("menu_price"));
					vo.setMenu_date(rs.getTimestamp("menu_date"));
					
					list.add(vo);
					
				} while (rs.next());
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		return list;
	}
}
