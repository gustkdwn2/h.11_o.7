package list.model;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import dbclose.util.CloseUtil;
import join.model.JoinVO;

public class ListDAO {

	private static ListDAO instance = new ListDAO();

	public ListDAO() {

	}

	public static ListDAO getInstance() {
		return instance;
	}

	public Connection getConnection() throws Exception {

		Context ctx = new InitialContext();
		DataSource ds = (DataSource) ctx.lookup("java:comp/env/jdbc:ProjectDB");

		return ds.getConnection();
	}

	public int memDelete(JoinVO vo) throws Exception {

		Connection conn = getConnection();
		PreparedStatement pstmt = conn.prepareStatement("DELETE FROM MEMBERS WHERE M_EMAIL = ?");
		pstmt.setString(1, vo.getM_email());
		pstmt.executeUpdate();

		CloseUtil.close(pstmt);
		CloseUtil.close(conn);

		return 0;
	}
	
	public int reDelete(JoinVO vo) throws Exception {

		Connection conn = getConnection();
		PreparedStatement pstmt = conn.prepareStatement("DELETE FROM MEMBERS_RE WHERE MR_EMAIL = ?");
		pstmt.setString(1, vo.getMr_email());
		pstmt.executeUpdate();

		CloseUtil.close(pstmt);
		CloseUtil.close(conn);

		return 0;
	}

	public int getMemListAllCount() throws Exception {

		int count = 0;

		Connection conn = getConnection();
		PreparedStatement pstmt = conn.prepareStatement("SELECT COUNT(*) FROM MEMBERS");
		ResultSet rs = pstmt.executeQuery();

		if (rs.next())
			count = rs.getInt(1);

		CloseUtil.close(rs);
		CloseUtil.close(pstmt);
		CloseUtil.close(conn);

		return count;
	}

	public int getReListAllCount() throws Exception {

		int count = 0;

		Connection conn = getConnection();
		PreparedStatement pstmt = conn.prepareStatement("SELECT COUNT(*) FROM MEMBERS_RE");
		ResultSet rs = pstmt.executeQuery();

		if (rs.next())
			count = rs.getInt(1);

		CloseUtil.close(rs);
		CloseUtil.close(pstmt);
		CloseUtil.close(conn);

		return count;
	}

	public List<JoinVO> getMemSelectAll(int start, int end) throws Exception {

		List list = null;
		String sql = "SELECT M_EMAIL, M_NAME, M_DATE FROM (SELECT M_EMAIL, M_NAME, M_DATE, ROWNUM R FROM MEMBERS) WHERE R >= ? AND R <= ?";

		Connection conn = getConnection();
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setInt(1, start);
		pstmt.setInt(2, end);
		ResultSet rs = pstmt.executeQuery();

		if (rs.next()) {
			list = new ArrayList(end);

			do {

				JoinVO vo = new JoinVO();

				vo.setM_email(rs.getString("m_email"));
				vo.setM_name(rs.getString("m_name"));
				vo.setM_date(rs.getTimestamp("m_date"));
				list.add(vo);
			} while (rs.next());
		}

		CloseUtil.close(rs);
		CloseUtil.close(pstmt);

		return list;
	}

	public List<JoinVO> getReSelectAll(int start, int end) throws Exception {

		List list = null;
		String sql = "SELECT MR_EMAIL, MR_NAME, MR_DATE FROM (SELECT MR_EMAIL, MR_NAME, MR_DATE, ROWNUM R FROM MEMBERS_RE) WHERE R >= ? AND R <= ?";

		Connection conn = getConnection();
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setInt(1, start);
		pstmt.setInt(2, end);
		ResultSet rs = pstmt.executeQuery();

		if (rs.next()) {
			list = new ArrayList(end);

			do {

				JoinVO vo = new JoinVO();

				vo.setMr_email(rs.getString("mr_email"));
				vo.setMr_name(rs.getString("mr_name"));
				vo.setMr_date(rs.getTimestamp("mr_date"));
				list.add(vo);
			} while (rs.next());
		}

		CloseUtil.close(rs);
		CloseUtil.close(pstmt);

		return list;
	}

}
