package order.model;

import java.sql.*;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import dbclose.util.CloseUtil;
import store.model.StoreVO;

public class OrderDAO {

	private static OrderDAO instance = new OrderDAO();

	public OrderDAO() {

	}

	public static OrderDAO getInstance() {
		return instance;
	}

	public Connection getConnection() throws Exception {

		Context ctx = new InitialContext();
		DataSource ds = (DataSource) ctx.lookup("java:comp/env/jdbc:ProjectDB");

		return ds.getConnection();
	}
	
	public String getEmail(int num) throws Exception {
		
		String mr_email = null;
		String sql = "SELECT MR_EMAIL FROM MEMBERS_RE WHERE MR_NUM=?";

		Connection conn = getConnection();
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setInt(1, num);
		ResultSet rs = pstmt.executeQuery();

		if (rs.next())
			mr_email = rs.getString("mr_email");

		CloseUtil.close(rs);
		CloseUtil.close(pstmt);
		CloseUtil.close(conn);

		return mr_email;
	}
	
	public int getListAllCount(String email, int num) throws Exception {

		int count = 0;

		Connection conn = getConnection();
		PreparedStatement pstmt =
				conn.prepareStatement("SELECT COUNT(*) FROM ORDER_LIST WHERE OR_EMAIL = ? AND MR_NUM = ?");
		pstmt.setString(1, email);
		pstmt.setInt(2, num);

		ResultSet rs = pstmt.executeQuery();

		if (rs.next())
			count = rs.getInt(1);

		CloseUtil.close(rs);
		CloseUtil.close(pstmt);
		CloseUtil.close(conn);

		return count;
	}

	public int total(String email, int num) throws Exception {

		int total = 0;

		Connection conn = getConnection();
		PreparedStatement pstmt =
				conn.prepareStatement("SELECT SUM( OR_PRICE * OR_QTY ) FROM ORDER_LIST WHERE OR_EMAIL = ? AND MR_NUM = ?");
		pstmt.setString(1, email);
		pstmt.setInt(2, num);

		ResultSet rs = pstmt.executeQuery();

		if (rs.next())
			total = rs.getInt(1);

		CloseUtil.close(rs);
		CloseUtil.close(pstmt);
		CloseUtil.close(conn);

		return total;
	}

	public StoreVO getDetail(int num) throws Exception {

		StoreVO vo = null;
		String sql = "SELECT * FROM MEMBERS_RE WHERE MR_NUM = ?";

		Connection conn = getConnection();

		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setInt(1, num);

		ResultSet rs = pstmt.executeQuery();

		if (rs.next()) {

			vo = new StoreVO();

			do {
				vo.setMr_num(rs.getInt("mr_num"));
				vo.setMr_email(rs.getString("mr_email"));
				vo.setMr_type(rs.getString("mr_type"));
				vo.setMr_name(rs.getString("mr_name"));
				vo.setMr_img(rs.getString("mr_img"));
				vo.setMr_phone(rs.getString("mr_phone"));
				vo.setMr_locate(rs.getString("mr_locate"));
				vo.setMr_content(rs.getString("mr_content"));
				vo.setMr_info(rs.getString("mr_info"));
				vo.setMr_img1(rs.getString("mr_img1"));
				vo.setMr_img2(rs.getString("mr_img2"));
				vo.setMr_img3(rs.getString("mr_img3"));

			} while (rs.next());
		}

		CloseUtil.close(rs);
		CloseUtil.close(pstmt);
		CloseUtil.close(conn);

		return vo;
	}

	public int getMenuCount(int num) throws Exception {

		int count = 0;

		Connection conn = getConnection();

		PreparedStatement pstmt = conn.prepareStatement("SELECT COUNT(*) FROM MENU WHERE MR_NUM = ?");

		pstmt.setInt(1, num);
		ResultSet rs = pstmt.executeQuery();

		if (rs.next())
			count = rs.getInt(1);

		CloseUtil.close(rs);
		CloseUtil.close(pstmt);
		CloseUtil.close(conn);

		return count;
	}

	public List<StoreVO> getMenu(int num) throws Exception {

		List list = null;
		String sql = "SELECT * FROM MENU WHERE MR_NUM = ?";

		Connection conn = getConnection();

		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setInt(1, num);

		ResultSet rs = pstmt.executeQuery();

		if (rs.next()) {

			list = new ArrayList();

			do {
				StoreVO vo = new StoreVO();

				vo.setMenu_item(rs.getString("menu_item"));
				vo.setMenu_price(rs.getInt("menu_price"));
				vo.setMenu_date(rs.getTimestamp("menu_date"));

				list.add(vo);

			} while (rs.next());
		}

		CloseUtil.close(rs);
		CloseUtil.close(pstmt);
		CloseUtil.close(conn);

		return list;
	}

	public int getOrderCount(int num, String email) throws Exception {

		int count = 0;

		Connection conn = getConnection();

		PreparedStatement pstmt = conn
				.prepareStatement("SELECT COUNT(*) FROM ORDER_LIST WHERE MR_NUM = ? AND OR_EMAIL = ?");

		pstmt.setInt(1, num);
		pstmt.setString(2, email);

		ResultSet rs = pstmt.executeQuery();

		if (rs.next())
			count = rs.getInt(1);

		CloseUtil.close(rs);
		CloseUtil.close(pstmt);
		CloseUtil.close(conn);

		return count;
	}

	public List<StoreVO> getOrder(int num, String email) throws Exception {

		List list = null;
		StringBuffer sb = new StringBuffer();

		sb.append("SELECT OR_ITEM, OR_PRICE, OR_QTY FROM ORDER_LIST WHERE MR_NUM = ? AND OR_EMAIL = ?");

		Connection conn = getConnection();

		PreparedStatement pstmt = conn.prepareStatement(sb.toString());

		pstmt.setInt(1, num);
		pstmt.setString(2, email);

		ResultSet rs = pstmt.executeQuery();

		if (rs.next()) {

			list = new ArrayList();

			do {
				StoreVO vo = new StoreVO();

				vo.setOr_item(rs.getString("or_item"));
				vo.setOr_price(rs.getInt("or_price"));
				vo.setOr_qty(rs.getInt("or_qty"));

				list.add(vo);

			} while (rs.next());
		}

		CloseUtil.close(rs);
		CloseUtil.close(pstmt);
		CloseUtil.close(conn);

		return list;
	}
	
	public List getOrderList(int cnt, String email, int num) throws Exception {

		List list = null;
		StringBuffer sb = new StringBuffer();
		
		sb.append("SELECT OR_ITEM,OR_PRICE,OR_QTY,OR_PRICE*OR_QTY AS SUM ");
		sb.append("FROM ORDER_LIST WHERE OR_EMAIL =? AND MR_NUM=?");

		Connection conn = getConnection();
		PreparedStatement pstmt = conn.prepareStatement(sb.toString());
		
		pstmt.setString(1, email);
		pstmt.setInt(2, num);

		ResultSet rs = pstmt.executeQuery();

		if (rs.next()) {

			list = new ArrayList(cnt * 4);
			
			do {
				for (int i = 0; i < cnt; i++) {
					list.add(i, rs.getString("or_item"));
					i += 1;
					list.add(i, rs.getString("or_price"));
					i += 1;
					list.add(i, rs.getString("or_qty"));
					i += 1;
					list.add(i, rs.getString("sum"));
				}
			} while (rs.next());
		}

		CloseUtil.close(rs);
		CloseUtil.close(pstmt);
		CloseUtil.close(conn);

		return list;
	}

	public int delete(StoreVO vo) throws Exception {

		Connection conn = getConnection();

		PreparedStatement pstmt = conn
				.prepareStatement("DELETE ORDER_LIST WHERE MR_NUM = ? AND OR_EMAIL = ? AND OR_ITEM = ?");

		pstmt.setInt(1, vo.getMr_num());
		pstmt.setString(2, vo.getOr_email());
		pstmt.setString(3, vo.getOr_item());

		pstmt.executeUpdate();

		CloseUtil.close(pstmt);
		CloseUtil.close(conn);

		return 0;
	}
	
	public int allDelete(StoreVO vo) throws Exception {
		
		int point = 0;
		
		StringBuffer sb = new StringBuffer();
		sb.append("DELETE ORDER_LIST WHERE OR_EMAIL = ? AND MR_NUM = ?");

		Connection conn = getConnection();
		PreparedStatement pstmt = conn.prepareStatement(sb.toString());

		pstmt.setString(1, vo.getOr_email());
		pstmt.setInt(2, vo.getMr_num());

		pstmt.executeUpdate();

		CloseUtil.close(pstmt);
		CloseUtil.close(conn);

		return point;
	}
	
	public int addOder(StoreVO vo) throws Exception {
		
		int total = 0;
		int count = 0;

		StringBuffer sb = new StringBuffer();
		sb.append("SELECT COUNT(*) FROM ORDER_LIST WHERE MR_NUM = ? AND OR_EMAIL = ? AND OR_ITEM = ?");

		Connection conn = getConnection();
		PreparedStatement pstmt = conn.prepareStatement(sb.toString());

		pstmt.setInt(1, vo.getMr_num());
		pstmt.setString(2, vo.getOr_email());
		pstmt.setString(3, vo.getOr_item());

		ResultSet rs = pstmt.executeQuery();

		if (rs.next())
			count = rs.getInt(1);
		
		sb = new StringBuffer();
		
		if(count == 0) {
			sb.append("INSERT INTO ORDER_LIST VALUES (?, ?, ?, ?, ?)");
			
			pstmt = conn.prepareStatement(sb.toString());
			
			pstmt.setInt(1, vo.getMr_num());
			pstmt.setString(2, vo.getOr_item());
			pstmt.setInt(3, vo.getOr_price());
			pstmt.setInt(4, vo.getOr_qty());
			pstmt.setString(5, vo.getOr_email());

			pstmt.executeUpdate();
		}
		else {
			sb.append("UPDATE ORDER_LIST SET OR_QTY = OR_QTY + ? ");
			sb.append("WHERE MR_NUM = ? AND OR_EMAIL = ? AND OR_ITEM = ?");

			pstmt = conn.prepareStatement(sb.toString());

			pstmt.setInt(1, vo.getOr_qty());
			pstmt.setInt(2, vo.getMr_num());
			pstmt.setString(3, vo.getOr_email());
			pstmt.setString(4, vo.getOr_item());

			pstmt.executeUpdate();
		}
		
		sb = new StringBuffer();

		sb.append("SELECT SUM(OR_PRICE * OR_QTY) FROM ORDER_LIST ");
		sb.append("WHERE MR_NUM = ? AND OR_EMAIL = ?");

		pstmt = conn.prepareStatement(sb.toString());

		pstmt.setInt(1, vo.getMr_num());
		pstmt.setString(2, vo.getOr_email());

		rs = pstmt.executeQuery();

		if (rs.next())
			total = rs.getInt(1);
		
		CloseUtil.close(rs);
		CloseUtil.close(pstmt);
		CloseUtil.close(conn);

		return total;
	}
	
	public int subPoint(String id) throws Exception {
		
		StringBuffer sb = new StringBuffer();
		sb.append("UPDATE MEMBERS SET M_POINT = M_POINT - 50 WHERE M_EMAIL = ?");

		Connection conn = getConnection();
		
		PreparedStatement pstmt = conn.prepareStatement(sb.toString());
		pstmt.setString(1, id);
		
		pstmt.executeUpdate();
		
		int point = 0;
		
		sb = new StringBuffer();
		sb.append("SELECT M_POINT FROM MEMBERS WHERE M_EMAIL = ?");
		
		pstmt = conn.prepareStatement(sb.toString());
		pstmt.setString(1, id);
		
		ResultSet rs = pstmt.executeQuery();
		
		while (rs.next())
			point = rs.getInt("m_point");

		CloseUtil.close(pstmt);
		CloseUtil.close(conn);
		
		return point;
	}

}
