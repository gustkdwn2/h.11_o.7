package store.action;

import java.io.File;
import java.net.URLEncoder;
import java.sql.Timestamp;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import order.model.OrderDAO;
import project.action.CommandAction;
import store.model.*;

public class ReviewProAction implements CommandAction {

	public String getTypeName(String type) throws Exception {

		String typeName = "";

		if (type.equals("1"))
			typeName = "star1.png";
		else if (type.equals("2"))
			typeName = "star2.png";
		else if (type.equals("3"))
			typeName = "star3.png";
		else if (type.equals("4"))
			typeName = "star4.png";
		else if (type.equals("5"))
			typeName = "star5.png";

		return typeName;
	}

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {

		request.setCharacterEncoding("UTF-8");
		
		HttpSession session = request.getSession();
		
		String g_id = (String) session.getAttribute("memID");
		String b_id = (String) session.getAttribute("memID_re");
		
		int sizeLimit = 10 * 1024 * 1024;
		String savePath = request.getSession().getServletContext().getRealPath("/upload");
		
		MultipartRequest multi =
				new MultipartRequest( request, savePath, sizeLimit, "UTF-8", new DefaultFileRenamePolicy() );
		String fileName = multi.getFilesystemName("upfile");
		
		File files = multi.getFile("upfile");
		
		StoreVO vo = new StoreVO();
		StoreDAO dao = StoreDAO.getInstance();
		
		int num = Integer.parseInt(multi.getParameter("num"));
		
		vo.setMr_num(num);
		vo.setV_grade(multi.getParameter("grade"));
		vo.setV_writer(multi.getParameter("writer"));
		vo.setV_content(multi.getParameter("content"));
		vo.setV_img(fileName);
		vo.setV_date(new Timestamp(System.currentTimeMillis()));
		
		if( g_id != null)
			vo.setV_type(1);
		else if ( b_id != null)
			vo.setV_type(2);
		else
			vo.setV_type(0);

		dao.insert(vo);
		
		session.removeAttribute("memPoint");
		session.setAttribute("memPoint", dao.addPoint((String) session.getAttribute("memID")));

		int pageSize = 5;
		String pageNum = request.getParameter("pageNum");

		if (pageNum == null)
			pageNum = "1";

		int currentPage = Integer.parseInt(pageNum);
		int startRow = (currentPage * pageSize) - (pageSize - 1);
		int endRow = (currentPage * pageSize);
		int number = 0;

		dao = StoreDAO.getInstance();
		int count = dao.getReviewCount(num);

		List list = dao.getReview(num, startRow, endRow);
		vo = OrderDAO.getInstance().getDetail(num);

		number = count - (currentPage - 1) * pageSize;

		request.setAttribute("vo", vo);
		request.setAttribute("list", list);
		request.setAttribute("num", num);
		request.setAttribute("count", count);
		request.setAttribute("currentPage", new Integer(currentPage));
		request.setAttribute("startRow", new Integer(startRow));
		request.setAttribute("endRow", new Integer(endRow));
		request.setAttribute("count", new Integer(count));
		request.setAttribute("pageSize", new Integer(pageSize));
		request.setAttribute("number", new Integer(number));

		return "/store/review.jsp";
	}

}
