package board.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import board.model.*;
import project.action.CommandAction;

public class NoDeleteProAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		request.setCharacterEncoding("UTF-8");
		
		BoardVO vo = new BoardVO();
		
		String num = request.getParameter("num");
		String pageNum = request.getParameter("pageNum");

		vo.setNo_num(Integer.parseInt(request.getParameter("num")));
		BoardDAO dao = BoardDAO.getInstance();

		int check = dao.noDelete(vo);

		request.setAttribute("num", num);
		request.setAttribute("pageNum", pageNum);
		request.setAttribute("check", check);

		return "/board_notice/deletePro.jsp";
	}

}
