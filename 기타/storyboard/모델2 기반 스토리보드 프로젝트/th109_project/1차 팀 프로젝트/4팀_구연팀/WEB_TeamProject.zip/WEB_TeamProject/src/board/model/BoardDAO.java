package board.model;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import dbclose.util.CloseUtil;

public class BoardDAO {
	
	private static BoardDAO instance = new BoardDAO();

	public BoardDAO() {
		
	}

	public static BoardDAO getInstance() {
		return instance;
	}

	public Connection getConnection() throws Exception {

		Context ctx = new InitialContext();
		DataSource ds = (DataSource) ctx.lookup("java:comp/env/jdbc:ProjectDB");

		return ds.getConnection();
	}

	public void insert(BoardVO vo) throws Exception {
		
		int num = vo.getQa_num(), number = 0;
		
		int ref = vo.getRef();
		int re_step = vo.getRe_step();
		int re_level = vo.getRe_level();
		
		StringBuffer sb = new StringBuffer();
		
		Connection conn = getConnection();
		PreparedStatement pstmt = conn.prepareStatement("SELECT MAX(QA_NUM) FROM BOARD_QA");
		ResultSet rs = pstmt.executeQuery();
		
		if (rs.next())
			number = rs.getInt(1) + 1;
		else
			number = 1;
		
		if (num != 0) {
			
			sb.append("UPDATE BOARD_QA SET RE_STEP = RE_STEP + 1 WHERE REF = ? AND RE_STEP = ?");
			
			pstmt = conn.prepareStatement(sb.toString());
			pstmt.setInt(1, ref);
			pstmt.setInt(2, re_step);
			pstmt.executeUpdate();

			re_step = re_step + 1;
			re_level = re_level + 1;

			pstmt = conn.prepareStatement("SELECT MAX(RE_STEP) FROM BOARD_QA WHERE REF = ? AND RE_LEVEL = ?");
			pstmt.setInt(1, ref);
			pstmt.setInt(2, re_level);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				
				if (re_step == 0)
					re_step = rs.getInt(1) + 1;
				else
					re_step = 0;
			}
		}
		else {
			ref = number;
			re_step = 0;
			re_level = 0;
		}

		sb = new StringBuffer();
		
		sb.append("INSERT INTO BOARD_QA ");
		sb.append("(QA_NUM, QA_WRITER, QA_PASSWD, QA_TITLE, QA_CONTENT, QA_DATE, REF, RE_STEP, RE_LEVEL) ");
		sb.append("VALUES (QA_NUM.NEXTVAL, ?, ?, ?, ?, ?, ?, ?, ?)");
		
		pstmt = conn.prepareStatement(sb.toString());
		
		pstmt.setString(1, vo.getQa_writer());
		pstmt.setString(2, vo.getQa_passwd());
		pstmt.setString(3, vo.getQa_title());
		pstmt.setString(4, vo.getQa_content());
		pstmt.setTimestamp(5, vo.getQa_date());
		pstmt.setInt(6, ref);
		pstmt.setInt(7, re_step);
		pstmt.setInt(8, re_level);

		pstmt.executeUpdate();

		CloseUtil.close(rs);
		CloseUtil.close(pstmt);
		CloseUtil.close(conn);
	}
	
	public void noInsert(BoardVO vo) throws Exception {
		
		StringBuffer sb = new StringBuffer();
		
		sb.append("INSERT INTO BOARD_NOTICE (NO_NUM, NO_TITLE, NO_CONTENT, NO_IMG, NO_DATE) ");
		sb.append("VALUES (NOTICE_NUM.NEXTVAL, ?, ?, ?, ?)");
		
		Connection conn = getConnection();
		PreparedStatement pstmt = conn.prepareStatement(sb.toString());
		
		pstmt.setString(1, vo.getNo_title());
		pstmt.setString(2, vo.getNo_content());
		pstmt.setString(3, vo.getNo_img());
		pstmt.setTimestamp(4, vo.getNo_date());
		
		pstmt.executeUpdate();

		CloseUtil.close(pstmt);
		CloseUtil.close(conn);
	}

	public int getListAllCount() throws Exception {

		int count = 0;

		Connection conn = getConnection();
		PreparedStatement pstmt = conn.prepareStatement("SELECT COUNT(*) FROM BOARD_QA");
		ResultSet rs = pstmt.executeQuery();

		if (rs.next())
			count = rs.getInt(1);

		CloseUtil.close(rs);
		CloseUtil.close(pstmt);
		CloseUtil.close(conn);

		return count;
	}
	
	public int getNoListAllCount() throws Exception {

		int count = 0;

		Connection conn = getConnection();
		PreparedStatement pstmt = conn.prepareStatement("SELECT COUNT(*) FROM BOARD_NOTICE");
		ResultSet rs = pstmt.executeQuery();

		if (rs.next())
			count = rs.getInt(1);

		CloseUtil.close(rs);
		CloseUtil.close(pstmt);
		CloseUtil.close(conn);

		return count;
	}

	public List<BoardVO> getSelectAll(int start, int end) throws Exception {

		List list = null;
		StringBuffer sb = new StringBuffer();

		sb.append(
				"SELECT QA_NUM, QA_WRITER, QA_PASSWD, QA_TITLE, QA_CONTENT, QA_DATE, REF, RE_STEP, RE_LEVEL, R ");
		sb.append(
				"FROM (SELECT QA_NUM, QA_WRITER, QA_PASSWD, QA_TITLE, QA_CONTENT, QA_DATE, REF, RE_STEP, RE_LEVEL, ROWNUM R ");
		sb.append(
				"FROM (SELECT QA_NUM, QA_WRITER, QA_PASSWD, QA_TITLE, QA_CONTENT, QA_DATE, REF, RE_STEP, RE_LEVEL ");
		sb.append(
				"FROM BOARD_QA ORDER BY REF DESC, RE_STEP DESC) ORDER BY REF DESC, RE_STEP DESC, RE_LEVEL ASC, QA_DATE ASC) WHERE R >= ? AND R <= ?");

		Connection conn = getConnection();
		PreparedStatement pstmt = conn.prepareStatement(sb.toString());
		
		pstmt.setInt(1, start);
		pstmt.setInt(2, end);
		
		ResultSet rs = pstmt.executeQuery();

		if (rs.next()) {
			
			list = new ArrayList(end);

			do {
				
				BoardVO vo = new BoardVO();
				
				vo.setQa_num(rs.getInt("qa_num"));
				vo.setQa_writer(rs.getString("qa_writer"));
				vo.setQa_title(rs.getString("qa_title"));
				vo.setQa_content(rs.getString("qa_content"));
				vo.setQa_passwd(rs.getString("qa_passwd"));
				vo.setQa_date(rs.getTimestamp("qa_date"));
				vo.setRef(rs.getInt("ref"));
				vo.setRe_level(rs.getInt("re_level"));
				vo.setRe_step(rs.getInt("re_step"));
				
				list.add(vo);

			} while (rs.next());
		}
		
		CloseUtil.close(rs);
		CloseUtil.close(pstmt);

		return list;
	}
	
	public List<BoardVO> getNoSelectAll(int start, int end) throws Exception {

		List list = null;
		StringBuffer sb = new StringBuffer();

		sb.append(
				"SELECT NO_NUM, NO_TITLE, NO_CONTENT, NO_IMG, NO_DATE, R ");
		sb.append(
				"FROM (SELECT NO_NUM, NO_TITLE, NO_CONTENT, NO_IMG, NO_DATE, ROWNUM R ");
		sb.append(
				"FROM (SELECT NO_NUM, NO_TITLE, NO_CONTENT, NO_IMG, NO_DATE ");
		sb.append(
				"FROM BOARD_NOTICE ORDER BY NO_DATE DESC) ORDER BY NO_DATE DESC) WHERE R >= ? AND R <= ?");
		
		Connection conn = getConnection();
		PreparedStatement pstmt = conn.prepareStatement(sb.toString());
		
		pstmt.setInt(1, start);
		pstmt.setInt(2, end);
		
		ResultSet rs = pstmt.executeQuery();

		if (rs.next()) {
			
			list = new ArrayList(end);

			do {
				
				BoardVO vo = new BoardVO();
				
				vo.setNo_num(rs.getInt("no_num"));
				vo.setNo_title(rs.getString("no_title"));
				vo.setNo_content(rs.getString("no_content"));
				vo.setNo_img(rs.getString("no_img"));
				vo.setNo_date(rs.getTimestamp("no_date"));
				list.add(vo);

			} while (rs.next());
		}

		CloseUtil.close(rs);
		CloseUtil.close(pstmt);

		return list;
	}
	
	public BoardVO getDataDetail(int num) throws Exception {
		
		BoardVO vo = null;
		String sql = "SELECT * FROM BOARD_QA WHERE QA_NUM = ?";
		
		Connection conn = getConnection();
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setInt(1, num);
		ResultSet rs = pstmt.executeQuery();

		if (rs.next()) {
			
			vo = new BoardVO();
			
			vo.setQa_num(rs.getInt("qa_num"));
			vo.setQa_writer(rs.getString("qa_writer"));
			vo.setQa_passwd(rs.getString("qa_passwd"));
			vo.setQa_title(rs.getString("qa_title"));
			vo.setQa_content(rs.getString("qa_content"));
			vo.setQa_date(rs.getTimestamp("qa_date"));
			vo.setRef(rs.getInt("ref"));
			vo.setRe_level(rs.getInt("re_level"));
			vo.setRe_step(rs.getInt("re_step"));
		}
		
		CloseUtil.close(rs);
		CloseUtil.close(pstmt);
		CloseUtil.close(conn);
		
		return vo;
	}
	
	public BoardVO getNoDataDetail(int num) throws Exception {

		BoardVO vo = null;
		String sql = "SELECT * FROM BOARD_NOTICE WHERE NO_NUM = ?";

		Connection conn = getConnection();
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setInt(1, num);
		ResultSet rs = pstmt.executeQuery();

		if (rs.next()) {
			
			vo = new BoardVO();
			
			vo.setNo_num(rs.getInt("no_num"));
			vo.setNo_title(rs.getString("no_title"));
			vo.setNo_content(rs.getString("no_content"));
			vo.setNo_img(rs.getString("no_img"));
			vo.setNo_date(rs.getTimestamp("no_date"));
		}
		
		CloseUtil.close(rs);
		CloseUtil.close(pstmt);
		CloseUtil.close(conn);
		
		return vo;
	}

	public BoardVO update(int num) throws Exception {
		
		BoardVO vo = null;

		Connection conn = getConnection();
		PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM BOARD_QA WHERE QA_NUM = ?");
		pstmt.setInt(1, num);
		ResultSet rs = pstmt.executeQuery();

		if (rs.next()) {
			
			vo = new BoardVO();
			
			vo.setQa_num(rs.getInt("qa_num"));
			vo.setQa_writer(rs.getString("qa_writer"));
			vo.setQa_title(rs.getString("qa_title"));
			vo.setQa_content(rs.getString("qa_content"));
			vo.setQa_passwd(rs.getString("qa_passwd"));
			vo.setQa_date(rs.getTimestamp("qa_date"));
			vo.setRef(rs.getInt("ref"));
			vo.setRe_level(rs.getInt("re_level"));
			vo.setRe_step(rs.getInt("re_step"));
		}
		
		CloseUtil.close(rs);
		CloseUtil.close(pstmt);
		CloseUtil.close(conn);

		return vo;
	}
	
public BoardVO noUpdate(int num) throws Exception {
		
		BoardVO vo = null;

		Connection conn = getConnection();
		PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM BOARD_NOTICE WHERE NO_NUM = ?");
		pstmt.setInt(1, num);
		ResultSet rs = pstmt.executeQuery();

		if (rs.next()) {
			
			vo = new BoardVO();
			
			vo.setNo_num(rs.getInt("no_num"));
			vo.setNo_title(rs.getString("no_title"));
			vo.setNo_content(rs.getString("no_content"));
			vo.setNo_img(rs.getString("no_img"));
			vo.setNo_date(rs.getTimestamp("no_date"));
		}
		
		CloseUtil.close(rs);
		CloseUtil.close(pstmt);
		CloseUtil.close(conn);

		return vo;
	}

	public int update(BoardVO vo) throws Exception {

		int result = -1;
		String dbpw = null;

		Connection conn = getConnection();
		PreparedStatement pstmt = conn.prepareStatement("SELECT QA_PASSWD FROM BOARD_QA WHERE QA_NUM = ?");
		pstmt.setInt(1, vo.getQa_num());
		ResultSet rs = pstmt.executeQuery();
		
		if (rs.next()) {
			
			dbpw = rs.getString("qa_passwd");

			if (dbpw.equals(vo.getQa_passwd())) {
				
				String sql =
						"UPDATE BOARD_QA SET QA_TITLE = ?, QA_PASSWD = ?, QA_CONTENT = ?, QA_DATE = ? WHERE QA_NUM = ?";
				
				pstmt = conn.prepareStatement(sql);

				pstmt.setString(1, vo.getQa_title());
				pstmt.setString(2, vo.getQa_passwd());
				pstmt.setString(3, vo.getQa_content());
				pstmt.setTimestamp(4, vo.getQa_date());
				pstmt.setInt(5, vo.getQa_num());
				
				pstmt.executeUpdate();
				
				result = 1;
			}
			else
				result = 0;
		}
		
		CloseUtil.close(rs);
		CloseUtil.close(pstmt);
		CloseUtil.close(conn);

		return result;
	}
	
	public void noUpdate(BoardVO vo) throws Exception {

		String sql = "UPDATE BOARD_NOTICE SET NO_TITLE = ?, NO_CONTENT = ?, NO_DATE = ? WHERE NO_NUM = ?";

		Connection conn = getConnection();
		PreparedStatement pstmt = conn.prepareStatement(sql);
		
		pstmt.setString(1, vo.getNo_title());
		pstmt.setString(2, vo.getNo_content());
		pstmt.setTimestamp(3, vo.getNo_date());
		pstmt.setInt(4, vo.getNo_num());
		
		pstmt.executeUpdate();
		
		CloseUtil.close(pstmt);
		CloseUtil.close(conn);
	}

	public int delete(BoardVO vo) throws Exception {
		
		int result = -1;
		String dbpw = null;

		Connection conn = getConnection();
		PreparedStatement pstmt = conn.prepareStatement("SELECT QA_PASSWD FROM BOARD_QA WHERE QA_NUM = ?");
		pstmt.setInt(1, vo.getQa_num());
		ResultSet rs = pstmt.executeQuery();

		if (rs.next()) {
			
			dbpw = rs.getString("qa_passwd");

			if (dbpw.equals(vo.getQa_passwd())) {
				
				pstmt = conn.prepareStatement("DELETE FROM BOARD_QA WHERE QA_NUM = ?");
				pstmt.setInt(1, vo.getQa_num());
				pstmt.executeUpdate();
				
				result = 1;
			}
			else
				result = 0;
		}
		
		CloseUtil.close(rs);
		CloseUtil.close(pstmt);
		CloseUtil.close(conn);

		return result;
	}
	
	public int noDelete(BoardVO vo) throws Exception {

		Connection conn = getConnection();
		PreparedStatement pstmt = conn.prepareStatement("DELETE FROM BOARD_NOTICE WHERE NO_NUM = ?");
		pstmt.setInt(1, vo.getNo_num());
		pstmt.executeUpdate();

		CloseUtil.close(pstmt);
		CloseUtil.close(conn);

		return 0;
	}

}
