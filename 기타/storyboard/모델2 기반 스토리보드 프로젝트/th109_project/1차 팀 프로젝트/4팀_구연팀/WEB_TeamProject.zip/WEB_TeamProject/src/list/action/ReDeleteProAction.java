package list.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import board.model.*;
import join.model.JoinVO;
import list.model.ListDAO;
import project.action.CommandAction;

public class ReDeleteProAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		request.setCharacterEncoding("UTF-8");
		
		JoinVO vo = new JoinVO();
		
		String mr_email = request.getParameter("mr_email");
		String pageNum = request.getParameter("pageNum");

		vo.setMr_email(request.getParameter("mr_email"));
		ListDAO dao = ListDAO.getInstance();

		int check = dao.reDelete(vo);

		request.setAttribute("mr_email", mr_email);
		request.setAttribute("pageNum", pageNum);
		request.setAttribute("check", check);

		return "/list/memDeletePro_re.jsp";
	}

}
