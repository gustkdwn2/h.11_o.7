package order.action;

import java.util.List;
import java.util.Properties;

import javax.mail.*;
import javax.mail.internet.*;
import javax.servlet.http.*;

import join.model.*;
import order.model.OrderDAO;
import project.action.CommandAction;
import project.mail.SMTPAuthenticatior;
import store.model.StoreVO;

public class OrderSubmitAction2 implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {

		request.setCharacterEncoding("UTF-8");

		StoreVO vo = new StoreVO();
		OrderDAO dao = OrderDAO.getInstance();

		HttpSession session = request.getSession();
		String m_email = ((String) session.getAttribute("memID"));

		int num = Integer.parseInt(request.getParameter("num"));

		String mr_email = dao.getEmail(num);

		String from = "pangyoadvisor@gmail.com";
		String toClient = m_email;
		/*String toStore = mr_email;*/

		String subject = "안녕하세요. 판교어드바이저입니다.";

		String content = "";

		content += "<table style='border: 5px;border-color: solid white;border-collapse: collapse;";
		content += "padding: 5px;text-align: center;width: 500px;'>";
		content += "<tr><td colspan='4' ><h1>영 수 증 </h1></td></tr><tr><td colspan='2' ><h2>주문자</h2></td><td colspan='2' ><h2>"
				+ toClient + "</h2></td></tr></table>";

		content += "<table style='border: 5px;border-color: solid white;background-color:pink;";
		content += "border-collapse: collapse;padding: 5px;width: 500px;-moz-border-radius: 15px;";
		content += "-webkit-border-radius: 15px;-o-border-radius: 15px;text-align: center;'>";
		content += "<tr><th ><br><h3><b>메  뉴</b></h3></th><th ><br><h3><b>가  격</b></h3></th>";
		content += "<th ><br><h3><b>수  량</b></h3></th><th ><br><h3><b>합  계</b></h3></th></tr>";

		List receipt = null;

		int count = dao.getListAllCount(m_email, num);
		int total = dao.total(m_email, num);

		System.out.println("count값은?!!!!!" + count);
		System.out.println("total값은?!!!!!" + total);
		if (count > 0)
			receipt = dao.getOrderList(count, m_email, num);
		for (int i = 0; i < receipt.size(); i++) {
			System.out.println(receipt.get(i));

			if (i % 4 == 0) {

				content += "<tr><td style='text-align: center;'><br>" + receipt.get(i) + "</td>";
			} else if (i % 4 == 3) {
				content += "<td style='text-align: center;'><br>" + receipt.get(i) + "</td></tr>";

			} else {
				content += "<td style='text-align: center;'><br>" + receipt.get(i) + "</td>";

			}
		}

		content += "<tr><td colspan='3' style='text-align: right;'><br><br><font color='red'><b>총　　합</b></font><br><br></td>";
		content += "<td style='text-align: center;'><br><br><font color='red'><b>" + total + "</b></font><br><br></td>";
		content += "</tr>";
		content += "<tr><td colspan='3' style='text-align: right;'><br><br><b>예약자 전화번호 : </b><br><br></td>";
	    content += "<td style='text-align: center;'><br><br><b>" + request.getParameter("phone") + "</b><br><br></td></tr></table><br>";

		Properties p = new Properties();

		p.put("mail.smtp.host", "smtp.gmail.com");

		p.put("mail.smtp.port", "465");
		p.put("mail.smtp.starttls.enable", "true");
		p.put("mail.smtp.auth", "true");
		p.put("mail.smtp.debug", "true");
		p.put("mail.smtp.socketFactory.port", "465");
		p.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
		p.put("mail.smtp.socketFactory.fallback", "false");

		try {
			Authenticator auth = new SMTPAuthenticatior();
			Session ses = Session.getInstance(p, auth);

			ses.setDebug(true);

			MimeMessage msg = new MimeMessage(ses);
			msg.setSubject(subject);

			Address fromAddr = new InternetAddress(from);
			msg.setFrom(fromAddr);

			Address toClientAddr = new InternetAddress(toClient);
			msg.addRecipient(Message.RecipientType.TO, toClientAddr);
			/*Address toStoreAddr = new InternetAddress(toStore);
			msg.addRecipient(Message.RecipientType.TO, toStoreAddr);*/

			msg.setContent(content, "text/html;charset=UTF-8");

			Transport.send(msg);
		} catch (Exception e) {
			e.printStackTrace();
		}
		request.setAttribute("email", m_email);
		request.setAttribute("num", num);

		return "/store/orderSubmit.jsp";
	}

}
