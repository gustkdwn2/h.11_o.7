package menu.model;

import java.io.Serializable;
import java.sql.Timestamp;

public class MenuVO implements Serializable {

	private int mr_num, menu_price;
	private String menu_item;
	private Timestamp menu_date;

	public int getMr_num() {
		return mr_num;
	}

	public void setMr_num(int mr_num) {
		this.mr_num = mr_num;
	}

	public int getMenu_price() {
		return menu_price;
	}

	public void setMenu_price(int menu_price) {
		this.menu_price = menu_price;
	}

	public String getMenu_item() {
		return menu_item;
	}

	public void setMenu_item(String menu_item) {
		this.menu_item = menu_item;
	}

	public Timestamp getMenu_date() {
		return menu_date;
	}

	public void setMenu_date(Timestamp menu_date) {
		this.menu_date = menu_date;
	}

}
