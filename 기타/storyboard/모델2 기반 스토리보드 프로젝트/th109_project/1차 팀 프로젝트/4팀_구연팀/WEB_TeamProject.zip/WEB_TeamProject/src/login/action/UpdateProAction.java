package login.action;

import javax.servlet.http.*;

import join.model.JoinVO;
import login.model.LoginDAO;
import project.action.CommandAction;

public class UpdateProAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {

		request.setCharacterEncoding("UTF-8");
		
		HttpSession session = request.getSession();
		
		String id = (String) session.getAttribute("memID");
		String passwd = request.getParameter("passwd");
		
		JoinVO vo = new JoinVO();
		LoginDAO dao = LoginDAO.getInstance();
		
		int check = dao.userCheck(id, passwd);
		
		if (check == 1) {
			vo.setM_email(id);
			vo.setM_passwd(passwd);
			vo.setM_name(request.getParameter("name"));
			vo.setM_pwq(request.getParameter("pw_q"));
			vo.setM_pwa(request.getParameter("pw_a"));
			
			dao.updateMember(vo);
		}
		
		session.removeAttribute("memName");
		session.setAttribute("memName", request.getParameter("name"));
		
		request.setAttribute("check", check);

		return "/login/logUpPro.jsp";
	}
	
}
