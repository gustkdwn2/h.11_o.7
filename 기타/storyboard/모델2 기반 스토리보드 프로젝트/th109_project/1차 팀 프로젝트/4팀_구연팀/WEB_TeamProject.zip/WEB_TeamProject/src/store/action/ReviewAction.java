package store.action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import order.model.OrderDAO;
import project.action.CommandAction;
import store.model.*;

public class ReviewAction implements CommandAction {
	
	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		request.setCharacterEncoding("UTF-8");
		
		int pageSize = 5;
		String pageNum = request.getParameter("pageNum");
		
		if (pageNum == null)
			pageNum = "1";

		int currentPage = Integer.parseInt(pageNum);
		int startRow = (currentPage * pageSize) - (pageSize - 1);
		int endRow = (currentPage * pageSize); int number = 0;
		
		StoreDAO dao = StoreDAO.getInstance();
		String num = request.getParameter("num");
		
		int count = dao.getReviewCount(Integer.parseInt(num));
		double avg = dao.avg(Integer.parseInt(num));
		
		List list = dao.getReview(Integer.parseInt(num), startRow, endRow);
		StoreVO vo = OrderDAO.getInstance().getDetail(Integer.parseInt(num));
		
		number = count - (currentPage - 1) * pageSize;

		request.setAttribute("vo", vo);
		request.setAttribute("list", list);
		request.setAttribute("num", num);
		request.setAttribute("count", count);
		request.setAttribute("avg", avg);
		request.setAttribute("currentPage", new Integer(currentPage));
		request.setAttribute("startRow", new Integer(startRow));
		request.setAttribute("endRow", new Integer(endRow));
		request.setAttribute("pageSize", new Integer(pageSize));
		request.setAttribute("number", new Integer(number));

		return "/store/review.jsp";
	}

}
