package project.action;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import store.model.StoreVO;

public class MainAction implements CommandAction {

   @Override
   public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
      
      /*MainDAO dao = MainDAO.getInstance();
      
      StoreVO voKor = dao.getStoreDetail(dao.bestStore("한식"), "한식");
      StoreVO voChn = dao.getStoreDetail(dao.bestStore("중식"), "중식");
      StoreVO voJap = dao.getStoreDetail(dao.bestStore("일식"), "일식");
      StoreVO voCafe = dao.getStoreDetail(dao.bestStore("카페"), "카페");
      StoreVO voFast = dao.getStoreDetail(dao.bestStore("패스트푸드"), "패스트푸드");
      StoreVO voPub = dao.getStoreDetail(dao.bestStore("술집"), "술집");
      
      List list = new ArrayList();
      list.add(voKor);
      
//      list = new ArrayList();
      list.add(voChn);
      
 //     list = new ArrayList();
      list.add(voJap);
      
 //     list = new ArrayList();
      list.add(voCafe);
      
//      list = new ArrayList();
      list.add(voFast);
      
//      list = new ArrayList();
      list.add(voPub);
      
      request.setAttribute("list", list);*/
      
      return "/main/main.jsp";
   }
   
}