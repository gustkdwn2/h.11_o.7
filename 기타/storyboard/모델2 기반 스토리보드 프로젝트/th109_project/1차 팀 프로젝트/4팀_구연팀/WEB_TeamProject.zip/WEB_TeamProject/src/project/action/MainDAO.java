package project.action;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import dbclose.util.CloseUtil;
import store.model.StoreVO;

public class MainDAO {

   private static MainDAO instance = new MainDAO();

   public MainDAO() {

   }

   public static MainDAO getInstance() {
      return instance;
   }

   public Connection getConnection() throws Exception {

      Context ctx = new InitialContext();
      DataSource ds = (DataSource) ctx.lookup("java:comp/env/jdbc:ProjectDB");

      return ds.getConnection();
   }
   
   public int bestStore(String type) throws Exception {

      int mr_num = 0;
      
      StringBuffer sb = new StringBuffer();
      sb.append("SELECT MR_NUM FROM REVIEW GROUP BY MR_NUM HAVING AVG(V_GRADE) = (SELECT MAX(AVG(V_GRADE)) ");
      sb.append("FROM REVIEW GROUP BY MR_NUM HAVING MR_NUM IN ");
      sb.append("(SELECT MR_NUM FROM MEMBERS_RE WHERE MR_TYPE = ?))");
      
      Connection conn = getConnection();
      PreparedStatement pstmt = conn.prepareStatement(sb.toString());
      pstmt.setString(1, type);
      ResultSet rs = pstmt.executeQuery();

       while (rs.next())
          mr_num = rs.getInt("mr_num");
      
      CloseUtil.close(rs);
      CloseUtil.close(pstmt);
      CloseUtil.close(conn);

      return mr_num;
   }
   
   public StoreVO getStoreDetail(int num, String type) throws Exception {
      
      StoreVO vo = null;
      String sql = "SELECT * FROM MEMBERS_RE WHERE MR_NUM = ? AND MR_TYPE=?";
      
      Connection conn = getConnection();
      
      PreparedStatement pstmt = conn.prepareStatement(sql);
      pstmt.setInt(1, num);
      pstmt.setString(2, type);
      
      ResultSet rs = pstmt.executeQuery();
      
      if (rs.next()) {

         vo = new StoreVO();

         do {
            vo.setMr_num(rs.getInt("mr_num"));
            vo.setMr_email(rs.getString("mr_email"));
            vo.setMr_type(rs.getString("mr_type"));
            vo.setMr_name(rs.getString("mr_name"));
            vo.setMr_img(rs.getString("mr_img"));
            vo.setMr_phone(rs.getString("mr_phone"));
            vo.setMr_locate(rs.getString("mr_locate"));
            vo.setMr_content(rs.getString("mr_content"));
            vo.setMr_info(rs.getString("mr_info"));

         } while (rs.next());
      }

      return vo;
   }
   
}