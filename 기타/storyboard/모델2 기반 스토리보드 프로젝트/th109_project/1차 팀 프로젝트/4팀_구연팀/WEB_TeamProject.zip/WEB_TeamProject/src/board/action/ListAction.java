package board.action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import board.model.BoardDAO;
import project.action.CommandAction;

public class ListAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		request.setCharacterEncoding("UTF-8");
		
		int pageSize = 10;
		String pageNum = request.getParameter("pageNum");

		if (pageNum == null)
			pageNum = "1";

		int currentPage = Integer.parseInt(pageNum);
		int startRow = (currentPage * pageSize) - (pageSize - 1);
		int endRow = (currentPage * pageSize);

		List list = null;
		BoardDAO dao = BoardDAO.getInstance();
		
		int count = dao.getListAllCount();

		if (count > 0)
			list = dao.getSelectAll(startRow, endRow);

		int number = count - (currentPage - 1) * pageSize;

		request.setAttribute("pageSize", new Integer(pageSize));
		request.setAttribute("currentPage", new Integer(currentPage));
		request.setAttribute("startRow", new Integer(startRow));
		request.setAttribute("endRow", new Integer(endRow));
		request.setAttribute("count", new Integer(count));
		request.setAttribute("number", new Integer(number));
		request.setAttribute("list", list);

		return "/board_qa/list.jsp";
	}
	
}
