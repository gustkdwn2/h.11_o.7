package list.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import join.model.JoinVO;
import list.model.ListDAO;
import project.action.CommandAction;

public class DeleteProAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		request.setCharacterEncoding("UTF-8");
		
		JoinVO vo = new JoinVO();
		
		String m_email = request.getParameter("m_email");
		String pageNum = request.getParameter("pageNum");

		vo.setM_email(request.getParameter("m_email"));
		ListDAO dao = ListDAO.getInstance();

		int check = dao.memDelete(vo);

		request.setAttribute("m_email", m_email);
		request.setAttribute("pageNum", pageNum);
		request.setAttribute("check", check);

		return "/list/memDeletePro.jsp";
	}

}
