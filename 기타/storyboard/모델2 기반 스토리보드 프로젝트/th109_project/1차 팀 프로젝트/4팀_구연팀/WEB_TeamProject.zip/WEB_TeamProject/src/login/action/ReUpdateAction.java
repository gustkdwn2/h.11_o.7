package login.action;

import javax.servlet.http.*;

import join.model.JoinVO;
import login.model.LoginDAO;
import project.action.CommandAction;

public class ReUpdateAction implements CommandAction {
	
	public String getType(String type) throws Exception {

		String typeName = "";

		if (type.equals("한식"))
			typeName = "kor";
		else if (type.equals("중식"))
			typeName = "chn";
		else if (type.equals("일식"))
			typeName = "jap";
		else if (type.equals("카페"))
			typeName = "cafe";
		else if (type.equals("패스트푸드"))
			typeName = "fast";
		else if (type.equals("술집"))
			typeName = "soju";

		return typeName;
	}
	
	public String[] getPhone(String number) {

		String[] str = new String(number).split("-");

		return str;
	}

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {

		request.setCharacterEncoding("UTF-8");
		
		HttpSession session = request.getSession();
		String id = (String) session.getAttribute("memID_re");
		
		LoginDAO dao = LoginDAO.getInstance();
		JoinVO vo = dao.getMember_re(id);
		
		String[] str = getPhone(vo.getMr_phone());
		
		if (str.length == 2) {
			request.setAttribute("code", "x");
			request.setAttribute("phone1", str[0]);
			request.setAttribute("phone2", str[1]);
		}
		else if (str.length == 3) {
			request.setAttribute("code", str[0]);
			request.setAttribute("phone1", str[1]);
			request.setAttribute("phone2", str[2]);
		}
		
		request.setAttribute("vo", vo);
		request.setAttribute("typeName", getType(vo.getMr_type()));
		
		return "/login/logUpdate_re.jsp";
	}
}
