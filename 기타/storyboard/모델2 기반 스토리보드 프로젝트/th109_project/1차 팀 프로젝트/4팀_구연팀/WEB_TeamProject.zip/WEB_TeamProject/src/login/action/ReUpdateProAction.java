package login.action;

import java.awt.Image;
import java.io.File;
import java.sql.Timestamp;

import javax.servlet.http.*;
import javax.swing.ImageIcon;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import join.model.JoinVO;
import login.model.LoginDAO;
import project.action.CommandAction;

public class ReUpdateProAction implements CommandAction {

	public String getTypeName(String type) throws Exception {

		String typeName = "";

		if (type.equals("kor"))
			typeName = "한식";
		else if (type.equals("chn"))
			typeName = "중식";
		else if (type.equals("jap"))
			typeName = "일식";
		else if (type.equals("cafe"))
			typeName = "카페";
		else if (type.equals("fast"))
			typeName = "패스트푸드";
		else if (type.equals("soju"))
			typeName = "술집";

		return typeName;
	}

	public String getCode(String type) throws Exception {

		String code = "";

		if (type.equals("031"))
			code = "031-";
		else if (type.equals("010"))
			code = "010-";

		return code;
	}

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {

		request.setCharacterEncoding("UTF-8");

		HttpSession session = request.getSession();

		String id = (String) session.getAttribute("memID_re");
		String passwd = request.getParameter("passwd");

		JoinVO vo = new JoinVO();
		LoginDAO dao = LoginDAO.getInstance();

		int check = dao.userCheck_re(id, passwd);

		if (check == 1) {
			
			String infoVal = "";
			String phone = getCode(request.getParameter("code")) + request.getParameter("phone1") + "-"
					+ request.getParameter("phone2");
			String[] info = request.getParameterValues("etc");
			
			for (int i = 0; i < info.length; i++) {
				if (i < (info.length - 1))
					infoVal += info[i] + ", ";
				else
					infoVal += info[i];
			}
			
			vo.setMr_email(id);
			vo.setMr_passwd(passwd);
			vo.setMr_type(getTypeName(request.getParameter("type")));
			vo.setMr_name(request.getParameter("store"));
			vo.setMr_phone(phone);
			vo.setMr_locate(request.getParameter("locate"));
			vo.setMr_date(new Timestamp(System.currentTimeMillis()));
			vo.setMr_content(request.getParameter("content"));
			vo.setMr_info(infoVal);
			vo.setMr_pwq(request.getParameter("pw_q"));
			vo.setMr_pwa(request.getParameter("pw_a"));		

			dao.updateMember_re(vo);
		}
		
		session.removeAttribute("memName_re");
		session.setAttribute("memName_re", request.getParameter("store"));

		request.setAttribute("check", check);

		return "/login/logUpPro_re.jsp";
	}

}
