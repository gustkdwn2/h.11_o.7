package board.action;

import java.io.File;
import java.sql.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import board.model.*;
import project.action.CommandAction;

public class NoUpdateProAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {

		request.setCharacterEncoding("UTF-8");

		String pageNum = request.getParameter("pageNum");
		
		BoardVO vo = new BoardVO();
		BoardDAO dao = BoardDAO.getInstance();

		vo.setNo_num(Integer.parseInt(request.getParameter("num")));
		vo.setNo_title(request.getParameter("title"));
		vo.setNo_content(request.getParameter("content"));
		vo.setNo_date(new Timestamp(System.currentTimeMillis()));

		dao.noUpdate(vo);

		request.setAttribute("pageNum", pageNum);

		return "/board_notice/updatePro.jsp";
	}

}
