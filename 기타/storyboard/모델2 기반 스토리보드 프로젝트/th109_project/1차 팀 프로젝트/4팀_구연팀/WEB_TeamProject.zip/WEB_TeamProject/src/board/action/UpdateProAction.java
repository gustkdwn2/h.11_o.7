package board.action;

import java.sql.Timestamp;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import board.model.*;
import project.action.CommandAction;

public class UpdateProAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		request.setCharacterEncoding("UTF-8");

		String pageNum = request.getParameter("pageNum");

		BoardVO vo = new BoardVO();
		BoardDAO dao = BoardDAO.getInstance();

		vo.setQa_num(Integer.parseInt(request.getParameter("num")));
		vo.setQa_passwd(request.getParameter("passwd"));
		vo.setQa_title(request.getParameter("title"));
		vo.setQa_content(request.getParameter("content"));
		vo.setQa_date(new Timestamp(System.currentTimeMillis()));

		int check = dao.update(vo);

		request.setAttribute("pageNum", pageNum);
		request.setAttribute("check", new Integer(check));

		return "/board_qa/updatePro.jsp";
	}

}
