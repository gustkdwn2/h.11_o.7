package login.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import project.action.CommandAction;

public class LogImgProAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {

		request.setCharacterEncoding("UTF-8");
		HttpSession session = request.getSession();

		String upfile = request.getParameter("upfile");
		request.setAttribute("upfile", upfile);
		
		int i = 0;
		request.setAttribute("success", i);

		return "/login/logImagePro.jsp";
	}

}
