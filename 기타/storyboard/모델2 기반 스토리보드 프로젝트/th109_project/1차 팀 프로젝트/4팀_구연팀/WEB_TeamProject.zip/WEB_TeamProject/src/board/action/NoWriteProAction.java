package board.action;

import java.io.File;
import java.sql.Timestamp;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import board.model.*;
import project.action.CommandAction;

public class NoWriteProAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		request.setCharacterEncoding("UTF-8");
		
		int sizeLimit = 10 * 1024 * 1024;
		String savePath = request.getSession().getServletContext().getRealPath("/upload");
		
		MultipartRequest multi =
				new MultipartRequest( request, savePath, sizeLimit, "UTF-8", new DefaultFileRenamePolicy() );
		String fileName = multi.getFilesystemName("upfile");
		
		File files = multi.getFile("upfile");
		
		BoardVO vo = new BoardVO();
		BoardDAO dao = BoardDAO.getInstance();
		
		vo.setNo_num(Integer.parseInt(multi.getParameter("num")));
		vo.setNo_title(multi.getParameter("title"));
		vo.setNo_content(multi.getParameter("content"));	
		vo.setNo_img(fileName);
		vo.setNo_date(new Timestamp(System.currentTimeMillis()));
			
		dao.noInsert(vo);
		
		return "/board_notice/writePro.jsp";
	}

}
