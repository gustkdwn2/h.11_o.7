package board.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import board.model.*;
import project.action.CommandAction;

public class DeleteProAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		request.setCharacterEncoding("UTF-8");
		
		BoardVO vo = new BoardVO();
		
		String num = request.getParameter("num");
		String pageNum = request.getParameter("pageNum");
		String passwd = request.getParameter("passwd");

		vo.setQa_num(Integer.parseInt(request.getParameter("num")));
		vo.setQa_passwd(request.getParameter("passwd"));
		
		BoardDAO dao = BoardDAO.getInstance();

		int check = dao.delete(vo);

		request.setAttribute("num", num);
		request.setAttribute("pageNum", pageNum);
		request.setAttribute("check", check);

		return "/board_qa/deletePro.jsp";
	}

}
