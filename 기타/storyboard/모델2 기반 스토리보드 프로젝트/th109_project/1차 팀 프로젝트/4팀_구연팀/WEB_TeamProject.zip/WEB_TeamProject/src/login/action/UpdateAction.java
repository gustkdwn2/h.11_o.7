package login.action;

import javax.servlet.http.*;

import join.model.JoinVO;
import login.model.LoginDAO;
import project.action.CommandAction;

public class UpdateAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {

		request.setCharacterEncoding("UTF-8");
		
		HttpSession session = request.getSession();
		String id = (String) session.getAttribute("memID");
		
		LoginDAO dao = LoginDAO.getInstance();
		JoinVO vo = dao.getMember(id);

		request.setAttribute("vo", vo);
		
		return "/login/logUpdate.jsp";
	}

}
