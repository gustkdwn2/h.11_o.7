package store.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import order.model.OrderDAO;
import project.action.CommandAction;
import store.model.*;

public class DetailAction implements CommandAction {
	
	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		request.setCharacterEncoding("UTF-8");
		
		StoreDAO dao = StoreDAO.getInstance();
		String num = request.getParameter("num");

		StoreVO vo = OrderDAO.getInstance().getDetail(Integer.parseInt(num));
		double avg = dao.avg(vo.getMr_num());

		request.setAttribute("vo", vo);
		request.setAttribute("avg", avg);

		return "/store/detail.jsp";
	}

}
