package join.action;

import java.sql.Timestamp;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import join.model.*;
import project.action.CommandAction;

public class JoinProAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		request.setCharacterEncoding("UTF-8");
		
		JoinVO vo = new JoinVO();
		
		vo.setM_email(request.getParameter("id"));
		vo.setM_passwd(request.getParameter("passwd"));
		vo.setM_name(request.getParameter("name"));
		vo.setM_date(new Timestamp(System.currentTimeMillis()));
		vo.setM_pwq(request.getParameter("pw_q"));
		vo.setM_pwa(request.getParameter("pw_a"));
		
		JoinDAO dao = JoinDAO.getInstance();
		dao.insertMember(vo);

		return "/join/joinPro.jsp";
	}

}
