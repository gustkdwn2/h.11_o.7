package menu.action;

import javax.servlet.http.*;

import project.action.CommandAction;

public class MenuFormAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {

		return "/menu/menuForm.jsp";
	}

}
