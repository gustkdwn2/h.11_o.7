package join.action;

import java.awt.Image;
import java.io.File;
import java.sql.Timestamp;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.ImageIcon;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import join.model.*;
import project.action.CommandAction;

public class ReJoinProAction implements CommandAction {

	public String getTypeName(String type) throws Exception {

		String typeName = "";

		if (type.equals("kor"))
			typeName = "한식";
		else if (type.equals("chn"))
			typeName = "중식";
		else if (type.equals("jap"))
			typeName = "일식";
		else if (type.equals("cafe"))
			typeName = "카페";
		else if (type.equals("fast"))
			typeName = "패스트푸드";
		else if (type.equals("soju"))
			typeName = "술집";

		return typeName;
	}
	
	public String getCode(String type) throws Exception {

		String code = "";

		if (type.equals("031"))
			code = "031-";
		else if (type.equals("010"))
			code = "010-";

		return code;
	}

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {

		request.setCharacterEncoding("UTF-8");
		
		int sizeLimit = 10 * 1024 * 1024;
		String savePath = request.getSession().getServletContext().getRealPath("/upload");
		
		MultipartRequest multi =
				new MultipartRequest( request, savePath, sizeLimit, "UTF-8", new DefaultFileRenamePolicy() );
		String fileName = multi.getFilesystemName("upfile");
		
		File files = multi.getFile("upfile");
		
		String infoVal = "";
		String phone =
				getCode(multi.getParameter("code")) + multi.getParameter("phone1") + "-" + multi.getParameter("phone2");
		String[] info = multi.getParameterValues("etc");
		
		if (info.length != 0) {
			for (int i = 0; i < info.length; i++) {
				if (i < (info.length - 1))
					infoVal += info[i] + ", ";
				else
					infoVal += info[i];
			}
		}
		
		JoinVO vo = new JoinVO();
		JoinDAO dao = JoinDAO.getInstance();
		
		vo.setMr_email(multi.getParameter("id"));
		vo.setMr_passwd(multi.getParameter("passwd"));
		vo.setMr_type(getTypeName(multi.getParameter("type")));
		vo.setMr_name(multi.getParameter("store"));
		vo.setMr_img(fileName);
		vo.setMr_phone(phone);
		vo.setMr_locate(multi.getParameter("locate"));
		vo.setMr_content(multi.getParameter("content"));
		vo.setMr_date(new Timestamp(System.currentTimeMillis()));
		vo.setMr_info(infoVal);
		vo.setMr_pwq(multi.getParameter("pw_q"));
		vo.setMr_pwa(multi.getParameter("pw_a"));
		
		fileName = multi.getFilesystemName("upfile1");
		files = multi.getFile("upfile1");
		
		vo.setMr_img1(fileName);
		
		fileName = multi.getFilesystemName("upfile2");
		files = multi.getFile("upfile2");
		
		vo.setMr_img2(fileName);
		
		fileName = multi.getFilesystemName("upfile3");
		files = multi.getFile("upfile3");
		
		vo.setMr_img3(fileName);
		
		dao.insertMember_re(vo);
		
		request.setAttribute("vo", vo);

		return "/join/joinPro_re.jsp";
	}

}
