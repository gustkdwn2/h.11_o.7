create table notice(
JN number(4) PRIMARY key, --번호
JS varchar2(100),         --제목
JW varchar2(20),          --작성자
JD date default sysdate,  --작성일
JC varchar2(300)          --내용
);

create sequence notice_num;
select * from notice
commit;
drop sequence notice_seq;
-- 테스트를 위한 Dummy Date 입력

insert into notice (JN,JS,JW,JD,JC) 
values(1,'Title','Doyeon','2016-04-04','qq');

insert into notice (JN, JS, JW, JD, JC) values (notice_num.nextval, ?, ?, ?, ?);

select *from(select JS,JD, rownum rn from(select JS,JD from notice order by jd desc)) where rn>=3 and rn<=4

select jS,JD,JC, rownum rn from notice order by desc;
select * from(select * from notice order by JD desc) where rownum=1