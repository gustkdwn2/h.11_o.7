package edu.kosta.JuicyCall.board.model;

import java.io.Serializable;
import java.sql.Timestamp;
								// 네트워크에서 데이터는 바이트 단위로 전송이 된다. 객체를 바이트 단위로 보내야 한다.
								// 객체 직렬화 , 객체 데이터를 바이트 단위로 분해하여 보내주는 것
public class NoticeVO implements Serializable {
	
	// 필드 선언
	private int JN;			// 글번호
	private String JS;		// 제목
	private String JW;		// 작성자
	private Timestamp JD;		// 글쓴 날짜
	private String JC;		// 글 내용
	
	
	
	
	// Setter / Getter
	public int getJN() {
		return JN;
	}
	public void setJN(int jN) {
		JN = jN;
	}
	public String getJS() {
		return JS;
	}
	public void setJS(String jS) {
		JS = jS;
	}
	public String getJW() {
		return JW;
	}
	public void setJW(String jW) {
		JW = jW;
	}
	public Timestamp getJD() {
		return JD;
	}
	public void setJD(Timestamp jD) {
		JD = jD;
	}
	public String getJC() {
		return JC;
	}
	public void setJC(String jC) {
		JC = jC;
	}
	
	

	
}