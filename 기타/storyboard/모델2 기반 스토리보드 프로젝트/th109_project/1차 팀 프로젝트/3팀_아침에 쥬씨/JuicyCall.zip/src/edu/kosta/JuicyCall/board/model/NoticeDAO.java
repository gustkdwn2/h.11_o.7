package edu.kosta.JuicyCall.board.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import dbclose.util.CloseUtil;
import edu.kosta.JuicyCall.board.model.*;

// Controller
public class NoticeDAO {

	private static NoticeDAO instance = new NoticeDAO(); // 한번만 객체를 생성하여 모든
															// 클라이언트들이 공유

	// 생성자
	public NoticeDAO() {
	}

	public static NoticeDAO getInstance() {
		return instance;
	}// getInstance()

	// DB연결
	public Connection getConnection() throws Exception {
		// 연결은 JNDI & POLL 형태로 연결 객체 생성해서 리턴
		Context ctx = new InitialContext();
		// Context env = (Context)ctx.lookup("java:comp/env");
		DataSource ds = (DataSource) ctx.lookup("java:comp/env/jdbc:BoardDB");

		return ds.getConnection();
	}// getConnection();

	// insert(vo) method - 새로운 글을 게시판에 추가, 글 입력 처리에 사용
	public void insert(NoticeVO vo) throws Exception {
		Connection conn = getConnection();
		PreparedStatement pstmt = conn
				.prepareStatement("insert into notice (JN, JS, JW, JD, JC) values (notice_num.nextval, ?, ?, ?, ?)");

		pstmt.setString(1, vo.getJS());
		pstmt.setString(2, "관리자");
		pstmt.setTimestamp(3, vo.getJD());
		pstmt.setString(4, vo.getJC());

		pstmt.executeQuery(); // DB 명령문을 전달해서 보낸다. (DB는 명칭 oracle이 서버관리! 갤럭시&삼성
								// ㅇㅋ?ㅇㅇ)

		/* ResultSet rs = null; */ // 위에 내용을 보낸후에 값을 가져올때 그걸 result에 넣는다.
									// insert(집어넣는문, 집어넣었지만 결과는 보이지 않는다..)문에는
									// ResultSet이 거의 필요없다.
									// executeQuery();는 실행되고 나서 반응이나오면 그값을 가져온다.
									// executeUpdate를 써도 상관없다.

		CloseUtil.close(pstmt);
		CloseUtil.close(conn);

	}

	public NoticeVO show(int jn) throws Exception {
		Connection conn = getConnection();

		PreparedStatement pstmt = conn.prepareStatement("select * from notice where JN = ?");

		pstmt.setInt(1, jn); // "select * from notice where JN = ?" 앞에 숫자 '1'은
								// 물음표의 첫번째 index값을 나타내며 뒤에 jn은 그 물음표 부분에 들어가는
								// 값을 나타낸다.

		ResultSet rs = pstmt.executeQuery(); // 위에 내용을 보낸후에 값을 가져올때 그걸 result에
												// 넣는다.
		// insert(집어넣는문, 집어넣었지만 결과는 보이지 않는다..)문에는
		// ResultSet이 거의 필요없다.
		// executeQuery();는 실행되고 나서 반응이나오면 그값을 가져온다.
		// executeUpdate를 써도 상관없다.
		NoticeVO vo = new NoticeVO();
		if (rs.next()) {
			vo.setJN(rs.getInt("JN"));
			vo.setJS(rs.getString("JS"));
			vo.setJW(rs.getString("JW"));
			vo.setJD(rs.getTimestamp("JD"));
			vo.setJC(rs.getString("JC"));
		}

		CloseUtil.close(rs);
		CloseUtil.close(pstmt);
		CloseUtil.close(conn);

		return vo; // DB에 명령문 전달하고 다시 받아서 VIEW로 뿌리므로 return 적용.

	}// insert() 문과 content 문은 이걸로 끝!!!!!

	public void delete(int jn) throws Exception { // DeletePro.jsp 만들기 전에 여기서 먼저
													// 적용.
		Connection conn = getConnection();
		PreparedStatement pstmt = conn.prepareStatement("delete from notice where JN=?");
		pstmt.setInt(1, jn);

		pstmt.executeQuery();

		CloseUtil.close(pstmt);
		CloseUtil.close(conn);
	}

	// notice!
	public List<NoticeVO> getSelectAll(int start, int end) throws Exception {
		Connection conn = getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List list = null;

		// notice는 DB의 모든 파일을 가져와야 하기 때문에 변수가 아닌 배열 격에 리스트를 사용한다.

		// DB rownum 사용, 필드명 자체를 하나 더줘서 그걸로 나열하겠다.
		// rownum 자체는 값을 바로 필드명으로 써서 불러낼수 없음.
		String sql = "select *from(select JS,JD,JN, rownum rn from(select JS,JD,JN from notice order by jd desc)) where rn>=? and rn<=?";
                     // 시간순대로 최신글이 위로  나오게 오름차순으로 정렬함.
		pstmt = conn.prepareStatement(sql);
		pstmt.setInt(1, start);
		pstmt.setInt(2, end);
		rs = pstmt.executeQuery();

		if (rs.next()) {
			list = new ArrayList(end); // end는 배열의 개수를 정해준다.

			do {
				NoticeVO vo = new NoticeVO();
				vo.setJS(rs.getString("JS"));
				vo.setJD(rs.getTimestamp("JD"));
				vo.setJN(rs.getInt("JN"));
				list.add(vo); // list에 새로운 값을 계속 추가시키겠다.
			} while (rs.next());
		} // if문 완료

		CloseUtil.close(rs);
		CloseUtil.close(pstmt);
		CloseUtil.close(conn);
		
		

		// 열었으면 마지막 열었던 순서부터 다시 닫아주고~
		return list;
	}
     //list 정렬 정리는 끝났고 지금부터 notice를 구현하겠습니다. 이제 시작.. Notice.jsp으로 이동
	
	
	public int getListAllCount()throws Exception{//table 개수를 세는 함수를 추가한다.
		Connection conn = getConnection();
		PreparedStatement pstmt = conn.prepareStatement("select count(*) from notice");
		ResultSet rs = pstmt.executeQuery();
		int cnt = 0;
		
		if(rs.next()){
			cnt = rs.getInt(1);
		}
		CloseUtil.close(rs);
		CloseUtil.close(pstmt);
		CloseUtil.close(conn);
		
		return cnt;         //notice.jsp로 다시 이동!
	}
	
	public NoticeVO newNotice() throws Exception{
		Connection conn = getConnection();
		PreparedStatement pstmt = conn.prepareStatement("select * from(select * from notice order by JD desc) where rownum=1");
		ResultSet rs = pstmt.executeQuery();

		NoticeVO vo = new NoticeVO();
		
		if(rs.next()){
			vo.setJS(rs.getString("JS"));
			vo.setJD(rs.getTimestamp("JD"));
			vo.setJN(rs.getInt("JN"));
		}
		CloseUtil.close(rs);
		CloseUtil.close(pstmt);
		CloseUtil.close(conn);
	
		return vo;
	}
	 
}