package project01.action;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.jsp.PageContext;

import project01.members.MembersDAO;

public class LoginProAction extends HttpServlet implements CommandAction {
	//로그인 버튼 클릭 후
	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("utf-8");
		
		MembersDAO dao = MembersDAO.getInstance();
		HttpSession session = request.getSession(); 
		
		String id = request.getParameter("id");//loginForm에 있음, 사용자가 친 id값 읽어오기
		String pwd = request.getParameter("pwd");//사용자가 친 pwd값 읽어오기
		
		int check = dao.userCheck(id, pwd); //MembersDAO에서 만든 userCheck메소드에서 리턴받은 check로 
											//로그인 정상 처리인지, 비번정상처리인지 확인한다.
		
		System.out.println("LoginProAction의 id, pwd: " +id +" / " +pwd);
		System.out.println("LoginProAction의 check: "+check);
		
		if(check==1){
			System.out.println("LoginProAction의 if문의 안 id, pwd: " +id +" / " +pwd);
		    session.setAttribute("id", id);
		    System.out.println(session.getAttribute("id"));
			
		    session.setMaxInactiveInterval(60*60);
		    System.out.println("LoginProAction.java의 if문 안의 id: " +id);
		    //session.setAttribute("pwd", pwd);
		} 
		
		request.setAttribute("check", new Integer(check));
		//check를 loginPro.jsp로 보내서
		//프로 페이지에서 맞으면 메인페이지로..!
		
		return "/login/loginPro.jsp";
	}
}
