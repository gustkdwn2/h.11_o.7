package project01.action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import project01.bid.BidDAO;
import project01.members.MembersDAO;
import project01.products.ProductsDAO;

public class MypageFormAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {

		request.setCharacterEncoding("utf-8");

		MembersDAO Mdao = MembersDAO.getInstance();
		HttpSession session = request.getSession();

		List memberInfoList = null;

		String m_id = (String) session.getAttribute("id");
		memberInfoList = Mdao.memberConfirm(m_id);

		request.setAttribute("memberInfoList", memberInfoList);
		////////////////////////////////////////////////////////////////////
		ProductsDAO dao = ProductsDAO.getInstance();
		List list = dao.selectTimeout(); // products테이블에서 duedate지났는데 p_end가 N인
											// 데이터의 p_code값 list로 받아오기
		dao.updateTimeout(list); // 위에서 받아온 p_code에 해당하는 p_end를 Y로 update
		BidDAO biddao = BidDAO.getInstance();
		biddao.updateTimeout(list); // bid 테이블의 bid_success를 Y로 update
		///////////////////////////////////////////////////////////////////
		return "/mypage/mypageForm.jsp";
	}

}
