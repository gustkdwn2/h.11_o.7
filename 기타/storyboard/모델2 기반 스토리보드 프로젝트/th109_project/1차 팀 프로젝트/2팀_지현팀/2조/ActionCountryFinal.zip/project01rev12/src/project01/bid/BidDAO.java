package project01.bid;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import project01.products.ProductsVO;
import project01.util.CloseUtil;

public class BidDAO {
	private static BidDAO instance = new BidDAO();

	// static변수로 선언한 DAO객체를 리턴하는 메소드
	public static BidDAO getInstance() {
		return instance;
	}

	// 기본 생성자
	public BidDAO() {

	}

	// DB와 연결하는 메소드(web.xml과 이름 같은지 확인)
	public Connection getConnection() throws Exception {
		Context ctx = new InitialContext();
		DataSource ds = (DataSource) ctx.lookup("java:comp/env/jdbc:DB");

		return ds.getConnection();
	}

	public void insert(BidVO vo) throws Exception {
		Connection conn = null;
		PreparedStatement pstmt = null;
		StringBuffer sb = new StringBuffer();

		conn = getConnection();
		sb = new StringBuffer();

		sb.append("INSERT INTO BID(b_id, b_code, price_bid, reg_date)");
		sb.append(" VALUES(?, ?, ?, ?)");

		pstmt = conn.prepareStatement(sb.toString());

		pstmt.setString(1, vo.getB_id());
		pstmt.setString(2, vo.getB_code());
		pstmt.setLong(3, vo.getPrice_bid());
		pstmt.setTimestamp(4, vo.getReg_date());
		pstmt.executeUpdate();

		CloseUtil.close(pstmt);
		CloseUtil.close(conn);
	} // insert() end

	public List<BidVO> successbid(String b_id) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		BidVO vo = null;
		ProductsVO provo = null;
		List successbid = null;
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement("select b.b_id, b.b_code, b.price_bid, b.reg_date, b.bid_success, "
					+ "p.p_id, p.p_name, p.category1, p.category2, p.p_img from bid b, products p where b.b_code=p.p_code and b.bid_success='Y' and b.b_id=?");

			successbid = new ArrayList();

			pstmt.setString(1, b_id);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				do {
					vo = new BidVO();
					vo.setB_id(rs.getString("b_id")); // 낙찰된 사람 id
					vo.setB_code(rs.getString("b_code")); // 낙찰한 상품 code
					vo.setPrice_bid(rs.getInt("price_bid")); // 낙찰가
					vo.setReg_date(rs.getTimestamp("reg_date"));
					vo.setBid_success(rs.getString("bid_success"));

					provo = new ProductsVO();
					provo.setP_id(rs.getString("p_id"));
					provo.setP_name(rs.getString("p_name"));
					provo.setCategory1(rs.getString("category1"));
					provo.setCategory2(rs.getString("category2"));
					provo.setP_img(rs.getString("p_img"));

					successbid.add(vo);
					successbid.add(provo);
				} while (rs.next());
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		return successbid;
	}

	// 입찰내역
	public List<BidVO> select(String b_code) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		StringBuffer sb = new StringBuffer();
		BidVO vo = null;
		List bidList = null;

		try {
			conn = getConnection(); // 연결

			// select 처리 명령
			sb = new StringBuffer();
			sb.append("select * from bid where b_code = ? order by price_bid desc"); // b_code
																						// 의
																						// 대한
																						// 쿼리문
			pstmt = conn.prepareStatement(sb.toString()); //
			pstmt.setString(1, b_code); //
			rs = pstmt.executeQuery(); // 쿼리 실행

			bidList = new ArrayList();

			if (rs.next()) {
				do {
					vo = new BidVO();

					vo.setB_code(rs.getString("b_code"));
					vo.setB_id(rs.getString("b_id"));
					vo.setPrice_bid(rs.getInt("price_bid"));
					vo.setReg_date(rs.getTimestamp("reg_date"));
					vo.setBid_success(rs.getString("bid_success"));
					bidList.add(vo);
				} while (rs.next());
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		return bidList;
	}

	public List selectingCount(String b_id) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		StringBuffer sb = new StringBuffer();
		BidVO vo = null;
		List biddingListCount=null;
		
		try{
			conn=getConnection();
			pstmt=conn.prepareStatement("select * from bid where b_id=?");
			pstmt.setString(1, b_id);
			rs=pstmt.executeQuery();
			
			biddingListCount=new ArrayList();
			
			if(rs.next()){
				
				do{
					
					vo=new BidVO();
					vo.setB_code(rs.getString("b_code"));
					vo.setB_id(rs.getString("b_id"));
					vo.setBid_success(rs.getString("bid_success"));
					vo.setPrice_bid(rs.getInt("price_bid"));
					vo.setReg_date(rs.getTimestamp("reg_date"));
					
					biddingListCount.add(vo);
					
				}while(rs.next());
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);			
		}
		
		return biddingListCount;
	}

	// 마이페이지 입찰중 상품
	public List<BidVO> selecting(String b_id) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		StringBuffer sb = new StringBuffer();
		BidVO vo = null;
		ProductsVO provo = null;
		List biddingList = null;

		try {
			conn = getConnection(); // 연결
			// select 처리 명령
			sb = new StringBuffer();
			sb.append(
					"select p.p_code, p.p_name, p.p_id, p.category1, p.category2, p.p_img, b.price_bid, p.price_bid, p.due_date from products p, bid b where p.p_code = b.b_code and b.b_id=?"); // b_code
																																																	// 의
																																																	// 대한
																																																	// 쿼리문
			pstmt = conn.prepareStatement(sb.toString()); //
			pstmt.setString(1, b_id); //
			rs = pstmt.executeQuery(); // 쿼리 실행

			biddingList = new ArrayList();

			if (rs.next()) {
				do {
					vo = new BidVO();
					provo = new ProductsVO();

					provo.setP_code(rs.getString("p_code"));
					provo.setP_name(rs.getString("p_name"));
					provo.setPrice_bid(rs.getInt("price_bid"));

					vo.setPrice_bid(rs.getInt("price_bid"));

					provo.setDue_date(rs.getTimestamp("due_date"));
					provo.setP_id(rs.getString("p_id"));
					provo.setCategory1(rs.getString("category1"));
					provo.setCategory2(rs.getString("category2"));
					provo.setP_img(rs.getString("p_img"));
					biddingList.add(provo);
					biddingList.add(vo);
				} while (rs.next());
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		return biddingList;
	}

	public void deleteBidForm(String f_id, String[] p_code) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		StringBuffer sb = new StringBuffer();

		try {
			conn = getConnection(); // 연결
			// select 처리 명령
			sb = new StringBuffer();
			sb.append("DELETE FROM BID WHERE "); // b_code 의 대한 쿼리문

			for (int i = 0; i < p_code.length; i++) {
				sb.append("(B_ID=? AND B_CODE=?) ");
				if (i < p_code.length - 1) {
					sb.append("OR ");
				}
			} // for

			System.out.println("쿼리문 : " + sb);
			System.out.println("b_code 배열 크기 : " + p_code.length);

			pstmt = conn.prepareStatement(sb.toString());

			int j = 0;
			/*
			 * for(int i=0;i<p_code.length;i++){ System.out.println("p_code" + i
			 * + " : " + p_code[i]); } System.out.println("p_code.length : " +
			 * p_code.length);
			 */
			for (int i = 0; i < p_code.length; i++) {// i=0, i=1
				System.out.println(j + 1 + " : " + f_id);
				System.out.println(j + 2 + " : " + p_code[i]);

				pstmt.setString(j + 1, f_id);
				pstmt.setString(j + 2, p_code[i]);
				j = j + 2;
			}
			pstmt.executeQuery(); // 쿼리 실행

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
	}// deleteBidForm()
	////////////////////////

	public void deleteSuccessBidForm(String f_id, String[] p_code) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		StringBuffer sb = new StringBuffer();

		try {
			conn = getConnection(); // 연결
			// select 처리 명령
			sb = new StringBuffer();
			sb.append("DELETE FROM BID WHERE "); // b_code 의 대한 쿼리문

			for (int i = 0; i < p_code.length; i++) {
				sb.append("(B_ID=? AND B_CODE=?) ");
				if (i < p_code.length - 1) {
					sb.append("OR ");
				}
			} // for

			System.out.println("쿼리문 : " + sb);
			System.out.println("b_code 배열 크기 : " + p_code.length);

			pstmt = conn.prepareStatement(sb.toString());

			int j = 0;
			/*
			 * for(int i=0;i<p_code.length;i++){ System.out.println("p_code" + i
			 * + " : " + p_code[i]); } System.out.println("p_code.length : " +
			 * p_code.length);
			 */
			for (int i = 0; i < p_code.length; i++) {// i=0, i=1
				System.out.println(j + 1 + " : " + f_id);
				System.out.println(j + 2 + " : " + p_code[i]);

				pstmt.setString(j + 1, f_id);
				pstmt.setString(j + 2, p_code[i]);
				j = j + 2;
			}
			pstmt.executeQuery(); // 쿼리 실행

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
	}// deleteSuccessBidForm()

	// 한 페이지 당 검색결과 뿌리는 메소드
	public List<BidVO> searchOnePage(String b_id, int startRow, int endRow) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		BidVO vo = null;
		StringBuffer sb = new StringBuffer();
		ProductsVO provo = null;
		List successbid = null;

		try {
			conn = getConnection(); // 연결
			// select 처리 명령
			sb = new StringBuffer();

			sb.append(
					"SELECT B_ID, B_CODE, PRICE_BID, REG_DATE, BID_SUCCESS, P_ID, P_NAME, CATEGORY1, CATEGORY2, P_IMG, ROWSEQ ");
			sb.append(
					"FROM (SELECT ROWNUM AS ROWSEQ, B_ID, B_CODE, PRICE_BID, REG_DATE, BID_SUCCESS, P_ID, P_NAME, CATEGORY1, CATEGORY2, P_IMG ");
			sb.append(
					"FROM (SELECT B.B_ID, B.B_CODE, B.PRICE_BID, B.REG_DATE, B.BID_SUCCESS, P.P_ID, P.P_NAME, P.CATEGORY1, P.CATEGORY2, P.P_IMG, B.REG_DATE REG ");
			sb.append(
					"FROM BID B, PRODUCTS P WHERE B.B_CODE=P.P_CODE AND B.BID_SUCCESS='Y' AND B.B_ID=? ORDER BY REG DESC) ORDER BY ROWSEQ ASC) WHERE ROWSEQ BETWEEN ? AND ?");

			pstmt = conn.prepareStatement(sb.toString());
			pstmt.setString(1, b_id);
			pstmt.setInt(2, startRow);
			pstmt.setInt(3, endRow);

			rs = pstmt.executeQuery(); // 쿼리 실행

			successbid = new ArrayList();

			if (rs.next()) {
				do {
					vo = new BidVO();
					vo.setB_id(rs.getString("b_id")); // 낙찰된 사람 id
					vo.setB_code(rs.getString("b_code")); // 낙찰한 상품 code
					vo.setPrice_bid(rs.getInt("price_bid")); // 낙찰가
					vo.setReg_date(rs.getTimestamp("reg_date"));
					vo.setBid_success(rs.getString("bid_success"));

					provo = new ProductsVO();
					provo.setP_id(rs.getString("p_id"));
					provo.setP_name(rs.getString("p_name"));
					provo.setCategory1(rs.getString("category1"));
					provo.setCategory2(rs.getString("category2"));
					provo.setP_img(rs.getString("p_img"));

					successbid.add(vo);
					successbid.add(provo);
				} while (rs.next());
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		return successbid;
	}

	// 한 페이지 당 검색결과 뿌리는 메소드
	public List<BidVO> searchOnePage_bid(String b_id, int startRow, int endRow) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		StringBuffer sb = new StringBuffer();
		BidVO vo = null;
		ProductsVO provo = null;
		List biddingList = null;

		try {
			conn = getConnection(); // 연결
            // select 처리 명령
            sb = new StringBuffer();
            sb.append("SELECT P_CODE, P_NAME, P_ID, CATEGORY1, CATEGORY2, P_IMG, B_BID, P_BID, DUE_DATE, REG, ROWSEQ ");
            sb.append("FROM (SELECT ROWNUM AS ROWSEQ, P_CODE, P_NAME, P_ID, CATEGORY1, CATEGORY2, P_IMG, B_BID, P_BID, DUE_DATE, REG ");
            sb.append("FROM (SELECT P.P_CODE, P.P_NAME, P.P_ID, P.CATEGORY1, P.CATEGORY2, P.P_IMG, B.PRICE_BID B_BID, P.PRICE_BID P_BID, P.DUE_DATE, B.REG_DATE REG ");
            sb.append("FROM PRODUCTS P, BID B WHERE P.P_CODE = B.B_CODE and p.p_end='N' ");
            sb.append("and (b.b_code, b.price_bid) in (select b.b_code, max(b.price_bid) from products p, bid b where p.p_code=b.b_code and b.b_id=? group by b.b_code) ");
            sb.append("ORDER BY REG DESC) ORDER BY ROWSEQ ASC) WHERE ROWSEQ BETWEEN ? AND ?");
            
			pstmt = conn.prepareStatement(sb.toString());
			pstmt.setString(1, b_id);
			pstmt.setInt(2, startRow);
			pstmt.setInt(3, endRow);

			rs = pstmt.executeQuery(); // 쿼리 실행

			biddingList = new ArrayList();

			if (rs.next()) {
				do {
					vo = new BidVO();
					provo = new ProductsVO();

					provo.setP_code(rs.getString("p_code"));
					provo.setP_name(rs.getString("p_name"));
					provo.setPrice_bid(rs.getInt("p_bid"));

					vo.setPrice_bid(rs.getInt("b_bid"));

					provo.setDue_date(rs.getTimestamp("due_date"));
					provo.setP_id(rs.getString("p_id"));
					provo.setCategory1(rs.getString("category1"));
					provo.setCategory2(rs.getString("category2"));
					provo.setP_img(rs.getString("p_img"));
					biddingList.add(provo);
					biddingList.add(vo);
				} while (rs.next());
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		return biddingList;
	}

	public void updateTimeout(List list) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		PreparedStatement pstmt2 = null;
		ResultSet rs = null;
		ResultSet rs2 = null;
		StringBuffer sb = null;
		String price_bid = null; // price_bid
		try {
			conn = getConnection();
			for (int i = 0; i < list.size(); i++) {
				pstmt = conn.prepareStatement(
						"select p.price_bid from bid b,products p where b.b_code=p.p_code and b.b_code=?");
				pstmt.setString(1, (String) list.get(i));
				rs = pstmt.executeQuery();
				// product테이블에서 시간이 지난 i번째 b_code에 해당하는 price_bid를 가져와서 변수에 저장
				if (rs.next()) {
					price_bid = rs.getString(1);
				}
				System.out.println("price_bid++++++++" + price_bid);
				sb = new StringBuffer();
				sb.append("UPDATE bid ");
				sb.append("SET bid_success='Y' WHERE B_CODE = ? AND PRICE_BID = ?"); // 시간이
																						// 지난
																						// 상품코드와
																						// 위에서
																						// 뽑아낸
																						// price_bid에
																						// 해당하는
																						// bid_success를
																						// Y로
																						// 바꿈
				System.out.println("p_code+++++++++++" + (String) list.get(i));
				pstmt2 = conn.prepareStatement(sb.toString());
				pstmt2.setString(1, (String) list.get(i));
				pstmt2.setString(2, price_bid);
				pstmt2.executeUpdate();
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
	}

	// 즉시구매시 사용될 인서트 메소드
	public void bsuccess(BidVO vo) throws Exception {
		Connection conn = null;
		PreparedStatement pstmt = null;
		StringBuffer sb = new StringBuffer();

		try {
			conn = getConnection();
			sb = new StringBuffer();

			sb.append("INSERT INTO BID(b_id, b_code, price_bid, reg_date, bid_success)");
			sb.append(" VALUES(?, ?, ?, ?, ?)");

			pstmt = conn.prepareStatement(sb.toString());

			pstmt.setString(1, vo.getB_id());
			pstmt.setString(2, vo.getB_code());
			pstmt.setLong(3, vo.getPrice_bid());
			pstmt.setTimestamp(4, vo.getReg_date());
			pstmt.setString(5, "Y");
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // insert() end
	}

}
