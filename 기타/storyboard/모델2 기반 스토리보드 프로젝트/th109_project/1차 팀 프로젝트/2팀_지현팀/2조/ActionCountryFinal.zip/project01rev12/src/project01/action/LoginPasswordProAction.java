package project01.action;

import java.io.PrintWriter;
import java.util.Date;
import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.swing.JOptionPane;

import project01.members.MembersDAO;

public class LoginPasswordProAction extends HttpServlet implements CommandAction {
	// 로그인 버튼 클릭 후
	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("utf-8");

		MembersDAO dao = MembersDAO.getInstance();
		HttpSession session = request.getSession();

		String id = request.getParameter("id");// loginForm에 있음, 사용자가 친 id값 읽어오기
		String email = request.getParameter("email");// 사용자가 친 pwd값 읽어오기

		System.out.println("LoginIdProAction의 id, email: " + id + " / " + email);
		//맞는 id, 비밀번호인지 검사
		
		int check = dao.emailCheck(id, email);//제대로 있는 이메일인지 검사/////////////////
		System.out.println("email check검사 : " + check);
		
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();  
		       
		if(check==1){//해당 이메일이 있을 때
			//out.println("<script>alert(이메일로 전송 완료되었습니다.);</script>");
			//out.flush();
			
			String pwd = dao.pwdFind(email);
			
			System.out.println("pwd : " + pwd);
			Properties p = System.getProperties();
			p.put("mail.smtp.starttls.enable", "true"); // gmail은 무조건 true 고정
			p.put("mail.smtp.host", "smtp.gmail.com"); // smtp 서버 주소
			p.put("mail.smtp.auth", "true"); // gmail은 무조건 true 고정
			p.put("mail.smtp.port", "587"); // gmail 포트

			Authenticator auth = new MyAuthentication();

			// session 생성 및 MimeMessage생성
			Session session2 = Session.getDefaultInstance(p, auth);
			MimeMessage msg = new MimeMessage(session2);

			try {
				System.out.println("들어왔니???");
				MyAuthentication2 ma = new MyAuthentication2();
				// 편지보낸시간
				msg.setSentDate(new Date());

				InternetAddress from = new InternetAddress();

				from = new InternetAddress("Administrator<nice9010@gmail.com>");

				// 이메일 발신자
				msg.setFrom(from);

				// 이메일 수신자
				InternetAddress to = new InternetAddress(email);
				msg.setRecipient(Message.RecipientType.TO, to);

				// 이메일 제목
				msg.setSubject("경매나라 Password 찾기", "UTF-8");

				// 이메일 내용
				msg.setText("고객님의 Password는 " + pwd + "입니다.", "UTF-8");

				// 이메일 헤더
				msg.setHeader("content-Type", "text/html");

				// 메일보내기
				javax.mail.Transport.send(msg);
				System.out.println("들어왔니2??");
				
				//JOptionPane.showMessageDialog(null, "메일로 전송이 완료되었습니다.");
				//out.println("<script>alert('sName" + sName + "');</script>");
				//out.println("<script>alert('메일로 전송이 완료되었습니다.');</script>");
				//out.flush();
				

			} catch (AddressException addr_e) {
				addr_e.printStackTrace();
			} catch (MessagingException msg_e) {
				msg_e.printStackTrace();
			}
		}//if 
		
		request.setAttribute("check", check);
		
		return "/login/loginConfirm.jsp";
	}//process()

}// class

class MyAuthentication2 extends Authenticator {

	PasswordAuthentication pa;

	public MyAuthentication2() {

		String id = "nice9010"; // 구글 ID
		String pw = "wpsldtm12"; // 구글 비밀번호

		// ID와 비밀번호를 입력한다.
		pa = new PasswordAuthentication(id, pw);

	}

	// 시스템에서 사용하는 인증정보
	public PasswordAuthentication getPasswordAuthentication() {
		return pa;
	}
}
