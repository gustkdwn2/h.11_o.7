package project01.controller;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import project01.action.CommandAction;



public class Controller extends HttpServlet {
	private Map commandMap = new HashMap();
	

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		process(request, response);
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		process(request, response);
	}

	public void init(ServletConfig config) throws ServletException {
		String props = config.getInitParameter("Command");
		Properties p = new Properties();// key와 value로 이루어짐-> map타입을 상속받은 클래스
		FileInputStream f = null;

		try {
			// CommandBoard.properties파일의 내용을 읽어옴
			f = new FileInputStream(props);
			// 파일 객체로 읽어들인 프로퍼티 정보를 프로퍼티 객체에 저장
			p.load(f);

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (f != null) {
				try {
					f.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}

		Iterator key = p.keySet().iterator();
		// key에 키값이 저장

		while (key.hasNext()) {
			String command = (String) key.next();
			// 프로퍼티 파일의 명령처리 부분을 받아옴
			String className = p.getProperty(command);
			// ex) value값: edu.kosta.board.action.ListAction

			try {
				Class commandClass = Class.forName(className);
				// forName()메소드를 사용하여 문자열을 클래스로 변환
				// edu.kosta.board.action.ListAction -> 클래스가 됨
				Object commandInstance = commandClass.newInstance();
				// edu.kosta.board.action.ListAction -> commandClass ->
				// commandInstance라는 객체로써 생성

				commandMap.put(command, commandInstance);
				// = (list.do, edu.kosta.board.action.ListAction)
				// key값: list do & value값: edu.kosta.board.action.ListAction

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	private void process(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String view = null;
		CommandAction cp = null;

		try {
			String command = request.getRequestURI();
			// ~~~~/list.do
			System.out.println("command: " + command);
			// 출력결과: /web_boardMVC/list.do
			System.out.println("request.getContextPath(): " + request.getContextPath());
			// 출력결과: /web_boardMVC

			if (command.indexOf(request.getContextPath()) == 0) {
				// 경로가 없다면,
				command = command.substring(request.getContextPath().length() + 1);
				System.out.println("if command: " + command);
				// -> list.do 만 뽑아져 나옴
			}

			cp = (CommandAction) commandMap.get(command);
			System.out.println("cp: " + cp);
			// 출력결과: edu.kosta.board.action.ListAction

			view = cp.process(request, response);
			
			
			System.out.println("view: " + view);
			
		} catch (Exception e) {
			e.printStackTrace();
		}

		// 세팅 개시
		request.setAttribute("CONTENT", view);
		
		RequestDispatcher dp = request.getRequestDispatcher("/template/template.jsp");
		dp.forward(request, response);
	}

}
