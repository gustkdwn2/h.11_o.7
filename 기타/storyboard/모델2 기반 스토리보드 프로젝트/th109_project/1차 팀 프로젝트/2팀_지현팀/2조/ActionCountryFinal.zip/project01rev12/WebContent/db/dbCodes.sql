drop table members CASCADE CONSTRAINT;
drop table products CASCADE CONSTRAINT;
drop table bid;
drop table favorite;
drop table category;

select * from members;
select * from products;
select * from bid;
select * from favorite;


select p_code, p_name, price_start, price_immediate, price_bid, category1, 
category2, due_date, reg_date, p_id, p_img, content, bid_count, p_end, r
from (select p_code, p_name, price_start, price_immediate, price_bid, category1, 
category2, due_date, reg_date, p_id, p_img, content, bid_count, p_end, rownum r 
from products where p_name like '%%' or content like '%%' order by reg_date desc) where r >= 1 and r <= 7


select p_code, p_name, price_start, price_immediate, price_bid, 
category1, category2, due_date, reg_date, p_id, p_img, content, bid_count, p_end, r from 
	(select p_code, p_name, price_start, price_immediate, price_bid, 
	category1, category2, due_date, reg_date, p_id, p_img, content, bid_count, p_end, rownum r from
		(select * from products where p_name like '%%' or content like '%%' order by p_end, reg_date desc)) where r >= 1 and r <= 7 

select p.price_bid from bid b,products p where b.b_code=p.p_code and b.b_code=1
delete from products;
   
insert into products(p_code, p_name, price_start, price_immediate, category1, category2, due_date, reg_date, p_id, p_img, content ) values('5', '5', 100,10000,'패션의류','여성의류',TO_DATE('04-16-2016 16:35:00','MM-DD-YYYY HH24:MI:SS'),sysdate,'baeji','koala.jpg','코알라'); 
insert into products(p_code, p_name, price_start, price_immediate, category1, category2, due_date, reg_date, p_id, p_img, content ) values('6', '6', 100,10000,'패션의류','여성의류',TO_DATE('04-16-2016 16:37:00','MM-DD-YYYY HH24:MI:SS'),sysdate,'baeji','koala.jpg','코알라'); 
insert into products(p_code, p_name, price_start, price_immediate, category1, category2, due_date, reg_date, p_id, p_img, content ) values('7', '7', 100,10000,'패션의류','여성의류',TO_DATE('04-16-2016 16:39:00','MM-DD-YYYY HH24:MI:SS'),sysdate,'baeji','koala.jpg','코알라'); 
insert into products(p_code, p_name, price_start, price_immediate, category1, category2, due_date, reg_date, p_id, p_img, content ) values('8', '8', 100,10000,'패션의류','여성의류',TO_DATE('04-16-2016 16:45:00','MM-DD-YYYY HH24:MI:SS'),sysdate,'baeji','koala.jpg','코알라'); 
insert into products(p_code, p_name, price_start, price_immediate, category1, category2, due_date, reg_date, p_id, p_img, content ) values('10', '10', 100,10000,'패션의류','여성의류',TO_DATE('04-16-2016 16:45:00','MM-DD-YYYY HH24:MI:SS'),sysdate,'baeji','koala.jpg','코알라');
select * from bid where b_code = 27;


create table members (
  m_id varchar2(20) primary key,
  m_name varchar2(20) not null,
  m_password varchar2(20) not null,
  phone varchar2(15) not null,
  email varchar2(50) not null,
  jumin number(6) not null,
  address varchar2(100) not null,
  gender varchar2(1) not null,
  reg_date date not null
);
create table products(
  p_code varchar2(1000) primary key, 
  p_name varchar2(1000) not null,
  price_start number(10) not null,
  price_immediate number(10) not null, 
  price_bid number(10) default 0,
  category1 varchar2(100) not null,
  category2 varchar2(100) not null,
  due_date date not null,
  reg_date date not null,
  p_id varchar2(20) not null,
  p_img varchar2(2000),
  content varchar2(2000) not null,
  bid_count number default 0,
  p_end varchar2(1) default 'N',
  foreign key(p_id)references members(m_id) on delete cascade
);

drop sequence product_code;
create sequence product_code;

create table bid(
  b_id varchar2(20) not null,
  b_code varchar2(1000) not null,
  price_bid number(10) not null,
  reg_date date not null,
  bid_success varchar2(1) default 'N',
  primary key(b_id, b_code,price_bid),
  foreign key(b_id)references members(m_id) on delete cascade,
  foreign key(b_code)references products(p_code) on delete cascade
);
create table favorite(
  f_id varchar2(20),
  f_code varchar2(1000),
  reg_date date not null,
  primary key(f_id, f_code),
  foreign key(f_id)references members(m_id) on delete cascade,
  foreign key(f_code)references products(p_code) on delete cascade
);
create table category(
  category1 varchar2(100) not null,
  category2 varchar2(100) not null
);
insert into category values('패션의류','여성의류');
insert into category values('패션의류','남성의류');
insert into category values('패션의류','언더웨어/잠옷');
insert into category values('잡화','구두/여성화/남성화');
insert into category values('잡화','가방/패션잡화');
insert into category values('잡화','쥬얼리/시계/선글라스');
insert into category values('뷰티','화장품');
insert into category values('뷰티','바디/헤어/향수');
insert into category values('뷰티','건강식품/다이어트');
insert into category values('유아동','기저귀/분유/이유식');
insert into category values('유아동','유아동 의류');
insert into category values('유아동','유아동 잡화');
insert into category values('유아동','장난감');
insert into category values('가구/생활','가구/인테리어');
insert into category values('가구/생활','커피/음료/조미료');
insert into category values('가구/생활','쌀/과일/농수축산물');
insert into category values('가구/생활','즉석/간식/가공식품');
insert into category values('취미/컬렉션','반려동물용품');
insert into category values('취미/컬렉션','악기/취미/키덜트');
insert into category values('취미/컬렉션','디자인/문구/사무용품');
insert into category values('취미/컬렉션','꽃/원예/팬시/선물');
insert into category values('가전','TV/프로젝터');
insert into category values('가전','주방가전');
insert into category values('가전','냉난방/청정/제습');
insert into category values('가전','냉장고/세탁기/청소기');
insert into category values('가전','생활/가전');
insert into category values('디지털','카메라/액세서리');
insert into category values('디지털','태블릿/액세서리');
insert into category values('디지털','게임기/타이틀');
insert into category values('디지털','음향기기');
insert into category values('디지털','휴대폰/스마트폰');
insert into category values('컴퓨터','노트북/데스크탑');
insert into category values('컴퓨터','모니터/프린터/잉크');
insert into category values('컴퓨터','컴퓨터부품/주변기기');
insert into category values('컴퓨터','저장장치/메모리');
insert into category values('스포츠','자전거/헬스/수영');
insert into category values('스포츠','스포츠의류/운동화');
insert into category values('스포츠','골프클럽/의류/용품');
insert into category values('스포츠','등산');
insert into category values('자동차','자동차용품/블랙박스');
insert into category values('자동차','타이어/오일/부품');
insert into category values('도서/상품권','도서/교육/음반');
insert into category values('도서/상품권','백화점/상품권');