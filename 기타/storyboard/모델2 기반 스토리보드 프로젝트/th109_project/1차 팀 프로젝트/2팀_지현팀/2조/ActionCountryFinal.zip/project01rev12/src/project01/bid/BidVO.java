package project01.bid;

import java.sql.Timestamp;

public class BidVO {
	private String b_id, b_code, bid_success;
	private int price_bid;
	private Timestamp reg_date;
	public String getB_id() {
		return b_id;
	}
	public void setB_id(String b_id) {
		this.b_id = b_id;
	}
	public String getB_code() {
		return b_code;
	}
	public void setB_code(String b_code) {
		this.b_code = b_code;
	}
	public String getBid_success() {
		return bid_success;
	}
	public void setBid_success(String bid_success) {
		this.bid_success = bid_success;
	}
	public int getPrice_bid() {
		return price_bid;
	}
	public void setPrice_bid(int price_bid) {
		this.price_bid = price_bid;
	}
	public Timestamp getReg_date() {
		return reg_date;
	}
	public void setReg_date(Timestamp reg_date) {
		this.reg_date = reg_date;
	}
}