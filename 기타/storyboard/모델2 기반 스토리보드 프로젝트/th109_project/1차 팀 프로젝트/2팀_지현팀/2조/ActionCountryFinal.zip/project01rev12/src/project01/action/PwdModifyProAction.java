package project01.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import project01.members.MembersDAO;
import project01.members.MembersVO;

public class PwdModifyProAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("utf-8");

		MembersDAO dao = MembersDAO.getInstance();
		MembersVO vo = new MembersVO();
		HttpSession session = request.getSession();
		int result1 = 0;
		int result2 = 0;

		String m_id = (String) session.getAttribute("id");
		String oldPwd = request.getParameter("oldPwd");
		String newPwd = request.getParameter("newPwd");
		String newPwdAgain = request.getParameter("newPwdAgain");

		vo.setM_id(m_id);

		// 기존 비밀번호 일치 확인
		result1 = dao.confirmPwd(m_id, oldPwd);
		System.out.println("PwdModifyProAction.java의 result1: " + result1);
		// 일치하면 1 일치하지 않으면 0 리턴

		// 새 비밀번호 2번 입력한 게 서로 일치하나 확인
		if (newPwd.equals(newPwdAgain)) {

			vo.setM_password(newPwd);

			// vo의 m_password을 입력받은 새로운 비밀번호 값으로 변경
			result2 = dao.modifyMemberPwd(vo);
			System.out.println("PwdModifyProAction.java의 result2: " + result2);
			// 업데이트 성공하면 1 실패하면 0

		} else {
			result2 = 0;
		}

		request.setAttribute("result1", result1);
		request.setAttribute("result2", result2);

		return "/modify/pwdModifyPro.jsp";
	}

}
