package project01.members;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import project01.util.CloseUtil;

public class MembersDAO {
   private static MembersDAO instance = new MembersDAO();

   public static MembersDAO getInstance() {
      return instance;
   }

   public MembersDAO() {

   }

   // DB와 연결하는 메소드(web.xml과 이름 같은지 확인)
   public Connection getConnection() throws Exception {
      Context ctx = new InitialContext();
      DataSource ds = (DataSource) ctx.lookup("java:comp/env/jdbc:DB");

      return ds.getConnection();
   }

   // userCheck(id, pwd) - 로그인시 사용할 메소드 id/password 체크함
   public int userCheck(String id, String pwd) throws Exception {
      String sql = "SELECT M_PASSWORD FROM MEMBERS WHERE M_ID = ?";
      String dbpwd = "";

      int result = -1;
      Connection conn = getConnection();
      PreparedStatement pstmt = conn.prepareStatement(sql);
      pstmt.setString(1, id);

      ResultSet rs = pstmt.executeQuery();

      if (rs.next()) {// id check
         dbpwd = rs.getString("m_password");// db에서 가져오는거!!
         if (dbpwd.equals(pwd))
            result = 1;// 인증 성공!
         else
            result = 0; // 비번 틀림
      } else {
         result = -1; // 해당 아이디가 없음
      } // if

      CloseUtil.close(rs);
      CloseUtil.close(pstmt);
      CloseUtil.close(conn);

      return result;// 1이면 인증 성공, 0이면 비번 틀림, -1이면 해당 아이디가 없음.
   }// userCheck()

   public int login(String userId, String password) {
      Connection conn = null;
      PreparedStatement pstmt = null;
      ResultSet rs = null;
      String dbpasswd = "";
      int result = 0;

      try {
         conn = getConnection();
         pstmt = conn.prepareStatement("select m_password from members where m_id=?");
         pstmt.setString(1, userId);
         rs = pstmt.executeQuery();

         if (rs.next()) {
            dbpasswd = rs.getString("m_password");

            if (dbpasswd.equals(password)) {
               result = 1;
            } else {
               result = 0;
            }
         }

      } catch (Exception e) {
         e.printStackTrace();
      } finally {
         CloseUtil.close(rs);
         CloseUtil.close(pstmt);
         CloseUtil.close(conn);
      }

      return result;
   }

   // 회원가입
   public void insert(MembersVO vo) throws Exception {
      Connection conn = null;
      PreparedStatement pstmt = null;

      StringBuffer sb = new StringBuffer();
      sb.append(
            "insert into members(m_id, m_name, m_password, phone, email, address, gender, jumin, reg_date) ");
      sb.append(" values(?, ?, ?, ?, ?, ?, ?, ?, ?)");

      conn = getConnection();
      pstmt = conn.prepareStatement(sb.toString());

      pstmt.setString(1, vo.getM_id());
      pstmt.setString(2, vo.getM_name());
      pstmt.setString(3, vo.getM_password());
      pstmt.setString(4, vo.getPhone());
      pstmt.setString(5, vo.getEmail());
      pstmt.setString(6, vo.getAddress());
      pstmt.setString(7, vo.getGender());
      pstmt.setInt(8, vo.getJumin());
      pstmt.setTimestamp(9, vo.getReg_date());
      int result = pstmt.executeUpdate();

      System.out.println("result : " + result);

      CloseUtil.close(pstmt);
      CloseUtil.close(conn);
   } // insert() end

   // 아이디 중복 체크
   public int confirmID(String id) throws Exception {
      String sql = "SELECT m_id FROM MEMBERS WHERE m_id = ?";
      // String dbpwd ="";
      int result = -1;

      Connection conn = getConnection();
      PreparedStatement pstmt = conn.prepareStatement(sql);
      pstmt.setString(1, id);

      ResultSet rs = pstmt.executeQuery();

      if (rs.next())
         result = 1; // 해당 아이디 있음
      else
         result = -1;

      CloseUtil.close(rs);
      CloseUtil.close(pstmt);
      CloseUtil.close(conn);

      return result;
   } // confirmID(id) end
      // 회원정보 수정

   public void modifyMemberInfo(MembersVO vo) {
      Connection conn = null;
      PreparedStatement pstmt = null;

      try {
         conn = getConnection();
         pstmt = conn.prepareStatement(
               "update members set m_name=?, phone=?, email=?, " + " jumin=?, address=?, gender=? where m_id=?");

         pstmt.setString(1, vo.getM_name());
         pstmt.setString(2, vo.getPhone());
         pstmt.setString(3, vo.getEmail());
         pstmt.setInt(4, vo.getJumin());
         pstmt.setString(5, vo.getAddress());
         pstmt.setString(6, vo.getGender());
         pstmt.setString(7, vo.getM_id());
         pstmt.executeUpdate();

      } catch (Exception e) {
         e.printStackTrace();

      } finally {
         CloseUtil.close(pstmt);
         CloseUtil.close(conn);
      }
   }

   // 회원정보 확인하기(정보 불러오기)

   public List memberConfirm(String m_id) {
      Connection conn = null;
      PreparedStatement pstmt = null;
      ResultSet rs = null;
      MembersVO vo = null;
      List memberInfoList = null;

      try {
         conn = getConnection();
         pstmt = conn.prepareStatement(
               "select m_name, phone, email, jumin, address, " + "gender, reg_date from members where m_id = ?");

         pstmt.setString(1, m_id);
         rs = pstmt.executeQuery();

         memberInfoList = new ArrayList();

         if (rs.next()) {
            do {
               vo = new MembersVO();

               vo.setM_name(rs.getString("m_name"));
               vo.setPhone(rs.getString("phone"));
               vo.setEmail(rs.getString("email"));
               vo.setJumin(rs.getInt("jumin"));
               vo.setAddress(rs.getString("address"));
               vo.setGender(rs.getString("gender"));
               vo.setReg_date(rs.getTimestamp("reg_date"));

               memberInfoList.add(vo);

            } while (rs.next());
         }

      } catch (Exception e) {
         e.printStackTrace();

      } finally {
         CloseUtil.close(rs);
         CloseUtil.close(pstmt);
         CloseUtil.close(conn);
      }

      return memberInfoList;
   }

   // 기존 비밀번호 일치 확인하기
   // 일치하면 1 일치하지 않으면 0

   public int confirmPwd(String m_id, String oldPwd) {
      int result = 0;
      Connection conn = null;
      PreparedStatement pstmt = null;
      ResultSet rs = null;

      try {
         conn = getConnection();
         pstmt = conn.prepareStatement("select m_password from members where m_id=?");
         pstmt.setString(1, m_id);
         rs = pstmt.executeQuery();

         if (rs.next()) {
            if (oldPwd.equals(rs.getString("m_password"))) {
               result = 1;

            } else if (oldPwd.equalsIgnoreCase(rs.getString("m_password"))) {
               result = 0;
            }
         }

         System.out.println("MembersDAO의 confirmPwd메소드 안의 result: " + result);

      } catch (Exception e) {
         e.printStackTrace();
      } finally {
         CloseUtil.close(rs);
         CloseUtil.close(pstmt);
         CloseUtil.close(conn);
      }

      return result;
   }

   // 비밀번호 수정하기
   // 성공하면 1 실패하면 0
   public int modifyMemberPwd(MembersVO vo) {
      Connection conn = null;
      PreparedStatement pstmt = null;
      int rsCount = 0;
      int result = 0;

      try {
         conn = getConnection();
         pstmt = conn.prepareStatement("update members set m_password=? where m_id=?");

         pstmt.setString(1, vo.getM_password());
         pstmt.setString(2, vo.getM_id());

         rsCount = pstmt.executeUpdate();

         if (rsCount > 0) {
            result = 1;
         } else {
            result = 0;
         }

      } catch (Exception e) {
         e.printStackTrace();

      } finally {
         CloseUtil.close(pstmt);
         CloseUtil.close(conn);
      }

      return result;
   }

   // 판매자 정보 불러오기

   public List sellMemberInfo(String m_id) {
      Connection conn = null;
      PreparedStatement pstmt = null;
      ResultSet rs = null;
      MembersVO vo = null;
      List sellMemberInfoList = null;

      try {
         conn = getConnection();
         pstmt = conn.prepareStatement("select phone, email from members where m_id=?");
         pstmt.setString(1, m_id);
         rs = pstmt.executeQuery();

         sellMemberInfoList = new ArrayList();

         if (rs.next()) {
            do {
               vo = new MembersVO();
               vo.setPhone(rs.getString("phone"));
               vo.setEmail(rs.getString("email"));
               sellMemberInfoList.add(vo);

            } while (rs.next());
         }

      } catch (Exception e) {
         e.printStackTrace();

      } finally {
         CloseUtil.close(rs);
         CloseUtil.close(pstmt);
         CloseUtil.close(conn);
      }

      return sellMemberInfoList;
   }

   // 회원정보-회원탈퇴 에서 사용할 비밀번호 체크 함수
   public int userpwdCheck(String m_id, String m_pwd) throws Exception {
      String sql = "SELECT M_PASSWORD FROM MEMBERS WHERE M_ID = ?"; // 아이디에 맞는
                                                      // pwd를
                                                      // db에서
                                                      // 찾음
      int result = 0; // if문 돌리기 위한 변수생성
      Connection conn = getConnection();
      PreparedStatement pstmt = conn.prepareStatement(sql); // 쿼리 실행
      pstmt.setString(1, m_id); // 로그인되어있는 id 받아와야함
      ResultSet rs = pstmt.executeQuery(); // 쿼리 실행해서 rs에 담음

      if (rs.next()) {

         if (m_pwd.equals(rs.getString("m_password"))) {
            result = 1; // m_pwd(사용자가 입력한 비번 과 db에 저장된 pwd가 같다면 result=1
         } else {
            result = 0;// 틀리면 0
         }
      } // if
      System.out.println("result : " + result);
      CloseUtil.close(rs);
      CloseUtil.close(pstmt);
      CloseUtil.close(conn);
      return result;// result를 리턴해서 1또는 0으로 갖고있음. 1이면 비번 같음 탈퇴 성공 시킬것임, 0이면 비번
                  // 틀림 탈퇴불가
   }

   // 회원정보 - 회원탈퇴 메소드
   public void deletemembers(String m_id) throws Exception {
      String sql = "DELETE FROM MEMBERS WHERE M_ID = ?"; // 삭제 쿼리문

      Connection conn = getConnection();
      PreparedStatement pstmt = conn.prepareStatement(sql); // 쿼리 실행
      pstmt.setString(1, m_id); // 로그인되어있는 id 받아와야함
      ResultSet rs = pstmt.executeQuery(); // 쿼리 실행해서 rs에 담음

   }

   // 맞는 email인지 검사(id, email)
   public int idCheck(String name, String email) throws Exception {
      String sql = "SELECT EMAIL FROM MEMBERS WHERE M_NAME = ?";
      String dbemail = "";

      int result = -1;
      Connection conn = getConnection();
      PreparedStatement pstmt = conn.prepareStatement(sql);
      pstmt.setString(1, name);

      ResultSet rs = pstmt.executeQuery();

      if (rs.next()) {// email check
         dbemail = rs.getString("email");// db에서 가져오기
         if (dbemail.equals(email)) {
            result = 1;// 인증 성공
         } else
            result = -1; // 같은 이메일 없음
      } else {
         result = -1; // 해당 이메일 없음
      } // if

      CloseUtil.close(rs);
      CloseUtil.close(pstmt);
      CloseUtil.close(conn);

      return result;// 1이면 인증 성공, -1이면 해당 이메일 없음
   }// idCheck()

   // 맞는 id인지 검사(id, email)
   public String idFind(String email) throws Exception {
      String sql = "SELECT M_ID FROM MEMBERS WHERE EMAIL = ?";
      String dbid = "";

      Connection conn = getConnection();
      PreparedStatement pstmt = conn.prepareStatement(sql);
      pstmt.setString(1, email);

      ResultSet rs = pstmt.executeQuery();

      if (rs.next()) {// email check
         dbid = rs.getString("m_id");// db에서 가져오기
      }

      CloseUtil.close(rs);
      CloseUtil.close(pstmt);
      CloseUtil.close(conn);

      return dbid;// db에 있는 id리턴
   }// idFind()

   // 맞는 email인지 검사(id, email)
   public int emailCheck(String id, String email) throws Exception {
      String sql = "SELECT EMAIL FROM MEMBERS WHERE M_ID = ?";
      String dbemail = "";

      int result = -1;
      Connection conn = getConnection();
      PreparedStatement pstmt = conn.prepareStatement(sql);
      pstmt.setString(1, id);

      ResultSet rs = pstmt.executeQuery();

      if (rs.next()) {// email check
         dbemail = rs.getString("email");// db에서 가져오기
         if (dbemail.equals(email)) {
            result = 1;// 인증 성공
         } else
            result = -1; // 같은 이메일 없음
      } else {
         result = -1; // 해당 이메일 없음
      } // if

      CloseUtil.close(rs);
      CloseUtil.close(pstmt);
      CloseUtil.close(conn);

      return result;// 1이면 인증 성공, -1이면 해당 이메일 없음
   }// idCheck()

   // 맞는 id인지 검사(id, email)
   public String pwdFind(String email) throws Exception {
      String sql = "SELECT M_PASSWORD FROM MEMBERS WHERE EMAIL = ?";
      String dbpwd = "";

      Connection conn = getConnection();
      PreparedStatement pstmt = conn.prepareStatement(sql);
      pstmt.setString(1, email);

      ResultSet rs = pstmt.executeQuery();

      if (rs.next()) {// email check
         dbpwd = rs.getString("m_password");// db에서 가져오기
      }

      CloseUtil.close(rs);
      CloseUtil.close(pstmt);
      CloseUtil.close(conn);

      return dbpwd;// db에 있는 id리턴
   }// idFind()

   // 관리자 페이지에서 전체 뽑기

   public List adminMemberInfo(int start, int end) {
      Connection conn = null;
      PreparedStatement pstmt = null;
      ResultSet rs = null;
      MembersVO vo = null;
      List adminMemberInfoList = null;

      try {
         conn = getConnection();
         pstmt = conn.prepareStatement("select m_id, m_name, phone, email, jumin, address, gender, reg_date, r from "
               + " (select m_id, m_name, phone, email, jumin, address, gender, reg_date, rownum r from members) "
               + " where r >= ? and r <= ?");
         pstmt.setInt(1, start);
         pstmt.setInt(2, end);
         rs = pstmt.executeQuery();

         adminMemberInfoList = new ArrayList();

         if (rs.next()) {

            do {
               vo = new MembersVO();

               vo.setM_id(rs.getString("m_id"));
               vo.setM_name(rs.getString("m_name"));
               vo.setPhone(rs.getString("phone"));
               vo.setEmail(rs.getString("email"));
               vo.setJumin(rs.getInt("jumin"));
               vo.setAddress(rs.getString("address"));
               vo.setGender(rs.getString("gender"));
               vo.setReg_date(rs.getTimestamp("reg_date"));

               adminMemberInfoList.add(vo);

            } while (rs.next());
         }

         System.out.println("adminMemberInfoList Size: " + adminMemberInfoList.size());

      } catch (Exception e) {
         e.printStackTrace();

      } finally {
         CloseUtil.close(rs);
         CloseUtil.close(pstmt);
         CloseUtil.close(conn);
      }

      return adminMemberInfoList;
   }

   // 카운트용 리스트

   public List adminMemberInfoAll() {
      Connection conn = null;
      PreparedStatement pstmt = null;
      ResultSet rs = null;
      MembersVO vo = null;
      List adminMemberInfoAllList = null;

      try {
         conn = getConnection();
         pstmt = conn.prepareStatement("select * from members");
         rs = pstmt.executeQuery();

         adminMemberInfoAllList = new ArrayList();

         if (rs.next()) {

            do {
               vo = new MembersVO();

               vo.setM_id(rs.getString("m_id"));
               vo.setM_name(rs.getString("m_name"));
               vo.setPhone(rs.getString("phone"));
               vo.setEmail(rs.getString("email"));
               vo.setJumin(rs.getInt("jumin"));
               vo.setAddress(rs.getString("address"));
               vo.setGender(rs.getString("gender"));
               vo.setReg_date(rs.getTimestamp("reg_date"));

               adminMemberInfoAllList.add(vo);

            } while (rs.next());
         }

         System.out.println("adminMemberInfoAllList Size: " + adminMemberInfoAllList.size());

      } catch (Exception e) {
         e.printStackTrace();

      } finally {
         CloseUtil.close(rs);
         CloseUtil.close(pstmt);
         CloseUtil.close(conn);
      }

      return adminMemberInfoAllList;
   }

   public List adminSearchMemberInfoAll(String m_id) {
      Connection conn = null;
      PreparedStatement pstmt = null;
      ResultSet rs = null;
      MembersVO vo = null;
      List adminSearchMemberInfoAllList = null;

      try {
         conn = getConnection();
         pstmt = conn.prepareStatement("select * from members where m_id like ?");
         pstmt.setString(1, "%" + m_id + "%");
         rs = pstmt.executeQuery();

         adminSearchMemberInfoAllList = new ArrayList();

         if (rs.next()) {

            do {
               vo = new MembersVO();

               vo.setM_id(rs.getString("m_id"));
               vo.setM_name(rs.getString("m_name"));
               vo.setPhone(rs.getString("phone"));
               vo.setEmail(rs.getString("email"));
               vo.setJumin(rs.getInt("jumin"));
               vo.setAddress(rs.getString("address"));
               vo.setGender(rs.getString("gender"));
               vo.setReg_date(rs.getTimestamp("reg_date"));

               adminSearchMemberInfoAllList.add(vo);

            } while (rs.next());
         }

         System.out.println("adminSearchMemberInfoAllList Size: " + adminSearchMemberInfoAllList.size());

      } catch (Exception e) {
         e.printStackTrace();

      } finally {
         CloseUtil.close(rs);
         CloseUtil.close(pstmt);
         CloseUtil.close(conn);
      }

      return adminSearchMemberInfoAllList;
   }

   // 관리자 페이지에서 아이디 검색해서 찾기

   public List adminSearchMemberInfo(String m_id, int start, int end) {
      Connection conn = null;
      PreparedStatement pstmt = null;
      ResultSet rs = null;
      MembersVO vo = null;
      List adminSearchMemberInfoList = null;

      try {
         conn = getConnection();
         pstmt = conn.prepareStatement("select m_id, m_name, phone, email, jumin, address, gender, reg_date, r from "
               + " (select m_id, m_name, phone, email, jumin, address, gender, reg_date, rownum r from members "
               + " where m_id like ?) where r >= ? and r <= ?");
         pstmt.setString(1, "%" + m_id + "%");
         pstmt.setInt(2, start);
         pstmt.setInt(3, end);
         rs = pstmt.executeQuery();

         adminSearchMemberInfoList = new ArrayList();

         if (rs.next()) {

            do {
               vo = new MembersVO();

               vo.setM_id(rs.getString("m_id"));
               vo.setM_name(rs.getString("m_name"));
               vo.setPhone(rs.getString("phone"));
               vo.setEmail(rs.getString("email"));
               vo.setJumin(rs.getInt("jumin"));
               vo.setAddress(rs.getString("address"));
               vo.setGender(rs.getString("gender"));
               vo.setReg_date(rs.getTimestamp("reg_date"));

               adminSearchMemberInfoList.add(vo);

            } while (rs.next());
         }

         System.out.println("adminSearchMemberInfoList Size: " + adminSearchMemberInfoList.size());

      } catch (Exception e) {
         e.printStackTrace();

      } finally {
         CloseUtil.close(rs);
         CloseUtil.close(pstmt);
         CloseUtil.close(conn);
      }

      return adminSearchMemberInfoList;
   }
   
   
   
   public void memberLeave(String[] m_id) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        StringBuffer sb = new StringBuffer();
        
        try{
           conn = getConnection();         // 연결
           // select 처리 명령
           sb = new StringBuffer();
           sb.append("DELETE FROM MEMBERS WHERE ");   // b_code 의 대한 쿼리문
           
           for(int i=0;i<m_id.length;i++){
              sb.append("(M_ID=?) ");
              if(i<m_id.length-1){
                 sb.append("OR ");
              }
           }//for
           
           System.out.println("쿼리문 : " + sb);
           System.out.println("b_code 배열 크기 : " + m_id.length);
           
           pstmt = conn.prepareStatement(sb.toString());
           
           int j=0;
           
           System.out.println("p_code.length : " + m_id.length);
           for(int i=0;i<m_id.length;i++){//i=0, i=1
              System.out.println(i+1 + " : " + m_id[i]);
              
              pstmt.setString(i+1, m_id[i]);
           }
           pstmt.executeQuery(); // 쿼리 실행
           
        }catch(Exception e){
           e.printStackTrace();
        }finally{
           CloseUtil.close(pstmt);
           CloseUtil.close(conn);
        }
     }//memberLeave()
}