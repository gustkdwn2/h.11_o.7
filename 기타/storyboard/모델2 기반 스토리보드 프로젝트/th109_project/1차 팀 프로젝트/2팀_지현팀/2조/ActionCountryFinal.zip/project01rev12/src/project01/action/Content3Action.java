package project01.action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import project01.bid.BidDAO;
import project01.products.ProductsDAO;

public class Content3Action implements CommandAction{

   @Override
   public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
     HttpSession session = request.getSession(); 
      request.setCharacterEncoding("utf-8");
      
      String b_code=request.getParameter("b_code");
      String b_id=(String)session.getAttribute("id");
      String p_name=request.getParameter("p_name");
      String due_date = request.getParameter("due_date");
      String price_bid = request.getParameter("price_bid");
      String price_immediate = request.getParameter("price_immediate");

      request.setAttribute("b_code", b_code);
      request.setAttribute("b_id", b_id);
      request.setAttribute("p_name",p_name);
      request.setAttribute("due_date", due_date);
      request.setAttribute("price_bid", price_bid);
      request.setAttribute("price_immediate",price_immediate);
      
      return "/content/content3.jsp";
   }

}