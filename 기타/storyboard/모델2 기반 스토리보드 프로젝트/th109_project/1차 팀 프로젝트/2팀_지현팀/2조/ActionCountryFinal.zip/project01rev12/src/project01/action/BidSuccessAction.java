package project01.action;

import java.sql.Timestamp;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import project01.bid.BidDAO;
import project01.bid.BidVO;
import project01.products.ProductsDAO;

public class BidSuccessAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		   HttpSession session = request.getSession(); 
		      request.setCharacterEncoding("utf-8");
		      
		      String b_code=request.getParameter("b_code");////
		      String b_id=(String)session.getAttribute("id");////
		      String p_name=request.getParameter("p_name");
		      String due_date = request.getParameter("due_date");
		      int price_bid = Integer.parseInt(request.getParameter("price_bid"));////
		      String price_immediate = request.getParameter("price_immediate");
		      
		      System.out.println("b_code : " + b_code);
		      System.out.println("b_id : " + b_id);
		      System.out.println("p_name : " + p_name);
		      System.out.println("due_date : " + due_date);
		      System.out.println("price_bid : " + price_bid);
		      System.out.println("price_immediate : " + price_immediate);
		      
		      BidVO vo = new BidVO();
		      vo.setB_code(b_code);
		      vo.setB_id(b_id);
		      vo.setPrice_bid(price_bid);
		      vo.setReg_date(new Timestamp(System.currentTimeMillis()));
		      

		      
		      BidDAO bid_dao = BidDAO.getInstance();
		      bid_dao.bsuccess(vo);//bid table에 insert
		      
		      ProductsDAO dao=ProductsDAO.getInstance();
		      dao.bidsuc(price_bid, b_code);//product테이블 update
		      
		      List list=dao.selectContent(b_code);
		      
		      request.setAttribute("list", list);
		      
		return "/content/content.jsp";
	}

}
