package project01.category;

import java.sql.Connection;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class CategoryDAO {
	private static CategoryDAO instance = new CategoryDAO();

	// static변수로 선언한 DAO객체를 리턴하는 메소드
	public static CategoryDAO getInstance() {
		return instance;
	}

	// 기본 생성자
	public CategoryDAO(){
		
	}

	// DB와 연결하는 메소드(web.xml과 이름 같은지 확인)
	public Connection getConnection() throws Exception {
		Context ctx = new InitialContext();
		DataSource ds = (DataSource) ctx.lookup("java:comp/env/jdbc:DB");

		return ds.getConnection();
	}
}
