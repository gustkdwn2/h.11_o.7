package project01.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import project01.members.MembersDAO;
import project01.products.ProductsDAO;

public class MemberLeaveProAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("utf-8");
		HttpSession session = request.getSession();
		String m_id = (String)session.getAttribute("id");
		String m_pwd = request.getParameter("pwd");
		
		 MembersDAO members_dao = MembersDAO.getInstance();
	     int check= members_dao.userpwdCheck( m_id, m_pwd);
		
	     
	     if(check==1){
	    	 members_dao.deletemembers(m_id);
	    	 session.invalidate();
	    	 return "/modify/memberleavePro.jsp";
	     }else{
	    	 
	    	 return "/modify/memberleaveForm.jsp";
	     }
	    	 
	     
		
	}

}
