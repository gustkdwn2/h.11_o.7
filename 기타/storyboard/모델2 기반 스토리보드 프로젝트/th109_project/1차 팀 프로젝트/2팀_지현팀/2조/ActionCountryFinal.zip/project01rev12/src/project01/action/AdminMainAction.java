package project01.action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import project01.members.MembersDAO;

public class AdminMainAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("utf-8");
		
		MembersDAO dao=MembersDAO.getInstance();
		HttpSession session=request.getSession();
		
		List memberInfoList=null;
		
		String m_id=(String) session.getAttribute("id");
		System.out.println("admin id: " +m_id);
		
		memberInfoList=dao.memberConfirm(m_id);
		System.out.println("admin InfoList: " +memberInfoList.size());
		
		request.setAttribute("memberInfoList", memberInfoList);
		
		return "/admin/adminMain.jsp";
	}

}