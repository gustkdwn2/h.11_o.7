package project01.action;

import java.sql.Timestamp;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import project01.members.MembersVO;
import project01.products.ProductsDAO;
import project01.products.ProductsVO;

public class Content5Action implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("utf-8");
		String p_code=request.getParameter("p_code");
		ProductsDAO dao=ProductsDAO.getInstance();
		List list=dao.selectContent(p_code);
		request.setAttribute("list", list);
		
		
	
		
		return "/content/content5.jsp";
	}

}
