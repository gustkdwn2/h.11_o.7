package project01.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import project01.members.MembersDAO;
import project01.members.MembersVO;

public class MemberModifyProAction implements CommandAction{

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
request.setCharacterEncoding("utf-8");
		
		MembersDAO dao=MembersDAO.getInstance();
		MembersVO vo=new MembersVO();
		HttpSession session=request.getSession();
		
		String m_name=request.getParameter("m_name");
		System.out.println("MemberModifyFormAction.java의 m_name: " +m_name);
		
		int jumin=Integer.parseInt(request.getParameter("jumin"));
		System.out.println("MemberModifyFormAction.java의 jumin: " +jumin);
		
		String gender=request.getParameter("gender");
		System.out.println("MemberModifyFormAction.java의 gender: " +gender);
		
		String phone=request.getParameter("phone1")+request.getParameter("phone2")+request.getParameter("phone3");
		System.out.println("MemberModifyFormAction.java의 phone: " +phone);
		
		String email=request.getParameter("email1") +"@" +request.getParameter("email3");
		System.out.println("MemberModifyFormAction.java의 email: " +email);
		
		String address=request.getParameter("address") +request.getParameter("address1");
		System.out.println("MemberModifyFormAction.java의 address: " +address);
		
		String m_id=(String) session.getAttribute("id");
		System.out.println("MemberModifyFormAction.java의 m_id: " +m_id);
		
		vo.setM_name(m_name);
		vo.setJumin(jumin);
		vo.setGender(gender);
		vo.setPhone(phone);
		vo.setEmail(email);
		vo.setAddress(address);
		vo.setM_id(m_id);
		
		dao.modifyMemberInfo(vo);
		
		return "/modify/memberModifyPro.jsp";
	}

}
