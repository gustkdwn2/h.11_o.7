package project01.action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import project01.members.MembersDAO;

public class AdminMemberAction implements CommandAction {

   @Override
   public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
      request.setCharacterEncoding("utf-8");

      MembersDAO dao = MembersDAO.getInstance();
      List adminMemberInfoList = null;
      List adminSearchMemberInfoList = null;
      String m_id = request.getParameter("searchID");
      System.out.println("searchID: " + m_id);
      
      ///////////페이징///////////
      
      int pageSize = 10;
      int count=0, Allcount=0;
      
      String pageNum = request.getParameter("pageNum");
      if (pageNum == null) {
         pageNum = "1";
      }
      System.out.println("pageNum: " + pageNum);
      
      int currentPage = Integer.parseInt(pageNum);
      System.out.println("currentPage: " + currentPage);
      
      int startRow = (currentPage * pageSize) - 9;
      System.out.println("startRow: " + startRow);

      int endRow = currentPage * pageSize;
      System.out.println("endRow: " + endRow);
      
      adminSearchMemberInfoList = dao.adminSearchMemberInfo(m_id, startRow, endRow);
      request.setAttribute("adminSearchMemberInfoList", adminSearchMemberInfoList);

      adminMemberInfoList = dao.adminMemberInfo(startRow, endRow);
      request.setAttribute("adminMemberInfoList", adminMemberInfoList);
      
      
      if(adminSearchMemberInfoList.isEmpty()){
         List allInfoList=dao.adminMemberInfoAll();
         
         count=adminMemberInfoList.size();
         Allcount=allInfoList.size();
         
         System.out.println("adminMemberInfo count: " +count);
         System.out.println("adminMemberInfo Allcount: " +Allcount);
         
         request.setAttribute("Allcount", Allcount);
         request.setAttribute("count", count);
         
      }else{
         List allInfoList=dao.adminSearchMemberInfoAll(m_id);
         
         count=adminSearchMemberInfoList.size();
         Allcount=allInfoList.size();
         
         System.out.println("adminSearchMemberInfo count: " +count);
         System.out.println("adminSearchMemberInfo Allcount: " +Allcount);
         
         request.setAttribute("count", count);
         request.setAttribute("Allcount", Allcount);
      }

      request.setAttribute("currentPage", new Integer(currentPage));
      request.setAttribute("startRow", new Integer(startRow));
      request.setAttribute("endRow", new Integer(endRow));
      request.setAttribute("count", new Integer(count));
      request.setAttribute("Allcount", new Integer(Allcount));
      request.setAttribute("pageSize", new Integer(pageSize));   
      request.setAttribute("searchID", m_id);
      
      return "/admin/adminMember.jsp";
   }

}