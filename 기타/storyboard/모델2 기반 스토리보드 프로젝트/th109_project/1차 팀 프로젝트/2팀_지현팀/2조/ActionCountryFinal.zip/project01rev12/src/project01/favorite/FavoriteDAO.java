package project01.favorite;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import project01.bid.BidVO;
import project01.products.ProductsVO;
import project01.util.CloseUtil;

public class FavoriteDAO {
	private static FavoriteDAO instance=new FavoriteDAO();
	
	//static변수로 선언한 DAO객체를 리턴하는 메소드
	public static FavoriteDAO getInstance(){
		return instance;
	}
	
	//기본 생성자
	public FavoriteDAO(){
		
	}
	
	//DB와 연결하는 메소드(web.xml과 이름 같은지 확인)
	public Connection getConnection() throws Exception{
		Context ctx=new InitialContext();
		DataSource ds=(DataSource)ctx.lookup("java:comp/env/jdbc:DB");
		
		return ds.getConnection();
	}
	//insert
		public void insert(FavoriteVO vo) throws Exception {
		      Connection conn = null;
		      PreparedStatement pstmt = null;
		      StringBuffer sb = new StringBuffer();
		      
		      conn = getConnection();
		      sb = new StringBuffer();
		      
		      sb.append("INSERT INTO FAVORITE(F_ID, F_CODE, REG_DATE)");
		      sb.append(" VALUES(?, ?, ?)");
		         
		      pstmt = conn.prepareStatement(sb.toString());
		      
		      pstmt.setString(1, vo.getF_id());
		      pstmt.setString(2, vo.getF_code());
		      pstmt.setTimestamp(3, vo.getReg_date());
		      pstmt.executeUpdate();
		      
		      CloseUtil.close(pstmt);
		      CloseUtil.close(conn);
		   } //insert() end
		
		 public List<BidVO> selectContent(String f_id) {
		      Connection conn = null;
		      PreparedStatement pstmt = null;
		      ResultSet rs = null;
		      StringBuffer sb = new StringBuffer();
		      FavoriteVO vo = null;
		      ProductsVO provo = null;
		      List favoriteList=null;
		      
		      try{
		         conn = getConnection();         // 연결
		         // select 처리 명령
		         sb = new StringBuffer();
		         sb.append("SELECT P.P_IMG, P.P_ID, P.P_CODE, P.P_NAME, P.CATEGORY1, P.CATEGORY2, P.DUE_DATE, P.PRICE_IMMEDIATE, P.PRICE_BID FROM PRODUCTS P, FAVORITE F WHERE P.P_CODE = F.F_CODE AND F.F_ID=?");   // b_code 의 대한 쿼리문
		         pstmt = conn.prepareStatement(sb.toString()); //
		         pstmt.setString(1, f_id); //
		         rs=pstmt.executeQuery(); // 쿼리 실행
		         
		         favoriteList=new ArrayList();
		         
		         if(rs.next()) {
		            do{
			            vo= new FavoriteVO();
			            provo = new ProductsVO();
			            
			            provo.setP_img(rs.getString("p_img"));
			            provo.setP_id(rs.getString("p_id"));
			            provo.setP_code(rs.getString("p_code"));
			            provo.setP_name(rs.getString("p_name"));
			            provo.setCategory1(rs.getString("category1"));
			            provo.setCategory2(rs.getString("category2"));
			            provo.setDue_date(rs.getTimestamp("due_date"));
			            provo.setPrice_immediate(rs.getInt("price_immediate"));
			            provo.setPrice_bid(rs.getInt("price_bid"));

			            favoriteList.add(provo);
		            }while(rs.next());
		         }

		      }catch(Exception e){
		         e.printStackTrace();
		      }finally{
		         CloseUtil.close(rs);
		         CloseUtil.close(pstmt);
		         CloseUtil.close(conn);
		      }
		      return favoriteList;
		   }
		 
		 public String f_id(String f_code) {
				Connection conn = null;
				PreparedStatement pstmt = null;
				ResultSet rs = null;
				StringBuffer sb = new StringBuffer();
				String f_id = "";

				try {
					conn = getConnection(); // 연결
					// select 처리 명령
					sb = new StringBuffer();
					sb.append("SELECT F_ID FROM FAVORITE WHERE F_CODE=?"); // b_code 의
																			// 대한 쿼리문
					pstmt = conn.prepareStatement(sb.toString()); //
					pstmt.setString(1, f_code); //
					rs = pstmt.executeQuery(); // 쿼리 실행

					if (rs.next()) {
						do {
							f_id = rs.getString("f_id");
						} while (rs.next());
					}

				} catch (Exception e) {
					e.printStackTrace();
				} finally {
					CloseUtil.close(rs);
					CloseUtil.close(pstmt);
					CloseUtil.close(conn);
				}
				return f_id;
			}
		 
		 
		 
		 public void deleteFavoriteForm(String f_id, String[] p_code) {
	         Connection conn = null;
	         PreparedStatement pstmt = null;
	         StringBuffer sb = new StringBuffer();
	         
	         try{
	            conn = getConnection();         // 연결
	            // select 처리 명령
	            sb = new StringBuffer();
	            sb.append("DELETE FROM FAVORITE WHERE ");   // b_code 의 대한 쿼리문
	            
	            for(int i=0;i<p_code.length;i++){
	               sb.append("(F_ID=? AND F_CODE=?) ");
	               if(i<p_code.length-1){
	                  sb.append("OR ");
	               }
	            }//for
	            
	            System.out.println("쿼리문 : " + sb);
	            System.out.println("p_code 배열 크기 : " + p_code.length);
	            
	            pstmt = conn.prepareStatement(sb.toString());
	            
	            int j=0;
	            /*for(int i=0;i<p_code.length;i++){
	            	System.out.println("p_code" + i + " : " + p_code[i]);
	            }
	            System.out.println("p_code.length : " + p_code.length);*/
	            for(int i=0;i<p_code.length;i++){//i=0, i=1
	               System.out.println(j+1 + " : " + f_id);
	               System.out.println(j+2 + " : " + p_code[i]);
	               
	               pstmt.setString(j+1, f_id);
	               pstmt.setString(j+2, p_code[i]);
	               j = j+2;
	            }
	            pstmt.executeQuery(); // 쿼리 실행
	            
	         }catch(Exception e){
	            e.printStackTrace();
	         }finally{
	            CloseUtil.close(pstmt);
	            CloseUtil.close(conn);
	         }
	      }//deleteFavoriteForm()
		// 한 페이지 당 검색결과 뿌리는 메소드
			public List<BidVO> searchOnePage(String f_id, int startRow, int endRow) {
				Connection conn = null;
				PreparedStatement pstmt = null;
				ResultSet rs = null;
				StringBuffer sb = new StringBuffer();
				FavoriteVO vo = null;
				ProductsVO provo = null;
				List favoriteList = null;

				try {
					conn = getConnection(); // 연결
					// select 처리 명령
					sb = new StringBuffer();
					
					sb.append("SELECT P_IMG, P_ID, P_CODE, P_NAME, CATEGORY1, CATEGORY2, DUE_DATE, PRICE_IMMEDIATE, PRICE_BID, REG, ROWSEQ ");
					sb.append("FROM (SELECT ROWNUM AS ROWSEQ, P_IMG, P_ID, P_CODE, P_NAME, CATEGORY1, CATEGORY2, DUE_DATE, PRICE_IMMEDIATE, PRICE_BID, REG ");			
					sb.append("FROM (SELECT P.P_IMG, P.P_ID, P.P_CODE, P.P_NAME, P.CATEGORY1, P.CATEGORY2, P.DUE_DATE, P.PRICE_IMMEDIATE, P.PRICE_BID, F.REG_DATE REG ");
					sb.append("FROM PRODUCTS P, FAVORITE F WHERE P.P_CODE = F.F_CODE AND F.F_ID=? ORDER BY REG DESC) ORDER BY  ROWSEQ ASC) WHERE ROWSEQ BETWEEN ? AND ?");

					pstmt = conn.prepareStatement(sb.toString());
					pstmt.setString(1, f_id);
					pstmt.setInt(2, startRow);
					pstmt.setInt(3, endRow);

					rs = pstmt.executeQuery(); // 쿼리 실행

					favoriteList = new ArrayList();

					if (rs.next()) {
						do {
							vo = new FavoriteVO();
							provo = new ProductsVO();

							provo.setP_img(rs.getString("p_img"));
							provo.setP_id(rs.getString("p_id"));
							provo.setP_code(rs.getString("p_code"));
							provo.setP_name(rs.getString("p_name"));
							provo.setCategory1(rs.getString("category1"));
							provo.setCategory2(rs.getString("category2"));
							provo.setDue_date(rs.getTimestamp("due_date"));
							provo.setPrice_immediate(rs.getInt("price_immediate"));
							provo.setPrice_bid(rs.getInt("price_bid"));

							favoriteList.add(provo);
						} while (rs.next());
					}

				} catch (Exception e) {
					e.printStackTrace();
				} finally {
					CloseUtil.close(rs);
					CloseUtil.close(pstmt);
					CloseUtil.close(conn);
				}
				return favoriteList;
			}
}
