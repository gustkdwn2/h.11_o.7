package project01.action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import project01.bid.BidDAO;
import project01.products.ProductsDAO;

public class Content2Action implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
			request.setCharacterEncoding("utf-8");
			//잘되면 리스트에서 링크로 p_code만넘기게 바꾸기!!
			String p_code=request.getParameter("p_code");
			

			ProductsDAO dao=ProductsDAO.getInstance();
			List list=dao.selectContent(p_code);
			
			request.setAttribute("list", list);
			

			//입찰내역
			BidDAO bid_dao = BidDAO.getInstance(); //
			
			List bidlist=bid_dao.select(p_code);
			request.setAttribute("bidlist", bidlist);
			request.setAttribute("p_code", p_code);
			
			return "/content/content2.jsp";
		}

	}