package project01.action;

import java.sql.Timestamp;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import project01.bid.*;
import project01.favorite.*;
import project01.products.*;

public class DeleteFavoriteFormAction implements CommandAction{

   @Override
   public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
     HttpSession session = request.getSession(); 
      request.setCharacterEncoding("utf-8");
      
      //String p_code = request.getParameter("p_code");
      String[] p_code = request.getParameterValues("p_code");
      String f_id = (String)session.getAttribute("id");
      
      for(int i=0;i<p_code.length;i++){
         System.out.println("p_code : "+ p_code[i]);
      }
      
      FavoriteDAO fiv_dao = FavoriteDAO.getInstance();
      fiv_dao.deleteFavoriteForm(f_id, p_code);//관심상품 테이블에서 지우기
      /////////////////////////////////////////////////////////
      
      /*List list=fiv_dao.selectContent(f_id);
      
      request.setAttribute("list", list);*/
      
      // page 처리 부분//
   		int pageSize = 7;
   		int Allcount = 0, count = 0;

   		String pageNum = request.getParameter("pageNum");
   		if (pageNum == null) {
   			pageNum = "1";
   		}
   		System.out.println("pageNum : " + pageNum);

   		int currentPage = Integer.parseInt(pageNum);
   		System.out.println("currentPage : " + currentPage);

   		int startRow = (currentPage * pageSize) - 6;
   		System.out.println("startRow: " + startRow);

   		int endRow = currentPage * pageSize;// 1*20
   		System.out.println("endRow: " + endRow);

   		////////////////////////////////////////////////
   		List searchAllList = fiv_dao.selectContent(f_id);
   		System.out.println("searchAllList: " + searchAllList.toString());

   		Allcount = searchAllList.size();//전체 관심상품 목록 개수
   		System.out.println("Allcount: " + Allcount);
   		//////////////////////////////////////////////
   		
   		List searchOnePageList = fiv_dao.searchOnePage(f_id, startRow, endRow);
   		count = searchOnePageList.size();
   		System.out.println("searchOnePageCount: " + count);

   		request.setAttribute("count", new Integer(count));
   		request.setAttribute("searchOnePageList", searchOnePageList);
   		/////////////////////////
   		request.setAttribute("searchAllList", searchAllList);
   		request.setAttribute("currentPage", new Integer(currentPage));
   		request.setAttribute("startRow", new Integer(startRow));
   		request.setAttribute("endRow", new Integer(endRow));
   		request.setAttribute("Allcount", new Integer(Allcount));
   		request.setAttribute("pageSize", new Integer(pageSize));
      
      return "/favorite/favoriteForm.jsp";
   }

}