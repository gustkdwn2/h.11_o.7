package project01.action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import project01.products.ProductsDAO;
import project01.bid.BidDAO;
import project01.favorite.FavoriteDAO;

public class ContentAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("utf-8");

		String p_code = request.getParameter("p_code");

		ProductsDAO dao = ProductsDAO.getInstance();
		List list = dao.selectContent(p_code);

		FavoriteDAO fav_dao = FavoriteDAO.getInstance();
		String f_id = fav_dao.f_id(p_code);

		request.setAttribute("list", list);
		request.setAttribute("f_id", f_id);
		////////////////////////////////////////////////////////////////////
		List prolist = dao.selectTimeout(); // products테이블에서 duedate지났는데 p_end가 N인
		// 데이터의 p_code값 list로 받아오기
		dao.updateTimeout(prolist); // 위에서 받아온 p_code에 해당하는 p_end를 Y로 update
		BidDAO biddao = BidDAO.getInstance();
		biddao.updateTimeout(prolist); // bid 테이블의 bid_success를 Y로 update
		///////////////////////////////////////////////////////////////////
		return "/content/content.jsp";
	}
}
