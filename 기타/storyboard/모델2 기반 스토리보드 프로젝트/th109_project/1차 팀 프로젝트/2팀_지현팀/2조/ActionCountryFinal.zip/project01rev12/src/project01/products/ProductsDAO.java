package project01.products;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import project01.util.CloseUtil;

public class ProductsDAO {
	private static ProductsDAO instance=new ProductsDAO();
	
	//static변수로 선언한 DAO객체를 리턴하는 메소드
	public static ProductsDAO getInstance(){
		return instance;
	}
	
	//기본 생성자
	public ProductsDAO(){
		
	}
	
	//DB와 연결하는 메소드(web.xml과 이름 같은지 확인)
	public Connection getConnection() throws Exception{
		Context ctx=new InitialContext();
		DataSource ds=(DataSource)ctx.lookup("java:comp/env/jdbc:DB");
		
		return ds.getConnection();
	}

	//상품등록하기 products 테이블에 insert
		public void insert(ProductsVO vo) {
			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			StringBuffer sb = new StringBuffer();
			try{
				conn = getConnection();			// 연결
				
				// insert 처리 명령
				sb = new StringBuffer();
				sb.append("INSERT INTO PRODUCTS(p_code, p_name, category1, category2, content, p_id, p_img, ");
				sb.append("price_start, price_immediate, due_date, reg_date, price_bid) ");
				sb.append("VALUES(product_code.nextval, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
				
				pstmt = conn.prepareStatement(sb.toString());
				pstmt.setString(1, vo.getP_name());
				pstmt.setString(2, vo.getCategory1());
				pstmt.setString(3, vo.getCategory2());
				pstmt.setString(4, vo.getContent());
				pstmt.setString(5, vo.getP_id());
				pstmt.setString(6, vo.getP_img());
				pstmt.setInt(7, vo.getPrice_start());
				pstmt.setInt(8, vo.getPrice_immediate());
				pstmt.setTimestamp(9, vo.getDue_date());
				pstmt.setTimestamp(10, vo.getReg_date());
				pstmt.setInt(11, vo.getPrice_bid());
				pstmt.executeUpdate();
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				CloseUtil.close(rs);
				CloseUtil.close(pstmt);
				CloseUtil.close(conn);
			}
		}
	
		//받아온 검색어에 대한 모든 검색 결과를 list에 저장하여 list를 리턴
		public List<ProductsVO> searchAll(String word){
			Connection conn=null;
			PreparedStatement pstmt=null;
			ResultSet rs=null;
			ProductsVO vo=null;
			List searchAllList=null;
			
			try{
				conn=getConnection();
				pstmt=conn.prepareStatement
						("select * from products where p_name like ? or content like ?");
				
				pstmt.setString(1, "%"+word+"%");
				pstmt.setString(2, "%"+word+"%");
				rs=pstmt.executeQuery();
				
				searchAllList=new ArrayList();
				
				if(rs.next()){
					do{
						vo=new ProductsVO();
						vo.setP_code(rs.getString("p_code"));
						vo.setP_name(rs.getString("p_name"));
						vo.setPrice_start(rs.getInt("price_start"));
						vo.setPrice_immediate(rs.getInt("price_immediate"));
						vo.setPrice_bid(rs.getInt("price_bid"));
						vo.setCategory1(rs.getString("category1"));
						vo.setCategory2(rs.getString("category2"));
						vo.setDue_date(rs.getTimestamp("due_date"));
						vo.setReg_date(rs.getTimestamp("reg_date"));
						vo.setP_id(rs.getString("p_id"));
						vo.setP_img(rs.getString("p_img"));
						vo.setContent(rs.getString("content"));
						vo.setBid_count(rs.getInt("bid_count"));
						vo.setP_end(rs.getString("p_end"));
						
						searchAllList.add(vo);
						
					}while(rs.next());
				}
				
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				CloseUtil.close(rs);
				CloseUtil.close(pstmt);
				CloseUtil.close(conn);
			}
			
			return searchAllList;
		}
		
		//메인 페이지에 출력하는 메소드(마감임박)
				public List<ProductsVO> mainPageEndList(){
					Connection conn=null;
					PreparedStatement pstmt=null;
					ResultSet rs=null;
					ProductsVO vo=null;
					List mainPageEndList=null;
					
					try{
						conn=getConnection();
						pstmt=conn.prepareStatement("select * from (select * from products order by due_date) where rownum<=5 and p_end='N'");
						rs=pstmt.executeQuery();
						mainPageEndList=new ArrayList();
						
						if(rs.next()){
							do{
								vo=new ProductsVO();
								
								vo.setP_code(rs.getString("p_code"));
								vo.setP_name(rs.getString("p_name"));
								vo.setPrice_start(rs.getInt("price_start"));
								vo.setPrice_immediate(rs.getInt("price_immediate"));
								vo.setPrice_bid(rs.getInt("price_bid"));
								vo.setCategory1(rs.getString("category1"));
								vo.setCategory2(rs.getString("category2"));
								vo.setDue_date(rs.getTimestamp("due_date"));
								vo.setReg_date(rs.getTimestamp("reg_date"));
								vo.setP_id(rs.getString("p_id"));
								vo.setP_img(rs.getString("p_img"));
								vo.setContent(rs.getString("content"));
								vo.setBid_count(rs.getInt("bid_count"));
								vo.setP_end(rs.getString("p_end"));
								
								mainPageEndList.add(vo);
								
							}while(rs.next());
						}
						
					}catch(Exception e){
						e.printStackTrace();
						
					}finally{
						CloseUtil.close(rs);
						CloseUtil.close(pstmt);
						CloseUtil.close(conn);
					}
					
					return mainPageEndList;
				}
				
				//메인 페이지에 출력하는 메소드(신규등록)
				public List<ProductsVO> mainPageNewList(){
					Connection conn=null;
					PreparedStatement pstmt=null;
					ResultSet rs=null;
					ProductsVO vo=null;
					List mainPageNewList=null;
					
					try{
						conn=getConnection();
						pstmt=conn.prepareStatement("select * from (select * from products order by reg_date desc) where rownum<=5 and p_end='N'");
						rs=pstmt.executeQuery();
						mainPageNewList=new ArrayList();
						
						if(rs.next()){
							do{
								vo=new ProductsVO();
								
								vo.setP_code(rs.getString("p_code"));
								vo.setP_name(rs.getString("p_name"));
								vo.setPrice_start(rs.getInt("price_start"));
								vo.setPrice_immediate(rs.getInt("price_immediate"));
								vo.setPrice_bid(rs.getInt("price_bid"));
								vo.setCategory1(rs.getString("category1"));
								vo.setCategory2(rs.getString("category2"));
								vo.setDue_date(rs.getTimestamp("due_date"));
								vo.setReg_date(rs.getTimestamp("reg_date"));
								vo.setP_id(rs.getString("p_id"));
								vo.setP_img(rs.getString("p_img"));
								vo.setContent(rs.getString("content"));
								vo.setBid_count(rs.getInt("bid_count"));
								vo.setP_end(rs.getString("p_end"));
								
								mainPageNewList.add(vo);
								
							}while(rs.next());
						}
						
					}catch(Exception e){
						e.printStackTrace();
						
					}finally{
						CloseUtil.close(rs);
						CloseUtil.close(pstmt);
						CloseUtil.close(conn);
					}
					
					return mainPageNewList;
				}
				
				//메인 페이지에 출력하는 메소드(베스트)
				public List<ProductsVO> mainPageBestList(){
					Connection conn=null;
					PreparedStatement pstmt=null;
					ResultSet rs=null;
					ProductsVO vo=null;
					List mainPageBestList=null;
					
					try{
						conn=getConnection();
						pstmt=conn.prepareStatement("select * from (select * from products order by bid_count desc) where rownum<=5 and p_end='N'");
						rs=pstmt.executeQuery();
						mainPageBestList=new ArrayList();
						
						if(rs.next()){
							do{
								vo=new ProductsVO();
								
								vo.setP_code(rs.getString("p_code"));
								vo.setP_name(rs.getString("p_name"));
								vo.setPrice_start(rs.getInt("price_start"));
								vo.setPrice_immediate(rs.getInt("price_immediate"));
								vo.setPrice_bid(rs.getInt("price_bid"));
								vo.setCategory1(rs.getString("category1"));
								vo.setCategory2(rs.getString("category2"));
								vo.setDue_date(rs.getTimestamp("due_date"));
								vo.setReg_date(rs.getTimestamp("reg_date"));
								vo.setP_id(rs.getString("p_id"));
								vo.setP_img(rs.getString("p_img"));
								vo.setContent(rs.getString("content"));
								vo.setBid_count(rs.getInt("bid_count"));
								vo.setP_end(rs.getString("p_end"));
								
								mainPageBestList.add(vo);
								
							}while(rs.next());
						}
						
					}catch(Exception e){
						e.printStackTrace();
						
					}finally{
						CloseUtil.close(rs);
						CloseUtil.close(pstmt);
						CloseUtil.close(conn);
					}
					
					return mainPageBestList;
				}
				
				//한 페이지 당 검색결과 뿌리는 메소드(기본 마감임박)
				public List<ProductsVO> searchOnePage(String word, int start, int end, int selectNum){
					Connection conn=null;
					PreparedStatement pstmt=null;
					ResultSet rs=null;
					ProductsVO vo=null;
					List searchOnePageList=null;
					
					if(selectNum==1){
						try{
							conn=getConnection();
							pstmt=conn.prepareStatement
									("select p_code, p_name, price_start, price_immediate, price_bid, "
											+ " category1, category2, due_date, reg_date, p_id, p_img, content, bid_count, p_end, r from "
											+ " (select p_code, p_name, price_start, price_immediate, price_bid, category1, category2, "
											+ " due_date, reg_date, p_id, p_img, content, bid_count, p_end, rownum r from "
											+ " (select * from products where ( p_name like ? or content like ? ) and p_end = 'N' order by due_date)) "
											+ " where r >= ? and r <= ? ");
							
							pstmt.setString(1, "%"+word+"%");
							pstmt.setString(2, "%"+word+"%");
							pstmt.setInt(3, start);
							pstmt.setInt(4, end);
							rs=pstmt.executeQuery();
							
							searchOnePageList=new ArrayList();
							
							if(rs.next()){
								do{
									vo=new ProductsVO();
									vo.setP_code(rs.getString("p_code"));
									vo.setP_name(rs.getString("p_name"));
									vo.setPrice_start(rs.getInt("price_start"));
									vo.setPrice_immediate(rs.getInt("price_immediate"));
									vo.setPrice_bid(rs.getInt("price_bid"));
									vo.setCategory1(rs.getString("category1"));
									vo.setCategory2(rs.getString("category2"));
									vo.setDue_date(rs.getTimestamp("due_date"));
									vo.setReg_date(rs.getTimestamp("reg_date"));
									vo.setP_id(rs.getString("p_id"));
									vo.setP_img(rs.getString("p_img"));
									vo.setContent(rs.getString("content"));
									vo.setBid_count(rs.getInt("bid_count"));
									vo.setP_end(rs.getString("p_end"));
									
									searchOnePageList.add(vo);
									
								}while(rs.next());
							}
							
						}catch(Exception e){
							e.printStackTrace();
						}finally{
							CloseUtil.close(rs);
							CloseUtil.close(pstmt);
							CloseUtil.close(conn);
						}
						
					}else if(selectNum==2){
						try{
							conn=getConnection();
							pstmt=conn.prepareStatement
									("select p_code, p_name, price_start, price_immediate, price_bid, "
											+ " category1, category2, due_date, reg_date, p_id, p_img, content, bid_count, p_end, r from "
											+ " (select p_code, p_name, price_start, price_immediate, price_bid, category1, category2, "
											+ " due_date, reg_date, p_id, p_img, content, bid_count, p_end, rownum r from "
											+ " (select * from products where ( p_name like ? or content like ? ) and p_end = 'N' order by reg_date desc)) "
											+ " where r >= ? and r <= ? ");
									
							
							pstmt.setString(1, "%"+word+"%");
							pstmt.setString(2, "%"+word+"%");
							pstmt.setInt(3, start);
							pstmt.setInt(4, end);
							rs=pstmt.executeQuery();
							
							searchOnePageList=new ArrayList();
							
							if(rs.next()){
								do{
									vo=new ProductsVO();
									vo.setP_code(rs.getString("p_code"));
									vo.setP_name(rs.getString("p_name"));
									vo.setPrice_start(rs.getInt("price_start"));
									vo.setPrice_immediate(rs.getInt("price_immediate"));
									vo.setPrice_bid(rs.getInt("price_bid"));
									vo.setCategory1(rs.getString("category1"));
									vo.setCategory2(rs.getString("category2"));
									vo.setDue_date(rs.getTimestamp("due_date"));
									vo.setReg_date(rs.getTimestamp("reg_date"));
									vo.setP_id(rs.getString("p_id"));
									vo.setP_img(rs.getString("p_img"));
									vo.setContent(rs.getString("content"));
									vo.setBid_count(rs.getInt("bid_count"));
									vo.setP_end(rs.getString("p_end"));
									
									searchOnePageList.add(vo);
									
								}while(rs.next());
							}
							
						}catch(Exception e){
							e.printStackTrace();
						}finally{
							CloseUtil.close(rs);
							CloseUtil.close(pstmt);
							CloseUtil.close(conn);
						}
						
					}else if(selectNum==3){
						try{
							conn=getConnection();
							pstmt=conn.prepareStatement
									("select p_code, p_name, price_start, price_immediate, price_bid, category1, "
											+ " category2, due_date, reg_date, p_id, p_img, content, bid_count, p_end, r "
											+ " from (select p_code, p_name, price_start, price_immediate, price_bid, category1, "
											+ " category2, due_date, reg_date, p_id, p_img, content, bid_count, p_end, rownum r "
											+ " from products where (p_name like ? or content like ?) and p_end='N') where r >= ? and r <= ? "
											+ " order by bid_count desc");
							
							pstmt.setString(1, "%"+word+"%");
							pstmt.setString(2, "%"+word+"%");
							pstmt.setInt(3, start);
							pstmt.setInt(4, end);
							rs=pstmt.executeQuery();
							
							searchOnePageList=new ArrayList();
							
							if(rs.next()){
								do{
									vo=new ProductsVO();
									vo.setP_code(rs.getString("p_code"));
									vo.setP_name(rs.getString("p_name"));
									vo.setPrice_start(rs.getInt("price_start"));
									vo.setPrice_immediate(rs.getInt("price_immediate"));
									vo.setPrice_bid(rs.getInt("price_bid"));
									vo.setCategory1(rs.getString("category1"));
									vo.setCategory2(rs.getString("category2"));
									vo.setDue_date(rs.getTimestamp("due_date"));
									vo.setReg_date(rs.getTimestamp("reg_date"));
									vo.setP_id(rs.getString("p_id"));
									vo.setP_img(rs.getString("p_img"));
									vo.setContent(rs.getString("content"));
									vo.setBid_count(rs.getInt("bid_count"));
									vo.setP_end(rs.getString("p_end"));
									
									searchOnePageList.add(vo);
									
								}while(rs.next());
							}
							
						}catch(Exception e){
							e.printStackTrace();
						}finally{
							CloseUtil.close(rs);
							CloseUtil.close(pstmt);
							CloseUtil.close(conn);
						}
					}else if(selectNum==4){
						try{
							conn=getConnection();
							pstmt=conn.prepareStatement
									("select p_code, p_name, price_start, price_immediate, price_bid, "
											+ " category1, category2, due_date, reg_date, p_id, p_img, content, bid_count, p_end, r from "
											+ " (select p_code, p_name, price_start, price_immediate, price_bid, category1, category2, "
											+ " due_date, reg_date, p_id, p_img, content, bid_count, p_end, rownum r from "
											+ " (select * from products where (p_name like ? or content like ?) and p_end='Y' order by due_date)) "
											+ " where r >= ? and r <= ? ");
			/*						("select p_code, p_name, price_start, price_immediate, price_bid, category1, "
											+ " category2, due_date, reg_date, p_id, p_img, content, bid_count, p_end, r "
											+ " from (select p_code, p_name, price_start, price_immediate, price_bid, category1, "
											+ " category2, due_date, reg_date, p_id, p_img, content, bid_count, p_end, rownum r "
											+ " from products where (p_name like ? or content like ?) and p_end='Y') where r >= ? and r <= ? "
											+ " order by due_date");*/
							
							pstmt.setString(1, "%"+word+"%");
							pstmt.setString(2, "%"+word+"%");
							pstmt.setInt(3, start);
							pstmt.setInt(4, end);
							rs=pstmt.executeQuery();
							
							searchOnePageList=new ArrayList();
							
							if(rs.next()){
								do{
									vo=new ProductsVO();
									vo.setP_code(rs.getString("p_code"));
									vo.setP_name(rs.getString("p_name"));
									vo.setPrice_start(rs.getInt("price_start"));
									vo.setPrice_immediate(rs.getInt("price_immediate"));
									vo.setPrice_bid(rs.getInt("price_bid"));
									vo.setCategory1(rs.getString("category1"));
									vo.setCategory2(rs.getString("category2"));
									vo.setDue_date(rs.getTimestamp("due_date"));
									vo.setReg_date(rs.getTimestamp("reg_date"));
									vo.setP_id(rs.getString("p_id"));
									vo.setP_img(rs.getString("p_img"));
									vo.setContent(rs.getString("content"));
									vo.setBid_count(rs.getInt("bid_count"));
									vo.setP_end(rs.getString("p_end"));
									
									searchOnePageList.add(vo);
									
								}while(rs.next());
							}
							
							//System.out.println("ProductsDAO searchOnePageList size3:" +searchOnePageList.size());
							
						}catch(Exception e){
							e.printStackTrace();
						}finally{
							CloseUtil.close(rs);
							CloseUtil.close(pstmt);
							CloseUtil.close(conn);
						}
					
					}else if(selectNum==5){
						try{
							conn=getConnection();
							pstmt=conn.prepareStatement
									("select p_code, p_name, price_start, price_immediate, price_bid, "
											+ " category1, category2, due_date, reg_date, p_id, p_img, content, bid_count, p_end, r from "
											+ " (select p_code, p_name, price_start, price_immediate, price_bid, category1, category2, "
											+ " due_date, reg_date, p_id, p_img, content, bid_count, p_end, rownum r from "
											+ " (select * from products where p_name like ? or content like ? order by p_end, reg_date desc)) "
											+ " where r >= ? and r <= ? ");
							
							pstmt.setString(1, "%"+word+"%");
							pstmt.setString(2, "%"+word+"%");
							pstmt.setInt(3, start);
							pstmt.setInt(4, end);
							rs=pstmt.executeQuery();
							
							searchOnePageList=new ArrayList();
							
							if(rs.next()){
								do{
									vo=new ProductsVO();
									vo.setP_code(rs.getString("p_code"));
									vo.setP_name(rs.getString("p_name"));
									vo.setPrice_start(rs.getInt("price_start"));
									vo.setPrice_immediate(rs.getInt("price_immediate"));
									vo.setPrice_bid(rs.getInt("price_bid"));
									vo.setCategory1(rs.getString("category1"));
									vo.setCategory2(rs.getString("category2"));
									vo.setDue_date(rs.getTimestamp("due_date"));
									vo.setReg_date(rs.getTimestamp("reg_date"));
									vo.setP_id(rs.getString("p_id"));
									vo.setP_img(rs.getString("p_img"));
									vo.setContent(rs.getString("content"));
									vo.setBid_count(rs.getInt("bid_count"));
									vo.setP_end(rs.getString("p_end"));
									
									searchOnePageList.add(vo);
									
								}while(rs.next());
							}
							
							//System.out.println("ProductsDAO searchOnePageList size3:" +searchOnePageList.size());
							
						}catch(Exception e){
							e.printStackTrace();
						}finally{
							CloseUtil.close(rs);
							CloseUtil.close(pstmt);
							CloseUtil.close(conn);
						}
					}//if end
					
					
					return searchOnePageList;
				}  
		
		//searchAll메소드에서 리턴된 list 사이즈를 int count에 저장하고 count 리턴
		public int searchAllCount(List<ProductsVO> list){
			int Allcount=list.size();
			return Allcount;
		}
		
		public int searchOnePageCount(List<ProductsVO> list){
			int count=list.size();
			return count;
		}
		

		//마감일자(due date) 계산해서 Sell_WriteProAction.java로 리턴
		public Timestamp countTime(int time) {
			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs=null;
			Timestamp due = null;
			
			try{
		          conn=getConnection();
		          pstmt=conn.prepareStatement("select sysdate+? from dual");
		          pstmt.setInt(1, time);
		          rs=pstmt.executeQuery();
		          
				if (rs.next()) {
					due = rs.getTimestamp(1);
				}

		       }catch(Exception e){
		          e.printStackTrace();
		       }finally{
		          CloseUtil.close(rs);
		          CloseUtil.close(pstmt);
		          CloseUtil.close(conn);
		       }
			
			return due; // 마감일자 리턴		
		}

		public List selectContent(String p_code) { // 리스트에서 컨텐츠 선택했을 때 화면에 필요한 내용
			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs=null;
			Timestamp due = null;
			List list = null;
			
			try{
		          conn=getConnection();
		          pstmt=conn.prepareStatement("select * from products where p_code=?");
		          pstmt.setString(1, p_code);
		          rs=pstmt.executeQuery();
		          ProductsVO vo=null;
		          list = new ArrayList();
		          
			if (rs.next()) {
				do {
					vo = new ProductsVO();
					vo.setP_code(rs.getString("p_code"));
					vo.setP_name(rs.getString("p_name"));
					vo.setPrice_start(rs.getInt("price_start"));
					vo.setPrice_immediate(rs.getInt("price_immediate"));
					vo.setPrice_bid(rs.getInt("price_bid"));
					vo.setCategory1(rs.getString("category1"));
					vo.setCategory2(rs.getString("category2"));
					vo.setDue_date(rs.getTimestamp("due_date"));
					vo.setReg_date(rs.getTimestamp("reg_date"));
					vo.setP_id(rs.getString("p_id"));
					vo.setP_img(rs.getString("p_img"));
					vo.setContent(rs.getString("content"));
					vo.setBid_count(rs.getInt("bid_count"));
					vo.setP_end(rs.getString("p_end"));

					list.add(vo);

				} while (rs.next());
			}
		       }catch(Exception e){
		          e.printStackTrace();
		       }finally{
		          CloseUtil.close(rs);
		          CloseUtil.close(pstmt);
		          CloseUtil.close(conn);
		       }
			return list;		
		}

		//클릭한 카테고리에 해당하는 데이터 list에 저장해서 return
		public List<ProductsVO> categorySearch(String category1, String category2) {
			Connection conn=null;
			PreparedStatement pstmt=null;
			ResultSet rs=null;
			ProductsVO vo=null;
			List categoryList=null;
			
			try{
				conn=getConnection();
				pstmt=conn.prepareStatement
						("select * from products where category1=? and category2=?");
				
				pstmt.setString(1, category1);
				pstmt.setString(2, category2);

				rs=pstmt.executeQuery();
				categoryList=new ArrayList();
				if(rs.next()){
					do{
						vo=new ProductsVO();
						vo.setP_code(rs.getString("p_code"));
						vo.setP_name(rs.getString("p_name"));
						vo.setPrice_start(rs.getInt("price_start"));
						vo.setPrice_immediate(rs.getInt("price_immediate"));
						vo.setPrice_bid(rs.getInt("price_bid"));
						vo.setCategory1(rs.getString("category1"));
						vo.setCategory2(rs.getString("category2"));
						vo.setDue_date(rs.getTimestamp("due_date"));
						vo.setReg_date(rs.getTimestamp("reg_date"));
						vo.setP_id(rs.getString("p_id"));
						vo.setP_img(rs.getString("p_img"));
						vo.setContent(rs.getString("content"));
						vo.setBid_count(rs.getInt("bid_count"));
						vo.setP_end(rs.getString("p_end"));
						categoryList.add(vo);
					}while(rs.next());
				}// if end
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				CloseUtil.close(rs);
				CloseUtil.close(pstmt);
				CloseUtil.close(conn);
			}
			return categoryList;
		}

		public List<ProductsVO> categoryOnePage(String category1, String category2, int start, int end, int selectNum) {
			Connection conn=null;
			PreparedStatement pstmt=null;
			ResultSet rs=null;
			ProductsVO vo=null;
			List categoryOnePageList=null;
			
			if(selectNum==1){ // 마감임박순 
				try{
					conn=getConnection();
					pstmt=conn.prepareStatement
							("select p_code, p_name, price_start, price_immediate, price_bid, "
									+ " category1, category2, due_date, reg_date, p_id, p_img, content, bid_count, p_end, r from "
									+ " (select p_code, p_name, price_start, price_immediate, price_bid, category1, category2, "
									+ " due_date, reg_date, p_id, p_img, content, bid_count, p_end, rownum r from "
									+ " (select * from products where ( category1 = ? and category2 = ? ) and p_end = 'N' order by due_date)) "
									+ " where r >= ? and r <= ? ");
				
					pstmt.setString(1, category1);
					pstmt.setString(2, category2);
					pstmt.setInt(3, start);
					pstmt.setInt(4, end);
					rs=pstmt.executeQuery();
					
					categoryOnePageList=new ArrayList();
					
					if(rs.next()){
						do{
							vo=new ProductsVO();
							vo.setP_code(rs.getString("p_code"));
							vo.setP_name(rs.getString("p_name"));
							vo.setPrice_start(rs.getInt("price_start"));
							vo.setPrice_immediate(rs.getInt("price_immediate"));
							vo.setPrice_bid(rs.getInt("price_bid"));
							vo.setCategory1(rs.getString("category1"));
							vo.setCategory2(rs.getString("category2"));
							vo.setDue_date(rs.getTimestamp("due_date"));
							vo.setReg_date(rs.getTimestamp("reg_date"));
							vo.setP_id(rs.getString("p_id"));
							vo.setP_img(rs.getString("p_img"));
							vo.setContent(rs.getString("content"));
							vo.setBid_count(rs.getInt("bid_count"));
							vo.setP_end(rs.getString("p_end"));
							
							categoryOnePageList.add(vo);
							
						}while(rs.next());
					}
					
				}catch(Exception e){
					e.printStackTrace();
				}finally{
					CloseUtil.close(rs);
					CloseUtil.close(pstmt);
					CloseUtil.close(conn);
				}
				
			}else if(selectNum==2){
				try{
					conn=getConnection();
					pstmt=conn.prepareStatement
							("select p_code, p_name, price_start, price_immediate, price_bid, "
									+ " category1, category2, due_date, reg_date, p_id, p_img, content, bid_count, p_end, r from "
									+ " (select p_code, p_name, price_start, price_immediate, price_bid, category1, category2, "
									+ " due_date, reg_date, p_id, p_img, content, bid_count, p_end, rownum r from "
									+ " (select * from products where ( category1 = ? and category2 = ? ) and p_end = 'N' order by reg_date desc)) "
									+ " where r >= ? and r <= ? ");
					
					pstmt.setString(1, category1);
					pstmt.setString(2, category2);
					pstmt.setInt(3, start);
					pstmt.setInt(4, end);
					rs=pstmt.executeQuery();
					
					categoryOnePageList=new ArrayList();
					
					if(rs.next()){
						do{
							vo=new ProductsVO();
							vo.setP_code(rs.getString("p_code"));
							vo.setP_name(rs.getString("p_name"));
							vo.setPrice_start(rs.getInt("price_start"));
							vo.setPrice_immediate(rs.getInt("price_immediate"));
							vo.setPrice_bid(rs.getInt("price_bid"));
							vo.setCategory1(rs.getString("category1"));
							vo.setCategory2(rs.getString("category2"));
							vo.setDue_date(rs.getTimestamp("due_date"));
							vo.setReg_date(rs.getTimestamp("reg_date"));
							vo.setP_id(rs.getString("p_id"));
							vo.setP_img(rs.getString("p_img"));
							vo.setContent(rs.getString("content"));
							vo.setBid_count(rs.getInt("bid_count"));
							vo.setP_end(rs.getString("p_end"));
							
							categoryOnePageList.add(vo);
							
						}while(rs.next());
					}
					
				}catch(Exception e){
					e.printStackTrace();
				}finally{
					CloseUtil.close(rs);
					CloseUtil.close(pstmt);
					CloseUtil.close(conn);
				}
				
			}else if(selectNum==3){
				try{
					conn=getConnection();
					pstmt=conn.prepareStatement
							("select p_code, p_name, price_start, price_immediate, price_bid, category1, "
									+ " category2, due_date, reg_date, p_id, p_img, content, bid_count, p_end, r "
									+ " from (select p_code, p_name, price_start, price_immediate, price_bid, category1, "
									+ " category2, due_date, reg_date, p_id, p_img, content, bid_count, p_end, rownum r "
									+ " from products where (category1=? and category2=?) and p_end='N' order by bid_count desc) where r >= ? and r <= ?");
					System.out.println(category1);
					System.out.println(category2);
					System.out.println(start);
					System.out.println(end);
					pstmt.setString(1, category1);
					pstmt.setString(2, category2);
					pstmt.setInt(3, start);
					pstmt.setInt(4, end);
					rs=pstmt.executeQuery();
					
					categoryOnePageList=new ArrayList();
					
					if(rs.next()){
						do{
							vo=new ProductsVO();
							vo.setP_code(rs.getString("p_code"));
							vo.setP_name(rs.getString("p_name"));
							vo.setPrice_start(rs.getInt("price_start"));
							vo.setPrice_immediate(rs.getInt("price_immediate"));
							vo.setPrice_bid(rs.getInt("price_bid"));
							vo.setCategory1(rs.getString("category1"));
							vo.setCategory2(rs.getString("category2"));
							vo.setDue_date(rs.getTimestamp("due_date"));
							vo.setReg_date(rs.getTimestamp("reg_date"));
							vo.setP_id(rs.getString("p_id"));
							vo.setP_img(rs.getString("p_img"));
							vo.setContent(rs.getString("content"));
							vo.setBid_count(rs.getInt("bid_count"));
							vo.setP_end(rs.getString("p_end"));
							
							categoryOnePageList.add(vo);
							
						}while(rs.next());
					}
					
				}catch(Exception e){
					e.printStackTrace();
				}finally{
					CloseUtil.close(rs);
					CloseUtil.close(pstmt);
					CloseUtil.close(conn);
				}
			}else if(selectNum==4){
				try{
					conn=getConnection();
					pstmt=conn.prepareStatement
							("select p_code, p_name, price_start, price_immediate, price_bid, "
									+ " category1, category2, due_date, reg_date, p_id, p_img, content, bid_count, p_end, r from "
									+ " (select p_code, p_name, price_start, price_immediate, price_bid, category1, category2, "
									+ " due_date, reg_date, p_id, p_img, content, bid_count, p_end, rownum r from "
									+ " (select * from products where (category1 = ? and category2 = ?) and p_end='Y' order by due_date)) "
									+ " where r >= ? and r <= ? ");
	/*						("select p_code, p_name, price_start, price_immediate, price_bid, category1, "
									+ " category2, due_date, reg_date, p_id, p_img, content, bid_count, p_end, r "
									+ " from (select p_code, p_name, price_start, price_immediate, price_bid, category1, "
									+ " category2, due_date, reg_date, p_id, p_img, content, bid_count, p_end, rownum r "
									+ " from products where (category1=? and category2=?) and p_end='Y' order by due_date) where r >= ? and r <= ?");
					*/
					
					System.out.println(category1);
					System.out.println(category2);
					System.out.println(start);
					System.out.println(end);
					pstmt.setString(1, category1);
					pstmt.setString(2, category2);
					pstmt.setInt(3, start);
					pstmt.setInt(4, end);
					rs=pstmt.executeQuery();
					
					categoryOnePageList=new ArrayList();
					
					if(rs.next()){
						do{
							vo=new ProductsVO();
							vo.setP_code(rs.getString("p_code"));
							vo.setP_name(rs.getString("p_name"));
							vo.setPrice_start(rs.getInt("price_start"));
							vo.setPrice_immediate(rs.getInt("price_immediate"));
							vo.setPrice_bid(rs.getInt("price_bid"));
							vo.setCategory1(rs.getString("category1"));
							vo.setCategory2(rs.getString("category2"));
							vo.setDue_date(rs.getTimestamp("due_date"));
							vo.setReg_date(rs.getTimestamp("reg_date"));
							vo.setP_id(rs.getString("p_id"));
							vo.setP_img(rs.getString("p_img"));
							vo.setContent(rs.getString("content"));
							vo.setBid_count(rs.getInt("bid_count"));
							vo.setP_end(rs.getString("p_end"));
							
							categoryOnePageList.add(vo);
							
						}while(rs.next());
					}
					
				}catch(Exception e){
					e.printStackTrace();
				}finally{
					CloseUtil.close(rs);
					CloseUtil.close(pstmt);
					CloseUtil.close(conn);
				}
			}else if(selectNum==5){
				try{
					conn=getConnection();
					pstmt=conn.prepareStatement
							("select p_code, p_name, price_start, price_immediate, price_bid, "
									+ " category1, category2, due_date, reg_date, p_id, p_img, content, bid_count, p_end, r from "
									+ " (select p_code, p_name, price_start, price_immediate, price_bid, category1, category2, "
									+ " due_date, reg_date, p_id, p_img, content, bid_count, p_end, rownum r from "
									+ " (select * from products where category1 = ? and category2 = ? order by p_end, reg_date desc)) "
									+ " where r >= ? and r <= ? ");
					System.out.println(category1);
					System.out.println(category2);
					System.out.println(start);
					System.out.println(end);
					pstmt.setString(1, category1);
					pstmt.setString(2, category2);
					pstmt.setInt(3, start);
					pstmt.setInt(4, end);
					rs=pstmt.executeQuery();
					
					categoryOnePageList=new ArrayList();
					
					if(rs.next()){
						do{
							vo=new ProductsVO();
							vo.setP_code(rs.getString("p_code"));
							vo.setP_name(rs.getString("p_name"));
							vo.setPrice_start(rs.getInt("price_start"));
							vo.setPrice_immediate(rs.getInt("price_immediate"));
							vo.setPrice_bid(rs.getInt("price_bid"));
							vo.setCategory1(rs.getString("category1"));
							vo.setCategory2(rs.getString("category2"));
							vo.setDue_date(rs.getTimestamp("due_date"));
							vo.setReg_date(rs.getTimestamp("reg_date"));
							vo.setP_id(rs.getString("p_id"));
							vo.setP_img(rs.getString("p_img"));
							vo.setContent(rs.getString("content"));
							vo.setBid_count(rs.getInt("bid_count"));
							vo.setP_end(rs.getString("p_end"));
							
							categoryOnePageList.add(vo);
							
						}while(rs.next());
					}
					
				}catch(Exception e){
					e.printStackTrace();
				}finally{
					CloseUtil.close(rs);
					CloseUtil.close(pstmt);
					CloseUtil.close(conn);
				}
			}//if end
			
			return categoryOnePageList;
		}	
		
		public void update(int price_bid, String b_code){
	         Connection conn = null;
	         PreparedStatement pstmt = null;
	         ResultSet rs = null;
	         StringBuffer sb = new StringBuffer();
	         try{
	            conn = getConnection();         // 연결
	            
	            // update 처리 명령
	            sb = new StringBuffer();
	            sb.append("UPDATE PRODUCTS ");
	            sb.append("SET PRICE_BID = ?, BID_COUNT = BID_COUNT+1 WHERE P_CODE = ?");
	            
	            pstmt = conn.prepareStatement(sb.toString());
	            pstmt.setLong(1, price_bid);
	            pstmt.setString(2, b_code);
	            pstmt.executeUpdate();
	         }catch(Exception e){
	            e.printStackTrace();
	         }finally{
	            CloseUtil.close(rs);
	            CloseUtil.close(pstmt);
	            CloseUtil.close(conn);
	         }
	      }
	
	// 해당 아이디의 출품상품 목록 - EntryFormAction.java
	public List selectSell(String p_id) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List list = null;

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement("select * from products where p_id=? order by reg_date desc");
			pstmt.setString(1, p_id);
			rs = pstmt.executeQuery();
			ProductsVO vo = null;
			list = new ArrayList();

			if (rs.next()) {
				do {
					vo = new ProductsVO();
					vo.setP_code(rs.getString("p_code"));
					vo.setP_name(rs.getString("p_name"));
					vo.setPrice_start(rs.getInt("price_start"));
					vo.setPrice_immediate(rs.getInt("price_immediate"));
					vo.setPrice_bid(rs.getInt("price_bid"));
					vo.setCategory1(rs.getString("category1"));
					vo.setCategory2(rs.getString("category2"));
					vo.setDue_date(rs.getTimestamp("due_date"));
					vo.setReg_date(rs.getTimestamp("reg_date"));
					vo.setP_id(rs.getString("p_id"));
					vo.setP_img(rs.getString("p_img"));
					vo.setContent(rs.getString("content"));
					vo.setBid_count(rs.getInt("bid_count"));
					vo.setP_end(rs.getString("p_end"));
					
					list.add(vo);
				} while (rs.next());
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		return list;
	}
	//출품중인 상품 수정, content5
		public void updating(ProductsVO vo){
			   Connection conn = null;
			   PreparedStatement pstmt = null;
			   
			   try{
				   System.out.println(vo.getP_code());
				   System.out.println(vo.getP_img());
				   System.out.println(vo.getP_name());
				   System.out.println(vo.getPrice_start());
				   conn = getConnection();
				   pstmt = conn.prepareStatement("update products set p_name=?, price_start=?, price_immediate=?, "
				   								+ " category1=?, category2=?, p_img=?, content=? where p_code=?");
				   
				   pstmt.setString(1, vo.getP_name());
				   pstmt.setInt(2, vo.getPrice_start());
				   pstmt.setInt(3, vo.getPrice_immediate());
				   pstmt.setString(4, vo.getCategory1());
				   pstmt.setString(5, vo.getCategory2());
				  
				   pstmt.setString(6, vo.getP_img());
				   pstmt.setString(7, vo.getContent());
				   pstmt.setString(8, vo.getP_code());
				   pstmt.executeUpdate();
				   
			   }catch(Exception e){
				   e.printStackTrace();
				   
			   }finally{
				   CloseUtil.close(pstmt); 
				   CloseUtil.close(conn);
			   }
		   }

		public void deleteEntryForm(String f_id, String[] p_code) {
	        Connection conn = null;
	        PreparedStatement pstmt = null;
	        StringBuffer sb = new StringBuffer();
	        
	        try{
	           conn = getConnection();         // 연결
	           // select 처리 명령
	           sb = new StringBuffer();
	           sb.append("DELETE FROM PRODUCTS WHERE ");   // b_code 의 대한 쿼리문
	           
	           for(int i=0;i<p_code.length;i++){
	              sb.append("(P_ID=? AND P_CODE=?) ");
	              if(i<p_code.length-1){
	                 sb.append("OR ");
	              }
	           }//for
	           
	           System.out.println("쿼리문 : " + sb);
	           System.out.println("p_code 배열 크기 : " + p_code.length);
	           
	           pstmt = conn.prepareStatement(sb.toString());
	           
	           int j=0;
	           /*for(int i=0;i<p_code.length;i++){
	           	System.out.println("p_code" + i + " : " + p_code[i]);
	           }
	           System.out.println("p_code.length : " + p_code.length);*/
	           for(int i=0;i<p_code.length;i++){//i=0, i=1
	              System.out.println(j+1 + " : " + f_id);
	              System.out.println(j+2 + " : " + p_code[i]);
	              
	              pstmt.setString(j+1, f_id);
	              pstmt.setString(j+2, p_code[i]);
	              j = j+2;
	           }
	           pstmt.executeQuery(); // 쿼리 실행
	           
	        }catch(Exception e){
	           e.printStackTrace();
	        }finally{
	           CloseUtil.close(pstmt);
	           CloseUtil.close(conn);
	        }
	     }//deleteEntryForm()
		//content6.jsp 상품삭제
		public void deletecontent(String p_code) { //변수가 하나라서 별로 vo 사용 할 필요가 없음 간단해서
	        Connection conn = null;
	        PreparedStatement pstmt = null;
	        StringBuffer sb = new StringBuffer();
	        
	        try{
	           conn = getConnection();         // 연결
	          
	           sb = new StringBuffer();
	           sb.append("DELETE FROM PRODUCTS WHERE p_code=?");   // p_code 의 대한 쿼리문
	           pstmt = conn.prepareStatement(sb.toString());
	          
	           pstmt.setString(1, p_code); // 쿼리문에 p_code를 넣음
	           pstmt.executeQuery(); // 쿼리 실행
	           
	        }catch(Exception e){
	           e.printStackTrace();
	        }finally{
	           CloseUtil.close(pstmt);
	           CloseUtil.close(conn);
	        }
	     }//deletecontent6()

		public List selectTimeout() {
			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			List list = null;

			try {
				conn = getConnection();
				pstmt = conn.prepareStatement("select p_code from products where sysdate>due_date and p_end='N'");
				rs = pstmt.executeQuery();
				list = new ArrayList();

				if (rs.next()) {
					do {
						list.add(rs.getString("p_code"));
					} while (rs.next());
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				CloseUtil.close(rs);
				CloseUtil.close(pstmt);
				CloseUtil.close(conn);
			}
			return list;
		}

		public void updateTimeout(List list) {
			Connection conn = null;
	         PreparedStatement pstmt = null;
	         ResultSet rs = null;
	         StringBuffer sb = new StringBuffer();
	         try{
	            conn = getConnection();         // 연결
	            
	            for(int i=0;i<list.size();i++){
	            	// update 처리 명령
		            sb = new StringBuffer();
		            sb.append("UPDATE PRODUCTS ");
		            sb.append("SET p_end='Y' WHERE P_CODE = ?");
	            	System.out.println((String)list.get(i));
	            	pstmt = conn.prepareStatement(sb.toString());
		            pstmt.setString(1, (String)list.get(i));
		            pstmt.executeUpdate();
	            }
	         }catch(Exception e){
	            e.printStackTrace();
	         }finally{
	            CloseUtil.close(rs);
	            CloseUtil.close(pstmt);
	            CloseUtil.close(conn);
	         }
		}
		
		// 한 페이지 당 검색결과 뿌리는 메소드
				public List<ProductsVO> searchPage(String p_id, int startRow, int endRow) {
					Connection conn = null;
					PreparedStatement pstmt = null;
					ResultSet rs = null;
					StringBuffer sb = new StringBuffer();
					ProductsVO vo = null;
					List favoriteList = null;

					try {
						conn = getConnection(); // 연결
						// select 처리 명령
						sb = new StringBuffer();
						
						sb.append("SELECT P_CODE, P_NAME, PRICE_START, PRICE_IMMEDIATE, PRICE_BID, CATEGORY1, CATEGORY2, DUE_DATE, REG_DATE, P_ID, P_IMG, CONTENT, BID_COUNT, P_END, ROWSEQ ");
						sb.append("FROM (SELECT ROWNUM AS ROWSEQ, P_CODE, P_NAME, PRICE_START, PRICE_IMMEDIATE, PRICE_BID, CATEGORY1, CATEGORY2, DUE_DATE, REG_DATE, P_ID, P_IMG, CONTENT, BID_COUNT, P_END ");
						sb.append("FROM (SELECT P_CODE, P_NAME, PRICE_START, PRICE_IMMEDIATE, PRICE_BID, CATEGORY1, CATEGORY2, DUE_DATE, REG_DATE, P_ID, P_IMG, CONTENT, BID_COUNT, P_END ");
						sb.append("FROM PRODUCTS WHERE P_ID=? ORDER BY REG_DATE DESC) ORDER BY ROWSEQ ASC) WHERE ROWSEQ BETWEEN ? AND ?");

						pstmt = conn.prepareStatement(sb.toString());
						pstmt.setString(1, p_id);
						pstmt.setInt(2, startRow);
						pstmt.setInt(3, endRow);
						
						rs = pstmt.executeQuery(); // 쿼리 실행

						favoriteList = new ArrayList();

						if (rs.next()) {
							do {
								vo = new ProductsVO();
								
								vo.setP_code(rs.getString("p_code"));
								vo.setP_name(rs.getString("p_name"));
								vo.setPrice_start(rs.getInt("price_start"));
								vo.setPrice_immediate(rs.getInt("price_immediate"));
								vo.setPrice_bid(rs.getInt("price_bid"));
								vo.setCategory1(rs.getString("category1"));
								vo.setCategory2(rs.getString("category2"));
								vo.setDue_date(rs.getTimestamp("due_date"));
								vo.setReg_date(rs.getTimestamp("reg_date"));
								vo.setP_id(rs.getString("p_id"));
								vo.setP_img(rs.getString("p_img"));
								vo.setContent(rs.getString("content"));
								vo.setBid_count(rs.getInt("bid_count"));
								vo.setP_end(rs.getString("p_end"));
								
								favoriteList.add(vo);
							} while (rs.next());
						}

					} catch (Exception e) {
						e.printStackTrace();
					} finally {
						CloseUtil.close(rs);
						CloseUtil.close(pstmt);
						CloseUtil.close(conn);
					}
					return favoriteList;
				}
				//즉시구매시 사용될 업데이트 메소드
				public void bidsuc(int price_bid, String b_code){
			        Connection conn = null;
			        PreparedStatement pstmt = null;
			        ResultSet rs = null;
			        StringBuffer sb = new StringBuffer();
			        try{
			           conn = getConnection();         // 연결
			           
			           // update 처리 명령
			           sb = new StringBuffer();
			           sb.append("UPDATE PRODUCTS ");
			           sb.append("SET PRICE_BID = ?, p_end = 'Y', BID_COUNT = BID_COUNT+1 WHERE P_CODE = ?");
			         
			           pstmt = conn.prepareStatement(sb.toString());
			           pstmt.setLong(1, price_bid);
			           pstmt.setString(2, b_code);
			           pstmt.executeUpdate();
			        }catch(Exception e){
			           e.printStackTrace();
			        }finally{
			           CloseUtil.close(rs);
			           CloseUtil.close(pstmt);
			           CloseUtil.close(conn);
			        }
			     }

		
				
				/////////////////List AllCount////////////////
				
				public List select123Count(String word){
					Connection conn=null;
					PreparedStatement pstmt=null;
					ResultSet rs=null;
					ProductsVO vo=null;
					List select123List=null;
					
					try{
						conn=getConnection();
						pstmt=conn.prepareStatement("select p_code from products where ( p_name like ? or content like ? ) and p_end = 'N'");
						pstmt.setString(1, "%"+word+"%");
						pstmt.setString(2, "%"+word+"%");
						rs=pstmt.executeQuery();		
						
						select123List=new ArrayList();
						
						if(rs.next()){
							do{
								vo=new ProductsVO();
								
								vo.setP_code(rs.getString("p_code")); 
								select123List.add(vo);
								
							}while(rs.next());
						}
						
					}catch(Exception e){
						e.printStackTrace();
						
					}finally{
						CloseUtil.close(rs);
						CloseUtil.close(pstmt);
						CloseUtil.close(conn);
					}
					
					return select123List;
				}
				
				public List select4Count(String word){
					Connection conn=null;
					PreparedStatement pstmt=null;
					ResultSet rs=null;
					ProductsVO vo=null;
					List select4List=null;
					
					try{
						conn=getConnection();
						pstmt=conn.prepareStatement("select p_code from products where (p_name like ? or content like ?) and p_end='Y'");
						pstmt.setString(1, "%"+word+"%");
						pstmt.setString(2, "%"+word+"%");
						rs=pstmt.executeQuery();	
						
						select4List=new ArrayList();
						
						if(rs.next()){
							do{
								vo=new ProductsVO();
								
								vo.setP_code(rs.getString("p_code")); 
								select4List.add(vo);
								
							}while(rs.next());
						}
						
					}catch(Exception e){
						e.printStackTrace();
						
					}finally{
						CloseUtil.close(rs);
						CloseUtil.close(pstmt);
						CloseUtil.close(conn);
					}
					
					return select4List;
				}
				
				public List select5Count(String word){
					Connection conn=null;
					PreparedStatement pstmt=null;
					ResultSet rs=null;
					ProductsVO vo=null;
					List select5List=null;
					
					try{
						conn=getConnection();
						pstmt=conn.prepareStatement("select p_code from products where p_name like ? or content like ?");
						pstmt.setString(1, "%"+word+"%");
						pstmt.setString(2, "%"+word+"%");
						rs=pstmt.executeQuery();		
						
						select5List=new ArrayList();
						
						if(rs.next()){
							do{
								vo=new ProductsVO();
								
								vo.setP_code(rs.getString("p_code")); 
								select5List.add(rs.getString("p_code"));
								
							}while(rs.next());
						}
						
						System.out.println("ProductsDAO select5List: " +select5List.size());
						
					}catch(Exception e){
						e.printStackTrace();
						
					}finally{
						CloseUtil.close(rs);
						CloseUtil.close(pstmt);
						CloseUtil.close(conn);
					}
					
					return select5List;
				}
				
				
				public List categoryCount123(String category1, String category2){ // select=1,2,3 일때 총갯수 세기위해...
			         
			         Connection conn=null;
			         PreparedStatement pstmt=null;
			         ResultSet rs=null;
			         ProductsVO vo=null;
			         List categoryList=null;
			         
			         try{
			            conn=getConnection();
			            pstmt=conn.prepareStatement("select p_code from products where category1=? and category2=? and p_end='N'");
			            
			            pstmt.setString(1, category1);
			            pstmt.setString(2, category2);

			            rs=pstmt.executeQuery();
			            categoryList=new ArrayList();
			            if(rs.next()){
			               do{
			                  categoryList.add(rs.getString("p_code"));
			               }while(rs.next());
			            }// if end
			         }catch(Exception e){
			            e.printStackTrace();
			         }finally{
			            CloseUtil.close(rs);
			            CloseUtil.close(pstmt);
			            CloseUtil.close(conn);
			         }
			         return categoryList;
			      }
			      public List categoryCount4(String category1, String category2){ // 4. 마감된상품
			         
			         Connection conn=null;
			         PreparedStatement pstmt=null;
			         ResultSet rs=null;
			         ProductsVO vo=null;
			         List categoryList=null;
			         
			         try{
			            conn=getConnection();
			            pstmt=conn.prepareStatement("select p_code from products where category1=? and category2=? and p_end='Y'");
			            
			            pstmt.setString(1, category1);
			            pstmt.setString(2, category2);

			            rs=pstmt.executeQuery();
			            categoryList=new ArrayList();
			            if(rs.next()){
			               do{
			                  categoryList.add(rs.getString("p_code"));
			               }while(rs.next());
			            }// if end
			         }catch(Exception e){
			            e.printStackTrace();
			         }finally{
			            CloseUtil.close(rs);
			            CloseUtil.close(pstmt);
			            CloseUtil.close(conn);
			         }
			         return categoryList;
			      }

		
}
