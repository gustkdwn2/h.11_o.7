package project01.action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import project01.bid.BidDAO;
import project01.products.ProductsDAO;

public class EntryFormAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("utf-8");
		HttpSession session = request.getSession();

		String p_id = (String) session.getAttribute("id");

		ProductsDAO dao = ProductsDAO.getInstance();

		/*
		 * List list = dao.selectSell(p_id);
		 * 
		 * request.setAttribute("list", list);
		 */

		///////////////////////////////////////////
		// page 처리 부분//
		int pageSize = 7;
		int Allcount = 0, count = 0;

		String pageNum = request.getParameter("pageNum");
		if (pageNum == null) {
			pageNum = "1";
		}
		System.out.println("pageNum : " + pageNum);

		int currentPage = Integer.parseInt(pageNum);
		System.out.println("currentPage : " + currentPage);

		int startRow = (currentPage * pageSize) - 6;
		System.out.println("startRow: " + startRow);

		int endRow = currentPage * pageSize;// 1*20
		System.out.println("endRow: " + endRow);

		////////////////////////////////////////////////
		List searchAllList = dao.selectSell(p_id);
		System.out.println("searchAllList: " + searchAllList.toString());

		Allcount = searchAllList.size();// 전체 관심상품 목록 개수
		System.out.println("Allcount: " + Allcount);
		//////////////////////////////////////////////

		List searchOnePageList = dao.searchPage(p_id, startRow, endRow);
		count = searchOnePageList.size();
		System.out.println("searchOnePageCount: " + count);

		request.setAttribute("count", new Integer(count));
		request.setAttribute("searchOnePageList", searchOnePageList);
		/////////////////////////
		request.setAttribute("searchAllList", searchAllList);
		request.setAttribute("currentPage", new Integer(currentPage));
		request.setAttribute("startRow", new Integer(startRow));
		request.setAttribute("endRow", new Integer(endRow));
		request.setAttribute("Allcount", new Integer(Allcount));
		request.setAttribute("pageSize", new Integer(pageSize));

		////////////////////////////////////////////////////////////////////
		List list = dao.selectTimeout(); // products테이블에서 duedate지났는데 p_end가 N인
		// 데이터의 p_code값 list로 받아오기
		dao.updateTimeout(list); // 위에서 받아온 p_code에 해당하는 p_end를 Y로 update
		BidDAO biddao = BidDAO.getInstance();
		biddao.updateTimeout(list); // bid 테이블의 bid_success를 Y로 update
		///////////////////////////////////////////////////////////////////

		return "/entry/entryForm.jsp";
	}

}
