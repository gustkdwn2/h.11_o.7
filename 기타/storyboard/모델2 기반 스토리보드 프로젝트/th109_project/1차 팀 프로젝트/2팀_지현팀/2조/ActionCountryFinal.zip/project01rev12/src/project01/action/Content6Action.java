package project01.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import project01.products.ProductsDAO;

public class Content6Action implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("utf-8");
		HttpSession session = request.getSession(); 
	
		String p_code=request.getParameter("p_code"); // p_code를 받아왔으니 사용할려면 불러와야해서 씀
		ProductsDAO dao=ProductsDAO.getInstance(); //productsDAO 를 사용하려면 이걸 써야함
		
		dao.deletecontent(p_code);
		
		return "/content/content6.jsp";
	}

}
