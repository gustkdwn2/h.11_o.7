package project01.action;

import java.util.Enumeration;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import project01.products.ProductsDAO;
import project01.products.ProductsVO;

public class Content5ProAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("utf-8");
		

		String realFolder="";
	      String saveFolder="upload";
	      int maxSize = 1024 * 1024 * 5; // 5MB
	      String encType = "utf-8";
	      String fileName="null";
	      String orgFileName="null";
	      
	      ServletContext context = request.getSession().getServletContext(); // context에 웹 컨테이너가 들어감
	      realFolder = request.getRealPath(saveFolder);
	      
	      try{
	               MultipartRequest multi=null;
	               multi = new MultipartRequest(
	               request,    //request 객체
	               realFolder, //파일이 저장될 폴더 경로
	               maxSize,  //업로드할 파일의 최대 크기
	               encType, // 인코딩 타입
	               new DefaultFileRenamePolicy() 
	               //동일한 파일명이 업로드 되는 경우 덮어쓰기 방지
	            );
	         Enumeration files = multi.getFileNames();
	         int zoom = 5;
	         
	         while(files.hasMoreElements()){
	            String name = (String)files.nextElement();
	            fileName = multi.getFilesystemName(name);
	         }
	            
		
		ProductsDAO dao=ProductsDAO.getInstance();
	ProductsVO vo=new ProductsVO();
		
		String p_name=multi.getParameter("p_name");
		System.out.println("p_name===="+p_name);
		int price_start=Integer.parseInt(multi.getParameter("price_start"));
		int price_immediate=Integer.parseInt(multi.getParameter("price_immediate"));
		
		String category1=multi.getParameter("category1");
		String category2=multi.getParameter("category2");
		
		//String p_img=multi.getParameter("p_img");
		String content=multi.getParameter("content");
		String p_code=multi.getParameter("p_code");
		
		vo.setP_code(p_code);
		vo.setP_name(p_name);
		vo.setPrice_start(price_start);
		vo.setPrice_immediate(price_immediate);
		vo.setCategory1(category1);
		vo.setCategory2(category2);
		vo.setP_img(fileName);
		vo.setContent(content);
		
		dao.updating(vo);
	         }catch(Exception e){
	             e.printStackTrace();
	          }
		
		return "/content/content5Pro.jsp";
	

	      }
	}
