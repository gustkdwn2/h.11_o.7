package project01.action;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import project01.bid.BidDAO;
import project01.products.ProductsDAO;

public class SearchResultFormAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("utf-8");

		int pageSize = 7;
		int Allcount = 0, count = 0, select = 0, searchAllcount=0;

		ProductsDAO dao = ProductsDAO.getInstance();

		select = Integer.parseInt(request.getParameter("select"));
		System.out.println("select: " + select);

		String pageNum = request.getParameter("pageNum");
		if (pageNum == null) {
			pageNum = "1";
		}
		System.out.println("pageNum: " + pageNum);

		int currentPage = Integer.parseInt(pageNum);
		System.out.println("currentPage: " + currentPage);

		String searchText = request.getParameter("searchText");
		System.out.println("searchText: " + searchText);

		int startRow = (currentPage * pageSize) - 6;
		System.out.println("startRow: " + startRow);

		int endRow = currentPage * pageSize;// 1*20
		System.out.println("endRow: " + endRow);

		////////////////////////////////////////////////
		List searchAllList = dao.searchAll(searchText);
		System.out.println("searchAllList: " + searchAllList.toString());
		
		searchAllcount=searchAllList.size();

/*		Allcount = dao.searchAllCount(searchAllList);
		System.out.println("Allcount: " + Allcount);*/
		//////////////////////////////////////////////
		int selectNum = 0;

		// 정렬 방식에 따라 리스트에 저장하는 값을 다르게 하기
		if (select == 1) {
			selectNum = 1;
			List searchOnePageList = dao.searchOnePage(searchText, startRow, endRow, selectNum);
			count = dao.searchOnePageCount(searchOnePageList);
			Allcount=dao.select123Count(searchText).size();
			System.out.println("searchOnePageCount: " + count);
			System.out.println("select1 Allcount: " +Allcount);

			request.setAttribute("count", new Integer(count));
			request.setAttribute("searchOnePageList", searchOnePageList);
			request.setAttribute("Allcount", new Integer(Allcount));

		} else if (select == 2) {
			selectNum = 2;
			List searchOnePageList = dao.searchOnePage(searchText, startRow, endRow, selectNum);
			count = dao.searchOnePageCount(searchOnePageList);
			Allcount=dao.select123Count(searchText).size();
			System.out.println("searchOnePageCount: " + count);
			System.out.println("select2 Allcount: " +Allcount);

			request.setAttribute("count", new Integer(count));
			request.setAttribute("searchOnePageList", searchOnePageList);
			request.setAttribute("Allcount", new Integer(Allcount));

		} else if (select == 3) {
			selectNum = 3;
			List searchOnePageList = dao.searchOnePage(searchText, startRow, endRow, selectNum);
			count = dao.searchOnePageCount(searchOnePageList);
			Allcount=dao.select123Count(searchText).size();
			System.out.println("searchOnePageCount: " + count);
			System.out.println("select3 Allcount: " +Allcount);

			request.setAttribute("count", new Integer(count));
			request.setAttribute("searchOnePageList", searchOnePageList);
			request.setAttribute("Allcount", new Integer(Allcount));
		} else if (select == 4) {
			selectNum = 4;
			List searchOnePageList = dao.searchOnePage(searchText, startRow, endRow, selectNum);
			count = dao.searchOnePageCount(searchOnePageList);
			Allcount=dao.select4Count(searchText).size();
			System.out.println("searchOnePageCount4: " + count);
			System.out.println("select4 Allcount: " +Allcount);

			request.setAttribute("count", new Integer(count));
			request.setAttribute("searchOnePageList", searchOnePageList);
			request.setAttribute("Allcount", new Integer(Allcount));
		} else {
			selectNum = 5;
			List searchOnePageList = dao.searchOnePage(searchText, startRow, endRow, selectNum);
			count = dao.searchOnePageCount(searchOnePageList);
			Allcount=dao.select5Count(searchText).size();
			System.out.println("searchOnePageCount: " + count);
			System.out.println("select5 Allcount: " +Allcount);

			request.setAttribute("count", new Integer(count));
			request.setAttribute("searchOnePageList", searchOnePageList);
			request.setAttribute("Allcount", new Integer(Allcount));
		}

		Timestamp sysDate = new Timestamp(System.currentTimeMillis());
		request.setAttribute("sysDate", sysDate);

		request.setAttribute("searchText", searchText);
		request.setAttribute("searchAllcount", searchAllcount);
		request.setAttribute("select", new Integer(select));
		request.setAttribute("currentPage", new Integer(currentPage));
		request.setAttribute("startRow", new Integer(startRow));
		request.setAttribute("endRow", new Integer(endRow));
		request.setAttribute("pageSize", new Integer(pageSize));

		////////////////////////////////////////////////////////////////////
		List list = dao.selectTimeout(); // products테이블에서 duedate지났는데 p_end가 N인
		// 데이터의 p_code값 list로 받아오기
		dao.updateTimeout(list); // 위에서 받아온 p_code에 해당하는 p_end를 Y로 update
		BidDAO biddao = BidDAO.getInstance();
		biddao.updateTimeout(list); // bid 테이블의 bid_success를 Y로 update
		///////////////////////////////////////////////////////////////////

		return "/search/searchResultForm.jsp";
	}

}
