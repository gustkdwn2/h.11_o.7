package project01.action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import project01.bid.BidDAO;
import project01.products.ProductsDAO;

public class CategorySearchFormAction implements CommandAction {

   @Override
   public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
      request.setCharacterEncoding("UTF-8");

      int pageSize = 7; // 한페이지에 출력할 게시물 수
      int allcount = 0, count = 0, select = 0;
      // allcount : 해당 카테고리의 총 데이터 갯수
      // count
      // select : 정렬 기준
      select = Integer.parseInt(request.getParameter("select")); // 카테고리 버튼
                                                   // 누를때 기본값
                                                   // 1로 해서
                                                   // get방식으로
                                                   // 보내줌
      String pageNum = request.getParameter("pageNum"); // 카테고리 버튼 누를때 기본값 1로
                                             // 해서 get방식으로 보내줌
      if (pageNum == null) {
         pageNum = "1";
      }
      int currentPage = Integer.parseInt(pageNum); // currentPage : 현재 보고 있는
                                          // 페이지
      int startRow = (currentPage * pageSize) - 6; // 현재페이지의 시작행
      int endRow = currentPage * pageSize; // 현재페이지의 끝행

      System.out.println("select : " + select);
      System.out.println("pageNum : " + pageNum);
      System.out.println("currentPage : " + currentPage);
      System.out.println("startRow : " + startRow);
      System.out.println("endRow : " + endRow);

      ///////////////////////////////////////////////////////////////////////////////////////////////////
      String category1 = request.getParameter("category1");
      String category2 = request.getParameter("category2");
      // get방식으로 보내준 category1, category2
      ProductsDAO dao = ProductsDAO.getInstance();
      List categoryList=null;
      /////////////////////////////////////////////////////////////
      int selectNum = 0;
      // 정렬 방식에 따라 리스트에 저장하는 값을 다르게 하기
      if (select == 1) { // 마감임박
         selectNum = 1;
         
         categoryList = dao.categoryCount123(category1, category2);
         // 카테고리1,카테고리2에 해당하는 리스트 검색
         allcount = categoryList.size();
         System.out.println("allcount: " + allcount);
         // 해당하는 리스트 갯수 count
         
         List categoryOnePageList = dao.categoryOnePage(category1, category2, startRow, endRow, selectNum);
         count = dao.searchOnePageCount(categoryOnePageList);// 한페이지에 몇개의
                                                // 데이터가 있는지..
         System.out.println("searchOnePageCount: " + count);

         request.setAttribute("count", new Integer(count));
         request.setAttribute("categoryOnePageList", categoryOnePageList);

      } else if (select == 2) { // 신규등록
         selectNum = 2;
         
         categoryList = dao.categoryCount123(category1, category2);
         // 카테고리1,카테고리2에 해당하는 리스트 검색
         allcount = categoryList.size();
         System.out.println("allcount: " + allcount);
         // 해당하는 리스트 갯수 count
         
         List categoryOnePageList = dao.categoryOnePage(category1, category2, startRow, endRow, selectNum);
         count = dao.searchOnePageCount(categoryOnePageList);
         System.out.println("searchOnePageCount: " + count);

         request.setAttribute("count", new Integer(count));
         request.setAttribute("categoryOnePageList", categoryOnePageList);

      } else if (select == 3) { // 베스트
         selectNum = 3;
         
         categoryList = dao.categoryCount123(category1, category2);
         // 카테고리1,카테고리2에 해당하는 리스트 검색
         allcount = categoryList.size();
         System.out.println("allcount: " + allcount);
         // 해당하는 리스트 갯수 count
         
         List categoryOnePageList = dao.categoryOnePage(category1, category2, startRow, endRow, selectNum);
         count = dao.searchOnePageCount(categoryOnePageList);
         System.out.println("searchOnePageCount: " + count);

         request.setAttribute("count", new Integer(count));
         request.setAttribute("categoryOnePageList", categoryOnePageList);
      } else if (select == 4) { // 마감된 상품
         selectNum = 4;
         
         categoryList = dao.categoryCount4(category1, category2);
         // 카테고리1,카테고리2에 해당하는 리스트 검색
         allcount = categoryList.size();
         System.out.println("allcount: " + allcount);
         // 해당하는 리스트 갯수 count
         
         List categoryOnePageList = dao.categoryOnePage(category1, category2, startRow, endRow, selectNum);
         count = dao.searchOnePageCount(categoryOnePageList);
         System.out.println("searchOnePageCount: " + count);

         request.setAttribute("count", new Integer(count));
         request.setAttribute("categoryOnePageList", categoryOnePageList);
      } else { // default 마감상품+경매중인상품
         selectNum = 5;
         
         categoryList = dao.categorySearch(category1, category2);
         // 카테고리1,카테고리2에 해당하는 리스트 검색
         allcount = categoryList.size();
         System.out.println("allcount: " + allcount);
         // 해당하는 리스트 갯수 count
         
         List categoryOnePageList = dao.categoryOnePage(category1, category2, startRow, endRow, selectNum);
         count = dao.searchOnePageCount(categoryOnePageList);
         System.out.println("searchOnePageCount: " + count);

         request.setAttribute("count", new Integer(count));
         request.setAttribute("categoryOnePageList", categoryOnePageList);
      }
      request.setAttribute("category1", category1);
      request.setAttribute("category2", category2);
      request.setAttribute("select", new Integer(select));
      request.setAttribute("currentPage", new Integer(currentPage));
      request.setAttribute("startRow", new Integer(startRow));
      request.setAttribute("endRow", new Integer(endRow));
      request.setAttribute("Allcount", new Integer(allcount));
      request.setAttribute("pageSize", new Integer(pageSize));
      request.setAttribute("categoryList", categoryList);

      ////////////////////////////////////////////////////////////////////
      List list = dao.selectTimeout(); // products테이블에서 duedate지났는데 p_end가 N인
      // 데이터의 p_code값 list로 받아오기
      dao.updateTimeout(list); // 위에서 받아온 p_code에 해당하는 p_end를 Y로 update
      BidDAO biddao = BidDAO.getInstance();
      biddao.updateTimeout(list); // bid 테이블의 bid_success를 Y로 update
      ///////////////////////////////////////////////////////////////////

      return "/categorySearch/categorySearchForm.jsp";
   }
}