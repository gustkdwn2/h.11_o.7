package project01.action;

import java.sql.Timestamp;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import project01.members.*;

public class InsertProAction implements CommandAction{

   @Override
   public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
      request.setCharacterEncoding("utf-8");
      MembersVO vo = new MembersVO();
      String id = request.getParameter("m_id");
      String name = request.getParameter("m_name");
      
      String phone = (String)request.getParameter("phone1")
                +(String)request.getParameter("phone2")
                +(String)request.getParameter("phone3");
   
      String email = (String)request.getParameter("email");
      
      String address = (String)request.getParameter("address")
              +(String)request.getParameter("address1");
      
      	vo.setM_id(request.getParameter("m_id"));
        vo.setM_name(request.getParameter("m_name"));
        vo.setM_password(request.getParameter("m_password"));
        vo.setPhone(phone);
        vo.setEmail(email);
        vo.setAddress(address);
        vo.setGender(request.getParameter("gender"));
        vo.setJumin(Integer.parseInt(request.getParameter("jumin")));
        vo.setReg_date(new Timestamp(System.currentTimeMillis()));

       MembersDAO dao = MembersDAO.getInstance();
       dao.insert(vo);
       
       request.setAttribute("name", name);
       request.setAttribute("id", id);
       
      return "/register/insertPro.jsp";
   }
   
}