package project01.members;

import java.sql.Timestamp;

public class MembersVO {
   private String m_id, m_name, m_password, phone, email, address, gender;
   private int jumin;
   private Timestamp reg_date;

   public String getM_id() {
      return m_id;
   }

   public void setM_id(String m_id) {
      this.m_id = m_id;
   }

   public String getM_name() {
      return m_name;
   }

   public void setM_name(String m_name) {
      this.m_name = m_name;
   }

   public String getM_password() {
      return m_password;
   }

   public void setM_password(String m_password) {
      this.m_password = m_password;
   }

   public String getPhone() {
      return phone;
   }

   public void setPhone(String phone) {
      this.phone = phone;
   }

   public String getEmail() {
      return email;
   }

   public void setEmail(String email) {
      this.email = email;
   }

   public String getAddress() {
      return address;
   }

   public void setAddress(String address) {
      this.address = address;
   }

   public String getGender() {
      return gender;
   }

   public void setGender(String gender) {
      this.gender = gender;
   }

   public int getJumin() {
      return jumin;
   }

   public void setJumin(int jumin) {
      this.jumin = jumin;
   }

   public Timestamp getReg_date() {
      return reg_date;
   }

   public void setReg_date(Timestamp reg_date) {
      this.reg_date = reg_date;
   }

}