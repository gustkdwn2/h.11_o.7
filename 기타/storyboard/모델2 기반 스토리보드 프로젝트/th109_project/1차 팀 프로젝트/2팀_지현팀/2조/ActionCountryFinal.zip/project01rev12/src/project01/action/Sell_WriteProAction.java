package project01.action;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Enumeration;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import project01.products.ProductsDAO;
import project01.products.ProductsVO;

public class Sell_WriteProAction implements CommandAction {

   // 상품등록 메뉴 클릭 후
   @Override
   public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
      request.setCharacterEncoding("utf-8");      
      
      HttpSession session = request.getSession();
      
      String realFolder="";
      String saveFolder="upload";
      int maxSize = 1024 * 1024 * 5; // 5MB
      String encType = "utf-8";
      String fileName="null";
      String orgFileName="null";
      
      ServletContext context = request.getSession().getServletContext(); // context에 웹 컨테이너가 들어감
      realFolder = request.getRealPath(saveFolder);
      
      try{
               MultipartRequest multi=null;
               multi = new MultipartRequest(
               request,    //request 객체
               realFolder, //파일이 저장될 폴더 경로
               maxSize,  //업로드할 파일의 최대 크기
               encType, // 인코딩 타입
               new DefaultFileRenamePolicy() 
               //동일한 파일명이 업로드 되는 경우 덮어쓰기 방지
            );
         Enumeration files = multi.getFileNames();
         int zoom = 5;
         
         while(files.hasMoreElements()){
            String name = (String)files.nextElement();
            fileName = multi.getFilesystemName(name);
            orgFileName = realFolder+"\\"+fileName; 
         }//while end
         
      System.out.println("fileName : " + fileName);
      System.out.println("orgFileName : " + orgFileName);

      ProductsVO vo = new ProductsVO();
      ProductsDAO dao = ProductsDAO.getInstance();
      
      vo.setCategory1(multi.getParameter("category1"));
      vo.setCategory2(multi.getParameter("category2"));
      vo.setContent(multi.getParameter("content").replace("\r\n","<br>"));
      vo.setP_img(fileName);
      vo.setP_name(multi.getParameter("p_name"));
      vo.setPrice_immediate(Integer.parseInt(multi.getParameter("price_immediate")));
      vo.setPrice_start(Integer.parseInt(multi.getParameter("price_start")));
      vo.setP_id((String)session.getAttribute("id"));
      vo.setP_code("");
      vo.setPrice_bid(Integer.parseInt(multi.getParameter("price_start"))); // 현재 입찰가격은 시작가격과 같아야 함
      vo.setBid_count(0);
      
      Calendar dateCal = Calendar.getInstance();
      dateCal.setTime(new Timestamp(System.currentTimeMillis()));
      dateCal.add(Calendar.DATE, +Integer.parseInt(multi.getParameter("due_date")));

      
      vo.setReg_date(new Timestamp(System.currentTimeMillis()));
      vo.setDue_date(dao.countTime(Integer.parseInt(multi.getParameter("due_date"))));
      dao.insert(vo);
      //DB에 입력 작업을 함
      }catch(Exception e){
         e.printStackTrace();
      }
      return "/sell/sell_writePro.jsp";
   }
}