package project01.products;

import java.sql.Timestamp;

public class ProductsVO {
	private String p_code, p_name, category1, category2, content, p_id, p_img, p_end;
	private int price_start, price_immediate, price_bid, bid_count;
	private Timestamp due_date, reg_date;
	public String getP_code() {
		return p_code;
	}
	public void setP_code(String p_code) {
		this.p_code = p_code;
	}
	public String getP_name() {
		return p_name;
	}
	public void setP_name(String p_name) {
		this.p_name = p_name;
	}
	public String getCategory1() {
		return category1;
	}
	public void setCategory1(String category1) {
		this.category1 = category1;
	}
	public String getCategory2() {
		return category2;
	}
	public void setCategory2(String category2) {
		this.category2 = category2;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getP_id() {
		return p_id;
	}
	public void setP_id(String p_id) {
		this.p_id = p_id;
	}
	public String getP_img() {
		return p_img;
	}
	public void setP_img(String p_img) {
		this.p_img = p_img;
	}
	public int getPrice_start() {
		return price_start;
	}
	public void setPrice_start(int price_start) {
		this.price_start = price_start;
	}
	public int getPrice_immediate() {
		return price_immediate;
	}
	public void setPrice_immediate(int price_immediate) {
		this.price_immediate = price_immediate;
	}
	public int getPrice_bid() {
		return price_bid;
	}
	public void setPrice_bid(int price_bid) {
		this.price_bid = price_bid;
	}
	public int getBid_count() {
		return bid_count;
	}
	public void setBid_count(int bid_count) {
		this.bid_count = bid_count;
	}
	public Timestamp getDue_date() {
		return due_date;
	}
	public void setDue_date(Timestamp due_date) {
		this.due_date = due_date;
	}
	public Timestamp getReg_date() {
		return reg_date;
	}
	public void setReg_date(Timestamp reg_date) {
		this.reg_date = reg_date;
	}
	public String getP_end(){
		return p_end;
	}
	public void setP_end(String p_end){
		this.p_end = p_end;
	}
}