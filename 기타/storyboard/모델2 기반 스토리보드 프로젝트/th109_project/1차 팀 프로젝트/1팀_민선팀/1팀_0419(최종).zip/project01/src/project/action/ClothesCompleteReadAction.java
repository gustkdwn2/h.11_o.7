package project.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import project.model.Clothes_CompleteVO;
import project.model.ProjectDAO;

public class ClothesCompleteReadAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("UTF-8");
		int cl_num = Integer.parseInt(request.getParameter("cl_num"));
		
		
		try{
			ProjectDAO dao = ProjectDAO.getInstance();
			Clothes_CompleteVO vo = dao.getDataDetail_ClothesComplete(cl_num);
			
			request.setAttribute("vo", vo);
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return "/clothesView/ClothesViewWriteRead.jsp";
	}

}
