package codyHelp.action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import project.action.CommandAction;
import project.model.ProjectDAO;


public class CodyHelpListAction implements CommandAction {

	 @Override
	   public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
	      request.setCharacterEncoding("utf-8");  //인코딩

	   
	      
	      
	      int pageSize = 10;      // 글 최대 개수
	      
	      
	      
	      
	      String pageNum = request.getParameter("pageNum"); 

	      if(pageNum == null){
	         pageNum = "1";
	      }// if

	      int currentPage = Integer.parseInt(pageNum);      // ���� ������
	      int startRow = (currentPage * pageSize) - 9;      // ex) (1*10)-9 = 1 - start
	      int endRow = (currentPage * pageSize);            // ex) (1*10) = 10 - end

	      //  ��ü ���ڵ� �� , 
	      int count = 0;
	      System.out.println("count =" +count);
	      // ���ڵ带 �޾ƿ� List
	      List list = null;
	      List profileList = null;
	      ProjectDAO dao = ProjectDAO.getInstance();
	      count = dao.getListAllCount_CodyHelpImage();
	      System.out.println("count2 =" +count);
	      String select = request.getParameter("CodyHelp_select_list");
	      System.out.println("select ="+select);
	      if(count >0 ){
	         list = dao.codiHelpList(startRow, endRow, select);
	      }

	      if(list != null){
	         profileList = dao.helpProfileImageList(list);
	      }else
	         profileList = null;

	        // navigation text break -> update plz 글자깨짐현상 고칠것

	      String navigation = null;
	      if(select.equals("1")){
	         navigation="최신순";
	      }else if(select.equals("2")){
	         navigation="좋아요";
	      }
	      
	      request.setAttribute("navigation", navigation);
	      

	      request.setAttribute("pageSize", pageSize);
	      request.setAttribute("pageNum", pageNum);
	      request.setAttribute("currentPage", currentPage);
	      request.setAttribute("startRow", startRow);
	      request.setAttribute("endRow", endRow);
	      request.setAttribute("count", count);
	      request.setAttribute("list", list);
	      request.setAttribute("profileList", profileList);
	      request.setAttribute("CodyHelp_select_list", select);


		return "/codyHelp/codyHelpList.jsp";
	}

}
