package project.action;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ClothesViewWriteFormAction extends HttpServlet implements CommandAction {

	@Override
	public String process(HttpServletRequest request, 
			HttpServletResponse response) throws Exception {

		
		return "/clothesView/ClothesViewWriteForm.jsp";
	}

}
