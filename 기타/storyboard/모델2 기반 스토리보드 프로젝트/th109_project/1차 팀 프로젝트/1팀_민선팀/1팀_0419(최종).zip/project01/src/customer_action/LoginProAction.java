package customer_action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import project.action.CommandAction;
import project.model.ProjectDAO;

public class LoginProAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		ProjectDAO dao = ProjectDAO.getInstance();
		
		int check = dao.login_Check(request.getParameter("m_id"), request.getParameter("m_passwd"));
		
		
		request.setAttribute("check", new Integer(check));
		request.setAttribute("m_id", request.getParameter("m_id"));
		
		
		return "/board/loginPro.jsp";
	}

}
