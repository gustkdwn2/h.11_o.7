package project.mypage;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import project.action.CommandAction;
import project.model.ProjectDAO;

public class FollowForm_BookmarkFormAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("UTF-8");
		HttpSession session = request.getSession();
		
		List list = null;
		List profileList = null;
		
		// 현재 로그인 중인 id
		String my_id = (String)session.getAttribute("m_id");
		
		ProjectDAO dao = ProjectDAO.getInstance();
		list = dao.getBookmark(my_id);
		
		if(list != null){
			profileList = dao.profileImageList_Bookmark(list);
		}else
			profileList = null;
		
		request.setAttribute("list", list);
		request.setAttribute("profileList", profileList);
		request.setAttribute("count", list.size());
	
		
		
		return "/mypage/followForm_BookmarkForm.jsp";
	}

}
