package codyHelp.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import project.action.CommandAction;



public class CodyHelpWriteFormAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		int num=0, ref=1, re_step=0, re_level=0;
		HttpSession session =request.getSession();
		String m_id= (String)session.getAttribute("m_id"); //아이디 없이접근금지
		
		System.out.println("m_id=" +m_id);
		request.setAttribute("num", num);
		request.setAttribute("ref", ref);
		request.setAttribute("re_step", re_step);
		request.setAttribute("re_level", re_level);
		request.setAttribute("m_id", m_id);
		
		return "/codyHelp/codyHelpWriteForm.jsp";
		
		
	}

}
