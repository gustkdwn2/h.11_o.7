package project.action;

import java.sql.Timestamp;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import project.model.DealVO;
import project.model.ProjectDAO;
import project.model.Wish_ListVO;

public class ClothesDealProAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("UTF-8");
		HttpSession session = request.getSession();
		////deal 테이블 ////
		DealVO vo = new DealVO();
		/*내가 교환하고싶은 옷 주인 아이디*/
		vo.setSeller_id("your_id");
		/*내가 교환하고싶은 옷의 번호*/
		vo.setSeller_cl_num(0);
		vo.setBuyer_id((String)session.getAttribute("m_id"));
		vo.setBuyer_cl_num(Integer.parseInt(request.getParameter("buyer_cl_num")));
		vo.setCount(1);
		ProjectDAO dao = new ProjectDAO();
		dao.insert(vo);
		////wish_list 테이블 (4.12 am12 예람 수정한부분)////
		//로그인한 사람이 고른 옷 넘버.
		Wish_ListVO vo2 = new Wish_ListVO();
		vo2.setSeller_cl_num(Integer.parseInt(request.getParameter("seller_cl_num")));
		vo2.setBuyer_id((String)session.getAttribute("m_id"));
		vo2.setReg_date(new Timestamp(System.currentTimeMillis()));
		vo2.setBuyer_cl_num(Integer.parseInt(request.getParameter("buyer_cl_num")));
		Wish_ListVO tempVO = null;
		tempVO = dao.getBuyerData(Integer.parseInt(request.getParameter("buyer_cl_num"))); 
		//System.out.println("buyer_cl_num: "+request.getParameter("buyer_cl_num"));
		vo2.setB_image(tempVO.getB_image());
		vo2.setB_title(tempVO.getB_title());
		
		System.out.println(request.getParameter("seller_cl_num"));
		
		dao.insert(vo2);
		//////////////////////////////////

		return "/clothesView/ClothesDealPro.jsp";
	}//prcess end
}//ClothesDealProAction end
