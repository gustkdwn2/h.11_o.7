package project.model;

public class Clothes_CompleteVO {
	
	private int cl_num;
	private String cl_id;
	private String cl_image1;
	private String cl_image2;
	private String cl_image3;
	private String cl_title;
	private String cl_content;
	private String cl_condition;
	private String cl_size;
	private String cl_type;
	private String cl_area;
	private String cl_gender;
	private int cl_price;
	private String cl_hope;
	private String cl_deal;
	private int cl_favorite;
	
	public int getCl_favorite() {
		return cl_favorite;
	}
	public void setCl_favorite(int cl_favorite) {
		this.cl_favorite = cl_favorite;
	}
	public int getCl_num() {
		return cl_num;
	}
	public void setCl_num(int cl_num) {
		this.cl_num = cl_num;
	}
	public String getCl_id() {
		return cl_id;
	}
	public void setCl_id(String cl_id) {
		this.cl_id = cl_id;
	}
	public String getCl_image1() {
		return cl_image1;
	}
	public void setCl_image1(String cl_image1) {
		this.cl_image1 = cl_image1;
	}
	public String getCl_image2() {
		return cl_image2;
	}
	public void setCl_image2(String cl_image2) {
		this.cl_image2 = cl_image2;
	}
	public String getCl_image3() {
		return cl_image3;
	}
	public void setCl_image3(String cl_image3) {
		this.cl_image3 = cl_image3;
	}
	public String getCl_title() {
		return cl_title;
	}
	public void setCl_title(String cl_title) {
		this.cl_title = cl_title;
	}
	public String getCl_content() {
		return cl_content;
	}
	public void setCl_content(String cl_content) {
		this.cl_content = cl_content;
	}
	public String getCl_condition() {
		return cl_condition;
	}
	public void setCl_condition(String cl_condition) {
		this.cl_condition = cl_condition;
	}
	public String getCl_size() {
		return cl_size;
	}
	public void setCl_size(String cl_size) {
		this.cl_size = cl_size;
	}
	public String getCl_type() {
		return cl_type;
	}
	public void setCl_type(String cl_type) {
		this.cl_type = cl_type;
	}
	public String getCl_area() {
		return cl_area;
	}
	public void setCl_area(String cl_area) {
		this.cl_area = cl_area;
	}
	public String getCl_gender() {
		return cl_gender;
	}
	public void setCl_gender(String cl_gender) {
		this.cl_gender = cl_gender;
	}
	public int getCl_price() {
		return cl_price;
	}
	public void setCl_price(int cl_price) {
		this.cl_price = cl_price;
	}
	public String getCl_hope() {
		return cl_hope;
	}
	public void setCl_hope(String cl_hope) {
		this.cl_hope = cl_hope;
	}
	public String getCl_deal() {
		return cl_deal;
	}
	public void setCl_deal(String cl_deal) {
		this.cl_deal = cl_deal;
	}
	
}//ClothesVO end
