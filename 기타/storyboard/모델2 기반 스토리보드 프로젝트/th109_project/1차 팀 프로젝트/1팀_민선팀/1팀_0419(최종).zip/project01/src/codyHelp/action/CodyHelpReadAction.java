package codyHelp.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import project.action.CommandAction;
import project.model.Board_CoordiVO;
import project.model.ProjectDAO;

public class CodyHelpReadAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		HttpSession session = request.getSession();
		String m_id = (String) session.getAttribute("m_id");
		//getAttribute는 속성값을 받아오므로 잘못쓰면 null만 생겨요
		
		request.setCharacterEncoding("UTF-8");
		int num = Integer.parseInt(request.getParameter("num"));
		
		Board_CoordiVO actionobj = new Board_CoordiVO();
		actionobj.setId(m_id);
		actionobj.setNum(num);
		
		ProjectDAO dao =new ProjectDAO();
		
		try{
			Board_CoordiVO vo = dao.getDataDetail_Coordi(num);
			int count = dao.getFavoriteCount(actionobj);
			
			request.setAttribute("count", count);
			request.setAttribute("vo", vo);
		}catch(Exception e){
			e.printStackTrace();
		}
		
		
		
		
		
		return "/codyHelp/codyHelpRead.jsp";
	}

}
