select * from member
select * from member_profile
select * from clothes

select * from BOARD_COORDI_FAVORITE

delete from clothes

select * from BOARD_declare

select * from clothes;
select * from member;

SELECT NUM, id, title, content, REG_DATE, readcount,  ref, re_step, re_level  ,R 
 FROM(SELECT NUM, id, title, content, REG_DATE, readcount, ref, re_step, re_level  ,ROWNUM R 
 FROM(SELECT NUM, id, title, content, REG_DATE, readcount, ref, re_step, re_level  
 FROM board_declare ORDER BY num desc, REF DESC, RE_STEP ASC) ORDER BY REF DESC, RE_LEVEL ASC) WHERE R>=1 AND R<=5 order by R







select * from member_profile where p_id = 'g'

delete from BOARD_declare;

drop table clothes

delete from MEMBER
delete from MEMBER_PROFILE

insert into member(m_id, m_passwd, m_name, m_tel, m_addr) values('a', 'a', 'a', 'a', 'a');

select m_passwd from member where m_id='a';

delete from member where m_id='3'

delete from CLOTHES

select * from user_sequences

select last_number 
from user_sequences 
where sequence_name=upper('clothes_cl_num');

ALTER SEQUENCE CLOTHES_CL_NUM INCREMENT BY 1;

ALTER SEQUENCE CLOTHES_CL_NUM INCREMENT BY -8;
----------------------------------------------------------------------------------------------
-- �ʵѷ�����
select * from CLOTHES

insert into CLOTHES(cl_num, cl_id, cl_image1, cl_title, cl_content, cl_condition, cl_size, cl_type, cl_area, cl_gender, cl_price, cl_deal) 
values(clothes_cl_num.nextval,'a', '/project01/upload/23.jpeg', '�����Դϴ�', '�����̿�', '���ƿ�', '��', '����', '������', '��', 1, '��!');

insert into CLOTHES(cl_num, cl_id, cl_image1, cl_title, cl_content, cl_condition, cl_size, cl_type, cl_area, cl_gender, cl_price, cl_deal, cl_favorite) 
values(clothes_cl_num.nextval,'a', '/project01/upload/22.jpeg', '���ƿ�15', '�����̿�', '���ƿ�', '��', '����', '������', '��', 1, '��!', 15);


insert into CLOTHES(cl_num, cl_id, cl_image1, cl_title, cl_content, cl_condition, cl_size, cl_type, cl_area, cl_gender, cl_price, cl_deal) 
values(clothes_cl_num.nextval,'a', '/project01/upload/23.jpeg', '�����Դϴ�', '�����̿�', '���ƿ�', '��', 'ġ��', '���', '����', 1, '��!');
insert into CLOTHES(cl_num, cl_id, cl_image1, cl_title, cl_content, cl_condition, cl_size, cl_type, cl_area, cl_gender, cl_price, cl_deal) 
values(clothes_cl_num.nextval,'a', '/project01/upload/23.jpeg', '�����Դϴ�', '�����̿�', '���ƿ�', '��', 'ġ��', '���', '����', 1, '��!');insert into CLOTHES(cl_num, cl_id, cl_image1, cl_title, cl_content, cl_condition, cl_size, cl_type, cl_area, cl_gender, cl_price, cl_deal) 

insert into CLOTHES(cl_num, cl_id, cl_image1, cl_title, cl_content, cl_condition, cl_size, cl_type, cl_area, cl_gender, cl_price, cl_deal) 
values(clothes_cl_num.nextval,'a', '/project01/upload/23.jpeg', '�����Դϴ�', '�����̿�', '���ƿ�', '��', '�Ź�', '�泲', '����', 1, '��!');



select * from clothes order by cl_num desc

select * from (select * from clothes order by cl_num desc) where rownum >=1 and rownum <= 10
select * from (select * from clothes order by cl_num desc) where rownum <= 10
select * from (select * from clothes order by cl_num desc) where rownum >=11 and rownum <= 20

select * from clothes where rownum >=1 and rownum <=10 order by cl_num desc

select * from clothes order by favorite desc, cl_num desc



select B.*
from (select C.*, rownum R
from (select * from CLOTHES order by cl_num desc) C
where rownum <= 10) B
where R > 0;


select B.*
from (select C.*, rownum R
from (select * from CLOTHES order by cl_num desc) C
where rownum <= 20) B
where R > 10;

select B.*
from (select C.*, rownum R
from (select * from CLOTHES order by cl_num desc) C
where rownum <= 30) B
where R > 20;

select * from clothes
select * from member_profile


update MEMBER_PROFILE set p_image='/project01/upload/low_.png' where p_id='a'

update clothes set cl_image1='/project01/upload/23.jpeg' where cl_id='a'

update clothes set favorite=10 where cl_num=11;

update clothes set cl_type='��ĿƮ' where cl_type='ġ��';

select m.p_image
from clothes c, MEMBER_PROFILE m
where c.cl_id = m.p_id and c.cl_id = 'a';

select m.p_image from clothes c, MEMBER_PROFILE m where c.cl_id = m.p_id and c.cl_id = ?;

select m.* from clothes c, MEMBER_PROFILE m where c.cl_id = m.p_id and c.cl_id ='a' and c.cl_num = 6

select m.* from clothes c, MEMBER_PROFILE m where c.cl_id = m.p_id and c.cl_num = 6



select * from CLOTHES where cl_gender='����' or cl_gender='����'

select * from CLOTHES where  cl_gender = '����' or cl_gender = '����' or cl_gender = '����'

select count(*) from CLOTHES where  cl_gender = '����' or cl_gender = '����' or cl_gender = '����'

select m.* from clothes c, MEMBER_PROFILE m where c.cl_id = m.p_id and c.cl_num = '6'



select B.* from (select C.*, rownum R from (select * from CLOTHES where cl_gender='����' order by cl_num desc) C where rownum <= 10) B where R >= 1;

select * from CLOTHES where cl_gender='����' order by cl_num desc

select C.*, rownum R from (select * from CLOTHES where cl_gender='����' order by cl_num desc) C where rownum <= 10




select * from clothes where cl_title like '%���%'






insert into CLOTHES(cl_num, cl_id, cl_image1, cl_title, cl_content, cl_condition, cl_size, cl_type, cl_area, cl_gender, cl_price, cl_deal) 
values(clothes_cl_num.nextval, 'aaaaa', '/project01/upload/3.jpeg', '�����Ⱦƿ�', '������������', '�ֻ�', 'Free', '��Ʈ', '����', '����', 20000, '���ŷ�');

insert into CLOTHES(cl_num, cl_id, cl_image1, cl_title, cl_content, cl_condition, cl_size, cl_type, cl_area, cl_gender, cl_price, cl_deal) 
values(clothes_cl_num.nextval, 'aaaaa', '/project01/upload/21.jpeg', '�����Ⱦƿ�', '������������', '�ֻ�', 'Free', '��Ʈ', '����', '����', 20000, '���ŷ�');

insert into CLOTHES(cl_num, cl_id, cl_image1, cl_title, cl_content, cl_condition, cl_size, cl_type, cl_area, cl_gender, cl_price, cl_deal) 
values(clothes_cl_num.nextval, 'aaaaa', '/project01/upload/3.jpeg', '�����Ⱦƿ�', '������������', '�ֻ�', 'Free', '��Ʈ', '����', '����', 20000, '���ŷ�');

insert into CLOTHES(cl_num, cl_id, cl_image1, cl_title, cl_content, cl_condition, cl_size, cl_type, cl_area, cl_gender, cl_price, cl_deal) 
values(clothes_cl_num.nextval, 'aaaaa', '/project01/upload/3.jpeg', '�����Ⱦƿ�', '������������', '�ֻ�', 'Free', '��Ʈ', '����', '����', 20000, '���ŷ�');

insert into CLOTHES(cl_num, cl_id, cl_image1, cl_title, cl_content, cl_condition, cl_size, cl_type, cl_area, cl_gender, cl_price, cl_deal) 
values(clothes_cl_num.nextval, 'aaaaa', '/project01/upload/3.jpeg', '�����Ⱦƿ�', '������������', '�ֻ�', 'Free', '��Ʈ', '����', '����', 20000, '���ŷ�');

insert into CLOTHES(cl_num, cl_id, cl_image1, cl_title, cl_content, cl_condition, cl_size, cl_type, cl_area, cl_gender, cl_price, cl_deal) 
values(clothes_cl_num.nextval, 'aaaaa', '/project01/upload/3.jpeg', '�����Ⱦƿ�', '������������', '�ֻ�', 'Free', '��Ʈ', '����', '����', 20000, '���ŷ�');

insert into CLOTHES(cl_num, cl_id, cl_image1, cl_title, cl_content, cl_condition, cl_size, cl_type, cl_area, cl_gender, cl_price, cl_deal) 
values(clothes_cl_num.nextval, 'aaaaa', '/project01/upload/3.jpeg', '�����Ⱦƿ�', '������������', '�ֻ�', 'Free', '��Ʈ', '����', '����', 20000, '���ŷ�');

insert into CLOTHES(cl_num, cl_id, cl_image1, cl_title, cl_content, cl_condition, cl_size, cl_type, cl_area, cl_gender, cl_price, cl_deal) 
values(clothes_cl_num.nextval, 'aaaaa', '/project01/upload/3.jpeg', '�����Ⱦƿ�', '������������', '�ֻ�', 'Free', '��Ʈ', '����', '����', 20000, '���ŷ�');

insert into CLOTHES(cl_num, cl_id, cl_image1, cl_title, cl_content, cl_condition, cl_size, cl_type, cl_area, cl_gender, cl_price, cl_deal) 
values(clothes_cl_num.nextval, 'aaaaa', '/project01/upload/3.jpeg', '�����Ⱦƿ�', '������������', '�ֻ�', 'Free', '��Ʈ', '����', '����', 20000, '���ŷ�');

insert into CLOTHES(cl_num, cl_id, cl_image1, cl_title, cl_content, cl_condition, cl_size, cl_type, cl_area, cl_gender, cl_price, cl_deal) 
values(clothes_cl_num.nextval, 'aaaaa', '/project01/upload/3.jpeg', '�����Ⱦƿ�', '������������', '�ֻ�', 'Free', '��Ʈ', '����', '����', 20000, '���ŷ�');

insert into CLOTHES(cl_num, cl_id, cl_image1, cl_title, cl_content, cl_condition, cl_size, cl_type, cl_area, cl_gender, cl_price, cl_deal) 
values(clothes_cl_num.nextval, 'aaaaa', '/project01/upload/3.jpeg', '�����Ⱦƿ�', '������������', '�ֻ�', 'Free', '��Ʈ', '����', '����', 20000, '���ŷ�');

insert into CLOTHES(cl_num, cl_id, cl_image1, cl_title, cl_content, cl_condition, cl_size, cl_type, cl_area, cl_gender, cl_price, cl_deal) 
values(clothes_cl_num.nextval, 'aaaaa', '/project01/upload/3.jpeg', '�����Ⱦƿ�', '������������', '�ֻ�', 'Free', '��Ʈ', '����', '����', 20000, '���ŷ�');

insert into CLOTHES(cl_num, cl_id, cl_image1, cl_title, cl_content, cl_condition, cl_size, cl_type, cl_area, cl_gender, cl_price, cl_deal) 
values(clothes_cl_num.nextval, 'aaaaa', '/project01/upload/3.jpeg', '�����Ⱦƿ�', '������������', '�ֻ�', 'Free', '��Ʈ', '����', '����', 20000, '���ŷ�');

insert into CLOTHES(cl_num, cl_id, cl_image1, cl_title, cl_content, cl_condition, cl_size, cl_type, cl_area, cl_gender, cl_price, cl_deal) 
values(clothes_cl_num.nextval, 'aaaaa', '/project01/upload/3.jpeg', '�����Ⱦƿ�', '������������', '�ֻ�', 'Free', '��Ʈ', '����', '����', 20000, '���ŷ�');

insert into CLOTHES(cl_num, cl_id, cl_image1, cl_title, cl_content, cl_condition, cl_size, cl_type, cl_area, cl_gender, cl_price, cl_deal) 
values(clothes_cl_num.nextval, 'aaaaa', '/project01/upload/3.jpeg', '�����Ⱦƿ�', '������������', '�ֻ�', 'Free', '��Ʈ', '����', '����', 20000, '���ŷ�');

insert into CLOTHES(cl_num, cl_id, cl_image1, cl_title, cl_content, cl_condition, cl_size, cl_type, cl_area, cl_gender, cl_price, cl_deal) 
values(clothes_cl_num.nextval, 'aaaaa', '/project01/upload/3.jpeg', '�����Ⱦƿ�', '������������', '�ֻ�', 'Free', '��Ʈ', '����', '����', 20000, '���ŷ�');



----
delete from board_free
insert into board_free values(board_free_num.nextval, 'a', '제목검색용가리', '내용', '2016/04/08', 0, 0,0,0,'');
insert into board_free values(board_free_num.nextval, 'bbb', '제목검색용가리', '내용', '2016/04/08', 0, 0,0,0,'');
insert into board_free values(board_free_num.nextval, 'abba', '제목검', '내용', '2016/04/08', 0, 0,0,0,'');
insert into board_free values(board_free_num.nextval, 'a', '제목검색용가리', '내용', '2016/04/08', 0, 0,0,0,'');
insert into board_free values(board_free_num.nextval, 'bbb', '제목검색용가리', '내용', '2016/04/08', 0, 0,0,0,'');
insert into board_free values(board_free_num.nextval, 'abba', '제목검', '내용', '2016/04/08', 0, 0,0,0,'');
insert into board_free values(board_free_num.nextval, 'a', '제목검색용가리', '내용', '2016/04/08', 0, 0,0,0,'');
insert into board_free values(board_free_num.nextval, 'bbb', '제목검색용가리', '내용', '2016/04/08', 0, 0,0,0,'');
insert into board_free values(board_free_num.nextval, 'abba', '제목검', '내용', '2016/04/08', 0, 0,0,0,'');
insert into board_free values(board_free_num.nextval, 'a', '제목검색용가리', '내용', '2016/04/08', 0, 0,0,0,'');
insert into board_free values(board_free_num.nextval, 'bbb', '제목검색용가리', '내용', '2016/04/08', 0, 0,0,0,'');
insert into board_free values(board_free_num.nextval, 'abba', '제목검', '내용', '2016/04/08', 0, 0,0,0,'');
insert into board_free values(board_free_num.nextval, 'a', '제목검색용가리', '내용', '2016/04/08', 0, 0,0,0,'');
insert into board_free values(board_free_num.nextval, 'bbb', '제목검색용가리', '내용', '2016/04/08', 0, 0,0,0,'');
insert into board_free values(board_free_num.nextval, 'abba', '제목검', '내용', '2016/04/08', 0, 0,0,0,'');
insert into board_free values(board_free_num.nextval, 'a', '제목검색용가리', '내용', '2016/04/08', 0, 0,0,0,'');
insert into board_free values(board_free_num.nextval, 'bbb', '제목검색용가리', '내용', '2016/04/08', 0, 0,0,0,'');
insert into board_free values(board_free_num.nextval, 'abba', '제목검', '내용', '2016/04/08', 0, 0,0,0,'');
insert into board_free values(board_free_num.nextval, 'a', '제목검색용가리', '내용', '2016/04/08', 0, 0,0,0,'');
insert into board_free values(board_free_num.nextval, 'bbb', '제목검색용가리', '내용', '2016/04/08', 0, 0,0,0,'');
insert into board_free values(board_free_num.nextval, 'abba', '제목검', '내용', '2016/04/08', 0, 0,0,0,'');
insert into board_free values(board_free_num.nextval, 'abba', '제목검', '내용', '2016/04/08', 0, 0,0,0,'');
insert into board_free values(board_free_num.nextval, 'abba', '제목검', '내용', to_char(sysdate,'YYYY_mm_DD'), 0, 0,0,0,'');
select * from board_free where title like '%용%'

select * from board_free

select B.* from (select C.*, rownum R from (select * from board_free where title like '%용%' order by num desc) C where rownum <= 20) B where R >= 11



insert into board_buy values(board_buy_num.nextval, 'a', '제목검색용가리', '내용', '2016/04/08', 0, 0,0,0,'',0);
insert into board_buy values(board_buy_num.nextval, 'bbb', '제목검색용가리', '내용', '2016/04/08', 0, 0,0,0,'',0);
insert into board_buy values(board_buy_num.nextval, 'abba', '제목검', '내용', '2016/04/08', 0, 0,0,0,'',0);

select * from board_buy
select * from board_buy where title like '%용%'

select * from board_customer
insert into board_customer values(board_customer_num.nextval, 'a', '제목검색용가리', '내용', '2016/04/08', 0, 0,0,0);


delete from deal_complete
select * from deal_complete
select * from clothes


insert into deal_complete values(deal_complete_num.nextval, 'a', 'w', 56, '2016/04/12');
insert into deal_complete values(deal_complete_num.nextval, 'a', 'w', 51, '2016/04/12');
insert into deal_complete values(deal_complete_num.nextval, 'w', 'a', 64, '2016/04/12');
insert into deal_complete values(deal_complete_num.nextval, 'a', 'k', 51, '2016/04/12');

select B.* from (select a.*, rownum R from (select d.cl_num, d.seller_id, d.buyer_id, c.cl_title, d.reg_date from deal_complete d, clothes c where d.cl_num = c.cl_num and d.seller_id='a' and d.buyer_id='k' order by num desc) a where rownum <= 5) B where R >= 1

select B.* from (select C.*, rownum R from (select * from board_buy where id like ? order by num desc) C where rownum <= ?) B where R >= ?

select d.cl_num, d.seller_id, c.cl_title, d.reg_date from deal_complete d, clothes c where d.cl_num = c.cl_num and d.buyer_id='a';


select * from member


select * from clothes

select * from deal_complete

insert into deal_complete values(deal_complete_num.nextval, 'w', 'a', 62, 54, '2016/04/12');
insert into deal_complete values(deal_complete_num.nextval, 'w', 'a', 63, 53, '2016/04/12');
insert into deal_complete values(deal_complete_num.nextval, 'a', 'w', 62, 54, '2016/04/12');
insert into deal_complete values(deal_complete_num.nextval, 'a', 's', 63, 53, '2016/04/12');

select d.seller_id, d.seller_cl_num, c1.cl_title, d.buyer_id, d.buyer_cl_num, c2.cl_title, d.reg_date from deal_complete d, clothes c1, clothes c2 where d.seller_cl_num = c1.cl_num and d.buyer_cl_num = c2.cl_num and d.buyer_id='a' order by num desc
select B.* from (select a.*, rownum R from (select d.seller_id, d.seller_cl_num, c1.cl_title as seller_cl_title, d.buyer_id, d.buyer_cl_num, c2.cl_title as buyer_cl_title, d.reg_date from deal_complete d, clothes c1, clothes c2 where d.seller_cl_num = c1.cl_num and d.buyer_cl_num = c2.cl_num and d.buyer_id='a' order by num desc) a where rownum <= 5) B where R >= 1

select * from clothes_complete

insert into clothes_complete select * from clothes where cl_num = 49

select B.* from (select a.*, rownum R from (select d.seller_id, d.seller_cl_num, c1.cl_title as seller_cl_title, d.buyer_id, d.buyer_cl_num, c2.cl_title as buyer_cl_title, d.reg_date from deal_complete d, clothes c1, clothes c2 where d.seller_cl_num = c1.cl_num and d.buyer_cl_num = c2.cl_num and d.buyer_id='a' and d.seller_cl_num = 63 order by num desc) a where rownum <= 5) B where R >= 1


select count(*) from deal_complete d, clothes c1, clothes c2 where d.seller_cl_num = c1.cl_num and d.buyer_cl_num = c2.cl_num and d.buyer_id='a'

select B.* from (select a.*, rownum R from (select d.seller_id, d.seller_cl_num, c1.cl_title as seller_cl_title, d.buyer_id, d.buyer_cl_num, c2.cl_title as buyer_cl_title, d.reg_date from deal_complete d, clothes c1, clothes c2 where d.seller_cl_num = c1.cl_num and d.buyer_cl_num = c2.cl_num and d.seller_id='w' and d.buyer_id='%a%' order by num desc) a where rownum <= 5) B where R >= 1

select B.* from (select a.*, rownum R from (select d.seller_id, d.seller_cl_num, c1.cl_title as seller_cl_title, d.buyer_id, d.buyer_cl_num, c2.cl_title as buyer_cl_title, d.reg_date from deal_complete d, clothes c1, clothes c2 where d.seller_cl_num = c1.cl_num and d.buyer_cl_num = c2.cl_num and d.seller_id='w' and d.buyer_id like '%a%' order by num desc) a where rownum <= 5) B where R >= 1





select B.* from (select a.*, rownum R from (select d.seller_id, d.seller_cl_num, c1.cl_title as seller_cl_title, d.buyer_id, d.buyer_cl_num, c2.cl_title as buyer_cl_title, d.reg_date from deal_complete d, clothes c1, clothes c2 where d.seller_cl_num = c1.cl_num and d.buyer_cl_num = c2.cl_num and d.buyer_id='a' and c1.cl_title like '%ㄴ%' order by num desc) a where rownum <= 5) B where R >= 1


select B.* from (select a.*, rownum R from (select d.seller_id, d.seller_cl_num, c1.cl_title as seller_cl_title, d.buyer_id, d.buyer_cl_num, c2.cl_title as buyer_cl_title, d.reg_date from deal_complete d, clothes c1, clothes c2 where d.seller_cl_num = c1.cl_num and d.buyer_cl_num = c2.cl_num and d.buyer_id='a' and d.seller_cl_num = 62 order by num desc) a where rownum <= 5) B where R >= 1




select * from clothes_complete

insert into clothes_complete select * from clothes where cl_num = 53

delete from board_declare

drop table member;
drop table member_profile;
drop table board_buy;
drop table board_customer;
drop table board_declare;

select * from (select num, my_id, your_id, my_image, content, reg_date, rownum rnum from guest_book where your_id='aaaaaa' order by reg_date desc) where (rnum >=6 and rnum <= 10)
















select B.* from (select C.*, rownum R from (select num, my_id, your_id, my_image, content, reg_date, rownum rnum from guest_book where your_id='aaaaaa' order by reg_date desc) C where rownum <= 5) B where R >= 1;\


select * from (select cl_num, cl_image1, cl_title, cl_price, rownum rnum from clothes where cl_id=? where (rnum >=? and rnum <= ?)


select B.* from (select C.*, rownum R from (select cl_num, cl_image1, cl_title, cl_price, rownum rnum from clothes where cl_id='aaaaaa' order by cl_num desc) C where rownum <= 5) B where R >= 1



insert into CLOTHES(cl_num, cl_id, cl_image1, cl_title, cl_content, cl_condition, cl_size, cl_type, cl_area, cl_gender, cl_price, cl_deal) 
values(clothes_cl_num.nextval,'a', '/project01/upload/23.jpeg', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 1, 'a');
insert into CLOTHES(cl_num, cl_id, cl_image1, cl_title, cl_content, cl_condition, cl_size, cl_type, cl_area, cl_gender, cl_price, cl_deal) 
values(clothes_cl_num.nextval,'a', '/project01/upload/23.jpeg', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 1, 'a');
insert into CLOTHES(cl_num, cl_id, cl_image1, cl_title, cl_content, cl_condition, cl_size, cl_type, cl_area, cl_gender, cl_price, cl_deal) 
values(clothes_cl_num.nextval,'a', '/project01/upload/23.jpeg', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 1, 'a');
insert into CLOTHES(cl_num, cl_id, cl_image1, cl_title, cl_content, cl_condition, cl_size, cl_type, cl_area, cl_gender, cl_price, cl_deal) 
values(clothes_cl_num.nextval,'a', '/project01/upload/23.jpeg', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 1, 'a');
insert into CLOTHES(cl_num, cl_id, cl_image1, cl_title, cl_content, cl_condition, cl_size, cl_type, cl_area, cl_gender, cl_price, cl_deal) 
values(clothes_cl_num.nextval,'a', '/project01/upload/23.jpeg', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 1, 'a');
insert into CLOTHES(cl_num, cl_id, cl_image1, cl_title, cl_content, cl_condition, cl_size, cl_type, cl_area, cl_gender, cl_price, cl_deal) 
values(clothes_cl_num.nextval,'a', '/project01/upload/23.jpeg', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 1, 'a');
insert into CLOTHES(cl_num, cl_id, cl_image1, cl_title, cl_content, cl_condition, cl_size, cl_type, cl_area, cl_gender, cl_price, cl_deal) 
values(clothes_cl_num.nextval,'a', '/project01/upload/23.jpeg', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 1, 'a');
insert into CLOTHES(cl_num, cl_id, cl_image1, cl_title, cl_content, cl_condition, cl_size, cl_type, cl_area, cl_gender, cl_price, cl_deal) 
values(clothes_cl_num.nextval,'a', '/project01/upload/23.jpeg', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 1, 'a');
insert into CLOTHES(cl_num, cl_id, cl_image1, cl_title, cl_content, cl_condition, cl_size, cl_type, cl_area, cl_gender, cl_price, cl_deal) 
values(clothes_cl_num.nextval,'a', '/project01/upload/23.jpeg', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 1, 'a');




select * from DEAL_COMPLETE
select * from CLOTHES_COMPLETE
select B.* from (select a.*, rownum R from (select d.seller_id, d.seller_cl_num, c1.cl_title as seller_cl_title, d.buyer_id, d.buyer_cl_num, c2.cl_title as buyer_cl_title, d.reg_date from deal_complete d, CLOTHES_COMPLETE c1, CLOTHES_COMPLETE c2 where d.seller_cl_num = c1.cl_num and d.buyer_cl_num = c2.cl_num and d.seller_id='zzzzzz' order by num desc) a where rownum <= 5) B where R >= 1




select count(*) from deal_complete where seller_id='aaaaaa'
select count(*) from deal_complete where buyer_id='aaaaaa'

select * from deal_complete where seller_id='aaaaaa'
select * from deal_complete where buyer_id='aaaaaa'

delete from deal_complete

select * from deal_complete

select * from basket_num
