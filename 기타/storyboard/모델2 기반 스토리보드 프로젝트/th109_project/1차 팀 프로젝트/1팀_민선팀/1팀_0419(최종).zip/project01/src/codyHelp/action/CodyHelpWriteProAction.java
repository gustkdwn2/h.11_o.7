package codyHelp.action;

import java.net.URLEncoder;
import java.sql.Timestamp;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import project.action.CommandAction;
import project.model.Board_CoordiVO;
import project.model.ProjectDAO;

public class CodyHelpWriteProAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		HttpSession session =request.getSession();
		String m_id= (String)session.getAttribute("m_id"); //아이디 없이접근금지
		System.out.println("m_id=" +m_id);
		String realPath="";
		String savePath="upload";
		String encType="UTF-8";
		int maxSize=1024*1024*5;
		
		request.setCharacterEncoding("UTF-8"); //인코딩
		
		ServletContext context =request.getSession().getServletContext(); 
		//서블릿이 서블릿 컨테이너와 통신하기 위해서 사용되어지는 메서드들을 가지고 있는 클래스를 말합니다.
		realPath =context.getRealPath(savePath+"\\"); //저장될 장소를 가리키며 upload만들면된다
		MultipartRequest multi = new MultipartRequest(request, // request 객체
	            realPath, // 업로드 된 파일이 저장 될 파일폴더 경로
	            maxSize, // 업로드 할 파일의 최대 크기
	            "UTF-8", // 엔코딩 타입
	            new DefaultFileRenamePolicy()//파일 업로드 컴포넌트 입니다.
				);
		
		
		
		ProjectDAO dao =ProjectDAO.getInstance();
		Board_CoordiVO vo =new Board_CoordiVO();
	/*	int num=0, ref=1, re_step=0, re_level=0;*/
		vo.setNum(Integer.parseInt(multi.getParameter("num")));
		vo.setRef(Integer.parseInt(multi.getParameter("ref")));
		vo.setRe_step(Integer.parseInt(multi.getParameter("re_step")));
		vo.setRe_level(Integer.parseInt(multi.getParameter("re_level")));
		
		vo.setReg_date(new Timestamp(System.currentTimeMillis()));
		/*vo.setNum(Integer.parseInt(request.getParameter("num")));*/
		vo.setId(m_id);
		vo.setTitle(multi.getParameter("title"));
		vo.setContent(multi.getParameter("content"));
		vo.setImage1(multi.getParameter("image1"));
		vo.setImage2(multi.getParameter("image2"));
		vo.setImage3(multi.getParameter("image3"));
		
		
		String img1 = multi.getFilesystemName("image1");
		String img2 = multi.getFilesystemName("image2");
		String img3 = multi.getFilesystemName("image3");
		System.out.println("img1:"+img1);
		System.out.println("img2:"+img2);
		System.out.println("img3:"+img3);
		
		if( img1 != null ){
			String x = request.getContextPath() + "/" + savePath + "/" + URLEncoder.encode(img1, "UTF-8");
			vo.setImage1(x);
		}
		if( img2 != null ){
			String x = request.getContextPath() + "/" + savePath + "/" + URLEncoder.encode(img2, "UTF-8");
			vo.setImage2(x);
		}
		if( img3 != null ){
			String x = request.getContextPath() + "/" + savePath + "/" + URLEncoder.encode(img3, "UTF-8");
			vo.setImage3(x);
		}
		
		
		System.out.println("img1:"+img1);
		System.out.println("img2:"+img2);
		System.out.println("img3:"+img3);
		
		
		
		
		dao.insert(vo);  //이제 붙인값을 dao로 반환
		return "/codyHelp/codyHelpDeletePro.jsp";
	}

}
