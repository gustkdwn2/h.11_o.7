package project.model;

public class BookmarkVO {

	private int num;
	private String my_id;
	private String your_id;
	private int follow;
	
	public int getFollow() {
		return follow;
	}
	public void setFollow(int follow) {
		this.follow = follow;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getMy_id() {
		return my_id;
	}
	public void setMy_id(String my_id) {
		this.my_id = my_id;
	}
	public String getYour_id() {
		return your_id;
	}
	public void setYour_id(String your_id) {
		this.your_id = your_id;
	}
}//BookmarkVO end