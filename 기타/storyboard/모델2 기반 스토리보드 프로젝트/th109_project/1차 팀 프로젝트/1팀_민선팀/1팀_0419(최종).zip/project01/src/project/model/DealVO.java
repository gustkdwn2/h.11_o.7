package project.model;

public class DealVO {

	private int num;
	private String seller_id;
	private String buyer_id;
	private int seller_cl_num;
	private int buyer_cl_num;
	private int count;
	
	public int getSeller_cl_num() {
		return seller_cl_num;
	}
	public void setSeller_cl_num(int seller_cl_num) {
		this.seller_cl_num = seller_cl_num;
	}
	public int getBuyer_cl_num() {
		return buyer_cl_num;
	}
	public void setBuyer_cl_num(int buyer_cl_num) {
		this.buyer_cl_num = buyer_cl_num;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getSeller_id() {
		return seller_id;
	}
	public void setSeller_id(String seller_id) {
		this.seller_id = seller_id;
	}
	public String getBuyer_id() {
		return buyer_id;
	}
	public void setBuyer_id(String buyer_id) {
		this.buyer_id = buyer_id;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
}//DealVO end
