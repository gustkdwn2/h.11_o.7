package buy_action;

import java.sql.Timestamp;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import project.action.CommandAction;
import project.model.Board_BuyVO;
import project.model.ProjectDAO;

public class board_buy_WriteProAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		HttpSession session = request.getSession();
		request.setCharacterEncoding("UTF-8");
		
	
		
		String m_id = (String) session.getAttribute("m_id");
		session.getAttribute("m_id");
		
		Board_BuyVO vo =new Board_BuyVO();
	
		System.out.println("pro");
		
		vo.setNum(Integer.parseInt(request.getParameter("num")));
		vo.setId(request.getParameter("id"));
		vo.setTitle(request.getParameter("title"));
		vo.setContent(request.getParameter("content"));
		System.out.println("pro 4");
		
		vo.setReg_date(new Timestamp(System.currentTimeMillis()));
		
		vo.setRef(Integer.parseInt(request.getParameter("ref")));
		vo.setRe_level(Integer.parseInt(request.getParameter("re_level")));
		vo.setRe_step(Integer.parseInt(request.getParameter("re_step")));
		
		System.out.println(vo.getRef());
		System.out.println(vo.getRe_level());
		System.out.println(vo.getRe_step());
		
		//여기까진 됨
		
		ProjectDAO dao = ProjectDAO.getInstance();
		dao.insert(vo);
		
	//	response.sendRedirect("board_customerlist.do");
		return "/board_buy/board_buy_writePro.jsp";
	}

}
