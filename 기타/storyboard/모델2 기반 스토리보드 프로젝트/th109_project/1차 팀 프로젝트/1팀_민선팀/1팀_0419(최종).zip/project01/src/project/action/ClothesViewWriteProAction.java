package project.action;


import java.net.URLEncoder;
import java.sql.Timestamp;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.websocket.Session;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import project.model.ClothesVO;
import project.model.ProjectDAO;

public class ClothesViewWriteProAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, 
			HttpServletResponse response) throws Exception {
		
		String realPath = "";
		String savePath = "upload";
		String encType = "UTF-8";
		int maxSize = 1024 * 1024 * 5;

		ServletContext context = request.getSession().getServletContext();
		realPath = context.getRealPath(savePath + "\\");

		MultipartRequest multi = new MultipartRequest(request, // request ��ü
				realPath, // ���ε� �� ������ ���� �� �������� ���
				maxSize, // ���ε� �� ������ �ִ� ũ��
				"UTF-8", // ���ڵ� Ÿ��
				new DefaultFileRenamePolicy() // ���ε� �� ���ϸ��� ������ ���ϸ�� ���� ��� �����
												// ����
		);

		
		
		request.setCharacterEncoding("utf-8");
		ClothesVO vo = new ClothesVO();
		
		vo.setCl_id(multi.getParameter("cl_id"));

		String img1 = multi.getFilesystemName("cl_image1");
		String img2 = multi.getFilesystemName("cl_image2");
		String img3 = multi.getFilesystemName("cl_image3");
		if( img1 != null ){
			String x = request.getContextPath() + "/" + savePath + "/" + URLEncoder.encode(img1, "UTF-8");
			vo.setCl_image1(x);
		}
		if( img2 != null ){
			String x = request.getContextPath() + "/" + savePath + "/" + URLEncoder.encode(img2, "UTF-8");
			vo.setCl_image2(x);
		}
		if( img3 != null ){
			String x = request.getContextPath() + "/" + savePath + "/" + URLEncoder.encode(img3, "UTF-8");
			vo.setCl_image3(x);
		}
		
		vo.setCl_title(multi.getParameter("cl_title"));
		vo.setCl_content(multi.getParameter("cl_content"));
		vo.setCl_condition(multi.getParameter("cl_condition"));
		vo.setCl_size(multi.getParameter("cl_size"));
		vo.setCl_type(multi.getParameter("cl_type"));
		vo.setCl_area(multi.getParameter("cl_area"));
		vo.setCl_gender(multi.getParameter("cl_gender"));
		System.out.println(multi.getParameter("cl_gender"));
		vo.setCl_price(Integer.parseInt(multi.getParameter("cl_price")));
		vo.setCl_hope(multi.getParameter("cl_hope"));
		vo.setCl_deal(multi.getParameter("cl_deal"));
		
		ProjectDAO dao = ProjectDAO.getInstance();
		int cl_num = dao.insert(vo);
		
		request.setAttribute("cl_num", cl_num);
		
		return "/clothesView/ClothesViewWritePro.jsp";
	}

}
