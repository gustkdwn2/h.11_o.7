package project.action;

import java.net.URLEncoder;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import project.model.MemberVO;
import project.model.Member_ProfileVO;
import project.model.ProjectDAO;

public class CreateAccountProAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {

		String realPath = "";
		String savePath = "upload";
		String encType = "UTF-8";
		int maxSize = 1024 * 1024 * 5;

		ServletContext context = request.getSession().getServletContext();
		realPath = context.getRealPath(savePath + "\\");

		MultipartRequest multi = new MultipartRequest(request,
				realPath,
				maxSize,
				"UTF-8",
				new DefaultFileRenamePolicy()
		);

		request.setCharacterEncoding("UTF-8");
		ProjectDAO dao = ProjectDAO.getInstance();
		MemberVO member_vo = new MemberVO();
		Member_ProfileVO mp_vo = new Member_ProfileVO();

		// member insert
		member_vo.setM_id(multi.getParameter("m_id"));
		member_vo.setM_passwd(multi.getParameter("m_passwd"));
		member_vo.setM_name(multi.getParameter("m_name"));

		String m_tel = multi.getParameter("m_tel1") + multi.getParameter("m_tel2") + multi.getParameter("m_tel3");
		member_vo.setM_tel(m_tel);
		String m_email = multi.getParameter("m_email1") + "@" + multi.getParameter("m_email2");
		member_vo.setM_email(m_email);
		String m_addr = multi.getParameter("m_addr1") + " " + multi.getParameter("m_addr2");
		member_vo.setM_addr(m_addr);

		dao.insert(member_vo);
		// member_profile insert
		mp_vo.setP_id(multi.getParameter("m_id"));
		mp_vo.setP_height(multi.getParameter("p_height"));
		mp_vo.setP_weight(multi.getParameter("p_weight"));
		mp_vo.setP_self(multi.getParameter("p_self"));
		mp_vo.setP_area(multi.getParameter("p_area"));
		// ������ ���� ��� ����
		// mp_vo.setP_image(request.getParameter("p_image"));
		
		
		String y = multi.getFilesystemName("p_image");
		if( y != null ){
			String x = request.getContextPath() + "/" + savePath + "/" + URLEncoder.encode(y, "UTF-8");
			mp_vo.setP_image(x);
		}
		
		mp_vo.setP_message(multi.getParameter("p_message"));

		dao.insert(mp_vo);

		return "/view/createAccountPro.jsp";
	}// process

}
