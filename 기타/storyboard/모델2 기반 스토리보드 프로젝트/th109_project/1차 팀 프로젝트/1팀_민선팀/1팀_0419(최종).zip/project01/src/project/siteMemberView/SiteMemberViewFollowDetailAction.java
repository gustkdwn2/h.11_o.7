package project.siteMemberView;

import java.util.List;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import project.action.CommandAction;
import project.model.ProjectDAO; 

public class SiteMemberViewFollowDetailAction extends HttpServlet implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("utf-8");
		int count = 0;
		int count2 = 0;
		int start = 1;  // 게시물 글 갯수 스타트 값
		int end = 20;  // 게시물 글 갯수 엔드 값


		List list = null;
		List profileList = null;
		ProjectDAO dao = ProjectDAO.getInstance();
		count = dao.getListAllCount_MemberProfile();

		if(count >0 ){
			list = dao.siteMemberView_FollowRank(start, end);
		}


		if(list != null){
			profileList = dao.profileImageList_FollowRank(list);
		}else
			profileList = null;




		request.setAttribute("count", count);
		request.setAttribute("list", list);
		request.setAttribute("profileList", profileList);
		return "/siteMemberView/siteMemberViewFollowDetail.jsp";
	}

}
