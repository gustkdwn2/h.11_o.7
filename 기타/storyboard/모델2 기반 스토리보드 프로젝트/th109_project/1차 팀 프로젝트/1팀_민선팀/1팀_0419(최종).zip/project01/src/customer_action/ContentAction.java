package customer_action;

import java.text.SimpleDateFormat;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import project.action.CommandAction;
import project.model.Board_CustomerVO;
import project.model.ProjectDAO;

public class ContentAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		System.out.println("contentaction");
		int num = Integer.parseInt(request.getParameter("num"));
		
		String pageNum = request.getParameter("pageNum");
		System.out.println("contentaction2");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		
	
		ProjectDAO dao = ProjectDAO.getInstance();
		Board_CustomerVO vo = dao.getDataDetail(num); 
			
		int ref = vo.getRef();
		int re_step = vo.getRe_step();
		int re_level = vo.getRe_level();
			
			request.setAttribute("num", new Integer(num));
			request.setAttribute("pageNum", new Integer(pageNum));
			request.setAttribute("vo", vo);
			System.out.println("content 끝");
		
		
			return "/board/content.jsp";

}
}
