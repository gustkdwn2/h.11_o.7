package project.siteMemberView;

import java.util.List;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import project.action.CommandAction;
import project.model.ProjectDAO; 

public class SiteMemberViewDealDetailAction extends HttpServlet implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("utf-8");
		int count2 = 0;
		int start = 1;  // 게시물 글 갯수 스타트 값
		int end = 6;  // 게시물 글 갯수 엔드 값

		List list2 = null;
		List profileList2 = null;
		ProjectDAO dao2 = ProjectDAO.getInstance();
		count2 = dao2.getListAllCount_MemberProfile2();


		if(count2 >0 ){
			list2 = dao2.siteMemberView_DealRank(start, end);
		}

		if(list2 != null){
			profileList2 = dao2.profileImageList_DealRank(list2);
		}else
			profileList2 = null;

		request.setAttribute("count2", count2);  
		request.setAttribute("list2", list2);
		request.setAttribute("profileList2", profileList2);
		return "/siteMemberView/siteMemberViewDealDetail.jsp";
	}

}
