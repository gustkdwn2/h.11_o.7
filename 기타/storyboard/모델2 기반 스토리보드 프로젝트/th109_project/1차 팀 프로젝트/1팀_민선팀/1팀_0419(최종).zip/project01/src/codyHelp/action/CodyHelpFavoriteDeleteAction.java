package codyHelp.action;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import project.action.CommandAction;
import project.model.Board_CoordiVO;
import project.model.ProjectDAO;

public class CodyHelpFavoriteDeleteAction extends HttpServlet implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		HttpSession session = request.getSession();
		String m_id = (String) session.getAttribute("m_id");
		
		int num = Integer.parseInt(request.getParameter("num")); //이전페이지의 게시글 넘버를받아온다
		
		Board_CoordiVO actionobj = new Board_CoordiVO();
		actionobj.setId(m_id);
		actionobj.setNum(num);
		
		ProjectDAO dao =new ProjectDAO();
		
		Board_CoordiVO vo = dao.getDataDetail_Coordi(num);
		
		int count = dao.getFavoriteCount(actionobj);
		System.out.println("CodyHelpfavoriteDeleteAction");
		if(count > 0)
		{
			System.out.println("favorite_delete");
			dao.favorite_delete(actionobj);
		}
		else
		{
			System.out.println("정보없음");
		}
		
		request.setAttribute("vo", vo);
		request.setAttribute("num", num);
		
		return "/codyHelp/codyHelpFavoriteRefresh.jsp";
	}

}
