package customer_action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import project.action.CommandAction;
import project.model.Board_CustomerVO;
import project.model.ProjectDAO;

public class UpdateProAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("UTF-8");
		
		String pageNum =request.getParameter("pageNum");
		Board_CustomerVO vo =new Board_CustomerVO();
		
		vo.setNum(Integer.parseInt(request.getParameter("num")));
		vo.setId(request.getParameter("id"));
		vo.setTitle(request.getParameter("title"));
		vo.setContent(request.getParameter("content"));
		
		ProjectDAO dao =ProjectDAO.getInstance();
		int check =dao.update(vo);
		
		request.setAttribute("pageNum", pageNum);
		request.setAttribute("check", new Integer(check));
		return "/board/updatePro.jsp";
	}

}
