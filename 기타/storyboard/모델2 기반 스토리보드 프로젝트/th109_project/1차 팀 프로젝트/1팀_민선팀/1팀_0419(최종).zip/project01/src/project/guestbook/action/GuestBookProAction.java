package project.guestbook.action;

import java.sql.Timestamp;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import project.action.CommandAction;
import project.model.Guest_BookVO;
import project.model.ProjectDAO;

public class GuestBookProAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("UTF-8");
		Guest_BookVO vo = new Guest_BookVO();
		HttpSession session = request.getSession();
		
		String personal_id = request.getParameter("personal_id");

		vo.setMy_id((String)session.getAttribute("m_id"));
		vo.setYour_id(personal_id);
		vo.setMy_image((String)session.getAttribute("p_image"));
		vo.setContent(request.getParameter("content"));
		vo.setReg_date(new Timestamp(System.currentTimeMillis()));
		
		ProjectDAO dao = new ProjectDAO();
		dao.insert(vo);
		
		request.setAttribute("personal_id", personal_id);
		
		return "/guestBookView/guestBookPro.jsp";
	}//process end
}//guestbookproaction end
