package project.mypage;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import project.action.CommandAction;
import project.model.BasketVO;
import project.model.ProjectDAO;

public class BasketAddPro implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		request.setCharacterEncoding("UTF-8");
		HttpSession session = request.getSession();
		
		ProjectDAO dao = ProjectDAO.getInstance();
		BasketVO vo = new BasketVO();
		
		String my_id = (String)session.getAttribute("m_id");
		int cl_num = new Integer(request.getParameter("cl_num"));
		
		
		vo.setMy_id(my_id);
		vo.setCl_num(cl_num);
		
		int check = dao.check_basket(my_id, cl_num);
		
		if(check == 1){
			// basket 테이블에 데이터가 존재하지 않음
			// 게시글 팔로우 등록
			dao.insert(vo);
		}else if(check == 0){
			// basket 테이블에 데이터가 존재함
			// 이미 등록되어있는 팔로우. 삭제
			dao.delete_basket(my_id, cl_num);
		}
		
		request.setAttribute("check", check);
		
		return "/mypage/basketAdd.jsp";
	}

}
