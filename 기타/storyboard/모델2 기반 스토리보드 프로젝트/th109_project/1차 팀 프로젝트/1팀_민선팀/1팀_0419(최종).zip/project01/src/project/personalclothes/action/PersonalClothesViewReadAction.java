package project.personalclothes.action;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import project.action.CommandAction;
import project.model.ClothesVO;
import project.model.ProjectDAO;

public class PersonalClothesViewReadAction extends HttpServlet implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("UTF-8");
		int cl_num = Integer.parseInt(request.getParameter("cl_num"));
		
		
		try{
			ProjectDAO dao = ProjectDAO.getInstance();
			ClothesVO vo = dao.getDataDetail_Clothes(cl_num);
			
			request.setAttribute("vo", vo);
		}catch(Exception e){
			e.printStackTrace();
		}
						
		return "/personalClothesView/personalClothesViewRead.jsp";
	}

}
