package project.guestbook.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import project.action.CommandAction;
import project.model.ProjectDAO;

public class GuestBookUpdateFormAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		int num = Integer.parseInt(request.getParameter("num"));
		request.setAttribute("num", num);
		return "/guestBookView/guestBookUpdateForm.jsp";
	}
}
