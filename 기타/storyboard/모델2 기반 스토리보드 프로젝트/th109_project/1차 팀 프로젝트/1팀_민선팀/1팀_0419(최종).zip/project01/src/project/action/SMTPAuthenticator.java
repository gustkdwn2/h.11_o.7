package project.action;

import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;

public class SMTPAuthenticator extends Authenticator {
	public PasswordAuthentication getPasswordAuthentication(){
		// 네이버 사용자 계정 설정
		return new PasswordAuthentication("mail_testid", "password");
	}
}
