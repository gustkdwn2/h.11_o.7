package free_action;

import java.net.URLEncoder;
import java.sql.Timestamp;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import project.action.CommandAction;
import project.model.Board_FreeVO;
import project.model.ProjectDAO;

public class Board_Free_WriteProAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String realPath = "";
	      String savePath = "upload";
	      String encType = "UTF-8";
	      int maxSize = 1024 * 1024 * 5;

	      ServletContext context = request.getSession().getServletContext();
	      realPath = context.getRealPath(savePath + "\\");

	      MultipartRequest multi = new MultipartRequest(request, // request 객체
	            realPath, // 업로드 된 파일이 저장 될 파일폴더 경로
	            maxSize, // 업로드 할 파일의 최대 크기
	            "UTF-8", // 엔코딩 타입
	            new DefaultFileRenamePolicy() // 업로드 될 파일명이 기존의 파일명과 같을 경우 덮어쓰기
	                                    // 방지
	      );
		ProjectDAO dao = ProjectDAO.getInstance();
		
				
		request.setCharacterEncoding("UTF-8");
		Board_FreeVO vo =new Board_FreeVO();
		
		
		vo.setNum(Integer.parseInt(multi.getParameter("num")));
		vo.setId(multi.getParameter("id"));
		vo.setTitle(multi.getParameter("title"));
		vo.setContent(multi.getParameter("content"));
		
		System.out.println("writePro : " + multi.getParameter("id"));
		
		String y = multi.getFilesystemName("image");
	      if( y != null ){
	         String x = request.getContextPath() + "/" + savePath + "/" + URLEncoder.encode(y, "UTF-8");
	         vo.setImage(x);
	      }
		
		
		vo.setReg_date(new Timestamp(System.currentTimeMillis()));
		vo.setRef(Integer.parseInt(multi.getParameter("ref")));
		vo.setRe_level(Integer.parseInt(multi.getParameter("re_level")));
		vo.setRe_step(Integer.parseInt(multi.getParameter("re_step")));
		
		dao.insert(vo);
		
	//	response.sendRedirect("board_customerlist.do");
		return "/board_free/board_free_writePro.jsp";
	}

}
