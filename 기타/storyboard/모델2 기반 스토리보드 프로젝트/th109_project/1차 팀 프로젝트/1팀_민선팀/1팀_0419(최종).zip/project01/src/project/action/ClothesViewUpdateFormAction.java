package project.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import project.model.ClothesVO;
import project.model.ProjectDAO;

public class ClothesViewUpdateFormAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		System.out.println("update start");
		
		HttpSession session = request.getSession();
		String m_id =request.getParameter("m_id");
		
		int cl_num = Integer.parseInt(request.getParameter("cl_num")); //이전페이지의 게시글 넘버를받아온다
		System.out.println("cl_num= "+cl_num);
		ProjectDAO dao =new ProjectDAO();
		ClothesVO vo = dao.update_cloth(cl_num);
		
		request.setAttribute("cl_num", cl_num);
		request.setAttribute("vo", vo);
		

		return "/clothesView/ClothesViewUpdateForm.jsp";
	}

}
