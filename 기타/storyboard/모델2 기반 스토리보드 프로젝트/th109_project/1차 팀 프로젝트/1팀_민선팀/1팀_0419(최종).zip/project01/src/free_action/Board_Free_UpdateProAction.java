package free_action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import project.action.CommandAction;
import project.model.Board_FreeVO;
import project.model.ProjectDAO;

public class Board_Free_UpdateProAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		HttpSession session = request.getSession();
		session.getAttribute("m_id");
		String m_id = (String) session.getAttribute("m_id");
		
		
		String pageNum =request.getParameter("pageNum");
		Board_FreeVO vo =new Board_FreeVO();
		
		vo.setNum(Integer.parseInt(request.getParameter("num")));
		vo.setId(request.getParameter("id"));
		vo.setTitle(request.getParameter("title"));
		vo.setContent(request.getParameter("content"));
		
		ProjectDAO dao =ProjectDAO.getInstance();
		int check =dao.update_free(vo);
		
		request.setAttribute("pageNum", pageNum);
		request.setAttribute("check", new Integer(check));
		return "/board_free/board_free_updatePro.jsp";
	}

}
