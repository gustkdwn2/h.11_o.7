package project.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import project.model.ProjectDAO;

public class DeleteAccountProAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		request.setCharacterEncoding("UTF-8");
		String m_id = request.getParameter("m_id");
		String m_passwd = request.getParameter("m_passwd");
		
		ProjectDAO dao = ProjectDAO.getInstance();
		int check = dao.login_Check(m_id, m_passwd);

		
		System.out.println("check : " + check);
		
		if( check == 1){
			dao.delete(m_id);
		}
		
		request.setAttribute("check", check);
		
		return "/view/deleteAccountPro.jsp";
	}

}
