package project.controller;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import project.action.CommandAction;

//�Խ��� ������(������)
public class ProjectController extends HttpServlet {
	
	private Map commandMap = new HashMap();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		process(request, response);
	}// doGet

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		process(request, response);
	}// doPost

	
	// �ʱ�ȭ �۾� �޼ҵ� - 1ȸ�� ȣ��
	// ��ɾ�� ��ɾ�ó�� Ŭ������ ���εǾ� �ִ� CommandBoard.properties ������ �о� ���̴� ����
	@Override
	public void init(ServletConfig config) throws ServletException {
		String props = config.getInitParameter("ProjectConfig");
		Properties p = new Properties();				// Properties<K, V>�� HashMap<K, V>�� ��� ����
		FileInputStream f = null;
		
		try{
			// CommandBoard.properties ������ ������ �о��
			f = new FileInputStream(props);
			
			// CommandBoard.properties ������ ������ Properties ��ü�� ����
			p.load(f);
			
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			if( f != null){
				try{
					f.close();
				}catch(Exception e){
					e.printStackTrace();
				}// try
			}// if
		}// try
		
		Iterator key = p.keySet().iterator();
		
		
		while( key.hasNext()){
			String command = (String)key.next();
			// properties ������ ��ɾ� �κ��� �޾ƿ´�.(Ŭ������  Ÿ��)
			// ex) value : 
			String className = p.getProperty(command);
			
			try{
				// forName()�� ���ڿ� Ŭ������ ��ȯ
				Class commandClass = Class.forName(className);
				// Ŭ������ ��ȯ���ױ� ������ ��ü ������ �� ����
				Object commandInstatnce = commandClass.newInstance();
				
				// (key: list.do, value : edu.kosta.board.action.ListAction)
				commandMap.put(command, commandInstatnce);
				
			}catch(Exception e){
				e.printStackTrace();
			}// try
		}// while
	}// init
	
	
	
	protected void process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String view = null;
		CommandAction cp = null;
		
		try{
			// ��û URI ��ü�� ��ɾ�� ����ϴ� ���
			String command = request.getRequestURI();		// ~~~/list.do
			
			System.out.println("command : " + command);										//	  /web_boardMVC/list.do
			System.out.println("request.getContextPath() : " + request.getContextPath());	//    /web_boardMVC			 (�۾��ϴ� ������Ʈ ��)
			
			
			String[] result = command.split("/");
			
			command = result[result.length-1];
			
			/*
			// list.do �� ����
			if( command.indexOf(request.getContextPath()) ==0 ){		// �ƹ��͵� ����, ��ΰ� ����
				command = command.substring(request.getContextPath().length() + 1);			//	  /web_boardMVC/ <<<���� ��ŭ command�� �ڸ���		command : list.do
				System.out.println("if command : " + command);
			}// if
			*/
			System.out.println("if command : " + command);
			
			cp = (CommandAction)commandMap.get(command);	// CommandBoard.properties�� Ű ���� �Ѿ�� value ���� ������
			System.out.println("cp : " + cp);				// cp : edu.kosta.board.action.ListAction
			
			view = cp.process(request, response);
			System.out.println("view : " + view);
			
			
		}catch(Exception e){
			e.printStackTrace();
		}// try
		
		
		// 빈 템플릿
		if(view.equals("/view/loginPro.jsp") || view.equals("/view/search_PwPro.jsp") || view.equals("/view/search_IdPro.jsp")
				|| view.equals("/view/modifyAccountPro.jsp") || view.equals("/view/createAccountPro.jsp") || view.equals("/clothesView/ClothesDealPro.jsp")
				|| view.equals("/mypage/followForm_BasketForm.jsp") || view.equals("/mypage/followForm_BookmarkForm.jsp") || view.equals("/mypage/basketAdd.jsp")
				|| view.equals("/view/deleteAccountPro.jsp") || view.equals("/mypage/bookmarkAdd.jsp") || view.equals("/guestBookView/guestBookDeleteForm.jsp")
				|| view.equals("/guestBookView/guestBookDeletePro.jsp")){
			RequestDispatcher dp = request.getRequestDispatcher(view);
			dp.forward(request, response);
			
		// surround 전용 템플릿
		}else if(view.equals("/surroundImageList/surroundImageListForm.jsp") || view.equals("/surroundImageList/surroundImageSearchGender.jsp") 		// �ʵѷ����� ����Ʈ ó��
				|| view.equals("/surroundImageList/surroundImageSearchArea.jsp") || view.equals("/surroundImageList/surroundImageSearchKind.jsp") || view.equals("/surroundImageList/surroundImageSearchTitle.jsp")
				|| view.equals("/guestBookView/guestBookUpdateForm.jsp") || view.equals("/guestBookView/guestBookDeleteForm.jsp")){
			request.setAttribute("CONTENT", view);
			
			RequestDispatcher dp = request.getRequestDispatcher("/main/Surround_tem.jsp");
			dp.forward(request, response);
			
		}else{	// 기본 템플릿
			request.setAttribute("CONTENT", view);
			
			RequestDispatcher dp = request.getRequestDispatcher("/main/template.jsp");
			dp.forward(request, response);
		}
		
		/*
		RequestDispatcher dp = request.getRequestDispatcher(view);
		dp.forward(request, response);
		*/
	}// process


}