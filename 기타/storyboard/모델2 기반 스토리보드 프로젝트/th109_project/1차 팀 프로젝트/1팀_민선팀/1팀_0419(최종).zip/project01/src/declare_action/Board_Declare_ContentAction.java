package declare_action;

import java.text.SimpleDateFormat;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import project.action.CommandAction;
import project.model.Board_DeclareVO;
import project.model.ProjectDAO;

public class Board_Declare_ContentAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {

		
		HttpSession session = request.getSession();
		String m_id = (String) session.getAttribute("m_id");
		m_id = request.getParameter("m_id");
		int num = Integer.parseInt(request.getParameter("num"));
		
		String pageNum = request.getParameter("pageNum");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		
	
		ProjectDAO dao = ProjectDAO.getInstance();
		Board_DeclareVO vo = dao.getDataDetail_declare(num); 
			
		int ref = vo.getRef();
		int re_step = vo.getRe_step();
		int re_level = vo.getRe_level();
		int readcount =vo.getReadcount();
			
			request.setAttribute("num", new Integer(num));
			request.setAttribute("pageNum", new Integer(pageNum));
			request.setAttribute("vo", vo);
			request.setAttribute("readcount", readcount);
		
		
			return "/board_declare/board_declare_content.jsp";

}
}
