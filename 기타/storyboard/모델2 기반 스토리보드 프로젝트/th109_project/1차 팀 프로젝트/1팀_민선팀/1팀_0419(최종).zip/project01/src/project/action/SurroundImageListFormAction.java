package project.action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import project.model.ClothesVO;
import project.model.Member_ProfileVO;
import project.model.ProjectDAO;

public class SurroundImageListFormAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("UTF-8");
		int pageSize = 10;		// ȭ�� ��� ���ڵ� ��
		
		String pageNum = request.getParameter("pageNum");
		
		if(pageNum == null){
			pageNum = "1";
		}// if
		
		int currentPage = Integer.parseInt(pageNum);		// ���� ������
		int startRow = (currentPage * pageSize) - 9;		// ex) (1*10)-9 = 1 - start
		int endRow = (currentPage * pageSize);				// ex) (1*10) = 10 - end
		
		//  ��ü ���ڵ� �� , 
		int count = 0;
		
		// ���ڵ带 �޾ƿ� List
		List list = null;
		List profileList = null;
		ProjectDAO dao = ProjectDAO.getInstance();
		count = dao.getListAllCount_surroundImage();
		
		String select = request.getParameter("surround_select_list");
		
		if(count >0 ){
			list = dao.surroundImageList_selectSet(startRow, endRow, select);
		}
		
		if(list != null){
			profileList = dao.profileImageList(list);
		}else
			profileList = null;
		
		String navigation = null;
		if(select.equals("1")){
			navigation="최신 글 순서";
		}else if(select.equals("2")){
			navigation="좋아요 높은 순서";
		}
		request.setAttribute("navigation", navigation);
		
		
		request.setAttribute("pageSize", pageSize);
		request.setAttribute("pageNum", pageNum);
		request.setAttribute("currentPage", currentPage);
		request.setAttribute("startRow", startRow);
		request.setAttribute("endRow", endRow);
		request.setAttribute("count", count);
		request.setAttribute("list", list);
		request.setAttribute("profileList", profileList);
		request.setAttribute("surround_select_list", select);
		
		
		return "/surroundImageList/surroundImageListForm.jsp";
	}

}
