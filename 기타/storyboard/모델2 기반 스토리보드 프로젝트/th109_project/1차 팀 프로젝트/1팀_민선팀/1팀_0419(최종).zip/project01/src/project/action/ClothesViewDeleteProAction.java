package project.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import project.model.ClothesVO;
import project.model.ProjectDAO;

public class ClothesViewDeleteProAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
	 System.out.println("삭제 pro 시작");
	 
	 
	 int cl_num = (Integer.parseInt(request.getParameter("cl_num")));
	 ProjectDAO dao =ProjectDAO.getInstance();
		
		
		
		
		request.setAttribute("cl_num", new Integer(cl_num));
		ClothesVO vo =dao.delete_cloth(cl_num);
		return "/clothesView/ClothesViewDeletePro.jsp";
	}

}
