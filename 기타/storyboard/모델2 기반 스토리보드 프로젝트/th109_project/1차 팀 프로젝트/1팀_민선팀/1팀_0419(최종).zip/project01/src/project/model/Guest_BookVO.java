package project.model;

import java.sql.Timestamp;

public class Guest_BookVO {

	private int num;
	private String my_id;
	private String your_id;
	private String my_image;
	private String rnum;
	
	private String content;
	private Timestamp reg_date;
	
	public String getRnum() {
		return rnum;
	}
	public void setRnum(String rnum) {
		this.rnum = rnum;
	}
	public String getMy_image() {
		return my_image;
	}
	public void setMy_image(String my_image) {
		this.my_image = my_image;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getMy_id() {
		return my_id;
	}
	public void setMy_id(String my_id) {
		this.my_id = my_id;
	}
	public String getYour_id() {
		return your_id;
	}
	public void setYour_id(String your_id) {
		this.your_id = your_id;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public Timestamp getReg_date() {
		return reg_date;
	}
	public void setReg_date(Timestamp reg_date) {
		this.reg_date = reg_date;
	}
	
}//Guest_bookVO end
