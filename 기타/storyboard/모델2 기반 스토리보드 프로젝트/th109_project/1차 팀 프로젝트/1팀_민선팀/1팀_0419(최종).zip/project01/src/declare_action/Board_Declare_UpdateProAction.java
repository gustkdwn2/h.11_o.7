package declare_action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import project.action.CommandAction;
import project.model.Board_DeclareVO;
import project.model.ProjectDAO;

public class Board_Declare_UpdateProAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String pageNum =request.getParameter("pageNum");
		Board_DeclareVO vo =new Board_DeclareVO();
		
		vo.setNum(Integer.parseInt(request.getParameter("num")));
		vo.setId(request.getParameter("id"));
		vo.setTitle(request.getParameter("title"));
		vo.setContent(request.getParameter("content"));
		
		ProjectDAO dao =ProjectDAO.getInstance();
		int check =dao.update_declare(vo);
		
		request.setAttribute("pageNum", pageNum);
		request.setAttribute("check", new Integer(check));
		return "/board_declare/board_declare_updatePro.jsp";
	}

}
