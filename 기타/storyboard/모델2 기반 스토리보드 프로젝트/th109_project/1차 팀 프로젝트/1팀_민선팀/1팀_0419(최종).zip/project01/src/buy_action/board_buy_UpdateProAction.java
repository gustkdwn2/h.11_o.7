package buy_action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import project.action.CommandAction;
import project.model.Board_BuyVO;
import project.model.ProjectDAO;

public class board_buy_UpdateProAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String pageNum =request.getParameter("pageNum");
		Board_BuyVO vo =new Board_BuyVO();
		
		vo.setNum(Integer.parseInt(request.getParameter("num")));
		vo.setId(request.getParameter("id"));
		vo.setTitle(request.getParameter("title"));
		vo.setContent(request.getParameter("content"));
		
		ProjectDAO dao =ProjectDAO.getInstance();
		int check =dao.update_buy(vo);
		
		request.setAttribute("pageNum", pageNum);
		request.setAttribute("check", new Integer(check));
		return "/board_buy/board_buy_updatePro.jsp";
	}

}
