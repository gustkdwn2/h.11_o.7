package project.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.websocket.SessionException;

import project.model.ProjectDAO;

public class LoginProAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("UTF-8");
		ProjectDAO dao = ProjectDAO.getInstance();
		
		int check = dao.login_Check(request.getParameter("m_id"), request.getParameter("m_passwd"));
		
		
		request.setAttribute("check", new Integer(check));
		request.setAttribute("m_id", request.getParameter("m_id"));
		
		String p_image = dao.getP_image(request.getParameter("m_id"));
		request.setAttribute("p_image", p_image);
		
		return "/view/loginPro.jsp";
	}

}
