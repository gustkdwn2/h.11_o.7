package project.action;

import java.util.List;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import project.model.ClothesVO;
import project.model.ProjectDAO;

public class ClothesViewWriteReadAction extends HttpServlet implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("UTF-8");

		String back2_check = request.getParameter("back2_check");
		try{
			int cl_num = Integer.parseInt(request.getParameter("cl_num"));
			ProjectDAO dao = ProjectDAO.getInstance();
			ClothesVO vo = dao.getDataDetail_Clothes(cl_num);
			List wishList = null;
			request.setAttribute("vo", vo);
			wishList = dao.getWishList(cl_num);
			
			//ClothesViewWriteRead.jsp에서 특정 버튼 나오게할지 말지 결정하는 변수. 
			int choice;

			if(request.getParameter("choice") == null){
				choice = 0;
			} else {
				choice=Integer.parseInt(request.getParameter("choice"));
			}
			request.setAttribute("back2_check", back2_check);
			
			request.setAttribute("wishList", wishList);
			request.setAttribute("choice", new Integer(choice));
			request.setAttribute("seller_id",request.getParameter("seller_id"));
			request.setAttribute("seller_cl_num",request.getParameter("seller_cl_num"));
		}catch(Exception e){
			e.printStackTrace();
		}
			
		return "/clothesView/ClothesViewWriteRead.jsp";
	}

}
