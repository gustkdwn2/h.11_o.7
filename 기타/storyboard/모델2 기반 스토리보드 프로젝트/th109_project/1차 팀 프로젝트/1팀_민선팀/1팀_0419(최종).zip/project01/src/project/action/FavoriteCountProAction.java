package project.action;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import project.model.ClothesVO;
import project.model.ProjectDAO;

public class FavoriteCountProAction extends HttpServlet implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		HttpSession session = request.getSession();
		String m_id = (String)session.getAttribute("m_id");
		
		request.setCharacterEncoding("utf-8");
		ClothesVO vo = null;
		
		
		int cl_num = Integer.parseInt(request.getParameter("cl_num"));

		// 체크2
		
		ProjectDAO dao = ProjectDAO.getInstance();
		
		int check = dao.check_favorite(m_id, cl_num);
		
		
		if(check == 1){
			// favorite 테이블에 데이터 존재하지 않음
			// 좋아요 테이블에 등록 & 게시글 좋아요 +1
			dao.insert_favorite(m_id, cl_num);
			vo = dao.favoriteCount_add(cl_num);
		}else if(check == 0){
			// favorite 테이블에 데이터 존재
			// 좋아요 테이블에서 삭제 & 게시글 좋아요 -1
			dao.delete_favorite(m_id, cl_num);
			vo = dao.favoriteCount_sub(cl_num);
		}// if
		
		
		request.setAttribute("vo", vo);
		
	    
		return "/clothesView/ClothesViewWriteRead.jsp";
	}

}
