package project.personalclothes.action;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import project.action.CommandAction;
import project.model.Member_ProfileVO;
import project.model.ProjectDAO;

public class PersonalClothesViewAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("UTF-8");
		
		
		//.do로 실행시 받아올 아이디. 나중에 your_id로 받아올것임..
		HttpSession session = request.getSession();
		String m_id = (String)session.getAttribute("m_id");
		
		String personal_id = request.getParameter("personal_id");
		
		if(m_id == personal_id){			// 로그인한 본인의 옷장일 경우
			personal_id = m_id;
		}

		int pageSize = 10;		// 화면 출력 레코드 수
		
		String pageNum = request.getParameter("pageNum");
		
		if(pageNum == null){
			pageNum = "1";
		}// if
		
		int currentPage = Integer.parseInt(pageNum);		// 현재 페이지
		int startRow = (currentPage * pageSize) - 9;		// ex) (1*10)-9 = 1 - start
		int endRow = (currentPage * pageSize);				// ex) (1*10) = 10 - end
		
		//  전체 레코드 수 , 
		int count = 0;
		
		// 레코드를 받아올 List
		List clothesList = null;
		
		//List profileList = null;
		ProjectDAO dao = ProjectDAO.getInstance();		
		count = dao.getClothesCount(personal_id);
		
		
		if(count >0 ){
			clothesList = dao.getClothes(startRow, endRow, personal_id);
			count = dao.getClothesSearch_Count(startRow, endRow, personal_id);
		}
		
		Member_ProfileVO personal_profile = null;
		personal_profile = dao.getProfile(personal_id);
		
		// personal_id 존재 확인
		int check=0;
		if(personal_profile != null){
			check = 1;
		}
		
		request.setAttribute("pageSize", pageSize);
		request.setAttribute("pageNum", pageNum);
		request.setAttribute("currentPage", currentPage);
		request.setAttribute("startRow", startRow);
		request.setAttribute("endRow", endRow);
		request.setAttribute("count", count);
		request.setAttribute("clothesList", clothesList);
		request.setAttribute("personal_profile", personal_profile);
		request.setAttribute("personal_id", personal_id);
		request.setAttribute("check", check);
				
		return "/personalClothesView/personalClothesView.jsp";
	}
}
