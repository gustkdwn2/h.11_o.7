package project.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import com.sun.javafx.scene.paint.GradientUtils.Parser;

import dbclose.util.CloseUtil;

// Controller
public class ProjectDAO {

	private static ProjectDAO instance = new ProjectDAO();

	public ProjectDAO() {
	}

	public static ProjectDAO getInstance() {
		return instance;
	}// getInstance()

	////////////////////////////////////// DB Connection & close
	public Connection getConnection() throws Exception {
		Context ctx = new InitialContext();
		DataSource ds = (DataSource) ctx.lookup("java:comp/env/jdbc:TestDB");

		return ds.getConnection();
	}// getConnection()

	////////////////////////////////////////////////////////////////////////
	// insert
	// member DB insert
	public int insert(MemberVO vo) {
		Connection conn = null;
		PreparedStatement pstmt = null;

		String sql = "insert into member(m_id, m_passwd, m_name, m_tel, m_addr, m_email) values(?, ?, ?, ?, ?, ?)";

		System.out.println(vo.getM_tel());

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, vo.getM_id());
			pstmt.setString(2, vo.getM_passwd());
			pstmt.setString(3, vo.getM_name());
			pstmt.setString(4, vo.getM_tel());
			pstmt.setString(5, vo.getM_addr());
			pstmt.setString(6, vo.getM_email());

			pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		} finally {
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // try

		return 1;
	}// insert(MemberVO)

	// memberProfile DB insert
	public int insert(Member_ProfileVO vo) {
		Connection conn = null;
		PreparedStatement pstmt = null;

		String sql = "insert into member_profile(p_id, p_height, p_weight, p_self, p_area, p_image, p_message) "
				+ "values(?, ?, ?, ?, ?, ?, ?)";

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, vo.getP_id());
			pstmt.setString(2, vo.getP_height());
			pstmt.setString(3, vo.getP_weight());
			pstmt.setString(4, vo.getP_self());
			pstmt.setString(5, vo.getP_area());
			if (vo.getP_image() != null) {
				pstmt.setString(6, vo.getP_image());
			} else {
				pstmt.setString(6, "/project01/upload/p_img_default.png");
			}
			pstmt.setString(7, vo.getP_message());

			pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		} finally {
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // try

		return 1;
	}// insert()

	public int insert(Board_CoordiVO vo) {
		Connection conn = null;
		PreparedStatement pstmt = null;

		String sql = "insert into board_coordi(num, id, title, content, reg_date, readcount, ref, re_step, re_level, image1,image2,image3) "
				+ "values(board_coordi_num.nextval, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,?)";

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, vo.getId());
			pstmt.setString(2, vo.getTitle());
			pstmt.setString(3, vo.getContent());
			pstmt.setTimestamp(4, vo.getReg_date());
			pstmt.setInt(5, vo.getReadcount());
			pstmt.setInt(6, vo.getRef());
			pstmt.setInt(7, vo.getRe_step());
			pstmt.setInt(8, vo.getRe_level());
			pstmt.setString(9, vo.getImage1());
			pstmt.setString(10, vo.getImage2());
			pstmt.setString(11, vo.getImage3());
			pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		} finally {
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // try

		return 1;
	}// insert(Board_CoordiVO)

	public int insert(DealVO vo) {
		Connection conn = null;
		PreparedStatement pstmt = null;

		String sql = "insert into deal(num, seller_id, buyer_id, seller_cl_num, buyer_cl_num, count) "
				+ "values(deal_num.nextval, ?, ?, ?, ?, ?)";

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, vo.getSeller_id());
			pstmt.setString(2, vo.getBuyer_id());
			pstmt.setInt(3, vo.getSeller_cl_num());
			pstmt.setInt(4, vo.getBuyer_cl_num());
			pstmt.setInt(5, vo.getCount());

			pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		} finally {
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // try
		return 1;
	}// insert(DealVO)

	// bookmark DB insert
	public int insert(BookmarkVO vo) {
		Connection conn = null;
		PreparedStatement pstmt = null;

		String sql = "insert into bookmark(num, my_id, your_id) values(bookmark_num.nextval, ?, ?)";

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, vo.getMy_id());
			pstmt.setString(2, vo.getYour_id());

			pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		} finally {
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // try

		return 1;
	}

	// guest_book DB insert
	public int insert(Guest_BookVO vo) {
		Connection conn = null;
		PreparedStatement pstmt = null;

		String sql = "insert into guest_book(num, my_id, your_id, my_image, content, reg_date) values(guest_book_num.nextval, ?, ?, ?, ?, ?)";

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, vo.getMy_id());
			pstmt.setString(2, vo.getYour_id());
			pstmt.setString(3, vo.getMy_image());
			pstmt.setString(4, vo.getContent());
			pstmt.setTimestamp(5, vo.getReg_date());

			pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		} finally {
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}

		return 1;
	}// insert(Guest_bookVO)

	// guest_book DB update
	public int update(Guest_BookVO vo) {
		Connection conn = null;
		PreparedStatement pstmt = null;

		String sql = "update guest_book set content=?, reg_date=? where num=?";

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, vo.getContent());
			pstmt.setTimestamp(2, vo.getReg_date());
			pstmt.setInt(3, vo.getNum());
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		} finally {
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		return 1;
	}// update(Guest_bookVO)

	// guest_book DB delete
	public int delete(Guest_BookVO vo) {
		Connection conn = null;
		PreparedStatement pstmt = null;

		String sql = "delete from guest_book where num=?";

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);

			pstmt.setInt(1, vo.getNum());
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		} finally {
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		return 1;
	}// delete(Guest_bookVO)

	// guest_book ��ü �� �� �����.
	public int getGuest_BookCount(String my_id) throws Exception {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int x = 0;
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement("select count(*) from guest_book where your_id=?");
			pstmt.setString(1, my_id);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				x = rs.getInt(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		return x;
	}
	// guest_book �� ��� (�α����� ���̵���)

	public List getGuest_Book(int start, int end, String personal_id) throws Exception {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List guestBookList = null;
		String sql = "select B.* from (select C.*, rownum R from (select num, my_id, your_id, my_image, content, reg_date, rownum rnum from guest_book where your_id=? order by reg_date desc) C where rownum <= ?) B where R >= ?";
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, personal_id);
			pstmt.setInt(2, end);
			pstmt.setInt(3, start);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				guestBookList = new ArrayList(end);
				do {
					Guest_BookVO vo = new Guest_BookVO();
					vo.setNum(rs.getInt("num"));
					vo.setMy_id(rs.getString("my_id"));
					vo.setYour_id(rs.getString("your_id"));
					vo.setMy_image(rs.getString("my_image"));
					vo.setContent(rs.getString("content"));
					vo.setReg_date(rs.getTimestamp("reg_date"));
					vo.setRnum(rs.getString("rnum"));
					guestBookList.add(vo);
				} while (rs.next());
			} // if end
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		return guestBookList;
	}

	public int getGuest_Book_Count(String personal_id) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int x = 0;
		String sql = "select count(*) from guest_book where your_id=?";
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, personal_id);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				x = rs.getInt(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		return x;

	}

	// login ó�� / ȸ�� Ż�� ó�� / ���̵�� ��й�ȣ Ȯ���ϱ�
	public int login_Check(String m_id, String m_passwd) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		String sql = "select m_passwd from member where m_id=?";

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, m_id);

			rs = pstmt.executeQuery();

			if (rs.next()) {
				String dbpwd = rs.getString("m_passwd");
				if (m_passwd.equals(dbpwd)) {
					return 1; // �α���
				} else {
					return 0; // ��й�ȣ�� �ٸ�
				} // if
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // try

		return -1; // ���̵� ����
	}// login_Check(String, String)

	// ������� p_image ������ session�� �����ϱ� ���� �޼ҵ�
	public String getP_image(String p_id) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String p_image = null;

		String sql = "select p_image from member_profile where p_id = ?";

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, p_id);

			rs = pstmt.executeQuery();

			if (rs.next()) {
				p_image = rs.getString("p_image");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}

		return p_image;
	}

	// id �ߺ� Ȯ��
	public int confirmId(String m_id) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		String sql = "select m_id from member where m_id=?";

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, m_id);

			rs = pstmt.executeQuery();

			if (rs.next()) { // rs ����� �ִٸ� ���̵� �ߺ�
				return 1;
			} else
				return -1;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // try

		return 1;
	}// confirmId()

	// idã�� -> �̸�, ��ȭ��ȣ��
	public String search_Id(String m_name, String m_tel) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String m_id = null;

		String sql = "select m_id from member where m_name=? and m_tel = ?";

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, m_name);
			pstmt.setString(2, m_tel);

			rs = pstmt.executeQuery();

			if (rs.next()) {
				m_id = rs.getString("m_id");
			} else
				return null;

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // try

		return m_id;

	}// search_Id()

	// pw ã�� -> �̸�, ��ȭ��ȣ, ID
	public String search_Pw(String m_name, String m_tel, String m_id) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String m_passwd = null;

		String sql = "select m_passwd from member where m_name=? and m_tel = ? and m_id=?";

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, m_name);
			pstmt.setString(2, m_tel);
			pstmt.setString(3, m_id);

			rs = pstmt.executeQuery();

			if (rs.next()) {
				m_passwd = rs.getString("m_passwd");
			} else
				return null;

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // try

		return m_passwd;
	}// search_Pw()

	// id�� member���̺� �˻�
	public MemberVO search_member_id(String m_id) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		MemberVO vo = new MemberVO();

		String sql = "select * from member where m_id = ?";

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, m_id);

			rs = pstmt.executeQuery();

			if (rs.next()) {
				vo.setM_id(rs.getString("m_id"));
				vo.setM_passwd(rs.getString("m_passwd"));
				vo.setM_name(rs.getString("m_name"));
				vo.setM_tel(rs.getString("m_tel"));
				vo.setM_email(rs.getString("m_email"));
				vo.setM_addr(rs.getString("m_addr"));
				vo.setM_point(rs.getInt("m_point"));
			} // if

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // try

		return vo;
	}// search_member_id

	// id�� member_profile ���̺� �˻�
	public Member_ProfileVO search_profile_id(String p_id) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Member_ProfileVO vo = new Member_ProfileVO();

		String sql = "select * from member_profile where p_id = ?";

		System.out.println(p_id);

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, p_id);

			rs = pstmt.executeQuery();

			if (rs.next()) {
				vo.setP_id(rs.getString("p_id"));
				vo.setP_height(rs.getString("p_height"));
				vo.setP_weight(rs.getString("p_weight"));
				vo.setP_self(rs.getString("p_self"));
				vo.setP_area(rs.getString("p_area"));
				vo.setP_image(rs.getString("p_image"));
				vo.setP_message(rs.getString("p_message"));
			} // if

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // try

		return vo;
	}// search_member_id
	
	public Member_ProfileVO update_member(String p_id) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Member_ProfileVO mp_vo = null;
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement("select * from member_profile where p_id =?");
			pstmt.setString(1, p_id);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				mp_vo = new Member_ProfileVO();
				mp_vo.setP_id(rs.getString("p_id"));
				mp_vo.setP_height(rs.getString("p_height"));
				mp_vo.setP_weight(rs.getString("p_weight"));
				mp_vo.setP_self(rs.getString("p_self"));
				mp_vo.setP_area(rs.getString("p_area"));
				mp_vo.setP_image(rs.getString("P_image"));
				mp_vo.setP_message(rs.getString("p_message"));
			} // if


		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		return mp_vo;
	}//  update

	// update
	public void update(MemberVO vo) {
		Connection conn = null;
		PreparedStatement pstmt = null;

		String sql = "update member set m_passwd=?, m_tel=?, m_email=?, m_addr=? where m_id=?";

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, vo.getM_passwd());
			pstmt.setString(2, vo.getM_tel());
			pstmt.setString(3, vo.getM_email());
			pstmt.setString(4, vo.getM_addr());
			pstmt.setString(5, vo.getM_id());

			pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // try

	}// update(MemberVO)

	// ��� ������ ������Ʈ
	public void update(Member_ProfileVO vo) {
		Connection conn = null;
		PreparedStatement pstmt = null;

		String sql = "update member_profile set p_height=?, p_weight=?, p_self=?, p_area=?, p_image=?, p_message=? where p_id=?";

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, vo.getP_height());
			pstmt.setString(2, vo.getP_weight());
			pstmt.setString(3, vo.getP_self());
			pstmt.setString(4, vo.getP_area());
			if (vo.getP_image() != null) {
				pstmt.setString(5, vo.getP_image());
			} else {
				pstmt.setString(5, "/project01/upload/p_img_default.png");
			}
			pstmt.setString(6, vo.getP_message());
			pstmt.setString(7, vo.getP_id());

			pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // try
	}// update(Member_ProfileVO)

	// delete
	public void delete(String m_id) {
		Connection conn = null;
		PreparedStatement pstmt = null;

		String sql = "delete from member where m_id = ?";
		String sql2 = "delete from member_profile where p_id=?";

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, m_id);
			pstmt.executeUpdate();

			pstmt = conn.prepareStatement(sql2);
			pstmt.setString(1, m_id);
			pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // try
	}// delete()

	// ClothesViewWrite DBinsert
	public int insert(ClothesVO vo) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int result = 0;

		String sql = "insert into CLOTHES(cl_num, cl_id, cl_image1, cl_image2, cl_image3, cl_title, cl_content, cl_condition,"
				+ " cl_size, cl_type, cl_area, cl_gender, cl_price, cl_hope, cl_deal) values(CLOTHES_CL_NUM.NEXTVAL,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

		String sql2 = "select last_number from user_sequences where sequence_name=upper('clothes_cl_num')";

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, vo.getCl_id());
			pstmt.setString(2, vo.getCl_image1());
			pstmt.setString(3, vo.getCl_image2());
			pstmt.setString(4, vo.getCl_image3());
			pstmt.setString(5, vo.getCl_title());
			pstmt.setString(6, vo.getCl_content());
			pstmt.setString(7, vo.getCl_condition());
			pstmt.setString(8, vo.getCl_size());
			pstmt.setString(9, vo.getCl_type());
			pstmt.setString(10, vo.getCl_area());
			pstmt.setString(11, vo.getCl_gender());
			pstmt.setInt(12, vo.getCl_price());
			pstmt.setString(13, vo.getCl_hope());
			pstmt.setString(14, vo.getCl_deal());

			pstmt.executeUpdate();

			pstmt = conn.prepareStatement(sql2);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				result = rs.getInt(1);
				System.out.println(result);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}

		return result - 1;
	}

	// ClothesViewWriteRead DBview
	public ClothesVO getDataDetail_Clothes(int cl_num) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		ClothesVO vo = null;
		String sql = "";

		try {
			conn = getConnection();

			pstmt = conn.prepareStatement("SELECT * FROM CLOTHES WHERE CL_NUM = ?");
			pstmt.setInt(1, cl_num);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				vo = new ClothesVO();
				vo.setCl_num(rs.getInt("cl_num"));
				vo.setCl_id(rs.getString("cl_id"));
				vo.setCl_image1(rs.getString("cl_image1"));
				vo.setCl_image2(rs.getString("cl_image2"));
				vo.setCl_image3(rs.getString("cl_image3"));
				vo.setCl_title(rs.getString("cl_title"));
				vo.setCl_content(rs.getString("cl_content"));
				vo.setCl_condition(rs.getString("cl_condition"));
				vo.setCl_size(rs.getString("cl_size"));
				vo.setCl_type(rs.getString("cl_type"));
				vo.setCl_area(rs.getString("cl_area"));
				vo.setCl_gender(rs.getString("cl_gender"));
				vo.setCl_price(rs.getInt("cl_price"));
				vo.setCl_hope(rs.getString("cl_hope"));
				vo.setCl_deal(rs.getString("cl_deal"));
				vo.setCl_favorite(rs.getInt("cl_favorite"));
			}

		} catch (Exception e) {
			e.printStackTrace();

		} // try

		return vo;
	}// getDataDetail()

	// 좋아요 DB 데이터 존재여부
	public int check_favorite(String m_id, int cl_num) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		String sql = "select * from favorite_clothes where m_id=? and cl_num=?";

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, m_id);
			pstmt.setInt(2, cl_num);

			rs = pstmt.executeQuery();

			if (rs.next()) {
				return 0; // DB에 존재
			} else {
				return 1; // DB에 존재 x
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // try

		return 1; // DB에 존재 x
	}

	// favorite count update
	public ClothesVO favoriteCount_add(int cl_num) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ClothesVO vo = null;

		String sql2 = "";
		String sql3 = "";
		try {
			conn = getConnection();
			sql2 = "update CLOTHES set cl_favorite=cl_favorite+1 where cl_num=?";
			sql3 = "select * from clothes where cl_num=?";

			pstmt = conn.prepareStatement(sql2);
			pstmt.setInt(1, cl_num);
			pstmt.executeUpdate();

			pstmt = conn.prepareStatement(sql3);
			pstmt.setInt(1, cl_num);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				vo = new ClothesVO();
				vo.setCl_num(rs.getInt("cl_num"));
				vo.setCl_id(rs.getString("cl_id"));
				vo.setCl_image1(rs.getString("cl_image1"));
				vo.setCl_image2(rs.getString("cl_image2"));
				vo.setCl_image3(rs.getString("cl_image3"));
				vo.setCl_title(rs.getString("cl_title"));
				vo.setCl_content(rs.getString("cl_content"));
				vo.setCl_condition(rs.getString("cl_condition"));
				vo.setCl_size(rs.getString("cl_size"));
				vo.setCl_type(rs.getString("cl_type"));
				vo.setCl_area(rs.getString("cl_area"));
				vo.setCl_gender(rs.getString("cl_gender"));
				vo.setCl_price(rs.getInt("cl_price"));
				vo.setCl_hope(rs.getString("cl_hope"));
				vo.setCl_deal(rs.getString("cl_deal"));
				vo.setCl_favorite(rs.getInt("cl_favorite"));
			} // if end

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		return vo;

	}

	// 좋아요 테이블 등록
	public void insert_favorite(String m_id, int cl_num) {
		Connection conn = null;
		PreparedStatement pstmt = null;

		String sql = "insert into favorite_clothes values(favorite_clothes_num.nextval, ?, ?)";

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, m_id);
			pstmt.setInt(2, cl_num);

			pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
	}

	// 좋아요 테이블 삭제
	public void delete_favorite(String m_id, int cl_num) {
		Connection conn = null;
		PreparedStatement pstmt = null;

		String sql = "delete from favorite_clothes where m_id = ? and cl_num = ?";

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, m_id);
			pstmt.setInt(2, cl_num);

			pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
	}

	// favorite count update
	public ClothesVO favoriteCount_sub(int cl_num) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ClothesVO vo = null;

		String sql2 = "";
		String sql3 = "";
		try {
			conn = getConnection();
			sql2 = "update CLOTHES set cl_favorite=cl_favorite-1 where cl_num=?";
			sql3 = "select * from clothes where cl_num=?";

			pstmt = conn.prepareStatement(sql2);
			pstmt.setInt(1, cl_num);
			pstmt.executeUpdate();

			pstmt = conn.prepareStatement(sql3);
			pstmt.setInt(1, cl_num);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				vo = new ClothesVO();
				vo.setCl_num(rs.getInt("cl_num"));
				vo.setCl_id(rs.getString("cl_id"));
				vo.setCl_image1(rs.getString("cl_image1"));
				vo.setCl_image2(rs.getString("cl_image2"));
				vo.setCl_image3(rs.getString("cl_image3"));
				vo.setCl_title(rs.getString("cl_title"));
				vo.setCl_content(rs.getString("cl_content"));
				vo.setCl_condition(rs.getString("cl_condition"));
				vo.setCl_size(rs.getString("cl_size"));
				vo.setCl_type(rs.getString("cl_type"));
				vo.setCl_area(rs.getString("cl_area"));
				vo.setCl_gender(rs.getString("cl_gender"));
				vo.setCl_price(rs.getInt("cl_price"));
				vo.setCl_hope(rs.getString("cl_hope"));
				vo.setCl_deal(rs.getString("cl_deal"));
				vo.setCl_favorite(rs.getInt("cl_favorite"));
			} // if end

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		return vo;

	}

	// �ʵѷ�����
	public int getListAllCount_surroundImage() {

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int count = 0;

		String sql = "select count(*) from clothes";

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				count = rs.getInt(1);
			} // if

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}

		return count;
	}

	// �ʵѷ����� - �ֽż�/���ƿ��
	public List<ClothesVO> surroundImageList_selectSet(int startRow, int endRow, String check) {

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List list = null;

		String sql = "";

		// select check
		if (check.equals("1")) { // �ֽż�
			sql = "select B.* from (select C.*, rownum R from (select * from CLOTHES order by cl_num desc) C where rownum <= ?) B where R >= ?";
		} else { // ���ƿ��
			sql = "select B.* from (select C.*, rownum R from (select * from CLOTHES order by cl_favorite desc, cl_num desc) C where rownum <= ?) B where R >= ?";
		} // if

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, endRow);
			pstmt.setInt(2, startRow);
			rs = pstmt.executeQuery();

			System.out.println("dao start:" + startRow);
			System.out.println("dao end:" + endRow);

			if (rs.next()) {
				list = new ArrayList(endRow);

				do {
					ClothesVO vo = new ClothesVO();
					vo.setCl_num(rs.getInt("cl_num"));
					vo.setCl_id(rs.getString("cl_id"));
					vo.setCl_image1(rs.getString("cl_image1"));
					vo.setCl_image2(rs.getString("cl_image2"));
					vo.setCl_image3(rs.getString("cl_image3"));
					vo.setCl_title(rs.getString("cl_title"));
					vo.setCl_content(rs.getString("cl_content"));
					vo.setCl_condition(rs.getString("cl_condition"));
					vo.setCl_size(rs.getString("cl_size"));
					vo.setCl_type(rs.getString("cl_type"));
					vo.setCl_area(rs.getString("cl_area"));
					vo.setCl_gender(rs.getString("cl_gender"));
					vo.setCl_price(rs.getInt("cl_price"));
					vo.setCl_hope(rs.getString("cl_hope"));
					vo.setCl_deal(rs.getString("cl_deal"));
					vo.setCl_favorite(rs.getInt("cl_favorite"));

					list.add(vo);

				} while (rs.next());
			} // if

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // try

		System.out.println("DAO:" + list.size());

		return list;
	}

	// �ʵѷ����� - �ֽż�/���ƿ��/������ �������������
	public List<Member_ProfileVO> profileImageList(List<ClothesVO> list) {

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<Member_ProfileVO> profileList = new ArrayList();

		String sql = "select m.* from clothes c, MEMBER_PROFILE m where c.cl_id = m.p_id and c.cl_num = ?";

		try {
			conn = getConnection();

			System.out.println(list.size());

			for (int i = 0; i < list.size(); i++) {

				pstmt = conn.prepareStatement(sql);
				ClothesVO ex = (ClothesVO) list.get(i);
				pstmt.setInt(1, ex.getCl_num());
				rs = pstmt.executeQuery();

				if (rs.next()) {
					Member_ProfileVO vo = new Member_ProfileVO();
					vo.setP_id(rs.getString("p_id"));
					vo.setP_height(rs.getString("p_height"));
					vo.setP_weight(rs.getString("p_weight"));
					vo.setP_self(rs.getString("p_self"));
					vo.setP_area(rs.getString("p_area"));
					vo.setP_image(rs.getString("p_image"));
					vo.setP_message(rs.getString("p_message"));

					profileList.add(vo);
				} // if

			} // for
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // try

		return profileList;
	}

	// �ʵѷ����� - ���� �˻�
	public List<ClothesVO> surroundImageList_SearchGender(int startRow, int endRow, List<String> gender) {

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List list = null;

		String sql = "select B.* from (select C.*, rownum R from (select * from CLOTHES where ";
		sql += " cl_gender = '" + gender.get(0) + "'";
		for (int i = 1; i < gender.size(); i++) {
			sql += " or cl_gender = '" + gender.get(i) + "'";
		}
		sql += " order by cl_num desc) C where rownum <= ?) B where R >= ?";

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, endRow);
			pstmt.setInt(2, startRow);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				list = new ArrayList(endRow);

				do {
					ClothesVO vo = new ClothesVO();
					vo.setCl_num(rs.getInt("cl_num"));
					vo.setCl_id(rs.getString("cl_id"));
					vo.setCl_image1(rs.getString("cl_image1"));
					vo.setCl_image2(rs.getString("cl_image2"));
					vo.setCl_image3(rs.getString("cl_image3"));
					vo.setCl_title(rs.getString("cl_title"));
					vo.setCl_content(rs.getString("cl_content"));
					vo.setCl_condition(rs.getString("cl_condition"));
					vo.setCl_size(rs.getString("cl_size"));
					vo.setCl_type(rs.getString("cl_type"));
					vo.setCl_area(rs.getString("cl_area"));
					vo.setCl_gender(rs.getString("cl_gender"));
					vo.setCl_price(rs.getInt("cl_price"));
					vo.setCl_hope(rs.getString("cl_hope"));
					vo.setCl_deal(rs.getString("cl_deal"));
					vo.setCl_favorite(rs.getInt("cl_favorite"));

					list.add(vo);

				} while (rs.next());
			} // if

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // try
		return list;
	}

	// �ʵѷ����� - ���� �˻� ���ڵ� ��
	public int surroundImageList_SearchGender_count(int startRow, int endRow, List<String> gender) {

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int count = 0;

		String sql = "select count(*) from CLOTHES where "; /*
															 * cl_gender='����'
															 * or
															 * cl_gender='����'"
															 * ;
															 */
		sql += " cl_gender = '" + gender.get(0) + "'";
		for (int i = 1; i < gender.size(); i++) {
			sql += " or cl_gender = '" + gender.get(i) + "'";
		}

		System.out.println(sql);

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				count = rs.getInt(1);
			} // if

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // try
		return count;
	}

	// �ʵѷ����� - area �˻�
	public List<ClothesVO> surroundImageList_SearchArea(int startRow, int endRow, List<String> area) {

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List list = null;

		String sql = "select B.* from (select C.*, rownum R from (select * from CLOTHES where ";
		sql += " cl_area = '" + area.get(0) + "'";
		for (int i = 1; i < area.size(); i++) {
			sql += " or cl_area = '" + area.get(i) + "'";
		}
		sql += " order by cl_num desc) C where rownum <= ?) B where R >= ?";

		System.out.println(sql);

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, endRow);
			pstmt.setInt(2, startRow);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				list = new ArrayList(endRow);

				do {
					ClothesVO vo = new ClothesVO();
					vo.setCl_num(rs.getInt("cl_num"));
					vo.setCl_id(rs.getString("cl_id"));
					vo.setCl_image1(rs.getString("cl_image1"));
					vo.setCl_image2(rs.getString("cl_image2"));
					vo.setCl_image3(rs.getString("cl_image3"));
					vo.setCl_title(rs.getString("cl_title"));
					vo.setCl_content(rs.getString("cl_content"));
					vo.setCl_condition(rs.getString("cl_condition"));
					vo.setCl_size(rs.getString("cl_size"));
					vo.setCl_type(rs.getString("cl_type"));
					vo.setCl_area(rs.getString("cl_area"));
					vo.setCl_gender(rs.getString("cl_gender"));
					vo.setCl_price(rs.getInt("cl_price"));
					vo.setCl_hope(rs.getString("cl_hope"));
					vo.setCl_deal(rs.getString("cl_deal"));
					vo.setCl_favorite(rs.getInt("cl_favorite"));

					list.add(vo);

				} while (rs.next());
			} // if

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // try
		return list;
	}

	// �ʵѷ����� - Area �˻� ���ڵ� ��
	public int surroundImageList_SearchArea_count(int startRow, int endRow, List<String> area) {

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int count = 0;

		String sql = "select count(*) from CLOTHES where ";
		sql += " cl_area = '" + area.get(0) + "'";
		for (int i = 1; i < area.size(); i++) {
			sql += " or cl_area = '" + area.get(i) + "'";
		}

		System.out.println(sql);

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				count = rs.getInt(1);
			} // if

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // try
		return count;
	}

	// �ʵѷ����� - kind �˻�
	public List<ClothesVO> surroundImageList_SearchKind(int startRow, int endRow, List<String> kind) {

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List list = null;

		String sql = "select B.* from (select C.*, rownum R from (select * from CLOTHES where ";
		sql += " cl_type = '" + kind.get(0) + "'";
		for (int i = 1; i < kind.size(); i++) {
			sql += " or cl_type = '" + kind.get(i) + "'";
		}
		sql += " order by cl_num desc) C where rownum <= ?) B where R >= ?";

		System.out.println(sql);

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, endRow);
			pstmt.setInt(2, startRow);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				list = new ArrayList(endRow);

				do {
					ClothesVO vo = new ClothesVO();
					vo.setCl_num(rs.getInt("cl_num"));
					vo.setCl_id(rs.getString("cl_id"));
					vo.setCl_image1(rs.getString("cl_image1"));
					vo.setCl_image2(rs.getString("cl_image2"));
					vo.setCl_image3(rs.getString("cl_image3"));
					vo.setCl_title(rs.getString("cl_title"));
					vo.setCl_content(rs.getString("cl_content"));
					vo.setCl_condition(rs.getString("cl_condition"));
					vo.setCl_size(rs.getString("cl_size"));
					vo.setCl_type(rs.getString("cl_type"));
					vo.setCl_area(rs.getString("cl_area"));
					vo.setCl_gender(rs.getString("cl_gender"));
					vo.setCl_price(rs.getInt("cl_price"));
					vo.setCl_hope(rs.getString("cl_hope"));
					vo.setCl_deal(rs.getString("cl_deal"));
					vo.setCl_favorite(rs.getInt("cl_favorite"));

					list.add(vo);

				} while (rs.next());
			} // if

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // try
		return list;
	}

	// �ʵѷ����� - kind �˻� ���ڵ� ��
	public int surroundImageList_SearchKind_count(int startRow, int endRow, List<String> kind) {

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int count = 0;

		String sql = "select count(*) from CLOTHES where ";
		sql += " cl_type = '" + kind.get(0) + "'";
		for (int i = 1; i < kind.size(); i++) {
			sql += " or cl_type = '" + kind.get(i) + "'";
		}

		System.out.println(sql);

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				count = rs.getInt(1);
			} // if

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // try
		return count;
	}

	// �ʵѷ����� - title �˻�
	public List<ClothesVO> surroundImageList_titleSearch(int startRow, int endRow, String title) {

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List list = null;

		String sql = "select * from clothes where cl_title like ?";

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, "%" + title + "%");

			rs = pstmt.executeQuery();

			if (rs.next()) {
				list = new ArrayList(endRow);

				do {
					ClothesVO vo = new ClothesVO();
					vo.setCl_num(rs.getInt("cl_num"));
					vo.setCl_id(rs.getString("cl_id"));
					vo.setCl_image1(rs.getString("cl_image1"));
					vo.setCl_image2(rs.getString("cl_image2"));
					vo.setCl_image3(rs.getString("cl_image3"));
					vo.setCl_title(rs.getString("cl_title"));
					vo.setCl_content(rs.getString("cl_content"));
					vo.setCl_condition(rs.getString("cl_condition"));
					vo.setCl_size(rs.getString("cl_size"));
					vo.setCl_type(rs.getString("cl_type"));
					vo.setCl_area(rs.getString("cl_area"));
					vo.setCl_gender(rs.getString("cl_gender"));
					vo.setCl_price(rs.getInt("cl_price"));
					vo.setCl_hope(rs.getString("cl_hope"));
					vo.setCl_deal(rs.getString("cl_deal"));
					vo.setCl_favorite(rs.getInt("cl_favorite"));

					list.add(vo);

				} while (rs.next());
			} // if
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // try

		return list;
	}

	///////////////////////////////////////////////////////
	// 게시판 - 자유게시판

	public int insert(Board_FreeVO vo) {

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		// 답변 글인지 일반(새 게시글)인지 구분해서 입력 시키는 로직
		int num = vo.getNum(); // 내부적 부모 글번호
		int ref = vo.getRef(); // 부모의 ref(그룹 번호)
		int re_step = vo.getRe_step(); // 부모의 그룹 내 순서
		int re_level = vo.getRe_level(); // 부모의 re_level
		int number = 0; // board 테이블에 들어갈 번호
		StringBuffer sb = new StringBuffer();

		try {

			conn = getConnection(); // 연결

			// 현재 board테이블에 레코드 유무 판단과 글 번호 지정
			pstmt = conn.prepareStatement("SELECT MAX(NUM) FROM board_free");
			rs = pstmt.executeQuery();

			if (rs.next()) {
				number = rs.getInt(1) + 1; // 1 : num, 다음 글 번호는 가장 큰 번호 +1
			} else
				number = 1; // 첫번 째 글

			// 제목글과 답변글 간의 순서 결정
			if (num != 0) { // 답변글
				re_level = re_level + 1;

				pstmt = conn.prepareStatement("SELECT MAX(re_step) FROM board_free where ref = ? and re_level = ?");
				pstmt.setInt(1, ref);
				pstmt.setInt(2, re_level);
				rs = pstmt.executeQuery();

				if (rs.next()) {
					if (re_step == 0) {
						re_step = rs.getInt(1) + 1;
					}
				} else
					re_step = 0; // 첫번 째 글

			} else { // 부모글인 경우 글번호 없음
				ref = number;
				re_step = 0;
				re_level = 0;
			} // if

			// insert 처리 명령
			sb = new StringBuffer();
			sb.append("INSERT INTO BOARD_free(NUM,ID , TITLE, CONTENT,"
					+ "  REG_DATE,  REF  , RE_STEP,RE_LEVEL,image   ) ");
			sb.append("VALUES(BOARD_free_NUM.NEXTVAL,  ?, ?, ?, ?, ?, ?,?, ?)");

			pstmt = conn.prepareStatement(sb.toString());
			pstmt.setString(1, vo.getId());
			pstmt.setString(2, vo.getTitle());
			pstmt.setString(3, vo.getContent());
			/* pstmt.setString(5, vo.getPasswd()); */
			pstmt.setTimestamp(4, vo.getReg_date());
			/*
			 * pstmt.setInt(7, ref); //// 수정 pstmt.setInt(8, vo.getRe_step());
			 * pstmt.setInt(9, vo.getRe_level());
			 */
			pstmt.setInt(5, ref); //// 수정
			pstmt.setInt(6, re_step);
			pstmt.setInt(7, re_level);
			pstmt.setString(8, vo.getImage());

			/* pstmt.setString(10, vo.getIp()); */

			pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		} finally {
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // try

		return 1;
	}// insert(Board_FreeVO)

	public int delete_free(int num) { // 삭제할 넘버 추가
		Connection conn = null; // 연결 x
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int result = 0;
		try {
			conn = getConnection();// db연결 성공
			pstmt = conn.prepareStatement("DELETE BOARD_free WHERE NUM = ?");
			// 연결된 db에서 넘버값 받아오기
			pstmt.setInt(1, num);

			rs = pstmt.executeQuery();
			result = 1; // 글삭제 성공

		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // end try
		return result;
	}// 고객 delete free

	public Board_FreeVO update_free(int num) {

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Board_FreeVO vo = null;
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement("select *from board_free where num =?");
			pstmt.setInt(1, num);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				vo = new Board_FreeVO();
				vo.setNum(rs.getInt("num"));
				vo.setId(rs.getString("id"));
				vo.setTitle(rs.getString("title"));
				vo.setReg_date(rs.getTimestamp("reg_date"));
				vo.setReadcount(rs.getInt("readcount"));
				vo.setRef(rs.getInt("ref"));
				vo.setRe_level(rs.getInt("re_level"));
				vo.setRe_step(rs.getInt("re_step"));
				vo.setContent(rs.getString("content"));

			} // if

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		return vo;
	}// end update

	// update(vo) -글수정시 처리함수
	public int update_free(Board_FreeVO vo) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		String sql = "";
		int result = -1;
		try {
			conn = getConnection();

			pstmt = conn.prepareStatement("select * from board_free where num =?");
			pstmt.setInt(1, vo.getNum());
			rs = pstmt.executeQuery();

			sql = "update board_free set id=? ,title=? ,";
			sql += "content=? where num =?";

			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, vo.getId());

			pstmt.setString(2, vo.getTitle());

			pstmt.setString(3, vo.getContent());
			pstmt.setInt(4, vo.getNum());

			pstmt.executeUpdate();
			result = 1;

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}

		return result;
	}// end update free

	public Board_FreeVO getDataDetail_free(int num) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Board_FreeVO vo = null;
		String sql = "";
		String sql2 = "";

		try {
			conn = getConnection();
			sql = "update board_free set readcount = readcount + 1 where num = ?";
			sql2 = "select * from board_free where num=?";

			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, num);
			pstmt.executeUpdate();

			pstmt = conn.prepareStatement(sql2);
			pstmt.setInt(1, num);

			rs = pstmt.executeQuery();

			if (rs.next()) {
				vo = new Board_FreeVO();
				vo.setNum(rs.getInt("num"));
				vo.setId(rs.getString("id"));
				vo.setReg_date(rs.getTimestamp("reg_date"));
				vo.setTitle(rs.getString("title"));
				vo.setContent(rs.getString("content"));// 글내용
				vo.setImage(rs.getString("image"));

			} // if end

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}

		return vo;
	} // end getDataDetail(int num)

	public int getListAllCount_free() {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		int count = 0;

		try {
			conn = getConnection();

			pstmt = conn.prepareStatement("SELECT COUNT(*) FROM board_free");
			rs = pstmt.executeQuery();

			if (rs.next()) {
				count = rs.getInt(1);
			} // if

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // try
		System.out.println("count: " + count);
		return count;
	}// getListAllCount_free()

	// getSelectAll(start, end) - list.jsp
	public List<Board_FreeVO> getSelectAll_free(int start, int end) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<Board_FreeVO> list = null;

		try {
			conn = getConnection();

			System.out.println("test>>>>conn");

			StringBuffer sb = new StringBuffer();

			sb.append("SELECT NUM, id, title, content, REG_DATE, readcount,  ref, re_step, re_level,image  ,R  ");
			sb.append(
					" FROM(SELECT NUM, id, title, content, REG_DATE, readcount, ref, re_step, re_level ,image ,ROWNUM R ");
			sb.append(" FROM(SELECT NUM, id, title, content, REG_DATE, readcount, ref, re_step, re_level,image  ");
			sb.append(
					" FROM board_free ORDER BY num desc, REF DESC, RE_STEP ASC) ORDER BY REF DESC, RE_LEVEL ASC) WHERE R>=? AND R<=? ");

			pstmt = conn.prepareStatement(sb.toString());
			pstmt.setInt(1, start);
			pstmt.setInt(2, end);
			rs = pstmt.executeQuery();
			System.out.println("test>>>>1");
			if (rs.next()) {
				list = new ArrayList<Board_FreeVO>(end);
				System.out.println("test>>>>2");
				do {
					Board_FreeVO vo = new Board_FreeVO();
					vo.setNum(rs.getInt("num"));
					vo.setId(rs.getString("id"));
					vo.setTitle(rs.getString("title"));
					vo.setContent(rs.getString("content"));
					vo.setReg_date(rs.getTimestamp("reg_date"));
					vo.setReadcount(rs.getInt("readcount"));
					vo.setRef(rs.getInt("ref"));
					vo.setRe_step(rs.getInt("re_step"));
					vo.setRe_level(rs.getInt("re_level"));
					vo.setImage(rs.getString("image"));

					list.add(vo);

				} while (rs.next());
			} // if end
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}

		return list;
	} // end getSelectAll(start, end) Board_FreeVO

	// 게시판 - 구합니다
	// board_buy DB insert
	public int insert(Board_BuyVO vo) {
		Connection conn = null;
		PreparedStatement pstmt = null;

		String sql = "insert into board_buy(num, id, title, content, reg_date, readcount,  ref, re_step, re_level, image,favorite ) "
				+ "values(board_buy_num.nextval, ?, ?, ?, ?, ?, ?, ?, ?, ?,?)";

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, vo.getId());
			pstmt.setString(2, vo.getTitle());
			pstmt.setString(3, vo.getContent());
			pstmt.setTimestamp(4, vo.getReg_date());
			pstmt.setInt(5, vo.getReadcount());
			pstmt.setInt(6, vo.getRef());
			pstmt.setInt(7, vo.getRe_step());
			pstmt.setInt(8, vo.getRe_level());
			pstmt.setString(9, vo.getImage());
			pstmt.setInt(10, vo.getFavorite());

			pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		} finally {
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // try

		return 1;
	}// insert(Board_BuyVO)

	public int getListAllCount_buy() {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		int count = 0;

		try {
			conn = getConnection();

			pstmt = conn.prepareStatement("SELECT COUNT(*) FROM board_buy");
			rs = pstmt.executeQuery();

			if (rs.next()) {
				count = rs.getInt(1);
			} // if

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // try
		System.out.println("count: " + count);
		return count;
	}// getListAllCount()

	// getSelectAll(start, end) - list.jsp
	public List<Board_BuyVO> getSelectAll_buy(int start, int end) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<Board_BuyVO> list = null;

		try {
			conn = getConnection();

			System.out.println("test>>>>conn");

			StringBuffer sb = new StringBuffer();

			sb.append(
					"SELECT NUM, id, title, content, REG_DATE, readcount,  ref, re_step, re_level,image ,favorite ,R  ");
			sb.append(
					" FROM(SELECT NUM, id, title, content, REG_DATE, readcount, ref, re_step, re_level ,image ,favorite,ROWNUM R ");
			sb.append(
					" FROM(SELECT NUM, id, title, content, REG_DATE, readcount, ref, re_step, re_level,image ,favorite ");
			sb.append(
					" FROM board_buy ORDER BY num desc, REF DESC, RE_STEP ASC) ORDER BY REF DESC, RE_LEVEL ASC) WHERE R>=? AND R<=? ");

			pstmt = conn.prepareStatement(sb.toString());
			pstmt.setInt(1, start);
			pstmt.setInt(2, end);
			rs = pstmt.executeQuery();
			System.out.println("test>>>>1");
			if (rs.next()) {
				list = new ArrayList<Board_BuyVO>(end);
				System.out.println("test>>>>2");
				do {
					Board_BuyVO vo = new Board_BuyVO();
					vo.setNum(rs.getInt("num"));
					vo.setId(rs.getString("id"));
					vo.setTitle(rs.getString("title"));
					vo.setContent(rs.getString("content"));
					vo.setReg_date(rs.getTimestamp("reg_date"));
					vo.setReadcount(rs.getInt("readcount"));
					vo.setRef(rs.getInt("ref"));
					vo.setRe_step(rs.getInt("re_step"));
					vo.setRe_level(rs.getInt("re_level"));
					vo.setImage(rs.getString("image"));
					vo.setFavorite(rs.getInt("favorite"));

					list.add(vo);

				} while (rs.next());
			} // if end
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}

		return list;
	} // end getSelectAll(start, end) Board_BuyVO

	//// buy 디테일
	public Board_BuyVO getDataDetail_buy(int num) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Board_BuyVO vo = null;
		String sql = "";
		String sql2 = "";
		String sql3 = "";
		try {
			conn = getConnection();

			sql = "update board_buy set readcount = readcount + 1 where num = ?";
			sql2 = "select * from board_buy where num=?";

			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, num);
			pstmt.executeUpdate();

			pstmt = conn.prepareStatement(sql2);
			pstmt.setInt(1, num);

			rs = pstmt.executeQuery();

			if (rs.next()) {
				vo = new Board_BuyVO();
				vo.setNum(rs.getInt("num"));
				vo.setId(rs.getString("id"));
				vo.setReg_date(rs.getTimestamp("reg_date"));
				vo.setTitle(rs.getString("title"));
				vo.setContent(rs.getString("content"));// 글내용
				vo.setFavorite(rs.getInt("favorite"));
				vo.setReadcount(rs.getInt("readcount"));
			} // if end

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}

		return vo;
	} // end getDataDetail(int num)

	public Board_BuyVO getDataDetail_buy_hi(int num) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Board_BuyVO vo = null;
		String sql = "";
		String sql2 = "";
		String sql3 = "";
		try {
			conn = getConnection();

			sql2 = "select * from board_buy where num=?";
			sql3 = "update board_buy set favorite= favorite+1 where num=?";

			pstmt = conn.prepareStatement(sql3);
			pstmt.setInt(1, num);
			pstmt.executeUpdate();

			pstmt = conn.prepareStatement(sql2);
			pstmt.setInt(1, num);

			rs = pstmt.executeQuery();

			if (rs.next()) {
				vo = new Board_BuyVO();
				vo.setNum(rs.getInt("num"));
				vo.setId(rs.getString("id"));
				vo.setReg_date(rs.getTimestamp("reg_date"));
				vo.setTitle(rs.getString("title"));
				vo.setContent(rs.getString("content"));// 글내용
				vo.setFavorite(rs.getInt("favorite"));
				vo.setReadcount(rs.getInt("readcount"));
			} // if end

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}

		return vo;
	}

	// buy 삭제
	public int delete_buy(int num) { // 삭제할 넘버 추가
		Connection conn = null; // 연결 x
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int result = 0;
		try {
			conn = getConnection();// db연결 성공
			pstmt = conn.prepareStatement("DELETE BOARD_buy WHERE NUM = ?");
			// 연결된 db에서 넘버값 받아오기
			pstmt.setInt(1, num);

			rs = pstmt.executeQuery();
			result = 1; // 글삭제 성공

		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // end try
		return result;
	}// 고객 delete

	public Board_BuyVO update_buy(int num) {

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Board_BuyVO vo = null;
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement("select *from board_buy where num =?");
			pstmt.setInt(1, num);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				vo = new Board_BuyVO();
				vo.setNum(rs.getInt("num"));
				vo.setId(rs.getString("id"));
				vo.setTitle(rs.getString("title"));
				vo.setReg_date(rs.getTimestamp("reg_date"));
				vo.setReadcount(rs.getInt("readcount"));
				vo.setRef(rs.getInt("ref"));
				vo.setRe_level(rs.getInt("re_level"));
				vo.setRe_step(rs.getInt("re_step"));
				vo.setContent(rs.getString("content"));

			} // if

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		return vo;
	}// end update

	// update(vo) -글수정시 처리함수
	public int update_buy(Board_BuyVO vo) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		String sql = "";
		int result = -1;
		try {
			conn = getConnection();

			pstmt = conn.prepareStatement("select * from board_buy where num =?");
			pstmt.setInt(1, vo.getNum());
			rs = pstmt.executeQuery();

			sql = "update board_buy set id=? ,title=? ,";
			sql += "content=? where num =?";

			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, vo.getId());

			pstmt.setString(2, vo.getTitle());

			pstmt.setString(3, vo.getContent());
			pstmt.setInt(4, vo.getNum());

			pstmt.executeUpdate();
			result = 1;

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}

		return result;
	}// end update buy

	// 게시판 - 고객센터

	// board_customer DB insert
	public int insert(Board_CustomerVO vo) {

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		// 답변 글인지 일반(새 게시글)인지 구분해서 입력 시키는 로직
		int num = vo.getNum(); // 내부적 부모 글번호
		int ref = vo.getRef(); // 부모의 ref(그룹 번호)
		int re_step = vo.getRe_step(); // 부모의 그룹 내 순서
		int re_level = vo.getRe_level(); // 부모의 re_level
		int number = 0; // board 테이블에 들어갈 번호
		StringBuffer sb = new StringBuffer();

		try {

			conn = getConnection(); // 연결

			// 현재 board테이블에 레코드 유무 판단과 글 번호 지정
			pstmt = conn.prepareStatement("SELECT MAX(NUM) FROM board_customer");
			rs = pstmt.executeQuery();

			if (rs.next()) {
				number = rs.getInt(1) + 1; // 1 : num, 다음 글 번호는 가장 큰 번호 +1
			} else
				number = 1; // 첫번 째 글

			// 제목글과 답변글 간의 순서 결정
			if (num != 0) { // 답변글
				re_level = re_level + 1;

				pstmt = conn.prepareStatement("SELECT MAX(re_step) FROM board_customer where ref = ? and re_level = ?");
				pstmt.setInt(1, ref);
				pstmt.setInt(2, re_level);
				rs = pstmt.executeQuery();

				if (rs.next()) {
					if (re_step == 0) {
						re_step = rs.getInt(1) + 1;
					}
				} else
					re_step = 0; // 첫번 째 글

			} else { // 부모글인 경우 글번호 없음
				ref = number;
				re_step = 0;
				re_level = 0;
			} // if

			// insert 처리 명령
			sb = new StringBuffer();
			sb.append("INSERT INTO BOARD_CUSTOMER(NUM,ID , TITLE, CONTENT,"
					+ "  REG_DATE,  REF  , RE_STEP,RE_LEVEL   ) ");
			sb.append("VALUES(BOARD_CUSTOMER_NUM.NEXTVAL,  ?, ?, ?, ?, ?, ?, ?)");

			pstmt = conn.prepareStatement(sb.toString());
			pstmt.setString(1, vo.getId());
			pstmt.setString(2, vo.getTitle());

			pstmt.setString(3, vo.getContent());
			/* pstmt.setString(5, vo.getPasswd()); */
			pstmt.setTimestamp(4, vo.getReg_date());
			/*
			 * pstmt.setInt(7, ref); //// 수정 pstmt.setInt(8, vo.getRe_step());
			 * pstmt.setInt(9, vo.getRe_level());
			 */
			pstmt.setInt(5, ref); //// 수정
			pstmt.setInt(6, re_step);
			pstmt.setInt(7, re_level);
			/* pstmt.setString(10, vo.getIp()); */

			pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		} finally {
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // try

		return 1;
	}// insert(Board_CustomerVO)

	public int getListAllCount() {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		int count = 0;

		try {
			conn = getConnection();

			pstmt = conn.prepareStatement("SELECT COUNT(*) FROM BOARD_CUSTOMER");
			rs = pstmt.executeQuery();

			if (rs.next()) {
				count = rs.getInt(1);
			} // if

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // try
		System.out.println("count: " + count);
		return count;
	}// getListAllCount()

	// getSelectAll(start, end) - list.jsp
	public List<Board_CustomerVO> getSelectAll(int start, int end) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<Board_CustomerVO> list = null;

		try {
			conn = getConnection();

			System.out.println("test>>>>conn");

			StringBuffer sb = new StringBuffer();
			/*
			 * sb.append(
			 * "SELECT NUM, WRITER, EMAIL, TITLE, PASSWD, REG_DATE, REF, RE_STEP, RE_LEVEL, CONTENT, IP, READCOUNT, R "
			 * );
			 */
			sb.append("SELECT NUM, id, title, content, REG_DATE, readcount,  ref, re_step, re_level,R  ");
			sb.append(" FROM(SELECT NUM, id, title, content, REG_DATE, readcount, ref, re_step, re_level ,ROWNUM R ");
			sb.append(" FROM(SELECT NUM, id, title, content, REG_DATE, readcount, ref, re_step, re_level ");
			sb.append(
					" FROM BOARD_CUSTOMER ORDER BY num desc, REF DESC, RE_STEP ASC) ORDER BY REF DESC, RE_LEVEL ASC) WHERE R>=? AND R<=? order by R desc");

			pstmt = conn.prepareStatement(sb.toString());
			pstmt.setInt(1, start);
			pstmt.setInt(2, end);
			rs = pstmt.executeQuery();
			System.out.println("test>>>>1");
			if (rs.next()) {
				list = new ArrayList<Board_CustomerVO>(end);
				System.out.println("test>>>>2");
				do {
					Board_CustomerVO vo = new Board_CustomerVO();
					vo.setNum(rs.getInt("num"));

					vo.setId(rs.getString("id"));
					vo.setTitle(rs.getString("title"));
					vo.setContent(rs.getString("content"));

					vo.setReg_date(rs.getTimestamp("reg_date"));
					vo.setReadcount(rs.getInt("readcount"));

					vo.setRef(rs.getInt("ref"));
					vo.setRe_step(rs.getInt("re_step"));
					vo.setRe_level(rs.getInt("re_level"));

					// list 媛앹껜�뿉 �뜲�씠�꽣 ���옣鍮덉씤 BoardVO 媛앹껜�뿉 ���옣
					list.add(vo);

				} while (rs.next());
			} // if end
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}

		return list;
	} // end getSelectAll(start, end) customer board

	public int delete(int num) { // 삭제할 넘버 추가
		Connection conn = null; // 연결 x
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int result = 0;
		try {
			conn = getConnection();// db연결 성공
			pstmt = conn.prepareStatement("DELETE BOARD_CUSTOMER WHERE NUM = ?");
			// 연결된 db에서 넘버값 받아오기
			pstmt.setInt(1, num);

			rs = pstmt.executeQuery();
			result = 1; // 글삭제 성공

		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // end try
		return result;
	}// 고객 delete

	public Board_CustomerVO getDataDetail(int num) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Board_CustomerVO vo = null;
		String sql = "";
		String sql2 = "";

		try {
			conn = getConnection();

			sql = "update board_customer set readcount = readcount + 1 where num = ?";
			sql2 = "select * from board_customer where num=?";

			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, num);
			pstmt.executeUpdate();

			pstmt = conn.prepareStatement(sql2);
			pstmt.setInt(1, num);

			rs = pstmt.executeQuery();

			rs = pstmt.executeQuery();

			if (rs.next()) {
				vo = new Board_CustomerVO();
				vo.setNum(rs.getInt("num"));
				vo.setId(rs.getString("id"));
				vo.setReg_date(rs.getTimestamp("reg_date"));
				vo.setTitle(rs.getString("title"));
				vo.setContent(rs.getString("content"));// 글내용

			} // if end

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}

		return vo;
	} // end Board_CustomerVO getDataDetail(int num)

	public Board_CustomerVO update(int num) {

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Board_CustomerVO vo = null;
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement("select *from board_customer where num =?");
			pstmt.setInt(1, num);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				vo = new Board_CustomerVO();
				vo.setNum(rs.getInt("num"));
				vo.setId(rs.getString("id"));
				vo.setTitle(rs.getString("title"));
				vo.setReg_date(rs.getTimestamp("reg_date"));
				vo.setReadcount(rs.getInt("readcount"));
				vo.setRef(rs.getInt("ref"));
				vo.setRe_level(rs.getInt("re_level"));
				vo.setRe_step(rs.getInt("re_step"));
				vo.setContent(rs.getString("content"));

			} // if

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		return vo;
	}// end update

	// update(vo) -글수정시 처리함수
	public int update(Board_CustomerVO vo) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		String sql = "";
		int result = -1;
		try {
			conn = getConnection();

			pstmt = conn.prepareStatement("select * from board_customer where num =?");
			pstmt.setInt(1, vo.getNum());
			rs = pstmt.executeQuery();

			sql = "update board_customer set id=? ,title=? ,";
			sql += "content=? where num =?";

			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, vo.getId());

			pstmt.setString(2, vo.getTitle());

			pstmt.setString(3, vo.getContent());
			pstmt.setInt(4, vo.getNum());

			pstmt.executeUpdate();
			result = 1;

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}

		return result;
	}// end update

	// 게시판 - 신고해요
	// board_declare DB insert
	public int insert(Board_DeclareVO vo) {
		Connection conn = null;
		PreparedStatement pstmt = null;

		String sql = "insert into board_Declare(num, id, title, content, reg_date, readcount, ref, re_step, re_level) "
				+ "values(board_declare_num.nextval,  ?, ?, ?, ?, ?, ?, ?, ?)";

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, vo.getId());
			pstmt.setString(2, vo.getTitle());
			pstmt.setString(3, vo.getContent());
			pstmt.setTimestamp(4, vo.getReg_date());
			pstmt.setInt(5, vo.getReadcount());
			pstmt.setInt(6, vo.getRef());
			pstmt.setInt(7, vo.getRe_step());
			pstmt.setInt(8, vo.getRe_level());

			pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		} finally {
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // try

		return 1;
	}// insert(Board_DeclareVO)

	//////////////////////////////
	//// 신고해요! 삭제
	///////////////////////
	public int delete_declare(int num) { // 삭제할 넘버 추가
		Connection conn = null; // 연결 x
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int result = 0;
		try {
			conn = getConnection();// db연결 성공
			pstmt = conn.prepareStatement("DELETE BOARD_declare WHERE NUM = ?");
			// 연결된 db에서 넘버값 받아오기
			pstmt.setInt(1, num);

			rs = pstmt.executeQuery();
			result = 1; // 글삭제 성공

		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // end try
		return result;
	}// declare delete

	public Board_DeclareVO update_declare(int num) {

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Board_DeclareVO vo = null;
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement("select * from board_declare where num =?");
			pstmt.setInt(1, num);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				vo = new Board_DeclareVO();
				vo.setNum(rs.getInt("num"));
				vo.setId(rs.getString("id"));
				vo.setTitle(rs.getString("title"));
				vo.setReg_date(rs.getTimestamp("reg_date"));
				vo.setReadcount(rs.getInt("readcount"));
				vo.setRef(rs.getInt("ref"));
				vo.setRe_level(rs.getInt("re_level"));
				vo.setRe_step(rs.getInt("re_step"));
				vo.setContent(rs.getString("content"));

			} // if

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		return vo;
	}// end update declare

	/////
	// declare 업데이트
	/////

	public int update_declare(Board_DeclareVO vo) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		String sql = "";
		int result = -1;
		try {
			conn = getConnection();

			pstmt = conn.prepareStatement("select * from board_declare where num =?");
			pstmt.setInt(1, vo.getNum());
			rs = pstmt.executeQuery();

			sql = "update board_declare set id=? ,title=? ,";
			sql += "content=? where num =?";

			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, vo.getId());

			pstmt.setString(2, vo.getTitle());

			pstmt.setString(3, vo.getContent());
			pstmt.setInt(4, vo.getNum());

			pstmt.executeUpdate();
			result = 1;

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}

		return result;
	}// end update declare

	////////////////////
	/// declare dedail
	//////////////////
	public Board_DeclareVO getDataDetail_declare(int num) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Board_DeclareVO vo = null;
		String sql = "";
		String sql2 = "";

		try {
			conn = getConnection();

			sql = "update board_declare set readcount = readcount + 1 where num = ?";
			sql2 = "select * from board_declare where num=?";

			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, num);
			pstmt.executeUpdate();

			pstmt = conn.prepareStatement(sql2);
			pstmt.setInt(1, num);

			rs = pstmt.executeQuery();

			if (rs.next()) {
				vo = new Board_DeclareVO();
				vo.setNum(rs.getInt("num"));
				vo.setId(rs.getString("id"));
				vo.setReg_date(rs.getTimestamp("reg_date"));
				vo.setTitle(rs.getString("title"));
				vo.setContent(rs.getString("content"));// 글내용
				vo.setReadcount(rs.getInt("readcount"));
			} // if end

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}

		return vo;
	} // end getDataDetail(int num)

	///////////// 신고해요 게시판

	public int getListAllCount_declare() {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		int count = 0;

		try {
			conn = getConnection();

			pstmt = conn.prepareStatement("SELECT COUNT(*) FROM board_declare");
			rs = pstmt.executeQuery();

			if (rs.next()) {
				count = rs.getInt(1);
			} // if

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // try
		System.out.println("count: " + count);
		return count;
	}// getListAllCount_declare()

	// getSelectAll(start, end) - list.jsp
	public List<Board_DeclareVO> getSelectAll_declare(int start, int end) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<Board_DeclareVO> list = null;

		try {
			conn = getConnection();

			System.out.println("test>>>>conn");

			StringBuffer sb = new StringBuffer();

			sb.append("SELECT NUM, id, title, content, REG_DATE, readcount,  ref, re_step, re_level  ,R  ");
			sb.append(" FROM(SELECT NUM, id, title, content, REG_DATE, readcount, ref, re_step, re_level  ,ROWNUM R ");
			sb.append(" FROM(SELECT NUM, id, title, content, REG_DATE, readcount, ref, re_step, re_level  ");
			sb.append(
					" FROM board_declare ORDER BY num desc, REF DESC, RE_STEP ASC) ORDER BY REF DESC, RE_LEVEL ASC) WHERE R>=? AND R<=? order by R");

			pstmt = conn.prepareStatement(sb.toString());
			pstmt.setInt(1, start);
			pstmt.setInt(2, end);
			rs = pstmt.executeQuery();
			System.out.println("test>>>>1");
			if (rs.next()) {
				list = new ArrayList<Board_DeclareVO>(end);
				System.out.println("test>>>>2");
				do {
					Board_DeclareVO vo = new Board_DeclareVO();
					vo.setNum(rs.getInt("num"));
					vo.setId(rs.getString("id"));
					vo.setTitle(rs.getString("title"));
					vo.setContent(rs.getString("content"));
					vo.setReg_date(rs.getTimestamp("reg_date"));
					vo.setReadcount(rs.getInt("readcount"));
					vo.setRef(rs.getInt("ref"));
					vo.setRe_step(rs.getInt("re_step"));
					vo.setRe_level(rs.getInt("re_level"));

					list.add(vo);

				} while (rs.next());
			} // if end
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}

		return list;
	} // end getSelectAll(start, end) Board_Declare

	// 게시판 - 자유게시판 - 검색 결과
	public List<Board_FreeVO> getBoard_Free_Search(int startRow, int endRow, String select_Search, String text_Search) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<Board_FreeVO> list = new ArrayList<Board_FreeVO>();

		String sql = "";
		if (select_Search.equals("ID")) {
			sql = "select B.* from (select C.*, rownum R from (select * from board_free where id like ? order by num desc) C where rownum <= ?) B where R >= ?";
		} else {
			sql = "select B.* from (select C.*, rownum R from (select * from board_free where title like ? order by num desc) C where rownum <= ?) B where R >= ?";
		} // if

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, "%" + text_Search + "%");
			pstmt.setInt(2, endRow);
			pstmt.setInt(3, startRow);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				do {
					Board_FreeVO vo = new Board_FreeVO();
					vo.setNum(rs.getInt("num"));
					vo.setId(rs.getString("id"));
					vo.setTitle(rs.getString("title"));
					vo.setContent(rs.getString("content"));
					vo.setReg_date(rs.getTimestamp("reg_date"));
					vo.setReadcount(rs.getInt("readcount"));
					vo.setRef(rs.getInt("ref"));
					vo.setRe_step(rs.getInt("re_step"));
					vo.setRe_level(rs.getInt("re_level"));
					vo.setImage(rs.getString("image"));

					list.add(vo);
				} while (rs.next());
			} // if

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // try

		return list;
	}

	// 게시판 - 자유게시판 - 검색 결과 count
	public int getBoard_Free_Search_count(String select_Search, String text_Search) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		int count = 0;
		ResultSet rs = null;

		String sql = "";
		if (select_Search.equals("ID")) {
			sql = "select count(*) from board_free where id like ?";
		} else {
			sql = "select count(*) from board_free where title like ?";
		} // if

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, "%" + text_Search + "%");
			rs = pstmt.executeQuery();

			if (rs.next()) {
				count = rs.getInt(1);
			} // if

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // try

		return count;
	}

	// 게시판 - 구합니다게시판 - 검색 결과
	public List getBoard_buy_Search(int startRow, int endRow, String select_Search, String text_Search) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<Board_BuyVO> list = new ArrayList<Board_BuyVO>();

		String sql = "";
		if (select_Search.equals("ID")) {
			sql = "select B.* from (select C.*, rownum R from (select * from board_buy where id like ? order by num desc) C where rownum <= ?) B where R >= ?";
		} else {
			sql = "select B.* from (select C.*, rownum R from (select * from board_buy where title like ? order by num desc) C where rownum <= ?) B where R >= ?";
		} // if

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, "%" + text_Search + "%");
			pstmt.setInt(2, endRow);
			pstmt.setInt(3, startRow);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				do {
					Board_BuyVO vo = new Board_BuyVO();
					vo.setNum(rs.getInt("num"));
					vo.setId(rs.getString("id"));
					vo.setTitle(rs.getString("title"));
					vo.setContent(rs.getString("content"));
					vo.setReg_date(rs.getTimestamp("reg_date"));
					vo.setReadcount(rs.getInt("readcount"));
					vo.setRef(rs.getInt("ref"));
					vo.setRe_step(rs.getInt("re_step"));
					vo.setRe_level(rs.getInt("re_level"));
					vo.setImage(rs.getString("image"));
					vo.setFavorite(rs.getInt("favorite"));

					list.add(vo);
				} while (rs.next());
			} // if

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // try

		return list;
	}

	// 게시판 - 구합니다게시판 - 검색결과 count
	public int getBoard_buy_Search_count(String select_Search, String text_Search) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		int count = 0;
		ResultSet rs = null;

		String sql = "";
		if (select_Search.equals("ID")) {
			sql = "select count(*) from board_buy where id like ?";
		} else {
			sql = "select count(*) from board_buy where title like ?";
		} // if

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, "%" + text_Search + "%");
			rs = pstmt.executeQuery();

			if (rs.next()) {
				count = rs.getInt(1);
			} // if

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // try

		return count;
	}

	// 게시판 - 고객센터 게시판 - 검색 결과
	public List getBoard_Customer_Search(int startRow, int endRow, String select_Search, String text_Search) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<Board_CustomerVO> list = new ArrayList<Board_CustomerVO>();

		String sql = "";
		if (select_Search.equals("ID")) {
			sql = "select B.* from (select C.*, rownum R from (select * from board_customer where id like ? order by num desc) C where rownum <= ?) B where R >= ?";
		} else {
			sql = "select B.* from (select C.*, rownum R from (select * from board_customer where title like ? order by num desc) C where rownum <= ?) B where R >= ?";
		} // if

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, "%" + text_Search + "%");
			pstmt.setInt(2, endRow);
			pstmt.setInt(3, startRow);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				do {
					Board_CustomerVO vo = new Board_CustomerVO();
					vo.setNum(rs.getInt("num"));
					vo.setId(rs.getString("id"));
					vo.setTitle(rs.getString("title"));
					vo.setContent(rs.getString("content"));
					vo.setReg_date(rs.getTimestamp("reg_date"));
					vo.setReadcount(rs.getInt("readcount"));
					vo.setRef(rs.getInt("ref"));
					vo.setRe_step(rs.getInt("re_step"));
					vo.setRe_level(rs.getInt("re_level"));

					list.add(vo);
				} while (rs.next());
			} // if

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // try

		return list;
	}

	// 게시판 - 고객센터 게시판 - 검색 결과 count
	public int getBoard_Customer_Search_count(String select_Search, String text_Search) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		int count = 0;
		ResultSet rs = null;

		String sql = "";
		if (select_Search.equals("ID")) {
			sql = "select count(*) from board_customer where id like ?";
		} else {
			sql = "select count(*) from board_customer where title like ?";
		} // if

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, "%" + text_Search + "%");
			rs = pstmt.executeQuery();

			if (rs.next()) {
				count = rs.getInt(1);
			} // if

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // try

		return count;
	}

	// 게시판 - 신고해요 게시판 - 검색 결과
	public List getBoard_Declare_Search(int startRow, int endRow, String select_Search, String text_Search) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<Board_DeclareVO> list = new ArrayList<Board_DeclareVO>();

		String sql = "";
		if (select_Search.equals("ID")) {
			sql = "select B.* from (select C.*, rownum R from (select * from board_declare where id like ? order by num desc) C where rownum <= ?) B where R >= ?";
		} else {
			sql = "select B.* from (select C.*, rownum R from (select * from board_declare where title like ? order by num desc) C where rownum <= ?) B where R >= ?";
		} // if

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, "%" + text_Search + "%");
			pstmt.setInt(2, endRow);
			pstmt.setInt(3, startRow);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				do {
					Board_DeclareVO vo = new Board_DeclareVO();
					vo.setNum(rs.getInt("num"));
					vo.setId(rs.getString("id"));
					vo.setTitle(rs.getString("title"));
					vo.setContent(rs.getString("content"));
					vo.setReg_date(rs.getTimestamp("reg_date"));
					vo.setReadcount(rs.getInt("readcount"));
					vo.setRef(rs.getInt("ref"));
					vo.setRe_step(rs.getInt("re_step"));
					vo.setRe_level(rs.getInt("re_level"));

					list.add(vo);
				} while (rs.next());
			} // if

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // try

		return list;
	}

	// 게시판 - 고객센터 게시판 - 검색 결과 count
	public int getBoard_Declare_Search_count(String select_Search, String text_Search) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		int count = 0;
		ResultSet rs = null;

		String sql = "";
		if (select_Search.equals("ID")) {
			sql = "select count(*) from board_declare where id like ?";
		} else {
			sql = "select count(*) from board_declare where title like ?";
		} // if

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, "%" + text_Search + "%");
			rs = pstmt.executeQuery();

			if (rs.next()) {
				count = rs.getInt(1);
			} // if

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // try

		return count;
	}

	// guest_book 전체 글 수 몇개인지.
	public int getClothesCount(String your_id) throws Exception {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int x = 0;
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement("select count(*) from clothes where cl_id=?");
			pstmt.setString(1, your_id);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				x = rs.getInt(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		return x;
	}

	// getMy_Clothes (내 옷 리스트로 보기)
	public List getClothes(String your_id) throws Exception {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List ClothesList = null;
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement("SELECT CL_IMAGE1, CL_TITLE, CL_PRICE, CL_NUM FROM CLOTHES WHERE CL_ID = ?");
			pstmt.setString(1, your_id);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				ClothesList = new ArrayList();
				do {
					ClothesVO vo = new ClothesVO();
					vo.setCl_image1(rs.getString("CL_IMAGE1"));
					vo.setCl_title(rs.getString("CL_TITLE"));
					vo.setCl_price(rs.getInt("CL_PRICE"));
					vo.setCl_num(rs.getInt("CL_NUM"));
					ClothesList.add(vo);
				} while (rs.next());
			} // if end
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		return ClothesList;
	}

	// getClothes()
	public List getClothes(int start, int end, String your_id) throws Exception {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List clothesList = null;

		String sql = "select B.* from (select C.*, rownum R from (select cl_num, cl_image1, cl_title, cl_price, rownum rnum from clothes where cl_id=? order by cl_num desc) C where rownum <= ?) B where R >= ?";
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, your_id);
			pstmt.setInt(2, end);
			pstmt.setInt(3, start);

			rs = pstmt.executeQuery();

			if (rs.next()) {
				clothesList = new ArrayList(end);
				do {
					ClothesVO vo = new ClothesVO();
					vo.setCl_num(rs.getInt("cl_num"));
					vo.setCl_image1(rs.getString("cl_image1"));
					vo.setCl_title(rs.getString("cl_title"));
					vo.setCl_price(rs.getInt("cl_price"));
					vo.setRnum(rs.getInt("rnum"));
					vo.setCl_id(your_id);
					clothesList.add(vo);
				} while (rs.next());
			} // if end
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		return clothesList;
	}// getClothes() end

	// 내옷장보기
	public int getClothesSearch_Count(int startRow, int endRow, String personal_id) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int count = 0;

		String sql = "select count(*) from clothes where cl_id=?";
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, personal_id);

			rs = pstmt.executeQuery();

			if (rs.next()) {
				count = rs.getInt(1);
			} // if end
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}

		return count;
	}

	// mypage - 팔로우 목록 - 마음에 드는옷 팔로우
	public List<ClothesVO> getBasket(String my_id) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<ClothesVO> list = new ArrayList<ClothesVO>();

		String sql = "select c.* from CLOTHES c, basket b where c.cl_num = b.cl_num and b.my_id=?";

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, my_id);

			rs = pstmt.executeQuery();

			if (rs.next()) {
				do {
					ClothesVO vo = new ClothesVO();

					vo.setCl_num(rs.getInt("cl_num"));
					vo.setCl_id(rs.getString("cl_id"));
					vo.setCl_image1(rs.getString("cl_image1"));
					vo.setCl_image2(rs.getString("cl_image2"));
					vo.setCl_image3(rs.getString("cl_image3"));
					vo.setCl_title(rs.getString("cl_title"));
					vo.setCl_content(rs.getString("cl_content"));
					vo.setCl_condition(rs.getString("cl_condition"));
					vo.setCl_size(rs.getString("cl_size"));
					vo.setCl_type(rs.getString("cl_type"));
					vo.setCl_area(rs.getString("cl_area"));
					vo.setCl_gender(rs.getString("cl_gender"));
					vo.setCl_price(rs.getInt("cl_price"));
					vo.setCl_hope(rs.getString("cl_hope"));
					vo.setCl_deal(rs.getString("cl_deal"));
					vo.setCl_favorite(rs.getInt("cl_favorite"));

					list.add(vo);
				} while (rs.next());
			} // if
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // try

		return list;
	}// getBasket

	// mypage - 팔로우 - 마음에 드는 사람 팔로우
	public List<MemberVO> getBookmark(String my_id) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<MemberVO> list = new ArrayList<MemberVO>();

		String sql = "select m.* from MEMBER m, BOOKMARK b where b.your_id = m.m_id and b.my_id = ? ";

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, my_id);

			rs = pstmt.executeQuery();

			if (rs.next()) {
				do {
					MemberVO vo = new MemberVO();

					vo.setM_id(rs.getString("m_id"));
					vo.setM_passwd(rs.getString("m_passwd"));
					vo.setM_name(rs.getString("m_name"));
					vo.setM_tel(rs.getString("m_tel"));
					vo.setM_addr(rs.getString("m_addr"));
					vo.setM_email(rs.getString("m_email"));
					vo.setM_point(rs.getInt("m_point"));

					list.add(vo);
				} while (rs.next());
			} // if
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // try

		return list;
	}

	// mypage - 팔로우 - 마음에 드는 사람 팔로우 - 프로필 보기
	public List<Member_ProfileVO> profileImageList_Bookmark(List<MemberVO> list) {

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<Member_ProfileVO> profileList = new ArrayList<Member_ProfileVO>();

		String sql = "select m2.* from member m1, MEMBER_PROFILE m2 where m1.m_id = m2.p_id and m1.m_id = ?";

		try {
			conn = getConnection();

			System.out.println(list.size());

			for (int i = 0; i < list.size(); i++) {

				pstmt = conn.prepareStatement(sql);
				MemberVO ex = (MemberVO) list.get(i);
				pstmt.setString(1, ex.getM_id());
				rs = pstmt.executeQuery();

				if (rs.next()) {
					Member_ProfileVO vo = new Member_ProfileVO();
					vo.setP_id(rs.getString("p_id"));
					vo.setP_height(rs.getString("p_height"));
					vo.setP_weight(rs.getString("p_weight"));
					vo.setP_self(rs.getString("p_self"));
					vo.setP_area(rs.getString("p_area"));
					vo.setP_image(rs.getString("p_image"));
					vo.setP_message(rs.getString("p_message"));

					profileList.add(vo);
				} // if

			} // for
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // try

		return profileList;
	}

	// 게시글 팔로우 DB 존재여부
	public int check_basket(String my_id, int cl_num) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		String sql = "select * from basket where my_id=? and cl_num=?";

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, my_id);
			pstmt.setInt(2, cl_num);

			rs = pstmt.executeQuery();

			if (rs.next()) {
				return 0; // DB에 존재
			} else {
				return 1; // DB에 존재 x
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // try

		return 1; // DB에 존재 x
	}

	// 게시글 팔로우 등록
	public int insert(BasketVO vo) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		int check = 0;

		String sql = "insert into basket values(basket_num.nextval, ?, ?)";

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, vo.getMy_id());
			pstmt.setInt(2, vo.getCl_num());

			check = pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // try

		return check;
	}// insert(BasketVO)

	// 게시글 팔로우 삭제
	public void delete_basket(String my_id, int cl_num) {
		Connection conn = null;
		PreparedStatement pstmt = null;

		String sql = "delete from basket where my_id=? and cl_num=?";

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, my_id);
			pstmt.setInt(2, cl_num);

			pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // try
	}// delete

	// 아이디로 프로필 이미지 검색
	public Member_ProfileVO getProfile(String personal_id) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Member_ProfileVO vo = null;

		String sql = "select * from member_profile where p_id = ?";

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, personal_id);

			rs = pstmt.executeQuery();

			if (rs.next()) {
				vo = new Member_ProfileVO();
				vo.setP_id(rs.getString("p_id"));
				vo.setP_height(rs.getString("p_height"));
				vo.setP_weight(rs.getString("p_weight"));
				vo.setP_self(rs.getString("p_self"));
				vo.setP_area(rs.getString("p_area"));
				vo.setP_image(rs.getString("p_image"));
				vo.setP_message(rs.getString("p_message"));
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // try

		return vo;
	}

	//// cody count list//////////

	public int getListAllCount_CodyHelpImage() {

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int count = 0;

		String sql = "select count(*) from board_coordi";

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				count = rs.getInt(1);
			} // if

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}

		return count;
	}

	//////
	////////// cody list
	public List<Member_ProfileVO> helpProfileImageList(List<Board_CoordiVO> list) {

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<Member_ProfileVO> profileList = new ArrayList();

		String sql = "select m.* from board_coordi c, MEMBER_PROFILE m where c.id = m.p_id and c.num = ?";

		try {
			conn = getConnection();

			System.out.println(list.size());

			for (int i = 0; i < list.size(); i++) {

				pstmt = conn.prepareStatement(sql);
				Board_CoordiVO ex = (Board_CoordiVO) list.get(i);
				pstmt.setInt(1, ex.getNum());
				rs = pstmt.executeQuery();

				if (rs.next()) {
					Member_ProfileVO vo = new Member_ProfileVO();
					vo.setP_id(rs.getString("p_id"));
					vo.setP_height(rs.getString("p_height"));
					vo.setP_weight(rs.getString("p_weight"));
					vo.setP_self(rs.getString("p_self"));
					vo.setP_area(rs.getString("p_area"));
					vo.setP_image(rs.getString("p_image"));
					vo.setP_message(rs.getString("p_message"));

					profileList.add(vo);
				} // if

			} // for
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // try

		return profileList;
	}

	//////// cody list ///////
	/// 좋아요순 정렬////////

	public List<Board_CoordiVO> codiHelpList(int startRow, int endRow, String check) {

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List list = null;

		String sql = "";

		// select check
		if (check.equals("1")) { // 최신순 정렬
			sql = "select B.* from (select C.*, rownum R from (select * from board_coordi order by num desc) C where rownum <= ?) B where R >= ?";
		} else if (check.equals("2")) { // 좋아요순 정렬
			sql = "select B.* from (select C.*, rownum R from (select * from board_coordi order by favorite desc, num desc) C where rownum <= ?) B where R >= ?";
		} else { // 조회수

		}

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, endRow);
			pstmt.setInt(2, startRow);
			rs = pstmt.executeQuery();

			System.out.println("dao start:" + startRow);
			System.out.println("dao end:" + endRow);

			if (rs.next()) {
				list = new ArrayList(endRow);

				do {
					Board_CoordiVO vo = new Board_CoordiVO();
					vo.setNum(rs.getInt("num"));
					vo.setId(rs.getString("id"));
					vo.setTitle(rs.getString("title"));
					vo.setContent(rs.getString("content"));
					vo.setReg_date(rs.getTimestamp("reg_date"));
					vo.setReadcount(rs.getInt("readcount"));
					vo.setRef(rs.getInt("ref"));
					vo.setRe_step(rs.getInt("re_step"));
					vo.setRe_level(rs.getInt("re_level"));
					vo.setImage1(rs.getString("image1"));
					vo.setImage2(rs.getString("image2"));
					vo.setImage3(rs.getString("image3"));
					vo.setFavorite(rs.getInt("favorite"));

					list.add(vo);

				} while (rs.next());
			} // if

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // try

		System.out.println("DAO:" + list.size());

		return list;
	}

	public Board_CoordiVO delete_cody(int num) {
		Connection conn = null;
		PreparedStatement pstmt = null;

		Board_CoordiVO vo = null;
		String sql = "";

		try {
			conn = getConnection();

			pstmt = conn.prepareStatement("delete  board_coordi WHERE NUM = ?");
			pstmt.setInt(1, num);
			pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} // try
		return vo;
	}// getDataDetail() cody delete

	public Board_CoordiVO getDataDetail_Coordi(int num) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Board_CoordiVO vo = null;
		/*
		 * String sql = "";//조회수
		 */ String sql2 = "";// 가져올 게시판 번호

		try {
			conn = getConnection();

			/*
			 * sql =
			 * "update board_coordi set readcount = readcount + 1 where num = ?"
			 * ;
			 */
			sql2 = "select * from board_coordi where num=?";

			/*
			 * pstmt = conn.prepareStatement(sql); pstmt.setInt(1, num);
			 * pstmt.executeUpdate();
			 */

			pstmt = conn.prepareStatement(sql2);
			pstmt.setInt(1, num);

			/* rs = pstmt.executeQuery(); */

			rs = pstmt.executeQuery();

			if (rs.next()) {
				vo = new Board_CoordiVO();
				vo.setNum(rs.getInt("num"));
				vo.setId(rs.getString("id"));
				vo.setReg_date(rs.getTimestamp("reg_date"));
				vo.setTitle(rs.getString("title"));
				vo.setContent(rs.getString("content"));// 글내용
				vo.setImage1(rs.getString("image1"));
				vo.setImage2(rs.getString("image2"));
				vo.setImage3(rs.getString("image3"));
				vo.setFavorite(rs.getInt("favorite"));

				System.out.println("image1:" + rs.getString("image1"));
				System.out.println("image2:" + rs.getString("image2"));
				System.out.println("image3:" + rs.getString("image3"));

			} // if end

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}

		return vo;
	} // end getDataDetail codyHelpContentAction(int num)

	public Board_CoordiVO update_cody(int num) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Board_CoordiVO vo = null;
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement("select * from board_coordi where num =?");
			pstmt.setInt(1, num);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				vo = new Board_CoordiVO();
				vo.setNum(rs.getInt("num"));
				vo.setId(rs.getString("id"));
				vo.setTitle(rs.getString("title"));
				vo.setReg_date(rs.getTimestamp("reg_date"));
				vo.setReadcount(rs.getInt("readcount"));
				vo.setRef(rs.getInt("ref"));
				vo.setRe_level(rs.getInt("re_level"));
				vo.setRe_step(rs.getInt("re_step"));
				vo.setContent(rs.getString("content"));
				vo.setImage1(rs.getString("image1"));
				vo.setImage2(rs.getString("image2"));
				vo.setImage3(rs.getString("image3"));
			} // if

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		return vo;
	}// Board_CoordiVO update

	public int update_cody(Board_CoordiVO vo) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		// rs=업데이트에는 필용없다
		String sql = "update board_coordi set content=?, title=? ,image1=? " + ",image2=?, image3=? where num=?";
		// 내용, 제목, 이미지3개 삽입
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			System.out.println("sql=" + sql);


			pstmt.setString(1, vo.getContent());
			System.out.println("vo.getContent()=" + vo.getContent());
			pstmt.setString(2, vo.getTitle());
			System.out.println("vo.getTitle()=" + vo.getTitle());
			pstmt.setString(3, vo.getImage1());
			System.out.println("vo.getImage1=" + vo.getImage1());
			pstmt.setString(4, vo.getImage2());
			System.out.println("vo.getImage2=" + vo.getImage2());
			pstmt.setString(5, vo.getImage3());
			System.out.println("vo.getImage3=" + vo.getImage3());
			pstmt.setInt(6, vo.getNum());
			System.out.println("daoNum" + vo.getNum());
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();

		} finally {
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);

		}
		return 1;
	}// update(Board_CoodiVO)

	// 회원보기
	// SiteMemberView DAO 추가부분

	// 회원보기1
	public int getListAllCount_MemberProfile() {

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int count = 0;

		String sql = "select count(*) from (select your_id from member_profile, bookmark  where p_id=your_id GROUP BY your_id)";

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				count = rs.getInt(1);
			} // if

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}

		return count;
	}

	// 프로필 정보 뺴오기 - 팔로우순
	public List<Member_ProfileVO> profileImageList_FollowRank(List<BookmarkVO> list) {

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<Member_ProfileVO> profileList = new ArrayList();

		String sql = "select m.* from member_profile m, (select your_id from bookmark GROUP by your_id) b where p_id=your_id and your_id=?";

		try {
			conn = getConnection();

			System.out.println(list.size());

			for (int i = 0; i < list.size(); i++) {

				pstmt = conn.prepareStatement(sql);
				BookmarkVO ex = (BookmarkVO) list.get(i);
				pstmt.setString(1, ex.getYour_id());
				rs = pstmt.executeQuery();

				if (rs.next()) {
					Member_ProfileVO vo = new Member_ProfileVO();
					vo.setP_id(rs.getString("p_id"));
					vo.setP_image(rs.getString("p_image"));
					vo.setP_message(rs.getString("p_message"));

					profileList.add(vo);
				} // if

			} // for
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // try

		return profileList;
	}

	// 팔로우 많이 받은 top6
	public List<BookmarkVO> siteMemberView_FollowRank(int start, int end) {

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List list = null;

		String sql = "";

		// select check

		sql = "select * from (select * from (select your_id, follow, rownum r from "
				+ "(select your_id, count(your_id) follow from member , bookmark  where m_id=your_id "
				+ "GROUP BY your_id order by count(your_id)desc)) where r<=?) where r>=?";

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, end);
			pstmt.setInt(2, start);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				list = new ArrayList();

				do {
					BookmarkVO vo = new BookmarkVO();
					vo.setYour_id(rs.getString("your_id"));
					vo.setFollow(rs.getInt("follow"));

					list.add(vo);

				} while (rs.next());
			} // if

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // try

		System.out.println("DAO:" + list.size());

		return list;
	}

	// 회원보기2
	public int getListAllCount_MemberProfile2() {

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int count = 0;

		String sql = "select count(*) from ( select seller_id id from deal_complete union all select buyer_id from deal_complete)";
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				count = rs.getInt(1);
			} // if

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}

		return count;
	}

	// 거래성사내역 top6
	public List<Deal_CompleteVO> siteMemberView_DealRank(int start, int end) {

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List list2 = null;

		String sql = "";

		// select check

		sql = "select * from (select id, deal, rownum r from "
				+ "(select id, count(id) deal from (select seller_id id from deal_complete union all "
				+ "select buyer_id from deal_complete) group by id order by count(id) desc, id) "
				+ "where rownum<=?) where r >=?";

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, end);
			pstmt.setInt(2, start);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				list2 = new ArrayList();

				do {
					Deal_CompleteVO vo = new Deal_CompleteVO();
					vo.setId(rs.getString("id"));
					vo.setDeal(rs.getInt("deal"));
					list2.add(vo);

				} while (rs.next());
			} // if

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // try

		System.out.println("DAO:" + list2.size());

		return list2;
	}

	// 프로필 정보 뺴오기 - 팔로우순
	public List<Member_ProfileVO> profileImageList_DealRank(List<Deal_CompleteVO> list) {

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<Member_ProfileVO> profileList2 = new ArrayList();

		String sql = "select m.* from member_profile m, (select id from "
				+ "(select seller_id id from deal_complete union all select buyer_id from deal_complete) group by id) d where p_id=id and id=?";

		try {
			conn = getConnection();

			System.out.println(list.size());

			for (int i = 0; i < list.size(); i++) {

				pstmt = conn.prepareStatement(sql);
				Deal_CompleteVO ex = (Deal_CompleteVO) list.get(i);
				pstmt.setString(1, ex.getId());
				rs = pstmt.executeQuery();

				if (rs.next()) {
					Member_ProfileVO vo = new Member_ProfileVO();
					vo.setP_id(rs.getString("p_id"));
					vo.setP_image(rs.getString("p_image"));
					vo.setP_message(rs.getString("p_message"));

					profileList2.add(vo);
				} // if

			} // for
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // try

		return profileList2;
	}

	// 04-14 멤버 뷰 검색 추가부분

	// 사이트멤버 뷰 - 검색 결과
	public List<Member_ProfileVO> getSiteMemberView_Search(int startRow, int endRow, String select_Search,
			String text_Search) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<Member_ProfileVO> list = new ArrayList<Member_ProfileVO>();

		String sql = "";
		if (select_Search.equals("ID")) {
			sql = "select B.* from (select C.*, rownum R from (select * from MEMBER_PROFILE where p_id like ? order by p_id) C where rownum <= ?) B where R >= ?";
		} else {
			sql = "select B.* from (select C.*, rownum R from (select * from MEMBER_PROFILE where p_message like ? order by p_message) C where rownum <= ?) B where R >= ?";
		} // if

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, "%" + text_Search + "%");
			pstmt.setInt(2, endRow);
			pstmt.setInt(3, startRow);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				do {
					Member_ProfileVO vo = new Member_ProfileVO();
					vo.setP_id(rs.getString("p_id"));
					vo.setP_height(rs.getString("p_height"));
					vo.setP_weight(rs.getString("p_weight"));
					vo.setP_self(rs.getString("p_self"));
					vo.setP_area(rs.getString("p_area"));
					vo.setP_image(rs.getString("p_image"));
					vo.setP_message(rs.getString("p_message"));

					list.add(vo);
				} while (rs.next());
			} // if

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // try

		return list;
	}

	// 사이트멤버 뷰 - 검색 결과 count
	public int getSiteMemberView_Search_count(String select_Search, String text_Search) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		int count = 0;
		ResultSet rs = null;

		try {
			conn = getConnection();
			if (select_Search.equals("ID")) {
				String sql = "select count(*) from member_profile where p_id like ?";
				pstmt = conn.prepareStatement(sql);
			} else {
				String sql = "select count(*) from member_profile where p_message like ?";
				pstmt = conn.prepareStatement(sql);
			}
			pstmt.setString(1, "%" + text_Search + "%");
			rs = pstmt.executeQuery();

			if (rs.next()) {
				count = rs.getInt(1);
			} // if

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // try

		return count;
	}

	// 프로필 정보 뺴오기 - 검색
	public List<Member_ProfileVO> profileImageList_Search(String select_Search, String text_Search) {

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<Member_ProfileVO> profileList = new ArrayList();

		try {
			conn = getConnection();
			if (select_Search.equals("ID")) {
				String sql = "select * from member_profile where p_id like ?";
				pstmt = conn.prepareStatement(sql);
			} else {
				String sql = "select * from member_profile where p_message like ?";
				pstmt = conn.prepareStatement(sql);
			}
			for (int i = 0; i < profileList.size(); i++) {

				pstmt.setString(1, "%" + text_Search + "%");
				rs = pstmt.executeQuery();

				if (rs.next()) {
					Member_ProfileVO vo = new Member_ProfileVO();
					vo.setP_id(rs.getString("p_id"));
					vo.setP_image(rs.getString("p_image"));
					vo.setP_message(rs.getString("p_message"));

					profileList.add(vo);
				} // if

			} // for
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // try

		return profileList;
	}

	// 거래성사 테이블의 m_id의 구매내역 수
	public int deal_BuyComplete_Count(String m_id) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int count = 0;

		String sql = "select count(*) from deal_complete where buyer_id=?";

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, m_id);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				count = rs.getInt(1);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}

		return count;
	}

	// 거래성사 테이블의 m_id의 구매내역
	public List deal_BuyComplate_List(int startRow, int endRow, String m_id) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<Deal_CompleteVO> list = new ArrayList<Deal_CompleteVO>();

		String sql = "select B.* from (select a.*, rownum R from (select d.seller_id, d.seller_cl_num, c1.cl_title as seller_cl_title, d.buyer_id, d.buyer_cl_num, c2.cl_title as buyer_cl_title, d.reg_date from deal_complete d, CLOTHES_COMPLETE c1, CLOTHES_COMPLETE c2 where d.seller_cl_num = c1.cl_num and d.buyer_cl_num = c2.cl_num and d.buyer_id=? order by num desc) a where rownum <= ?) B where R >= ?";

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, m_id);
			pstmt.setInt(2, endRow);
			pstmt.setInt(3, startRow);

			rs = pstmt.executeQuery();

			if (rs.next()) {
				do {
					Deal_CompleteVO vo = new Deal_CompleteVO();
					vo.setSeller_id(rs.getString(1));
					vo.setSeller_cl_num(rs.getInt(2));
					vo.setSeller_cl_title(rs.getString(3));
					vo.setBuyer_id(rs.getString(4));
					vo.setBuyer_cl_num(rs.getInt(5));
					vo.setBuyer_cl_title(rs.getString(6));
					vo.setReg_date(rs.getTimestamp(7));

					list.add(vo);
				} while (rs.next());
			} // if

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		return list;
	}

	// 거래성사 테이블의 m_id의 구매내역 검색
	public List deal_BuyComplate_List_Search(int startRow, int endRow, String m_id, String select_Search,
			String text_Search) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<Deal_CompleteVO> list = new ArrayList<Deal_CompleteVO>();

		String sql = "";
		if (select_Search.equals("판매자 ID")) {
			sql = "select B.* from (select a.*, rownum R from (select d.seller_id, d.seller_cl_num, c1.cl_title as seller_cl_title, d.buyer_id, d.buyer_cl_num, c2.cl_title as buyer_cl_title, d.reg_date from deal_complete d, CLOTHES_COMPLETE c1, CLOTHES_COMPLETE c2 where d.seller_cl_num = c1.cl_num and d.buyer_cl_num = c2.cl_num and d.buyer_id=? and d.seller_id like ? order by num desc) a where rownum <= ?) B where R >= ?";
		} else if (select_Search.equals("판매글 제목")) {
			sql = "select B.* from (select a.*, rownum R from (select d.seller_id, d.seller_cl_num, c1.cl_title as seller_cl_title, d.buyer_id, d.buyer_cl_num, c2.cl_title as buyer_cl_title, d.reg_date from deal_complete d, CLOTHES_COMPLETE c1, CLOTHES_COMPLETE c2 where d.seller_cl_num = c1.cl_num and d.buyer_cl_num = c2.cl_num and d.buyer_id=? and c1.cl_title like ? order by num desc) a where rownum <= ?) B where R >= ?";
		} else {
			sql = "select B.* from (select a.*, rownum R from (select d.seller_id, d.seller_cl_num, c1.cl_title as seller_cl_title, d.buyer_id, d.buyer_cl_num, c2.cl_title as buyer_cl_title, d.reg_date from deal_complete d, CLOTHES_COMPLETE c1, CLOTHES_COMPLETE c2 where d.seller_cl_num = c1.cl_num and d.buyer_cl_num = c2.cl_num and d.buyer_id=? and d.seller_cl_num = ? order by num desc) a where rownum <= ?) B where R >= ?";
		}

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, m_id);
			if (select_Search.equals("판매글 글번호")) {
				pstmt.setInt(2, Integer.parseInt(text_Search));
			} else {
				pstmt.setString(2, "%" + text_Search + "%");
			}
			pstmt.setInt(3, endRow);
			pstmt.setInt(4, startRow);

			rs = pstmt.executeQuery();

			if (rs.next()) {
				do {
					Deal_CompleteVO vo = new Deal_CompleteVO();
					vo.setSeller_id(rs.getString(1));
					vo.setSeller_cl_num(rs.getInt(2));
					vo.setSeller_cl_title(rs.getString(3));
					vo.setBuyer_id(rs.getString(4));
					vo.setBuyer_cl_num(rs.getInt(5));
					vo.setBuyer_cl_title(rs.getString(6));
					vo.setReg_date(rs.getTimestamp(7));

					list.add(vo);
				} while (rs.next());
			} // if

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // try
		return list;
	}

	// 거래성사 테이블의 m_id의 구매내역 검색 결과 레코드 수
	public int deal_BuyComplate_List_Search_count(String m_id, String select_Search, String text_Search) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int count = 0;

		String sql = "";
		if (select_Search.equals("판매자 ID")) {
			sql = "select count(*) from deal_complete d, CLOTHES_COMPLETE c1, CLOTHES_COMPLETE c2 where d.seller_cl_num = c1.cl_num and d.buyer_cl_num = c2.cl_num and d.buyer_id=? and d.seller_id like ?";
		} else if (select_Search.equals("판매글 제목")) {
			sql = "select count(*) from deal_complete d, CLOTHES_COMPLETE c1, CLOTHES_COMPLETE c2 where d.seller_cl_num = c1.cl_num and d.buyer_cl_num = c2.cl_num and d.buyer_id=? and c1.cl_title like ?";
		} else {
			sql = "select count(*) from deal_complete d, CLOTHES_COMPLETE c1, CLOTHES_COMPLETE c2 where d.seller_cl_num = c1.cl_num and d.buyer_cl_num = c2.cl_num and d.buyer_id=? and d.seller_cl_num = ?";
		}

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, m_id);
			if (select_Search.equals("판매글 글번호")) {
				pstmt.setInt(2, Integer.parseInt(text_Search));
			} else {
				pstmt.setString(2, "%" + text_Search + "%");
			} // if

			rs = pstmt.executeQuery();

			if (rs.next()) {
				count = rs.getInt(1);
			} // if

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		return count;
	}

	// 거래성사 테이블의 m_id의 판매내역 수
	public int deal_SellComplete_Count(String m_id) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int count = 0;

		String sql = "select count(*) from deal_complete where seller_id=?";

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, m_id);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				count = rs.getInt(1);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}

		return count;
	}

	// 거래성사 테이블의 m_id의 판매내역
	public List deal_SellComplate_List(int startRow, int endRow, String m_id) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<Deal_CompleteVO> list = new ArrayList<Deal_CompleteVO>();

		String sql = "select B.* from (select a.*, rownum R from (select d.seller_id, d.seller_cl_num, c1.cl_title as seller_cl_title, d.buyer_id, d.buyer_cl_num, c2.cl_title as buyer_cl_title, d.reg_date from deal_complete d, CLOTHES_COMPLETE c1, CLOTHES_COMPLETE c2 where d.seller_cl_num = c1.cl_num and d.buyer_cl_num = c2.cl_num and d.seller_id=? order by num desc) a where rownum <= ?) B where R >= ?";

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, m_id);
			pstmt.setInt(2, endRow);
			pstmt.setInt(3, startRow);

			rs = pstmt.executeQuery();

			if (rs.next()) {
				do {
					Deal_CompleteVO vo = new Deal_CompleteVO();
					vo.setSeller_id(rs.getString(1));
					vo.setSeller_cl_num(rs.getInt(2));
					vo.setSeller_cl_title(rs.getString(3));
					vo.setBuyer_id(rs.getString(4));
					vo.setBuyer_cl_num(rs.getInt(5));
					vo.setBuyer_cl_title(rs.getString(6));
					vo.setReg_date(rs.getTimestamp(7));

					list.add(vo);
				} while (rs.next());
			} // if

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		return list;
	}

	// 거래성사 테이블의 m_id의 판매내역 검색
	public List deal_SellComplate_List_Search(int startRow, int endRow, String m_id, String select_Search,
			String text_Search) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<Deal_CompleteVO> list = new ArrayList<Deal_CompleteVO>();

		String sql = "";
		if (select_Search.equals("구매자 ID")) {
			sql = "select B.* from (select a.*, rownum R from (select d.seller_id, d.seller_cl_num, c1.cl_title as seller_cl_title, d.buyer_id, d.buyer_cl_num, c2.cl_title as buyer_cl_title, d.reg_date from deal_complete d, CLOTHES_COMPLETE c1, CLOTHES_COMPLETE c2 where d.seller_cl_num = c1.cl_num and d.buyer_cl_num = c2.cl_num and d.seller_id=? and d.buyer_id like ? order by num desc) a where rownum <= ?) B where R >= ?";
		} else if (select_Search.equals("구매글 제목")) {
			sql = "select B.* from (select a.*, rownum R from (select d.seller_id, d.seller_cl_num, c1.cl_title as seller_cl_title, d.buyer_id, d.buyer_cl_num, c2.cl_title as buyer_cl_title, d.reg_date from deal_complete d, CLOTHES_COMPLETE c1, CLOTHES_COMPLETE c2 where d.seller_cl_num = c1.cl_num and d.buyer_cl_num = c2.cl_num and d.seller_id=? and c2.cl_title like ? order by num desc) a where rownum <= ?) B where R >= ?";
		} else {
			sql = "select B.* from (select a.*, rownum R from (select d.seller_id, d.seller_cl_num, c1.cl_title as seller_cl_title, d.buyer_id, d.buyer_cl_num, c2.cl_title as buyer_cl_title, d.reg_date from deal_complete d, CLOTHES_COMPLETE c1, CLOTHES_COMPLETE c2 where d.seller_cl_num = c1.cl_num and d.buyer_cl_num = c2.cl_num and d.seller_id=? and d.buyer_cl_num = ? order by num desc) a where rownum <= ?) B where R >= ?";
		}

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, m_id);
			if (select_Search.equals("구매글 글번호")) {
				pstmt.setInt(2, Integer.parseInt(text_Search));
			} else {
				pstmt.setString(2, "%" + text_Search + "%");
			}
			pstmt.setInt(3, endRow);
			pstmt.setInt(4, startRow);

			rs = pstmt.executeQuery();

			if (rs.next()) {
				do {
					Deal_CompleteVO vo = new Deal_CompleteVO();
					vo.setSeller_id(rs.getString(1));
					vo.setSeller_cl_num(rs.getInt(2));
					vo.setSeller_cl_title(rs.getString(3));
					vo.setBuyer_id(rs.getString(4));
					vo.setBuyer_cl_num(rs.getInt(5));
					vo.setBuyer_cl_title(rs.getString(6));
					vo.setReg_date(rs.getTimestamp(7));

					list.add(vo);
				} while (rs.next());
			} // if

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		return list;
	}

	// 거래성사 테이블의 m_id의 판매내역 검색결과 레코드 수
	public int deal_SellComplate_List_Search_count(String m_id, String select_Search, String text_Search) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int count = 0;

		String sql = "";
		if (select_Search.equals("구매자 ID")) {
			sql = "select count(*) from deal_complete d, CLOTHES_COMPLETE c1, CLOTHES_COMPLETE c2 where d.seller_cl_num = c1.cl_num and d.buyer_cl_num = c2.cl_num and d.seller_id=? and d.buyer_id like ?";
		} else if (select_Search.equals("구매글 제목")) {
			sql = "select count(*) from deal_complete d, CLOTHES_COMPLETE c1, CLOTHES_COMPLETE c2 where d.seller_cl_num = c1.cl_num and d.buyer_cl_num = c2.cl_num and d.seller_id=? and c2.cl_title like ?";
		} else {
			sql = "select count(*) from deal_complete d, CLOTHES_COMPLETE c1, CLOTHES_COMPLETE c2 where d.seller_cl_num = c1.cl_num and d.buyer_cl_num = c2.cl_num and d.seller_id=? and d.buyer_cl_num = ?";
		}

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, m_id);
			if (select_Search.equals("구매글 글번호")) {
				pstmt.setInt(2, Integer.parseInt(text_Search));
			} else {
				pstmt.setString(2, "%" + text_Search + "%");
			}

			rs = pstmt.executeQuery();

			if (rs.next()) {
				count = rs.getInt(1);
			} // if

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}

		return count;
	}

	// 마음에 드는 사람 즐겨찾기(팔로우) 확인
	public int check_bookmark(String my_id, String personal_id) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		String sql = "select * from bookmark where my_id=? and your_id=?";

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, my_id);
			pstmt.setString(2, personal_id);

			rs = pstmt.executeQuery();

			if (rs.next()) {
				return 0; // DB에 존재
			} else {
				return 1; // DB에 존재 x
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(rs);
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // try

		return 1; // DB에 존재 x
	}

	// 마음에 드는 사람 즐겨찾기(팔로우) 해제
	public void delete_bookmark(String my_id, String personal_id) {
		Connection conn = null;
		PreparedStatement pstmt = null;

		String sql = "delete from bookmark where my_id=? and your_id=?";

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, my_id);
			pstmt.setString(2, personal_id);

			pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // try

	}

	// 거래완료 clothes_complete DB 가져오기
	public Clothes_CompleteVO getDataDetail_ClothesComplete(int cl_num) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		Clothes_CompleteVO vo = null;
		String sql = "";

		try {
			conn = getConnection();

			pstmt = conn.prepareStatement("SELECT * FROM clothes_complete WHERE CL_NUM = ?");
			pstmt.setInt(1, cl_num);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				vo = new Clothes_CompleteVO();
				vo.setCl_num(rs.getInt("cl_num"));
				vo.setCl_id(rs.getString("cl_id"));
				vo.setCl_image1(rs.getString("cl_image1"));
				vo.setCl_image2(rs.getString("cl_image2"));
				vo.setCl_image3(rs.getString("cl_image3"));
				vo.setCl_title(rs.getString("cl_title"));
				vo.setCl_content(rs.getString("cl_content"));
				vo.setCl_condition(rs.getString("cl_condition"));
				vo.setCl_size(rs.getString("cl_size"));
				vo.setCl_type(rs.getString("cl_type"));
				vo.setCl_area(rs.getString("cl_area"));
				vo.setCl_gender(rs.getString("cl_gender"));
				vo.setCl_price(rs.getInt("cl_price"));
				vo.setCl_hope(rs.getString("cl_hope"));
				vo.setCl_deal(rs.getString("cl_deal"));
				vo.setCl_favorite(rs.getInt("cl_favorite"));
			}

		} catch (Exception e) {
			e.printStackTrace();

		} // try

		return vo;
	}

	// insert Deal_CompleteVO
	public int insert(Deal_CompleteVO vo) {
		Connection conn = null;
		PreparedStatement pstmt = null;

		String sql = "insert into deal_complete(num, seller_id, buyer_id, seller_cl_num, buyer_cl_num, reg_date) "
				+ "values(deal_complete_num.nextval, ?, ?, ?, ?, ?)";

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, vo.getSeller_id());
			pstmt.setString(2, vo.getBuyer_id());
			pstmt.setInt(3, vo.getSeller_cl_num());
			pstmt.setInt(4, vo.getBuyer_cl_num());
			pstmt.setTimestamp(5, vo.getReg_date());

			pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		} finally {
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		} // try
		return 1;
	}// insert(Deal_completeVO)

	// getBuyerData : 구매자의 정보를 리스트로 제공해줌
	public Wish_ListVO getBuyerData(int buyer_cl_num) throws Exception {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Wish_ListVO vo = new Wish_ListVO();
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement("select cl_image1, cl_title from clothes where cl_num=?");
			pstmt.setInt(1, buyer_cl_num);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				vo.setB_image(rs.getString("cl_image1"));
				vo.setB_title(rs.getString("cl_title"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return vo;
	}// getBuyerData

	// Wish_ListVO insert
	public int insert(Wish_ListVO vo2) {
		Connection conn = null;
		PreparedStatement pstmt = null;

		String sql = "insert into wish_list values(wish_list_num.nextval,?,?,?,?,?,?)";

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, vo2.getSeller_cl_num());
			pstmt.setInt(2, vo2.getBuyer_cl_num());
			pstmt.setString(3, vo2.getBuyer_id());
			pstmt.setString(4, vo2.getB_image());
			pstmt.setString(5, vo2.getB_title());
			pstmt.setTimestamp(6, vo2.getReg_date());

			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		} finally {
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}

		return 1;
	}// wish_listVO end

	// insertClothesComplete() : Clothes 테이블 값을 그대로 복사해 Clothes_complete 테이블에
	// 붙여넣기
	public int insertClothesComplete(int cl_num) {
		Connection conn = null;
		PreparedStatement pstmt = null;

		String sql = "insert into clothes_complete select * from clothes where cl_num = ?";

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, cl_num);

			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		} finally {
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		return 1;
	}// insertClothesComplete end

	// deleteClothes() : cl_num을 받아와 clothes테이블 레코드를 지우는 메소드
	public int deleteClothes(int cl_num) {
		Connection conn = null;
		PreparedStatement pstmt = null;

		String sql = "delete from clothes where cl_num=?";
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, cl_num);

			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		} finally {
			CloseUtil.close(pstmt);
			CloseUtil.close(conn);
		}
		return 1;
	}// deleteClothes end

	// getWishList() : wish_list 테이블의 정보를 가져오는 메소드
	public List getWishList(int cl_num) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List wishList = null;
		String sql = "select * from wish_list where seller_cl_num=?";
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, cl_num);

			rs = pstmt.executeQuery();

			if (rs.next()) {
				wishList = new ArrayList();
				do {
					Wish_ListVO vo = new Wish_ListVO();
					vo.setNum(rs.getInt("num"));
					vo.setSeller_cl_num(rs.getInt("seller_cl_num"));
					vo.setBuyer_cl_num(rs.getInt("buyer_cl_num"));
					vo.setBuyer_id(rs.getString("buyer_id"));
					vo.setB_image(rs.getString("b_image"));
					vo.setB_title(rs.getString("b_title"));
					vo.setReg_date(rs.getTimestamp("Reg_date"));
					wishList.add(vo);
				} while (rs.next());
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(conn);
			CloseUtil.close(pstmt);
			CloseUtil.close(rs);
		}
		return wishList;
	}// getWishList() end

	public Board_CustomerVO getBoard_Customer(int num) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		Board_CustomerVO vo = null;
		
		String sql = "select * from board_customer where num = ?";
		
		try{
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, num);

			rs = pstmt.executeQuery();
			
			if(rs.next()){
				vo = new Board_CustomerVO();
				
				vo.setNum(rs.getInt("num"));
				vo.setId(rs.getString("id"));
				vo.setTitle(rs.getString("title"));
				vo.setContent(rs.getString("content"));
				vo.setReg_date(rs.getTimestamp("reg_date"));
				vo.setReadcount(rs.getInt("readcount"));
				
			}// if
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(conn);
			CloseUtil.close(pstmt);
			CloseUtil.close(rs);
		}
		
		return vo;
	}
	
	// 4/16 추가본
	
		public void favorite_insert(Board_CoordiVO actionobj) {
			
			Connection conn = null;
			PreparedStatement pstmt = null;
			PreparedStatement pstmt2 = null;
			String sql = "INSERT INTO BOARD_COORDI_FAVORITE VALUES(?,?,TO_CHAR(SYSDATE,'YYYY/MM/DD'))";
			String sql2 = "update BOARD_COORDI set FAVORITE=favorite+1 where num=?";
			
			try {
				conn = getConnection();
				pstmt = conn.prepareStatement(sql);
				
				System.out.println("favorite_insert");
				System.out.println(actionobj.getNum());
				System.out.println(actionobj.getId());

				pstmt.setInt(1, actionobj.getNum());
				pstmt.setString(2, actionobj.getId());
				
				pstmt.executeUpdate();
				
				pstmt2 = conn.prepareStatement(sql2);
				pstmt2.setInt(1, actionobj.getNum());
				pstmt2.executeUpdate();
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				CloseUtil.close(pstmt);
				CloseUtil.close(conn);
			}
		}// Board_CoordiVO favorite update
		
	public void favorite_delete(Board_CoordiVO actionobj) {
			
			Connection conn = null;
			PreparedStatement pstmt = null;
			PreparedStatement pstmt2 = null;
			String sql = "delete from BOARD_COORDI_FAVORITE where num=? and id=?";
			String sql2 = "update board_coordi set favorite=favorite-1 where num = ?";
			
			try {
				conn = getConnection();
				pstmt = conn.prepareStatement(sql);
				
				System.out.println("favorite_delete");
				System.out.println(actionobj.getNum());
				System.out.println(actionobj.getId());

				pstmt.setInt(1, actionobj.getNum());
				pstmt.setString(2, actionobj.getId());
				
				pstmt.executeUpdate();
				
				pstmt2 = conn.prepareStatement(sql2);
				pstmt2.setInt(1, actionobj.getNum());
				pstmt2.executeUpdate();
				
				
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				CloseUtil.close(pstmt);
				CloseUtil.close(conn);
			}
		}// Board_CoordiVO favorite delete
		
		public int getFavoriteCount(Board_CoordiVO actionobj) {
			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			Board_CoordiVO vo = null;
			int count = 0;
			String sql = "";
			
			try {
				conn = getConnection();

				sql = "select count(num) as count from board_coordi_favorite where num=? and id = ?";

				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, actionobj.getNum());
				pstmt.setString(2, actionobj.getId());

				rs = pstmt.executeQuery();

				if (rs.next()) {
					count = rs.getInt("count");

				} // if end

			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				CloseUtil.close(rs);
				CloseUtil.close(pstmt);
				CloseUtil.close(conn);
			}

			return count;
		} // end 
		
		// 상현이부분 추가
		
		public ClothesVO delete_cloth(int cl_num) {
			Connection conn = null;
			PreparedStatement pstmt = null;

			ClothesVO vo = null;

			try {
				conn = getConnection();

				pstmt = conn.prepareStatement("delete  clothes WHERE cl_NUM = ?");
				pstmt.setInt(1, cl_num);
				pstmt.executeUpdate();

			} catch (Exception e) {
				e.printStackTrace();
			} // try
			return vo;
		}// getDataDetail()


	////////delete'//////////////



	////////// update///////////form/////
	public ClothesVO update_cloth(int cl_num) {
			Connection conn =null;
			PreparedStatement pstmt =null;
			ResultSet rs =null;
			ClothesVO vo =null;
			try{
				conn =getConnection();
				pstmt = conn.prepareStatement("select * from clothes where cl_num =?");
				pstmt.setInt(1, cl_num);
				rs= pstmt.executeQuery();
				
				if(rs.next()){
				vo =new ClothesVO();
				vo.setCl_num(rs.getInt("cl_num"));
				vo.setCl_id(rs.getString("cl_id"));
				vo.setCl_image1(rs.getString("cl_image1"));
				vo.setCl_image2(rs.getString("cl_image2"));
				vo.setCl_image3(rs.getString("cl_image3"));
				vo.setCl_title(rs.getString("cl_title"));
				vo.setCl_content(rs.getString("cl_content"));
				vo.setCl_condition(rs.getString("cl_condition"));
				vo.setCl_size(rs.getString("cl_size"));
				vo.setCl_type(rs.getString("cl_type"));
				vo.setCl_area(rs.getString("cl_area"));
				vo.setCl_gender(rs.getString("cl_gender"));
				vo.setCl_price(rs.getInt("cl_price"));
				vo.setCl_hope(rs.getString("cl_hope"));
				vo.setCl_deal(rs.getString("cl_deal"));
				vo.setCl_favorite(rs.getInt("cl_favorite"));
				
				}//if
				
			}catch (Exception e) {
				e.printStackTrace();
			} finally {
				CloseUtil.close(rs);  CloseUtil.close(pstmt);  CloseUtil.close(conn);  
			}	
			return vo;
		}//ClothesVO update

		




		public int update_clothes(ClothesVO vo) {
			Connection conn = null;
			PreparedStatement pstmt = null;
			// rs=업데이트에는 필요없다
			String sql="";
			 sql = "update clothes set cl_image1=?,cl_image2=?, cl_image3=?, cl_title=?,cl_content=?"
					+ ",cl_condition=? ,cl_size=? ,cl_type=? ,cl_area=?,cl_gender=?,cl_price=?,cl_hope=?,cl_deal=? where cl_num=?";
					
			// 내용, 제목, 이미지3개 삽입
			try {
				conn = getConnection();
				pstmt = conn.prepareStatement(sql);
			
				pstmt.setString(1, vo.getCl_image1());
				pstmt.setString(2, vo.getCl_image2());
				pstmt.setString(3, vo.getCl_image3());
				pstmt.setString(4, vo.getCl_title());
				pstmt.setString(5, vo.getCl_content());
				System.out.println("vo.getCl_content="+vo.getCl_content());
				pstmt.setString(6, vo.getCl_condition());
				pstmt.setString(7, vo.getCl_size());
				pstmt.setString(8, vo.getCl_type());
				pstmt.setString(9, vo.getCl_area());
				pstmt.setString(10, vo.getCl_gender());
				pstmt.setInt(11, vo.getCl_price());
				pstmt.setString(12, vo.getCl_hope());
				pstmt.setString(13, vo.getCl_deal());
				System.out.println("바뀐 cl_deal(DAO)="+vo.getCl_deal());
				pstmt.setInt(14, vo.getCl_num());
				pstmt.executeUpdate();
			} catch (Exception e) {
				e.printStackTrace();

			} finally {
				CloseUtil.close(pstmt);
				CloseUtil.close(conn);

			}
			return 1;
		}// update(clothes)

}
