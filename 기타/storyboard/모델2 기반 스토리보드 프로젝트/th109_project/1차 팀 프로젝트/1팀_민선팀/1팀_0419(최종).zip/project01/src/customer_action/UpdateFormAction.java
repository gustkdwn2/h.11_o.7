package customer_action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import project.action.CommandAction;
import project.model.Board_CustomerVO;
import project.model.ProjectDAO;

public class UpdateFormAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		HttpSession session = request.getSession(); //전페이지에서 로그인 정보를 가져온다
		String m_id = (String) session.getAttribute("m_id");
		
		
		int num=0, ref=1,re_step=0,re_level=0;
		
		num = Integer.parseInt(request.getParameter("num"));
		ProjectDAO dao = ProjectDAO.getInstance();
		
		Board_CustomerVO vo = new Board_CustomerVO();
		vo = dao.getBoard_Customer(num);
		
		request.setAttribute("vo", vo);
	
		return "/board/updateForm.jsp";
	}

}
