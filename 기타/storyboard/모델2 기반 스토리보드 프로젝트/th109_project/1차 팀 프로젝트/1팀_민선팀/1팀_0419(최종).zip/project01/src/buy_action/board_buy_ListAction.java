package buy_action;

import java.text.SimpleDateFormat;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import project.action.CommandAction;
import project.model.ProjectDAO;

public class board_buy_ListAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("UTF-8");
		
		int pageSize = 7; //화면에 출력 레코드 수 
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");//날짜 sdf저장
		
		String pageNum = request.getParameter("pageNum");//전 페이지에 잇던 pagenum을 pagenum저장
		
		if( pageNum == null ) pageNum = "1"; //페이지가없을때 1을생성하여 첫페이지 생성
		
		int currentPage = Integer.parseInt(pageNum); //1 
		//string형인pagenum을 integer로 형변환
		
		int count = 0, number = 0;
		//  글개수         글번호
		List list = null;
		//리스트 선언
		ProjectDAO dao = ProjectDAO.getInstance(); //dao에서 밑을 선언해준내용을 dao에넣는다

		count = dao.getListAllCount_buy(); //전체 페이지 리턴
		
		//int startRow = (currentPage * pageSize) - 6;  // ( 1 * 7 ) - 6 = 1
		int startRow = (currentPage - 1) * pageSize + 1;  
		 //   시작 크기             페이지              *   게시판 크기
		int endRow = currentPage * pageSize ; // 1 * 7 = 7
		// 끝나는 크기=    페이지가 7을 넘을수없다
		
		//6		테이블에 저장된 글이 있다면...	//	1	,	7
		
		
		String select_Search = request.getParameter("select_Search");
		String text_Search = request.getParameter("text_Search");
		
		if(select_Search != null && text_Search != null){
			if( count > 0 ){
				list = dao.getBoard_buy_Search(startRow, endRow, select_Search, text_Search);
				count = dao.getBoard_buy_Search_count(select_Search, text_Search);
			}// if
		}else{
			if( count > 0 ) list = dao.getSelectAll_buy(startRow, endRow);
		}// else
		
		
		number = count - (currentPage - 1) * pageSize;
		
		
		//해당 뷰에서 사용할 속성 저장
		request.setAttribute("currentPage", new Integer(currentPage));//변수, 값
		request.setAttribute("startRow", new Integer(startRow));
		request.setAttribute("endRow", new Integer(endRow));
		request.setAttribute("count", new Integer(count));
		request.setAttribute("pageSize", new Integer(pageSize));
		request.setAttribute("number", new Integer(number));
		request.setAttribute("list", list);
		
		request.setAttribute("select_Search", select_Search);
		request.setAttribute("text_Search", text_Search);

		
		return "/board_buy/board_buy_list.jsp";
	}

}
