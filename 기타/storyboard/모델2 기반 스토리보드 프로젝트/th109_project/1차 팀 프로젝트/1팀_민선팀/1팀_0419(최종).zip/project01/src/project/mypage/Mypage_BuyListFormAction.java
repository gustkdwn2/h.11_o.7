package project.mypage;

import java.text.SimpleDateFormat;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import project.action.CommandAction;
import project.model.ProjectDAO;

public class Mypage_BuyListFormAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("UTF-8");
		HttpSession session = request.getSession();
		
		String m_id = (String)session.getAttribute("m_id");
		
		///////////////////////////////// 페이지 번호 /////////////////////////////////
		int pageSize = 7; // 화면에 출력 레코드 수

		String pageNum = request.getParameter("pageNum");// 전 페이지에 잇던 pagenum을
															// pagenum저장
		
		
		if (pageNum == null)
			pageNum = "1"; // 페이지가없을때 1을생성하여 첫페이지 생성

		int currentPage = Integer.parseInt(pageNum); // 1
		// string형인pagenum을 integer로 형변환

		int count = 0, number = 0;
		// 글개수 글번호
		List list = null;
		// 리스트 선언
		ProjectDAO dao = ProjectDAO.getInstance();
		
		
		int startRow = (currentPage - 1) * pageSize + 1;

		int endRow = currentPage * pageSize;
		
		count = dao.deal_BuyComplete_Count(m_id); // 로그인한 사람의 거래 성사 내역
		

		String select_Search = request.getParameter("select_Search");
		String text_Search = request.getParameter("text_Search");
		
		if(select_Search != null && text_Search != null){
			if( count > 0 ){
				list = dao.deal_BuyComplate_List_Search(startRow, endRow, m_id, select_Search, text_Search);
				count = dao.deal_BuyComplate_List_Search_count(m_id, select_Search, text_Search);
			}// if
		}else{
			if( count > 0 ) list = dao.deal_BuyComplate_List(startRow, endRow, m_id);
		}// else
		
		
		request.setAttribute("currentPage", new Integer(currentPage));// 변수, 값
		request.setAttribute("startRow", new Integer(startRow));
		request.setAttribute("endRow", new Integer(endRow));
		request.setAttribute("count", new Integer(count));
		request.setAttribute("pageSize", new Integer(pageSize));
		request.setAttribute("number", new Integer(number));
		request.setAttribute("list", list);
		
		
		return "/mypage/mypage_BuyListForm.jsp";
	}

}
