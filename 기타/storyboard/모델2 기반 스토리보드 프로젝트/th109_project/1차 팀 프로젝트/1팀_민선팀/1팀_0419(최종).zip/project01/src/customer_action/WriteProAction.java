package customer_action;

import java.sql.Timestamp;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import project.action.CommandAction;
import project.model.Board_CustomerVO;
import project.model.ProjectDAO;

public class WriteProAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		HttpSession session = request.getSession();
		
		request.setCharacterEncoding("UTF-8");
		Board_CustomerVO vo =new Board_CustomerVO();
		
		System.out.println("pro");
		
		vo.setNum(Integer.parseInt(request.getParameter("num")));
		vo.setId(request.getParameter("id"));
		vo.setTitle(request.getParameter("title"));
		vo.setContent(request.getParameter("content"));
		vo.setImage(request.getParameter("image"));
		
		vo.setReg_date(new Timestamp(System.currentTimeMillis()));
		
		vo.setRef(Integer.parseInt(request.getParameter("ref")));
		vo.setRe_level(Integer.parseInt(request.getParameter("re_level")));
		vo.setRe_step(Integer.parseInt(request.getParameter("re_step")));
		
		//여기까진 됨
		
		ProjectDAO dao = ProjectDAO.getInstance();
		dao.insert(vo);
		
	//	response.sendRedirect("board_customerlist.do");
		return "/board/writePro.jsp";
	}

}
