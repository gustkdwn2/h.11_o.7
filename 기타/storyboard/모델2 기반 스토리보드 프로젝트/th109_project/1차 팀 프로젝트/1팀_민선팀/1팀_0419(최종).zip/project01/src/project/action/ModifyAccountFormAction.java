﻿package project.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import project.model.MemberVO;
import project.model.Member_ProfileVO;
import project.model.ProjectDAO;

public class ModifyAccountFormAction implements CommandAction {

   @Override
   public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
      HttpSession session = request.getSession( );
      request.setCharacterEncoding("UTF-8");
      
      ProjectDAO dao = ProjectDAO.getInstance();
      String m_id = (String)session.getAttribute("m_id");
      MemberVO mvo = dao.search_member_id(m_id);
      Member_ProfileVO mpvo = dao.search_profile_id(m_id);
      
      System.out.println(mpvo.getP_id());
      
      request.setAttribute("mvo", mvo);
      request.setAttribute("mpvo", mpvo);
      
      return "/view/modifyAccountForm.jsp";
   }

}