package codyHelp.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import project.action.CommandAction;
import project.model.Board_CoordiVO;
import project.model.ProjectDAO;

public class CodyHelpDeleteProAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		/*HttpSession session = request.getSession();
		String m_id = (String) session.getAttribute("m_id");*/
		int num=Integer.parseInt(request.getParameter("num"));
	
		ProjectDAO dao =ProjectDAO.getInstance();
		
		
		
		
		request.setAttribute("num", new Integer(num));
		Board_CoordiVO vo =dao.delete_cody(num);
		
		return "/codyHelp/codyHelpDeletePro.jsp";
	}

}
