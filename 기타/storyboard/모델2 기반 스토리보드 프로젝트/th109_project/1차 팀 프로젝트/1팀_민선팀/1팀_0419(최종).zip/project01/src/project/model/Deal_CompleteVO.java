package project.model;

import java.sql.Timestamp;

public class Deal_CompleteVO {
	
	private int num;
	private String seller_id;
	private String buyer_id;
	private int seller_cl_num;
	private int buyer_cl_num;
	private Timestamp reg_date;
	private int deal;
	private String seller_cl_title;
	private String buyer_cl_title;
	private String id;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getSeller_cl_title() {
		return seller_cl_title;
	}
	public void setSeller_cl_title(String seller_cl_title) {
		this.seller_cl_title = seller_cl_title;
	}
	public String getBuyer_cl_title() {
		return buyer_cl_title;
	}
	public void setBuyer_cl_title(String buyer_cl_title) {
		this.buyer_cl_title = buyer_cl_title;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getSeller_id() {
		return seller_id;
	}
	public void setSeller_id(String seller_id) {
		this.seller_id = seller_id;
	}
	public String getBuyer_id() {
		return buyer_id;
	}
	public void setBuyer_id(String buyer_id) {
		this.buyer_id = buyer_id;
	}
	public int getSeller_cl_num() {
		return seller_cl_num;
	}
	public void setSeller_cl_num(int seller_cl_num) {
		this.seller_cl_num = seller_cl_num;
	}
	public int getBuyer_cl_num() {
		return buyer_cl_num;
	}
	public void setBuyer_cl_num(int buyer_cl_num) {
		this.buyer_cl_num = buyer_cl_num;
	}
	public Timestamp getReg_date() {
		return reg_date;
	}
	public void setReg_date(Timestamp reg_date) {
		this.reg_date = reg_date;
	}
	public int getDeal() {
		return deal;
	}
	public void setDeal(int deal) {
		this.deal = deal;
	}

	
	
}//Deal_completeVO end
