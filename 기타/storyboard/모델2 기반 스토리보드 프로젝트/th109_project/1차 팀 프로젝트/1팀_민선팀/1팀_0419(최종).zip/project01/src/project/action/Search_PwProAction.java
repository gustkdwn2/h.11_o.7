package project.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.util.Properties;

import javax.mail.Address;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import project.model.MemberVO;
import project.model.ProjectDAO;

public class Search_PwProAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("UTF-8");
		String m_name = request.getParameter("m_name");
		String m_tel = request.getParameter("m_tel");
		String m_id = request.getParameter("m_id");
		
		ProjectDAO dao = ProjectDAO.getInstance();
		MemberVO vo = new MemberVO();
		String m_passwd = dao.search_Pw(m_name, m_tel, m_id);
		
		request.setAttribute("m_passwd", m_passwd);
		

		String errStr = null;
		
		// 입력한 정보가 맞으면 메일 전송
		if(m_id!=null){
			vo = dao.search_member_id(m_id);
			
			// 정보를 담기 위한 객체
			Properties p = new Properties();
			
			// SMTP 서버의 계정 설정
			p.put("mail.stmtp.user", "mail_testid");
			
			// SMTP 서버 정보 설정
			// 네이버 : smtp.naver.com
			p.put("mail.smtp.host", "smtp.naver.com");
			
			p.put("mail.smtp.port", "465");
			p.put("mail.smtp.starttls.enable", "true");
			p.put("mail.smtp.auth", "true");
			p.put("mail.smtp.debug", "true");
			p.put("mail.smtp.socketFactory.port", "465");
			p.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
			p.put("mail.smtp.socketFactory.fallback", "false");
			
			try{
				Authenticator auth = new SMTPAuthenticator();
				Session ses = Session.getInstance(p, auth);
				
				// 메일을 전송할 때 상세 상황을 콘솔에 출력
				ses.setDebug(true);
				
				// 메일의 내용을 담기 위한 객체
				MimeMessage msg = new MimeMessage(ses);
				
				// 제목 설정
				msg.setSubject("[사이트 이름] ID/PW 찾기 메일입니다.");
				
				// 보내는 사람의 메일주소
				Address fromAddr = new InternetAddress("mail_testid@naver.com");
				msg.setFrom(fromAddr);
				
				// 받는 사람의 메일주소
				Address toAddr = new InternetAddress(vo.getM_email());
				System.out.println("받을메일 : " + toAddr);
				msg.addRecipient(Message.RecipientType.TO, toAddr);
				
				// 메시지 본문의 내용과 형식, 캐릭터 셋 설정
				msg.setContent("회원님의 비밀번호는 [ " + vo.getM_passwd() + " ] 입니다.", "text/html;charset=UTF-8");
				
				// 발송하기
				Transport.send(msg);
				
			}catch(Exception e){
				errStr = "메일 발송에 실패했습니다.";
				e.printStackTrace();
			}//try
		}// if
		
		request.setAttribute("errStr", errStr);
		
		return "/view/search_PwPro.jsp";
	}

}
