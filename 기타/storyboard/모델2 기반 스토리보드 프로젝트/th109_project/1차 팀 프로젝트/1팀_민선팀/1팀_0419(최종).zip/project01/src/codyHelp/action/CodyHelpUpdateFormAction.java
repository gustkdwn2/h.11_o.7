package codyHelp.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import project.action.CommandAction;
import project.model.Board_CoordiVO;
import project.model.ProjectDAO;

public class CodyHelpUpdateFormAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		HttpSession session = request.getSession();
		String m_id =request.getParameter("m_id");
		
		
		int num = Integer.parseInt(request.getParameter("num")); //이전페이지의 게시글 넘버를받아온다
		ProjectDAO dao =new ProjectDAO();
		Board_CoordiVO vo = dao.update_cody(num);
	
		request.setAttribute("vo", vo);
		request.setAttribute("num", num);
		
		return "/codyHelp/codyHelpUpdateForm.jsp";
	}

}
