package project.action;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import project.model.ClothesVO;
import project.model.ProjectDAO;

public class SurroundImageSearchGenderAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("UTF-8");
		
		int pageSize = 10;		// ȭ�� ��� ���ڵ� ��
		
		String pageNum = request.getParameter("pageNum");
		
		if(pageNum == null){
			pageNum = "1";
		}// if
		
		int currentPage = Integer.parseInt(pageNum);		// ���� ������
		int startRow = (currentPage * pageSize) - 9;		// ex) (1*10)-9 = 1 - start
		int endRow = (currentPage * pageSize);				// ex) (1*10) = 10 - end
		
		//  ��ü ���ڵ� �� , 
		int count = 0;
		
		// ���ڵ带 �޾ƿ� List
		List list = null;
		List profileList = null;
		ProjectDAO dao = ProjectDAO.getInstance();
		count = dao.getListAllCount_surroundImage();
		
		List<String> gender = new ArrayList<String>();
		String[] genderArr = request.getParameterValues("gender");
		
		
		for(int i=0; i<genderArr.length; i++){
			gender.add(genderArr[i]);
		}// for
		
		
		///// �����Ѱ� ȭ�鿡 ���̱� //////
		String navigation="";
		navigation += genderArr[0];
		if(genderArr.length > 1){
			for(int i=1; i<genderArr.length; i++){
				navigation += " & " + genderArr[i];
			}//for
		}//if
		request.setAttribute("navigation", navigation);
		//////////////////////////
		
		
		if(count >0 ){
			list = dao.surroundImageList_SearchGender(startRow, endRow, gender);
		}
		
		if(list != null){
			profileList = dao.profileImageList(list);
			count = dao.surroundImageList_SearchGender_count(startRow, endRow, gender);
		}else{
			profileList = null;
			count = 0;
		}
		
		
		request.setAttribute("pageSize", pageSize);
		request.setAttribute("pageNum", pageNum);
		request.setAttribute("currentPage", currentPage);
		request.setAttribute("startRow", startRow);
		request.setAttribute("endRow", endRow);
		request.setAttribute("count", count);
		request.setAttribute("list", list);
		request.setAttribute("profileList", profileList);
		request.setAttribute("gender", gender);
		
		
		
		
		
		
		return "/surroundImageList/surroundImageSearchGender.jsp";
	}

}
