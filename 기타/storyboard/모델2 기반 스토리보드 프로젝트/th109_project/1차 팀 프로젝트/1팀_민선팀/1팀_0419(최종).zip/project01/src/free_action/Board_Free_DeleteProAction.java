package free_action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import project.action.CommandAction;
import project.model.ProjectDAO;

public class Board_Free_DeleteProAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, 
			HttpServletResponse response) throws Exception {
		
		
		request.setCharacterEncoding("utf-8");
		
		ProjectDAO dao =ProjectDAO.getInstance();
		int num =Integer.parseInt(request.getParameter("num"));
		String pageNum =request.getParameter("pageNum");
		
		int check =dao.delete_free(num);
		
		request.setAttribute("pageNum", pageNum);
		request.setAttribute("check", new Integer(check));
		
		return "/board_free/board_free_deletePro.jsp" ;
	}

}
