package project.guestbook.action;

import java.sql.Timestamp;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import project.action.CommandAction;
import project.model.Guest_BookVO;
import project.model.ProjectDAO;

public class GuestBookDeleteProAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("UTF-8");
		
		Guest_BookVO vo = new Guest_BookVO();
		
		HttpSession session = request.getSession();
		vo.setNum(Integer.parseInt(request.getParameter("num")));
		ProjectDAO dao = new ProjectDAO();
		dao.delete(vo);
		return "/guestBookView/guestBookDeletePro.jsp";
	}
}
