package buy_action;

import java.text.SimpleDateFormat;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import project.action.CommandAction;
import project.model.Board_BuyVO;
import project.model.ProjectDAO;

public class board_buy_Content_hihitAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		System.out.println("contentaction");
		int num = Integer.parseInt(request.getParameter("num"));

		String pageNum = request.getParameter("pageNum");
		int hihit = Integer.parseInt(request.getParameter("hihit"));
		System.out.println("contentaction2");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		Board_BuyVO vo = null;

		ProjectDAO dao = ProjectDAO.getInstance();

		vo = dao.getDataDetail_buy_hi(num);

		int ref = vo.getRef();
		int re_step = vo.getRe_step();
		int re_level = vo.getRe_level();

		request.setAttribute("num", new Integer(num));
		request.setAttribute("pageNum", new Integer(pageNum));
		request.setAttribute("vo", vo);

		return "/board_buy/board_buy_content.jsp";

	}
}
