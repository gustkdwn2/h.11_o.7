package project.guestbook.action;

import java.util.Collections;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import project.action.CommandAction;
import project.model.Member_ProfileVO;
import project.model.ProjectDAO;

public class GuestBookFormAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("UTF-8");
		
		HttpSession session = request.getSession();
		String pageNum = request.getParameter("pageNum");
		
		String m_id = (String)session.getAttribute("m_id");
		
		String personal_id = request.getParameter("personal_id");
		
		if(m_id == personal_id){			// 로그인한 본인의 옷장일 경우
			personal_id = m_id;
		}
		
		// page 번호 처리
		if(pageNum == null){
			pageNum = "1";
		}
		
		int pageSize = 5;
		int currentPage = Integer.parseInt(pageNum);//1
		int count = 0;
		int number = 0;
		int pageCount = 0;
		
		List guestBookList = null;
		ProjectDAO dao = ProjectDAO.getInstance();
		count = dao.getGuest_BookCount(personal_id); //12
		
		if(count%pageSize==0) pageCount = count/pageSize;
		else pageCount = count/pageSize+1;
		
		int startRow =  (currentPage * pageSize) - 4;
		int endRow = (currentPage * pageSize);
		
		if(count > 0){
			guestBookList = dao.getGuest_Book(startRow,endRow,personal_id);
			count = dao.getGuest_Book_Count(personal_id);
		} else {
			guestBookList = Collections.EMPTY_LIST;
		}

		Member_ProfileVO personal_profile = null;
		personal_profile = dao.getProfile(personal_id);
		
		// personal_id 존재 확인
		int check=0;
		if(personal_profile != null){
			check = 1;
		}
		
		number = count-(currentPage-1)*pageSize;
		
		request.setAttribute("currentPage", new Integer(currentPage));
		request.setAttribute("startRow", new Integer(startRow));
		request.setAttribute("endRow", new Integer(endRow));
		request.setAttribute("count", new Integer(count));
		request.setAttribute("pageSize", new Integer(pageSize));
		request.setAttribute("number", new Integer(number));
		request.setAttribute("guestBookList",guestBookList);
		request.setAttribute("personal_profile", personal_profile);
		request.setAttribute("personal_id", personal_id);
		request.setAttribute("check", check);

		return "/guestBookView/guestBookForm.jsp";
	}//process end
}
