package project.guestbook.action;

import java.sql.Timestamp;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import project.action.CommandAction;
import project.model.Guest_BookVO;
import project.model.ProjectDAO;

public class GuestBookUpdateProAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("UTF-8");
		
		Guest_BookVO vo = new Guest_BookVO();
		
		HttpSession session = request.getSession();
		vo.setContent(request.getParameter("content"));
		vo.setReg_date(new Timestamp(System.currentTimeMillis()));
		vo.setNum(Integer.parseInt(request.getParameter("num")));

		ProjectDAO dao = new ProjectDAO();
		dao.update(vo);
		return "/guestBookView/guestBookUpdatePro.jsp";
	}
}
