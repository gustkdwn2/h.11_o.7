package codyHelp.action;

import java.net.URLEncoder;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import project.action.CommandAction;
import project.model.Board_CoordiVO;
import project.model.ProjectDAO;

public class CodyHelpUpdateProAction implements CommandAction {
	
	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		System.out.println("update 시작 (수정)");
		
		HttpSession session = request.getSession();
		String m_id= (String)session.getAttribute("m_id");//아이디색션

		String realPath=""; //경로
		String savePath="upload"; //파일
		String encType ="UTF-8"; //인코딩
		int maxSize=1024*1024*5; //
		
		request.setCharacterEncoding("UTF-8");//인코딩
		
		ServletContext context =request.getSession().getServletContext();
		//서블릿이 서블릿 컨테이너와 통신하기 위해서 사용되어지는 메서드들을 가지고잇는 클래스를 말한다
		realPath = context.getRealPath(savePath+"\\");
		//저장될 장소 = 서블릿컨테스트메소드.주소를받아온다 (upload파일 +경로);
		MultipartRequest multi =new MultipartRequest(request,//request 객체
				realPath, //업로드 될 파일이 저장될 파일폴더 경로
				maxSize , //업로드 할 파일의 최대크기
				"UTF-8", //인코딩 타입
				
				new DefaultFileRenamePolicy()//파일업로드 컴포넌트
				);	
		
		ProjectDAO dao =ProjectDAO.getInstance(); //
		Board_CoordiVO vo =new Board_CoordiVO(); //업데이트가 끝낫으니 변경정보를 vo에저장
		int num=Integer.parseInt(multi.getParameter("num")); //num은 int이므로 형변환
		
		if(multi.getParameter("image1") == null){
			 vo = dao.update_cody(num);
		}else if(multi.getParameter("image2") ==null){
			 vo = dao.update_cody(num);
		}else if(multi.getParameter("image3") ==null){
			 vo = dao.update_cody(num);
		}	
		/*
		vo.setImage1(multi.getParameter("image1"));//image1 이라는이름의 값을 가져와 다시슨다
		vo.setImage2(multi.getParameter("image2"));
		vo.setImage3(multi.getParameter("image3"));		*/
		vo.setNum(Integer.parseInt(multi.getParameter("num")));
		vo.setTitle(multi.getParameter("title"));   //변경되는내용은 제목 내용 사진3개
		vo.setContent(multi.getParameter("content"));			//자료형을 받아올때는 request쓰지못함
		System.out.println("바뀐 content!! : "+multi.getParameter("content"));
	    dao.update_cody(vo);
		
		String img1 = multi.getFilesystemName("image1");
		String img2 = multi.getFilesystemName("image2");
		String img3 = multi.getFilesystemName("image3");
		
		
		if( img1 != null ){
			String x = request.getContextPath() + "/" + savePath + "/" + URLEncoder.encode(img1, "UTF-8");
			vo.setImage1(x);
		}
		if( img2 != null ){
			String x = request.getContextPath() + "/" + savePath + "/" + URLEncoder.encode(img2, "UTF-8");
			vo.setImage2(x);
		}
		if( img3 != null ){
			String x = request.getContextPath() + "/" + savePath + "/" + URLEncoder.encode(img3, "UTF-8");
			vo.setImage3(x);
		}	
		dao.update_cody(vo);
		
		return "/codyHelp/codyHelpUpdatePro.jsp";
	}

}
