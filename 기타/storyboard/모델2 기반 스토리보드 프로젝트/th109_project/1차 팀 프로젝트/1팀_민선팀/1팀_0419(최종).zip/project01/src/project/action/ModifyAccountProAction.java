package project.action;

import java.net.URLEncoder;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import project.model.MemberVO;
import project.model.Member_ProfileVO;
import project.model.ProjectDAO;

public class ModifyAccountProAction implements CommandAction {

   @Override
   public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
      HttpSession session = request.getSession();
      String p_id= (String)session.getAttribute("m_id");
      
      
      System.out.println("modifyAccountPro!!!!!!!!!!");
      
      String realPath = "";
      String savePath = "upload";
      String encType = "UTF-8";
      int maxSize = 1024 * 1024 * 5;

      ServletContext context = request.getSession().getServletContext();
      realPath = context.getRealPath(savePath + "\\");

      MultipartRequest multi = new MultipartRequest(request, // request ��ü
            realPath,
            maxSize,
            "UTF-8",
            new DefaultFileRenamePolicy()
      );

      request.setCharacterEncoding("UTF-8");
      ProjectDAO dao = ProjectDAO.getInstance();
      MemberVO member_vo = new MemberVO();
      
      Member_ProfileVO mp_vo = new Member_ProfileVO();
      
      System.out.println("id: " + p_id);
      if(multi.getParameter("image1") == null){
         mp_vo = dao.update_member(p_id);
      }
      // member insert
      member_vo.setM_id(multi.getParameter("m_id"));
      member_vo.setM_passwd(multi.getParameter("m_passwd"));
      member_vo.setM_name(multi.getParameter("m_name"));

      
      member_vo.setM_tel(multi.getParameter("m_tel"));
      member_vo.setM_email(multi.getParameter("m_email"));
      
      String m_addr = multi.getParameter("m_addr");
      member_vo.setM_addr(m_addr);

      dao.update(member_vo);
      // member_profile insert
      mp_vo.setP_id(multi.getParameter("m_id"));
      mp_vo.setP_height(multi.getParameter("p_height"));
      mp_vo.setP_weight(multi.getParameter("p_weight"));
      mp_vo.setP_self(multi.getParameter("p_self"));
      
      System.out.println(multi.getParameter("p_self"));
      
      mp_vo.setP_area(multi.getParameter("p_area"));
      // ������ ���� ��� ����
      // mp_vo.setP_image(request.getParameter("p_image"));
      
      String y = multi.getFilesystemName("p_image");
      if( y != null ){
         String x = request.getContextPath() + "/" + savePath + "/" + URLEncoder.encode(y, "UTF-8");
         mp_vo.setP_image(x);
      }
      
      mp_vo.setP_message(multi.getParameter("p_message"));

      dao.update(mp_vo);
      
      
      return "/view/modifyAccountPro.jsp";
   }

}