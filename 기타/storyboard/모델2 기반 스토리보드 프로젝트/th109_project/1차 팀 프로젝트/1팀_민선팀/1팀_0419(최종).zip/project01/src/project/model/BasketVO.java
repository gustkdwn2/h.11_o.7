package project.model;


public class BasketVO {

	private int num;		// 순차 증가
	private String my_id;	// 팔로우를 하는 사람( 현재 접속중인 id로 저장 )
	private int cl_num;		// 마음에 드는 옷 게시글 번호
	
	public String getMy_id() {
		return my_id;
	}
	public void setMy_id(String my_id) {
		this.my_id = my_id;
	}
	public int getCl_num() {
		return cl_num;
	}
	public void setCl_num(int cl_num) {
		this.cl_num = cl_num;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
}//BasketVO end
