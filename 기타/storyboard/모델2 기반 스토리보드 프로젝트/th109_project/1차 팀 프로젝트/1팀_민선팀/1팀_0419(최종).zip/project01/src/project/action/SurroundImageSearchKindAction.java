package project.action;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import project.model.ProjectDAO;

public class SurroundImageSearchKindAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("UTF-8");
		
		int pageSize = 10;		// ȭ�� ��� ���ڵ� ��
		
		String pageNum = request.getParameter("pageNum");
		
		if(pageNum == null){
			pageNum = "1";
		}// if
		
		int currentPage = Integer.parseInt(pageNum);		// ���� ������
		int startRow = (currentPage * pageSize) - 9;		// ex) (1*10)-9 = 1 - start
		int endRow = (currentPage * pageSize);				// ex) (1*10) = 10 - end
		
		//  ��ü ���ڵ� �� , 
		int count = 0;
		
		// ���ڵ带 �޾ƿ� List
		List list = null;
		List profileList = null;
		ProjectDAO dao = ProjectDAO.getInstance();
		count = dao.getListAllCount_surroundImage();
		
		List<String> kind = new ArrayList<String>();
		String[] kindArr = request.getParameterValues("kind");
		
		
		for(int i=0; i<kindArr.length; i++){
			kind.add(kindArr[i]);
		}// for
		
		
		///// �����Ѱ� ȭ�鿡 ���̱� //////
		String navigation="";
		navigation += kindArr[0];
		if(kindArr.length > 1){
			for(int i=1; i<kindArr.length; i++){
				navigation += " & " + kindArr[i];
			}//for
		}//if
		request.setAttribute("navigation", navigation);
		//////////////////////////
		
		
		if(count >0 ){
			list = dao.surroundImageList_SearchKind(startRow, endRow, kind);
		}
		

		if(list != null){
			profileList = dao.profileImageList(list);
			count = dao.surroundImageList_SearchKind_count(startRow, endRow, kind);
		}else{
			profileList = null;
			count = 0;
		}
		
		
		request.setAttribute("pageSize", pageSize);
		request.setAttribute("pageNum", pageNum);
		request.setAttribute("currentPage", currentPage);
		request.setAttribute("startRow", startRow);
		request.setAttribute("endRow", endRow);
		request.setAttribute("count", count);
		request.setAttribute("list", list);
		request.setAttribute("profileList", profileList);
		request.setAttribute("kind", kind);
		
		return "/surroundImageList/surroundImageSearchKind.jsp";
	}

}
