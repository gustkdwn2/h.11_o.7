package buy_action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import project.action.CommandAction;
import project.model.Board_BuyVO;
import project.model.ProjectDAO;

public class board_buy_UpdateFormAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		HttpSession session = request.getSession(); //전페이지에서 로그인 정보를 가져온다
		int num=0, ref=1,re_step=0,re_level=0;
		
		num = Integer.parseInt(request.getParameter("num"));
		String pageNum =request.getParameter("pageNum");
		
		ProjectDAO dao = ProjectDAO.getInstance();
		Board_BuyVO vo = dao.update_buy(num); 
		
		request.setAttribute("pageNum", pageNum);
		request.setAttribute("vo", vo);
		
		
		return "/board_buy/board_buy_updateForm.jsp";
	}

}
