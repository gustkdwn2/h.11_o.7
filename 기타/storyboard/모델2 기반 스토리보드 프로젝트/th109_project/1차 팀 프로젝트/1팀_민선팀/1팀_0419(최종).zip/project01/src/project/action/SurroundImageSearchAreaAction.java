package project.action;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import project.model.ProjectDAO;

public class SurroundImageSearchAreaAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("UTF-8");
		
		int pageSize = 10;		// ȭ�� ��� ���ڵ� ��
		
		String pageNum = request.getParameter("pageNum");
		
		if(pageNum == null){
			pageNum = "1";
		}// if
		
		int currentPage = Integer.parseInt(pageNum);		// ���� ������
		int startRow = (currentPage * pageSize) - 9;		// ex) (1*10)-9 = 1 - start
		int endRow = (currentPage * pageSize);				// ex) (1*10) = 10 - end
		
		//  ��ü ���ڵ� �� , 
		int count = 0;
		
		// ���ڵ带 �޾ƿ� List
		List list = null;
		List profileList = null;
		ProjectDAO dao = ProjectDAO.getInstance();
		count = dao.getListAllCount_surroundImage();
		
		List<String> area = new ArrayList<String>();
		String[] areaArr = request.getParameterValues("area");
		
		
		for(int i=0; i<areaArr.length; i++){
			area.add(areaArr[i]);
			
		}// for
		
		///// �����Ѱ� ȭ�鿡 ���̱� //////
		String navigation="";
		navigation += areaArr[0];
		if(areaArr.length > 1){
			for(int i=1; i<areaArr.length; i++){
				navigation += " & " + areaArr[i];
			}//for
		}//if
		request.setAttribute("navigation", navigation);
		//////////////////////////
		
		
		if(count >0 ){
			list = dao.surroundImageList_SearchArea(startRow, endRow, area);
		}
		
		if(list != null){
			profileList = dao.profileImageList(list);
			count = dao.surroundImageList_SearchArea_count(startRow, endRow, area);
		}else{
			profileList = null;
			count = 0;
		}
		
		
		
		request.setAttribute("pageSize", pageSize);
		request.setAttribute("pageNum", pageNum);
		request.setAttribute("currentPage", currentPage);
		request.setAttribute("startRow", startRow);
		request.setAttribute("endRow", endRow);
		request.setAttribute("count", count);
		request.setAttribute("list", list);
		request.setAttribute("profileList", profileList);
		request.setAttribute("area", area);
		
		
		
		
		return "/surroundImageList/surroundImageSearchArea.jsp";
	}

}
