package project.mypage;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import project.action.CommandAction;
import project.model.BasketVO;
import project.model.ProjectDAO;

public class FollowForm_BasketFormAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("UTF-8");
		HttpSession session = request.getSession();
		
		List list = null;
		
		// 현재 로그인 중인 id
		String my_id = (String)session.getAttribute("m_id");
		
		ProjectDAO dao = ProjectDAO.getInstance();
		list = dao.getBasket(my_id);
	
		
		request.setAttribute("list", list);
		request.setAttribute("count", list.size());
		
		
		
		return "/mypage/followForm_BasketForm.jsp";
	}

}
