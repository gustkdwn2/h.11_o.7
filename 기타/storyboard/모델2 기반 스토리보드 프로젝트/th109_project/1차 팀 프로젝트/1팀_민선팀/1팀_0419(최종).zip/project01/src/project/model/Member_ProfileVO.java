package project.model;

// ȸ�� ������
public class Member_ProfileVO {
	private String p_id;		// ���̵�
	private String p_height;	// Ű
	private String p_weight;	// ������
	private String p_self;		// �ڱ�Ұ�
	private String p_area;		// ����
	private String p_image;		// �����ʻ��� ���
	private String p_message;	// ���¸޼���
	
	
	public String getP_id() {
		return p_id;
	}
	public void setP_id(String p_id) {
		this.p_id = p_id;
	}
	public String getP_height() {
		return p_height;
	}
	public void setP_height(String p_height) {
		this.p_height = p_height;
	}
	public String getP_weight() {
		return p_weight;
	}
	public void setP_weight(String p_weight) {
		this.p_weight = p_weight;
	}
	public String getP_self() {
		return p_self;
	}
	public void setP_self(String p_self) {
		this.p_self = p_self;
	}
	public String getP_area() {
		return p_area;
	}
	public void setP_area(String p_area) {
		this.p_area = p_area;
	}
	public String getP_image() {
		return p_image;
	}
	public void setP_image(String p_image) {
		this.p_image = p_image;
	}
	public String getP_message() {
		return p_message;
	}
	public void setP_message(String p_message) {
		this.p_message = p_message;
	}
}
