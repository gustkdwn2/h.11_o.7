package project.action;

import java.net.URLEncoder;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import project.model.ClothesVO;
import project.model.ProjectDAO;

public class ClothesViewUpdateProAction implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		System.out.println("클로즈 업데이트 프로 시작");
		
		HttpSession session = request.getSession();
		String m_id =(String)session.getAttribute("m_id");
		
		System.out.println("m_id=" +m_id);
		String realPath=""; //경로
		String savePath="upload"; //파일
		String encType ="UTF-8"; //인코딩
		int maxSize=1024*1024*5; //
		
		request.setCharacterEncoding("UTF-8");//인코딩
		
		ServletContext context =request.getSession().getServletContext();
		//서블릿이 서블릿 컨테이너와 통신하기 위해서 사용되어지는 메서드들을 가지고잇는 클래스를 말한다
		realPath = context.getRealPath(savePath+"\\");
		//저장될 장소 = 서블릿컨테스트메소드.주소를받아온다 (upload파일 +경로);
		MultipartRequest multi =new MultipartRequest(request,//request 객체
				realPath, //업로드 될 파일이 저장될 파일폴더 경로
				maxSize , //업로드 할 파일의 최대크기
				"UTF-8", //인코딩 타입
				
				new DefaultFileRenamePolicy()//파일업로드 컴포넌트
				);
	
		ProjectDAO dao =ProjectDAO.getInstance(); //
		ClothesVO vo =new ClothesVO();
		int cl_num = Integer.parseInt(multi.getParameter("cl_num")); 
		
		if(multi.getParameter("cl_image1") ==null){
			 vo = dao.update_cloth(cl_num);
		}else if(multi.getParameter("cl_image2") ==null){
			 vo = dao.update_cloth(cl_num);
		}else if(multi.getParameter("cl_image3") ==null){
			 vo = dao.update_cloth(cl_num);
		}

		
		vo.setCl_num(Integer.parseInt(multi.getParameter("cl_num")));
		vo.setCl_id(multi.getParameter("cl_id"));
		
		vo.setCl_title(multi.getParameter("cl_title"));
		vo.setCl_content(multi.getParameter("cl_content"));
		vo.setCl_condition(multi.getParameter("cl_condition"));
		vo.setCl_size(multi.getParameter("cl_size"));
		vo.setCl_type(multi.getParameter("cl_type"));
		vo.setCl_area(multi.getParameter("cl_area"));
		vo.setCl_gender(multi.getParameter("cl_gender"));
		vo.setCl_price(Integer.parseInt(multi.getParameter("cl_price")));
		vo.setCl_hope(multi.getParameter("cl_hope"));
		vo.setCl_deal(multi.getParameter("cl_deal"));	
		System.out.println("바뀐cl_deal:"+multi.getParameter("cl_deal"));
		
		dao.update_clothes(vo);
		
		String img1 = multi.getFilesystemName("cl_image1");
		String img2 = multi.getFilesystemName("cl_image2");
		String img3 = multi.getFilesystemName("cl_image3");
		
	
		
		if( img1 != null ){
			String x = request.getContextPath() + "/" + savePath + "/" + URLEncoder.encode(img1, "UTF-8");
			vo.setCl_image1(x);
		}
		if( img2 != null ){
			String x = request.getContextPath() + "/" + savePath + "/" + URLEncoder.encode(img2, "UTF-8");
			vo.setCl_image2(x);
		}
		if( img3 != null ){
			String x = request.getContextPath() + "/" + savePath + "/" + URLEncoder.encode(img3, "UTF-8");
			vo.setCl_image3(x);
		}
		vo.setCl_num(cl_num);
		dao.update_clothes(vo);
				
		return "/clothesView/ClothesViewUpdatePro.jsp";
	}

}
