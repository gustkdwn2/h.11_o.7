package project.siteMemberView;

import java.util.List;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import project.action.CommandAction;
import project.model.ProjectDAO;

public class SiteMemberView_SearchAction extends HttpServlet implements CommandAction {

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("utf-8");
		int count = 0;
		int start = 1;  // 게시물 글 갯수 스타트 값
		int end = 20;  // 게시물 글 갯수 엔드 값
	 	String select_Search = request.getParameter("select_Search");
		String text_Search = request.getParameter("text_Search");
		
		List list = null;
		List profileList = null;
		ProjectDAO dao = ProjectDAO.getInstance();
		count = dao.getSiteMemberView_Search_count(select_Search, text_Search);	

		
		if(select_Search != null && text_Search != null){
			if( count > 0 ){
				list = dao.getSiteMemberView_Search(start, end, select_Search, text_Search);
				profileList = dao.profileImageList_Search(select_Search, text_Search);
			}//if
		}else{
			count = 0;
		}//else

		request.setAttribute("count", count);
		request.setAttribute("list", list);
		request.setAttribute("profileList", profileList);
		request.setAttribute("select_Search", select_Search);
		request.setAttribute("text_Search", text_Search);
		
		return"/siteMemberView/siteMemberView_Search.jsp";
	}

}
