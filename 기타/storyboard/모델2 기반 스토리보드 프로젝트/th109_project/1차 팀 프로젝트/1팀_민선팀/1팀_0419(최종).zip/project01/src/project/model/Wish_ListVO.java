package project.model;

import java.sql.Timestamp;

public class Wish_ListVO {
	private int num;
	private int seller_cl_num;
	private int buyer_cl_num;
	private String buyer_id;
	private String b_image;
	private String b_title;
	private Timestamp reg_date;
	
	public int getBuyer_cl_num() {
		return buyer_cl_num;
	}
	public void setBuyer_cl_num(int buyer_cl_num) {
		this.buyer_cl_num = buyer_cl_num;
	}
	
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	
	public int getSeller_cl_num() {
		return seller_cl_num;
	}
	public void setSeller_cl_num(int seller_cl_num) {
		this.seller_cl_num = seller_cl_num;
	}
	public String getBuyer_id() {
		return buyer_id;
	}
	public void setBuyer_id(String buyer_id) {
		this.buyer_id = buyer_id;
	}
	public String getB_image() {
		return b_image;
	}
	public void setB_image(String b_image) {
		this.b_image = b_image;
	}
	public String getB_title() {
		return b_title;
	}
	public void setB_title(String b_title) {
		this.b_title = b_title;
	}
	public Timestamp getReg_date() {
		return reg_date;
	}
	public void setReg_date(Timestamp reg_date) {
		this.reg_date = reg_date;
	}
	
}//Wish_ListVO end
