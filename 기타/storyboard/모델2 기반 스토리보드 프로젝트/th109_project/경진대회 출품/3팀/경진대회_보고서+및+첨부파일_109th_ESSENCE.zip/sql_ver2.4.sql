---------------------------------------------------DROP--------------------------------------------------

--����/���/�Խ���
drop table STOCK;
drop table INVOICE;
drop table SUPPLIER;
drop table RECEPTION;
drop table PAYMENT;
drop table NOTICE;
drop table BIZ_REPORT; 
drop table MINUTES;
drop SEQUENCE RECEPTION_SEQ;
drop SEQUENCE NOTICE_SEQ;
drop SEQUENCE BIZ_SEQ;
drop SEQUENCE MINUTES_SEQ;
drop SEQUENCE INVOICE_SEQ;

--ȯ��/����/ó��
DROP TABLE MEDICAL;
DROP TABLE PATIENT;
DROP TABLE TREATMENT;
DROP TABLE PRESCRIPTION;
DROP TABLE PATIENT_TREATMENT;
DROP TABLE PATIENT_PRESCRIPTION;
drop SEQUENCE MEDICAL_SEQ;
drop sequence patient_prescription_no;
drop sequence prescription_seq;
drop sequence patient_treatment_no;
DROP SEQUENCE TREATMENT_SEQ;

--ȸ��
drop table account;
drop table acc_type_code;
drop sequence account_seq;
drop sequence type_code_seq;

--�λ�
drop table pay_check_no;
DROP TABLE basic_pay_table;
DROP TABLE PAY_MANAGEMENT;
DROP TABLE retire_pay_management;
DROP TABLE commute_management;
DROP TABLE human_resourse_management;
DROP TABLE department_table;
DROP TABLE duty_responsibility_table;
DROP TABLE bank;
DROP TABLE commute_absence;
drop table emp_absence_list;
drop table emp_absence_wait_approval;
drop table etc_pay_table;
drop table income_tax;

drop SEQUENCE pay_check_no_seq;
drop SEQUENCE commute_seq;
drop SEQUENCE PAY_MANAGEMENT_seq;
drop SEQUENCE retire_PAY_MANAGEMENT_seq;
drop SEQUENCE emp_absence_list_seq;
drop SEQUENCE emp_absence_wait_seq;


--��������
drop table role_comparison;
drop table security_role;
drop table hospital_information;
drop table user_member;
drop table role_korea;
drop SEQUENCE  user_member_sequence;
---------------------------------------------------CREATE------------------------------------------------

-- STOCK : ���
CREATE TABLE STOCK (
	ST_CODE VARCHAR2(20) NOT NULL,
	ST_NAME VARCHAR2(50) NOT NULL,
	ST_STD VARCHAR2(20) NOT NULL,
	ST_MODEL VARCHAR2(20) NOT NULL,
	ST_MAN VARCHAR2(50) NOT NULL,
	ST_VENDOR VARCHAR2(50) NOT NULL,
	ST_QTY NUMBER NOT NULL,
	ST_UNIT VARCHAR2(20) NOT NULL
);

-- INVOICE : �ŷ�/���ų���
CREATE TABLE INVOICE (
   IN_SEQ NUMBER,
   ST_CODE VARCHAR2(20) NOT NULL,
   ST_NAME VARCHAR2(50) NOT NULL,
   ST_STD VARCHAR2(20) NOT NULL,
   ST_MODEL VARCHAR2(20) NOT NULL,
   ST_MAN VARCHAR2(50) NOT NULL,
   ST_VENDOR VARCHAR2(50) NOT NULL,
   ST_QTY NUMBER NOT NULL,
   ST_UNIT VARCHAR2(20) NOT NULL,
   IN_PRICE NUMBER NOT NULL,
   IN_DATE VARCHAR2(20) NOT NULL
);
CREATE SEQUENCE INVOICE_SEQ;
-- SUPPLIER : �ŷ�ó
CREATE TABLE SUPPLIER (
	SU_TAXID VARCHAR2(50) NOT NULL,
	SU_NAME VARCHAR2(50) NOT NULL,
	SU_CEO VARCHAR2(20) NOT NULL,
	SU_FNDT VARCHAR2(20) NOT NULL,
	SU_ADDR VARCHAR2(150) NOT NULL,
	SU_PHONE VARCHAR2(50) NOT NULL,
	SU_ITEM VARCHAR2(150) NOT NULL,
	SU_MGR VARCHAR2(50) NULL
);

-- RECEPTION : ���� �� ����
CREATE TABLE RECEPTION (
	R_NO NUMBER,
	C_NO VARCHAR2(20) NOT NULL,
	C_NAME VARCHAR2(50) NOT NULL,
	RES_DATE VARCHAR2(20) NULL,
	RES_TIME VARCHAR2(20) NULL,
	REC_DATE DATE NULL,
	CK NUMBER DEFAULT 0
);
CREATE SEQUENCE RECEPTION_SEQ;

-- PAYMENT : ���� ���
-- [ ȯ�� �˻� -> ���� -> ����(ȯ�� �󼼺��⿡�� ���᳻�� ���� ��) -> ���� ��Ͽ��� ����, �ش� ���̺��� ����� �߰� ] 
CREATE TABLE PAYMENT(
	C_NO VARCHAR2(20) NOT NULL,
	C_NAME VARCHAR2(20) NOT NULL,
	T_PAY NUMBER NOT NULL
);

--ȯ��/����/ó��
CREATE TABLE MEDICAL(
	M_NO NUMBER,
	M_NAME VARCHAR2(20),
	M_GENDER VARCHAR2(10),
	M_JUMIN1 VARCHAR2(20),
	M_JUMIN2 VARCHAR2(20),
	M_ADDRESS VARCHAR2(200),
	M_PHONE VARCHAR2(50)
);

-- PATIENT : ȯ��
CREATE TABLE PATIENT (
	C_NO NUMBER,
	C_NAME VARCHAR2(20),
	C_GENDER VARCHAR2(10),
	C_JUMIN1 VARCHAR2(30),
	C_JUMIN2 VARCHAR2(30),       
	C_ADDRESS VARCHAR2(200),
	C_PHONE VARCHAR2(50),
	C_DOCTOR VARCHAR2(20),	
	C_MDATE VARCHAR2(20),
	constraint pk_PATIENT_c_no primary key(C_NO)
);

-- TREATMENT : ���� ���
CREATE TABLE TREATMENT(
	T_CODE NUMBER (20),
	T_NAME VARCHAR(20),
	T_PAY NUMBER(20)
);

--PRESCRIPTION : ó�� ���
CREATE TABLE PRESCRIPTION(
   pre_code varchar2(10),
  pre_name varchar2(50),
  pre_way varchar2(50)
);

--patient_treatment : �ش�ȯ�� ������
create table patient_treatment (
patient_treatment_no number(10),
c_no varchar2(10),
t_code varchar2(20),
t_content varchar2(500),
t_date VARCHAR2(30)
);

--patient_prescription : �ش�ȯ�� ó����
create table patient_prescription (
patient_prescription_no number(10),
c_no varchar2(10),
pre_code varchar2(50),
pre_name varchar(50),
t_date VARCHAR2(20),
pre_day varchar(50),
pre_total varchar(50)
);

create sequence patient_prescription_no;
create sequence patient_treatment_no;
CREATE SEQUENCE TREATMENT_SEQ;
CREATE SEQUENCE PRESCRIPTION_SEQ;
CREATE SEQUENCE MEDICAL_SEQ
    MINVALUE 1 MAXVALUE 9999999999999999999999999999 
    INCREMENT BY 1 
    START WITH 1 
    NOCACHE  
    NOORDER  
    NOCYCLE ;

-- ȸ��
CREATE TABLE ACCOUNT (
	AC_SEQ NUMBER,
	AC_DATE VARCHAR2(50) NOT NULL,    			
	AC_TYPENAME VARCHAR2(50) NOT NULL,	
	AC_CONT VARCHAR2(300) NOT NULL,
	AC_IMP NUMBER DEFAULT 0,
	AC_EXP NUMBER DEFAULT 0
);


CREATE SEQUENCE ACCOUNT_SEQ    
    MINVALUE 1 MAXVALUE 9999999999999999999999999999 
    INCREMENT BY 1 
    START WITH 1 
    NOCACHE  
    NOORDER  
    NOCYCLE ;  
  

--type code    
--ACOUNT TYPE CODE TABLE
CREATE TABLE ACC_TYPE_CODE (
	TYPE_CODE VARCHAR2(10),
	TYPE_NAME VARCHAR2(50)
);
create sequence type_code_seq
    MINVALUE 1 MAXVALUE 9999999999999999999999999999 
    INCREMENT BY 1 
    START WITH 1 
    NOCACHE  
    NOORDER  
    NOCYCLE ; 


--�λ�
--��å ���
create table duty_responsibility_table (
duty_responsibility_code varchar2(15),
duty_responsibility varchar2(30),
 constraint pk_duty_responsibility_table primary key(duty_responsibility_code),
 unique(duty_responsibility)
);

--�μ����
 create table department_table (
department_code varchar2(15),
department varchar2(30),
 constraint pk_department_table primary key(department_code)
);

--�λ����(��������)
create table human_resourse_management(
emp_num varchar2(15), emp_name varchar2(15) not null,
telephone varchar2(30) not null, telephone2 varchar2(30),
address_number varchar2(20),address varchar2(200),
department_code varchar2(20),
jumin_number varchar2(25),gender varchar2(10),
join_date date, retire_date date,
email varchar2(30), rank_position varchar2(20),
duty_responsibility_code varchar2(20),
marital_status varchar2(10),bank_name varchar2(50),
account_holder varchar2(20),
account_number varchar2(30),
picture varchar2(2000), attach_file varchar2(4000),
join_company_division varchar2(10),
license_type varchar2(20), license_number varchar2(25),
license_date varchar2(20), 
dependent_family number(4),dependent_children number(4),
resignation_check number(3),
 constraint pk_human_resourse_management primary key(emp_num),
 CONSTRAINT fk_human_resourse_management FOREIGN KEY(duty_responsibility_code)
 REFERENCES duty_responsibility_table(duty_responsibility_code),
 CONSTRAINT fk2_human_resourse_management FOREIGN KEY(department_code)
 REFERENCES department_table (department_code)
);

--����� ���� 
create table commute_management(
   commute_num number(10),
   emp_num varchar2(10) ,
   status varchar2(100) not null,
   year varchar2(10),
   month varchar2(10),
   day varchar2(10),
   hour varchar2(10),
   minute varchar2(10),
   second varchar2(10),
   constraint pk_commute_management primary key(commute_num),
   CONSTRAINT fk_commute_management FOREIGN KEY(emp_num)
   REFERENCES human_resourse_management(emp_num),
   unique (emp_num,status,year,month,day)
); 
--����� ���� ������
CREATE SEQUENCE commute_seq
   MINVALUE 1 MAXVALUE 9999999999999999999999999999 
    INCREMENT BY 1 
    START WITH 1 
    NOCACHE  
    NOORDER  
    NOCYCLE;

-- ����� ��⵵ ����� �޿��� ȸ�質 ���� �޿� db�� ���� ���״��� üũ�ϴ� db
create table pay_check_no(
pay_check_no number(10),
year varchar (10),
month varchar (10),
emp_num varchar (12),
pay_check number (5),
CONSTRAINT PK_pay_check_no PRIMARY KEY (pay_check_no),
unique (year,month,emp_num),
CONSTRAINT fk_pay_check_no FOREIGN KEY(emp_num)
REFERENCES human_resourse_management(emp_num)
);
--üũ ������
create SEQUENCE pay_check_no_seq;


--�޿�����
create table pay_management 
(pay_num number(10), 
 emp_num varchar2(10),  
 pay_division varchar2(20),
total_pay number(20,0), 
real_pay number(20,0), 
income_tax number(20,0), 
residence_tax number(20,0), 
health_insurance number(20,0),
long_recuperation_insurance number(20,0),
unemployment_insurance number(20,0), 
nation_pension number(20,0), 
deduct_pay number(20,0), 
basic_pay number(20,0),
overtime_pay number(20,0),
weekend_pay number(20,0),
incentive_pay number(20,0), 
food_pay number(20,0), 
transportation_pay number(20,0),
annual_pay number(20,0),
year varchar(10),
month varchar(10),
 constraint pk_pay_management primary key (emp_num,year,month),
 constraint fk_pay_management foreign key(emp_num)
 references human_resourse_management(emp_num)
 );   
--�޿����� ������
CREATE SEQUENCE PAY_MANAGEMENT_seq
    MINVALUE 1 MAXVALUE 9999999999999999999999999999 
    INCREMENT BY 1 
    START WITH 1 
    NOCACHE  
    NOORDER  
    NOCYCLE;

--�޿�����-������
create table retire_pay_management (
 retire_pay_num number(10), 
 emp_num varchar2(10),  
 retire_total_pay number(20,0), 
 retire_real_pay  number(20,0), 
 continuous_service_year number(5,0),
 continuous_service_year_pay number(20,0),
 conversion_pay number(20,0),
 conversion_tax number(20,0),
 assessment number(20,0),
 assessment_tax number(20,0),
 retire_income_tax number(20,0),
 retire_resident_tax number(20,0),
 constraint pk_retire_pay_management primary key(emp_num),
 constraint fk_retire_pay_pay_management foreign key(emp_num)
 references human_resourse_management(emp_num)
);

--������ ������
CREATE SEQUENCE retire_pay_management_seq;



--�޿�����(�⺻�� ���̺�)
create table basic_pay_table (
duty_responsibility_code varchar(15),
basic_pay number(20),
   CONSTRAINT fk_basic_pay_table FOREIGN KEY(duty_responsibility_code)
   REFERENCES duty_responsibility_table(duty_responsibility_code)
);

--�޿�����(��Ÿ���� ���̺�)
create table etc_pay_table (
	etc_code varchar(20),
	etc_name varchar(35),
	etc_pay varchar(35),
CONSTRAINT PK_etc_code PRIMARY KEY (etc_code)
);

--���� �ڵ� ���̺�
create table bank(
	bank_code varchar(40),
	bank_name varchar(40),
	constraint pk_bank_code primary key(bank_code)
);

--��� ���� ���̺�
create table commute_absence (    
    absence_code varchar2 (10),
    absence_name varchar2 (40),
    constraint commute_absence_absence_code primary key(absence_code)
    );

--����� ����Ʈ ����
create table emp_absence_list( 
  emp_absence_list_code varchar2(50), 
  emp_num varchar2(20),
  status varchar2(100),  
  start_date varchar2(50),
  end_date varchar2(50),  
   constraint pk_emp_absence_list_code primary key(emp_absence_list_code)
  );
--����� ����Ʈ ������
create SEQUENCE emp_absence_list_seq;


--��� �� �ް� ��û ���� ��ٸ��� ���̺�
create table emp_absence_wait_approval( 
  emp_absence_list_code varchar2(50), 
  emp_num varchar2(20),
  status varchar2(100),  
  start_date varchar2(50),
  end_date varchar2(50),  
   constraint pk_emp_absence_wait_approval primary key(emp_absence_list_code)
  );
--��� �� �ް� ��û ���� ������
create SEQUENCE emp_absence_wait_seq;


--�ҵ漼 ����ϴ� ���̺�
create table income_tax (
income_low number (10), 
income_high number(10),
family1 number(10),
family2 number(10),
family3 number(10),
family4 number(10), 
family5 number(10),
family6 number(10),
family7 number(10),
family8 number(10),
family9 number(10),
family10 number(10),
family11 number(10)
);



-- ERP �޴����� ���̺�

create table role_comparison( -- ���� �� ���̺�
  c_reference VARCHAR2(100), -- ���ذ�
  c_authority_name VARCHAR2(30), -- �����ڵ�
  c_id VARCHAR2(30), -- ���id
  c_authority VARCHAR2(100) -- �������
);

-- ERP ���ٱ��� ���̺�

create table security_role(
r_id VARCHAR2(20) , -- id, ���
r_authority VARCHAR2(50) default ' ' -- ����
);

--�������� ���̺�

create table hospital_information(
  h_name VARCHAR2(30) not null, --������
  h_master VARCHAR2(15), --������ �̸�
  h_master_tel VARCHAR2(20), --������ ����ó
  h_tel VARCHAR2(20), --���� ����ó
  h_map VARCHAR2(300), --���� �ּ�
  h_lnum VARCHAR2(30), --���� ����ڵ����
  h_logo  VARCHAR2(200) --���� �ΰ�
);

--�������� ���̺�

create table user_member(
  u_num number, -- ���� ���ı���
  u_id VARCHAR2(20) primary key, -- id, ���
  u_pwd VARCHAR2(30) not null, -- �н�����
  u_position VARCHAR2(200) , -- ��å
  u_name VARCHAR2(20), -- �̸�
  u_phone VARCHAR2(20), -- ����ó
  u_email VARCHAR2(50), -- �̸���
  u_team VARCHAR2(20), -- �μ�
  u_joindate DATE, -- ������ 
  u_modifydate DATE -- ������ ������
);


-- ������ �ѱ۸�

create table role_korea(
  num NUMBER,
 C_AUTHORITY_NAME VARCHAR2(30),
 c_korea_name VARCHAR2(30)
);


CREATE SEQUENCE  user_member_sequence  
    MINVALUE 1 MAXVALUE 9999999999999999999999999999 
    INCREMENT BY 1 
    START WITH 1 
    NOCACHE  
    NOORDER  
    NOCYCLE ;

-- NOTICE : ��������(�Խ���)
CREATE TABLE NOTICE (
	N_ID NUMBER,
	N_NAME VARCHAR2(20) NOT NULL,
	N_TITLE VARCHAR2(200) NOT NULL,
	N_CONTENT VARCHAR2(2000) NOT NULL,
	N_DATE DATE DEFAULT SYSDATE,
	N_HIT NUMBER DEFAULT 0,
	N_FILESRC VARCHAR2(800) NULL
);
CREATE SEQUENCE NOTICE_SEQ;

-- BIZ_REPORT : ����������(�Խ���)
CREATE TABLE BIZ_REPORT ( -- 1
	B_ID NUMBER,
	B_NAME VARCHAR2(20) NOT NULL,
	B_TITLE VARCHAR2(200) NOT NULL,
	B_CONTENT VARCHAR2(2000) NOT NULL,
	B_DATE DATE DEFAULT SYSDATE,
	B_HIT NUMBER DEFAULT 0,
	B_GROUP NUMBER DEFAULT 0,
	B_STEP NUMBER DEFAULT 0,
	B_INDENT NUMBER DEFAULT 0,
	B_FILESRC VARCHAR2(800) NULL
);
CREATE SEQUENCE BIZ_SEQ;

-- MINUTES : ȸ�Ƿ�(�Խ���)
CREATE TABLE MINUTES (
	M_ID NUMBER,
	M_NAME VARCHAR2(20) NOT NULL,
	M_TITLE VARCHAR2(200) NOT NULL,
	M_CONTENT VARCHAR2(2000) NOT NULL,
	M_DATE DATE DEFAULT SYSDATE,
	M_HIT NUMBER DEFAULT 0,
	M_FILESRC VARCHAR2(800) NULL
);
CREATE SEQUENCE MINUTES_SEQ;
---------------------------------------------------INSERT------------------------------------------------

--ȯ��/����/ó��

insert into medical(M_NO,M_NAME,M_JUMIN1,M_JUMIN2,M_ADDRESS,M_PHONE,M_GENDER ) values
(medical_seq.nextval,'������','111111','1111111','��⵵1','01011111111','��');
insert into medical(M_NO,M_NAME,M_JUMIN1,M_JUMIN2,M_ADDRESS,M_PHONE,M_GENDER ) values
(medical_seq.nextval,'����ȯ','222222','2222222','��⵵2','01022222222','��');
insert into medical(M_NO,M_NAME,M_JUMIN1,M_JUMIN2,M_ADDRESS,M_PHONE,M_GENDER ) values
(medical_seq.nextval,'���̳�','333333','3333333','��⵵3','01033333333','��');
insert into medical(M_NO,M_NAME,M_JUMIN1,M_JUMIN2,M_ADDRESS,M_PHONE,M_GENDER ) values
(medical_seq.nextval,'������','444444','4444444','��⵵4','01044444444','��');
insert into medical(M_NO,M_NAME,M_JUMIN1,M_JUMIN2,M_ADDRESS,M_PHONE,M_GENDER ) values
(medical_seq.nextval,'���¹�','555555','5555555','��⵵5','01055555555','��');
insert into medical(M_NO,M_NAME,M_JUMIN1,M_JUMIN2,M_ADDRESS,M_PHONE,M_GENDER ) values
(medical_seq.nextval,'������','666666','6666666','��⵵6','01066666666','��');

insert into treatment values(treatment_seq.nextval,'����',3000);
insert into treatment values(treatment_seq.nextval,'�˻�',5000);
insert into treatment values(treatment_seq.nextval,'X-Ray',10000);
insert into treatment values(treatment_seq.nextval,'CT',20000);
insert into treatment values(treatment_seq.nextval,'MRI',100000);
insert into treatment values(treatment_seq.nextval,'����ġ��',5000);


INSERT INTO PRESCRIPTION VALUES (0,'ó�����','ó�����');
INSERT INTO PRESCRIPTION VALUES (prescription_seq.nextval,'���׸߽����500mg','����30��');
INSERT INTO PRESCRIPTION VALUES (prescription_seq.nextval,'Ǫ����3mg','����30��');
INSERT INTO PRESCRIPTION VALUES (prescription_seq.nextval,'�ڽ�(�ڿ���)','����30��');
INSERT INTO PRESCRIPTION VALUES (prescription_seq.nextval,'�ƽú����̾���','����30��');
INSERT INTO PRESCRIPTION VALUES (prescription_seq.nextval,'���꽺��Ʈ��50/1000MG','����30��');
INSERT INTO PRESCRIPTION VALUES (prescription_seq.nextval,'�Ը��忥��','����30��');
INSERT INTO PRESCRIPTION VALUES (prescription_seq.nextval,'�����������250','����30��');
INSERT INTO PRESCRIPTION VALUES (prescription_seq.nextval,'�׸��ڹ���','����30��');
INSERT INTO PRESCRIPTION VALUES (prescription_seq.nextval,'�׸�������','����10��');
INSERT INTO PRESCRIPTION VALUES (prescription_seq.nextval,'����(��)200mg','����30��');


--ȸ��
insert into account values(account_seq.nextval,to_char(sysdate, 'yyyy-mm-dd'), 'TEST' ,'�ݰ����ϴ�. ���� �����Ͻð� ����ϼ���', 0,0);

INSERT INTO ACC_TYPE_CODE (TYPE_CODE, TYPE_NAME) VALUES(type_code_seq.nextval, '����'); 
INSERT INTO ACC_TYPE_CODE (TYPE_CODE, TYPE_NAME) VALUES(type_code_seq.nextval, '����/�˻�');
INSERT INTO ACC_TYPE_CODE (TYPE_CODE, TYPE_NAME) VALUES(type_code_seq.nextval, '�Ǿ�ǰ');
INSERT INTO ACC_TYPE_CODE (TYPE_CODE, TYPE_NAME) VALUES(type_code_seq.nextval, '������');
INSERT INTO ACC_TYPE_CODE (TYPE_CODE, TYPE_NAME) VALUES(type_code_seq.nextval, '������');
INSERT INTO ACC_TYPE_CODE (TYPE_CODE, TYPE_NAME) VALUES(type_code_seq.nextval, '��Ÿ');


--�λ�

Insert into DUTY_RESPONSIBILITY_TABLE (DUTY_RESPONSIBILITY_CODE,DUTY_RESPONSIBILITY) values ('00001','������');
Insert into DUTY_RESPONSIBILITY_TABLE (DUTY_RESPONSIBILITY_CODE,DUTY_RESPONSIBILITY) values ('00002','��ȣ��');
Insert into DUTY_RESPONSIBILITY_TABLE (DUTY_RESPONSIBILITY_CODE,DUTY_RESPONSIBILITY) values ('00003','�ڵ������');
Insert into DUTY_RESPONSIBILITY_TABLE (DUTY_RESPONSIBILITY_CODE,DUTY_RESPONSIBILITY) values ('00004','�ǻ�');

Insert into DEPARTMENT_TABLE (DEPARTMENT_CODE,DEPARTMENT) values ('00001','�濵������');
Insert into DEPARTMENT_TABLE (DEPARTMENT_CODE,DEPARTMENT) values ('00002','����μ�');
Insert into DEPARTMENT_TABLE (DEPARTMENT_CODE,DEPARTMENT) values ('00003','�����μ�');

Insert into HUMAN_RESOURSE_MANAGEMENT (EMP_NUM,EMP_NAME,TELEPHONE,TELEPHONE2,ADDRESS_NUMBER,ADDRESS,DEPARTMENT_CODE,JUMIN_NUMBER,GENDER,JOIN_DATE,RETIRE_DATE,EMAIL,RANK_POSITION,DUTY_RESPONSIBILITY_CODE,MARITAL_STATUS,BANK_NAME,ACCOUNT_HOLDER,ACCOUNT_NUMBER,PICTURE,ATTACH_FILE,JOIN_COMPANY_DIVISION,license_type,license_number,license_date,dependent_family,dependent_children,resignation_check) values ('00001','���ٿ�','01042141244','0223122412','62404','���� ���걸 ������ 2-22','00001','8909131234124','����',to_date('16/05/04','RR/MM/DD'),null,'wjdekdns@naver.com',null,'00002','��ȥ','�ѱ�����','���ٿ�','308214208',null,null,'����','��ȣ��','021341',to_date('16/05/04','RR/MM/DD'),3,1,0);
Insert into HUMAN_RESOURSE_MANAGEMENT (EMP_NUM,EMP_NAME,TELEPHONE,TELEPHONE2,ADDRESS_NUMBER,ADDRESS,DEPARTMENT_CODE,JUMIN_NUMBER,GENDER,JOIN_DATE,RETIRE_DATE,EMAIL,RANK_POSITION,DUTY_RESPONSIBILITY_CODE,MARITAL_STATUS,BANK_NAME,ACCOUNT_HOLDER,ACCOUNT_NUMBER,PICTURE,ATTACH_FILE,JOIN_COMPANY_DIVISION,license_type,license_number,license_date,dependent_family,dependent_children,resignation_check) values ('00002','����ȣ','01024312342','05123421231','12715','��� ���ֽ� ���̸� ������� 6','00002','8901231234111','����',to_date('15/02/11','RR/MM/DD'),null,'chlwnsgh@naver.com',null,'00003','��ȥ','�����߾�ȸ','����ȣ','111823231311',null,null,'����',null,null,null,3,1,0);
Insert into HUMAN_RESOURSE_MANAGEMENT (EMP_NUM,EMP_NAME,TELEPHONE,TELEPHONE2,ADDRESS_NUMBER,ADDRESS,DEPARTMENT_CODE,JUMIN_NUMBER,GENDER,JOIN_DATE,RETIRE_DATE,EMAIL,RANK_POSITION,DUTY_RESPONSIBILITY_CODE,MARITAL_STATUS,BANK_NAME,ACCOUNT_HOLDER,ACCOUNT_NUMBER,PICTURE,ATTACH_FILE,JOIN_COMPANY_DIVISION,license_type,license_number,license_date,dependent_family,dependent_children,resignation_check) values ('00003','������','01045632363','0234512354','16979','��� ���ν� ���ﱸ ����� 2','00003','8904031312123','����',to_date('16/01/06','RR/MM/DD'),null,'wjdwlgns@naver.com',null,'00001','��ȥ','�ѱ�����','������','5151131231',null,null,'����','�ǻ�','342321',to_date('16/05/04','RR/MM/DD'),3,1,0);
Insert into HUMAN_RESOURSE_MANAGEMENT (EMP_NUM,EMP_NAME,TELEPHONE,TELEPHONE2,ADDRESS_NUMBER,ADDRESS,DEPARTMENT_CODE,JUMIN_NUMBER,GENDER,JOIN_DATE,RETIRE_DATE,EMAIL,RANK_POSITION,DUTY_RESPONSIBILITY_CODE,MARITAL_STATUS,BANK_NAME,ACCOUNT_HOLDER,ACCOUNT_NUMBER,PICTURE,ATTACH_FILE,JOIN_COMPANY_DIVISION,license_type,license_number,license_date,dependent_family,dependent_children,resignation_check) values ('00004','����ȯ','01023421155','0212411241','16979','��� ���ν� ���ﱸ ����� 2','00002','9210111231233','����',to_date('15/12/01','RR/MM/DD'),null,'wjdtjsghks@naver.com',null,'00004','��ȥ','��������','����ȯ','53901421341',null,null,'���','�ǻ�','021351',to_date('16/05/04','RR/MM/DD'),3,1,0);
Insert into HUMAN_RESOURSE_MANAGEMENT (EMP_NUM,EMP_NAME,TELEPHONE,TELEPHONE2,ADDRESS_NUMBER,ADDRESS,DEPARTMENT_CODE,JUMIN_NUMBER,GENDER,JOIN_DATE,RETIRE_DATE,EMAIL,RANK_POSITION,DUTY_RESPONSIBILITY_CODE,MARITAL_STATUS,BANK_NAME,ACCOUNT_HOLDER,ACCOUNT_NUMBER,PICTURE,ATTACH_FILE,JOIN_COMPANY_DIVISION,license_type,license_number,license_date,dependent_family,dependent_children,resignation_check) values ('00005','������','01013411241','0212411231','14901','��� ����� ������ 40-5','00002','8412131234111','����',to_date('15/12/30','RR/MM/DD'),null,'qkrwhdgns@naver.com',null,'00004','��ȥ','�ѱ����Ĵٵ���Ÿ������','������','621323123212',null,null,'���','�ǻ�','021361',to_date('16/05/04','RR/MM/DD'),3,1,0);
Insert into HUMAN_RESOURSE_MANAGEMENT (EMP_NUM,EMP_NAME,TELEPHONE,TELEPHONE2,ADDRESS_NUMBER,ADDRESS,DEPARTMENT_CODE,JUMIN_NUMBER,GENDER,JOIN_DATE,RETIRE_DATE,EMAIL,RANK_POSITION,DUTY_RESPONSIBILITY_CODE,MARITAL_STATUS,BANK_NAME,ACCOUNT_HOLDER,ACCOUNT_NUMBER,PICTURE,ATTACH_FILE,JOIN_COMPANY_DIVISION,license_type,license_number,license_date,dependent_family,dependent_children,resignation_check) values ('00006','������','01034531231','0243561134','13485','��� ������ �д籸 �Ǳ��� 20','00002','9201232312312','����',to_date('13/01/01','RR/MM/DD'),to_date('15/12/01','RR/MM/DD'),'tlswjddms@gmail.com',null,'00002','��ȥ','�ѱ���Ƽ����','������','42341212312123',null,null,'���','��ȣ��','021371',to_date('16/05/04','RR/MM/DD'),3,1,0);
Insert into HUMAN_RESOURSE_MANAGEMENT (EMP_NUM,EMP_NAME,TELEPHONE,TELEPHONE2,ADDRESS_NUMBER,ADDRESS,DEPARTMENT_CODE,JUMIN_NUMBER,GENDER,JOIN_DATE,RETIRE_DATE,EMAIL,RANK_POSITION,DUTY_RESPONSIBILITY_CODE,MARITAL_STATUS,BANK_NAME,ACCOUNT_HOLDER,ACCOUNT_NUMBER,PICTURE,ATTACH_FILE,JOIN_COMPANY_DIVISION,license_type,license_number,license_date,dependent_family,dependent_children,resignation_check) values ('00007','���̳�','01043544645','0235258852','13536','��� ������ �д籸 �Ǳ����� 12','00002','9112312234235','����',to_date('12/01/31','RR/MM/DD'),to_date('16/06/08','RR/MM/DD'),'dbsdlsk@gmail.com',null,'00002','��ȥ','��ȯ����','���̳�','41797234223',null,null,'���','��ȣ��','021381',to_date('16/05/04','RR/MM/DD'),3,1,0);

Insert into BASIC_PAY_TABLE (DUTY_RESPONSIBILITY_CODE,BASIC_PAY) values ('00001',50000000);
Insert into BASIC_PAY_TABLE (DUTY_RESPONSIBILITY_CODE,BASIC_PAY) values ('00002',3000000);
Insert into BASIC_PAY_TABLE (DUTY_RESPONSIBILITY_CODE,BASIC_PAY) values ('00003',2500000);
Insert into BASIC_PAY_TABLE (DUTY_RESPONSIBILITY_CODE,BASIC_PAY) values ('00004',40000000);


Insert into BANK (BANK_CODE,BANK_NAME) values ('1','�ѱ�����');
Insert into BANK (BANK_CODE,BANK_NAME) values ('2','�������');
Insert into BANK (BANK_CODE,BANK_NAME) values ('3','�������');
Insert into BANK (BANK_CODE,BANK_NAME) values ('4','��������');
Insert into BANK (BANK_CODE,BANK_NAME) values ('5','��ȯ����');
Insert into BANK (BANK_CODE,BANK_NAME) values ('7','�����߾�ȸ');
Insert into BANK (BANK_CODE,BANK_NAME) values ('8','����������');
Insert into BANK (BANK_CODE,BANK_NAME) values ('11','�����߾�ȸ');
Insert into BANK (BANK_CODE,BANK_NAME) values ('12','��������(����)');
Insert into BANK (BANK_CODE,BANK_NAME) values ('20','�츮����');
Insert into BANK (BANK_CODE,BANK_NAME) values ('23','�ѱ����Ĵٵ���Ÿ������');
Insert into BANK (BANK_CODE,BANK_NAME) values ('27','�ѱ���Ƽ����');
Insert into BANK (BANK_CODE,BANK_NAME) values ('31','�뱸����');
Insert into BANK (BANK_CODE,BANK_NAME) values ('32','�λ�����');
Insert into BANK (BANK_CODE,BANK_NAME) values ('34','��������');
Insert into BANK (BANK_CODE,BANK_NAME) values ('35','��������');
Insert into BANK (BANK_CODE,BANK_NAME) values ('37','��������');
Insert into BANK (BANK_CODE,BANK_NAME) values ('39','�泲����');
Insert into BANK (BANK_CODE,BANK_NAME) values ('45','�������ݰ��߾�ȸ');
Insert into BANK (BANK_CODE,BANK_NAME) values ('48','�����߾�ȸ');
Insert into BANK (BANK_CODE,BANK_NAME) values ('50','��ȣ��������');
Insert into BANK (BANK_CODE,BANK_NAME) values ('52','��ǽ��ĸ�����');
Insert into BANK (BANK_CODE,BANK_NAME) values ('54','HSBC����');
Insert into BANK (BANK_CODE,BANK_NAME) values ('55','����ġ����');
Insert into BANK (BANK_CODE,BANK_NAME) values ('56','�˺񿡽�����');
Insert into BANK (BANK_CODE,BANK_NAME) values ('57','�����Ǹ�ü�̽�����');
Insert into BANK (BANK_CODE,BANK_NAME) values ('58','����ȣ���۷���Ʈ����');
Insert into BANK (BANK_CODE,BANK_NAME) values ('59','�̾���õ���UFJ����');
Insert into BANK (BANK_CODE,BANK_NAME) values ('60','BOA����');
Insert into BANK (BANK_CODE,BANK_NAME) values ('61','�����ĸ�������');
Insert into BANK (BANK_CODE,BANK_NAME) values ('64','�긳�����߾�ȸ');
Insert into BANK (BANK_CODE,BANK_NAME) values ('71','���İ�����');
Insert into BANK (BANK_CODE,BANK_NAME) values ('76','�ſ뺸�����');
Insert into BANK (BANK_CODE,BANK_NAME) values ('77','����������');
Insert into BANK (BANK_CODE,BANK_NAME) values ('81','�ϳ�����');
Insert into BANK (BANK_CODE,BANK_NAME) values ('88','��������');
Insert into BANK (BANK_CODE,BANK_NAME) values ('92','�ѱ���å��������');
Insert into BANK (BANK_CODE,BANK_NAME) values ('93','�ѱ����ñ�������');
Insert into BANK (BANK_CODE,BANK_NAME) values ('94','���ﺸ������');
Insert into BANK (BANK_CODE,BANK_NAME) values ('95','����û');
Insert into BANK (BANK_CODE,BANK_NAME) values ('96','�ѱ����ڱ���(��)');
Insert into BANK (BANK_CODE,BANK_NAME) values ('99','����������');
Insert into BANK (BANK_CODE,BANK_NAME) values ('209','����Ÿ����');
Insert into BANK (BANK_CODE,BANK_NAME) values ('218','��������');
Insert into BANK (BANK_CODE,BANK_NAME) values ('230','�̷���������');
Insert into BANK (BANK_CODE,BANK_NAME) values ('238','�������');
Insert into BANK (BANK_CODE,BANK_NAME) values ('240','�Ｚ����');
Insert into BANK (BANK_CODE,BANK_NAME) values ('243','�ѱ���������');
Insert into BANK (BANK_CODE,BANK_NAME) values ('247','�츮��������');
Insert into BANK (BANK_CODE,BANK_NAME) values ('261','��������');
Insert into BANK (BANK_CODE,BANK_NAME) values ('262','������������');
Insert into BANK (BANK_CODE,BANK_NAME) values ('263','HMC��������');
Insert into BANK (BANK_CODE,BANK_NAME) values ('264','Ű������');
Insert into BANK (BANK_CODE,BANK_NAME) values ('265','�̺���Ʈ��������');
Insert into BANK (BANK_CODE,BANK_NAME) values ('266','SK����');
Insert into BANK (BANK_CODE,BANK_NAME) values ('267','�������');
Insert into BANK (BANK_CODE,BANK_NAME) values ('268','���̿���������');
Insert into BANK (BANK_CODE,BANK_NAME) values ('269','��ȭ��������');
Insert into BANK (BANK_CODE,BANK_NAME) values ('270','�ϳ���������');
Insert into BANK (BANK_CODE,BANK_NAME) values ('278','���ѱ�������');
Insert into BANK (BANK_CODE,BANK_NAME) values ('279','��������');
Insert into BANK (BANK_CODE,BANK_NAME) values ('280','������������');
Insert into BANK (BANK_CODE,BANK_NAME) values ('287','�޸������ձ�������');
Insert into BANK (BANK_CODE,BANK_NAME) values ('289','NH��������');
Insert into BANK (BANK_CODE,BANK_NAME) values ('290','�α�����');
Insert into BANK (BANK_CODE,BANK_NAME) values ('291','�ſ�����');
Insert into BANK (BANK_CODE,BANK_NAME) values ('292','����������������');


Insert into COMMUTE_ABSENCE (ABSENCE_CODE,ABSENCE_NAME) values ('00001','�ް�');
Insert into COMMUTE_ABSENCE (ABSENCE_CODE,ABSENCE_NAME) values ('00002','����');
Insert into COMMUTE_ABSENCE (ABSENCE_CODE,ABSENCE_NAME) values ('00003','������');
Insert into COMMUTE_ABSENCE (ABSENCE_CODE,ABSENCE_NAME) values ('00004','�İ�');
Insert into COMMUTE_ABSENCE (ABSENCE_CODE,ABSENCE_NAME) values ('00005','����');
Insert into COMMUTE_ABSENCE (ABSENCE_CODE,ABSENCE_NAME) values ('00006','������������');
Insert into COMMUTE_ABSENCE (ABSENCE_CODE,ABSENCE_NAME) values ('00020','�ӽð�����');
Insert into COMMUTE_ABSENCE (ABSENCE_CODE,ABSENCE_NAME) values ('00021','����');
Insert into COMMUTE_ABSENCE (ABSENCE_CODE,ABSENCE_NAME) values ('00022','����');
Insert into COMMUTE_ABSENCE (ABSENCE_CODE,ABSENCE_NAME) values ('00023','������');
Insert into COMMUTE_ABSENCE (ABSENCE_CODE,ABSENCE_NAME) values ('00024','��̳�');
Insert into COMMUTE_ABSENCE (ABSENCE_CODE,ABSENCE_NAME) values ('00025','����ź����');
Insert into COMMUTE_ABSENCE (ABSENCE_CODE,ABSENCE_NAME) values ('00026','������');
Insert into COMMUTE_ABSENCE (ABSENCE_CODE,ABSENCE_NAME) values ('00027','������');
Insert into COMMUTE_ABSENCE (ABSENCE_CODE,ABSENCE_NAME) values ('00028','�߼�');
Insert into COMMUTE_ABSENCE (ABSENCE_CODE,ABSENCE_NAME) values ('00029','��õ��');
Insert into COMMUTE_ABSENCE (ABSENCE_CODE,ABSENCE_NAME) values ('00030','�ѱ۳�');
Insert into COMMUTE_ABSENCE (ABSENCE_CODE,ABSENCE_NAME) values ('00031','ũ��������');



Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00001','���','2016','05','02','09','25','01');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00001','���','2016','05','02','15','10','22');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00001','���','2016','05','03','09','47','47');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00001','���','2016','05','03','16','46','39');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00001','���','2016','05','04','10','56','18');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00001','���','2016','05','04','18','32','03');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00001','���','2016','05','05','08','37','20');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00001','���','2016','05','05','17','35','20');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00001','���','2016','05','06','08','04','24');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00001','���','2016','05','06','16','54','35');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00001','���','2016','05','09','09','40','43');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00001','���','2016','05','09','18','52','28');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00001','���','2016','05','10','11','10','49');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00001','���','2016','05','10','19','25','38');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00001','���','2016','05','11','09','47','28');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00001','���','2016','05','11','17','55','03');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00001','���','2016','05','12','09','27','53');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00001','���','2016','05','12','16','32','37');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00001','���','2016','05','13','09','12','04');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00001','���','2016','05','13','16','55','55');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00001','���','2016','05','16','11','12','52');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00001','���','2016','05','16','17','15','59');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00001','���','2016','05','17','11','05','47');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00001','���','2016','05','17','18','33','43');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00001','���','2016','05','18','11','07','41');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00001','���','2016','05','18','20','35','06');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00001','���','2016','05','19','09','09','28');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00001','���','2016','05','19','20','33','25');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00001','���','2016','05','20','11','03','01');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00001','���','2016','05','20','17','16','47');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00001','���','2016','05','23','10','57','06');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00001','���','2016','05','23','16','51','11');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00001','���','2016','05','24','08','15','57');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00001','���','2016','05','24','18','53','34');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00001','���','2016','05','25','10','22','55');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00001','���','2016','05','25','17','16','45');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00001','���','2016','05','26','08','10','03');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00001','���','2016','05','26','19','02','17');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00001','���','2016','05','27','09','52','27');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00001','���','2016','05','27','16','34','57');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00001','���','2016','05','30','11','53','25');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00001','���','2016','05','30','15','59','15');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00001','���','2016','05','31','09','44','15');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00001','���','2016','05','31','19','33','18');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00002','���','2016','05','02','09','25','01');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00002','���','2016','05','02','15','10','22');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00002','���','2016','05','03','09','47','47');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00002','���','2016','05','03','16','46','39');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00002','���','2016','05','04','10','56','18');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00002','���','2016','05','04','18','32','03');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00002','���','2016','05','05','08','37','20');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00002','���','2016','05','05','17','35','20');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00002','���','2016','05','06','08','04','24');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00002','���','2016','05','06','16','54','35');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00002','���','2016','05','09','09','40','43');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00002','���','2016','05','09','18','52','28');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00002','���','2016','05','10','11','10','49');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00002','���','2016','05','10','19','25','38');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00002','���','2016','05','11','09','47','28');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00002','���','2016','05','11','17','55','03');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00002','���','2016','05','12','09','27','53');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00002','���','2016','05','12','16','32','37');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00002','���','2016','05','13','09','12','04');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00002','���','2016','05','13','16','55','55');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00002','���','2016','05','16','11','12','52');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00002','���','2016','05','16','17','15','59');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00002','���','2016','05','17','11','05','47');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00002','���','2016','05','17','18','33','43');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00002','���','2016','05','18','11','07','41');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00002','���','2016','05','18','20','35','06');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00002','���','2016','05','19','09','09','28');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00002','���','2016','05','19','20','33','25');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00002','���','2016','05','20','11','03','01');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00002','���','2016','05','20','17','16','47');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00002','���','2016','05','23','10','57','06');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00002','���','2016','05','23','16','51','11');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00002','���','2016','05','24','08','15','57');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00002','���','2016','05','24','18','53','34');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00002','���','2016','05','25','10','22','55');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00002','���','2016','05','25','17','16','45');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00002','���','2016','05','26','08','10','03');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00002','���','2016','05','26','19','02','17');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00002','���','2016','05','27','09','52','27');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00002','���','2016','05','27','16','34','57');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00002','���','2016','05','30','11','53','25');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00002','���','2016','05','30','15','59','15');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00002','���','2016','05','31','09','44','15');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00002','���','2016','05','31','19','33','18');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00003','���','2016','05','02','09','25','01');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00003','���','2016','05','02','15','10','22');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00003','���','2016','05','03','09','47','47');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00003','���','2016','05','03','16','46','39');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00003','���','2016','05','04','10','56','18');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00003','���','2016','05','04','18','32','03');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00003','���','2016','05','05','08','37','20');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00003','���','2016','05','05','17','35','20');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00003','���','2016','05','06','08','04','24');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00003','���','2016','05','06','16','54','35');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00003','���','2016','05','09','09','40','43');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00003','���','2016','05','09','18','52','28');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00003','���','2016','05','10','11','10','49');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00003','���','2016','05','10','19','25','38');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00003','���','2016','05','11','09','47','28');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00003','���','2016','05','11','17','55','03');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00003','���','2016','05','12','09','27','53');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00003','���','2016','05','12','16','32','37');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00003','���','2016','05','13','09','12','04');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00003','���','2016','05','13','16','55','55');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00003','���','2016','05','16','11','12','52');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00003','���','2016','05','16','17','15','59');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00003','���','2016','05','17','11','05','47');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00003','���','2016','05','17','18','33','43');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00003','���','2016','05','18','11','07','41');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00003','���','2016','05','18','20','35','06');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00003','���','2016','05','19','09','09','28');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00003','���','2016','05','19','20','33','25');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00003','���','2016','05','20','11','03','01');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00003','���','2016','05','20','17','16','47');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00003','���','2016','05','23','10','57','06');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00003','���','2016','05','23','16','51','11');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00003','���','2016','05','24','08','15','57');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00003','���','2016','05','24','18','53','34');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00003','���','2016','05','25','10','22','55');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00003','���','2016','05','25','17','16','45');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00003','���','2016','05','26','08','10','03');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00003','���','2016','05','26','19','02','17');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00003','���','2016','05','27','09','52','27');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00003','���','2016','05','27','16','34','57');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00003','���','2016','05','30','11','53','25');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00003','���','2016','05','30','15','59','15');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00003','���','2016','05','31','09','44','15');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00003','���','2016','05','31','19','33','18');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00004','���','2016','05','02','09','25','01');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00004','���','2016','05','02','15','10','22');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00004','���','2016','05','03','09','47','47');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00004','���','2016','05','03','16','46','39');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00004','���','2016','05','04','10','56','18');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00004','���','2016','05','04','18','32','03');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00004','���','2016','05','05','08','37','20');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00004','���','2016','05','05','17','35','20');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00004','���','2016','05','06','08','04','24');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00004','���','2016','05','06','16','54','35');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00004','���','2016','05','09','09','40','43');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00004','���','2016','05','09','18','52','28');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00004','���','2016','05','10','11','10','49');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00004','���','2016','05','10','19','25','38');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00004','���','2016','05','11','09','47','28');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00004','���','2016','05','11','17','55','03');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00004','���','2016','05','12','09','27','53');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00004','���','2016','05','12','16','32','37');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00004','���','2016','05','13','09','12','04');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00004','���','2016','05','13','16','55','55');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00004','���','2016','05','16','11','12','52');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00004','���','2016','05','16','17','15','59');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00004','���','2016','05','17','11','05','47');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00004','���','2016','05','17','18','33','43');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00004','���','2016','05','18','11','07','41');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00004','���','2016','05','18','20','35','06');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00004','���','2016','05','19','09','09','28');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00004','���','2016','05','19','20','33','25');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00004','���','2016','05','20','11','03','01');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00004','���','2016','05','20','17','16','47');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00004','���','2016','05','23','10','57','06');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00004','���','2016','05','23','16','51','11');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00004','���','2016','05','24','08','15','57');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00004','���','2016','05','24','18','53','34');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00004','���','2016','05','25','10','22','55');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00004','���','2016','05','25','17','16','45');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00004','���','2016','05','26','08','10','03');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00004','���','2016','05','26','19','02','17');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00004','���','2016','05','27','09','52','27');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00004','���','2016','05','27','16','34','57');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00004','���','2016','05','30','11','53','25');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00004','���','2016','05','30','15','59','15');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00004','���','2016','05','31','09','44','15');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00004','���','2016','05','31','19','33','18');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00005','���','2016','05','02','09','25','01');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00005','���','2016','05','02','15','10','22');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00005','���','2016','05','03','09','47','47');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00005','���','2016','05','03','16','46','39');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00005','���','2016','05','04','10','56','18');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00005','���','2016','05','04','18','32','03');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00005','���','2016','05','05','08','37','20');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00005','���','2016','05','05','17','35','20');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00005','���','2016','05','06','08','04','24');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00005','���','2016','05','06','16','54','35');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00005','���','2016','05','09','09','40','43');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00005','���','2016','05','09','18','52','28');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00005','���','2016','05','10','11','10','49');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00005','���','2016','05','10','19','25','38');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00005','���','2016','05','11','09','47','28');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00005','���','2016','05','11','17','55','03');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00005','���','2016','05','12','09','27','53');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00005','���','2016','05','12','16','32','37');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00005','���','2016','05','13','09','12','04');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00005','���','2016','05','13','16','55','55');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00005','���','2016','05','16','11','12','52');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00005','���','2016','05','16','17','15','59');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00005','���','2016','05','17','11','05','47');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00005','���','2016','05','17','18','33','43');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00005','���','2016','05','18','11','07','41');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00005','���','2016','05','18','20','35','06');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00005','���','2016','05','19','09','09','28');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00005','���','2016','05','19','20','33','25');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00005','���','2016','05','20','11','03','01');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00005','���','2016','05','20','17','16','47');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00005','���','2016','05','23','10','57','06');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00005','���','2016','05','23','16','51','11');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00005','���','2016','05','24','08','15','57');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00005','���','2016','05','24','18','53','34');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00005','���','2016','05','25','10','22','55');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00005','���','2016','05','25','17','16','45');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00005','���','2016','05','26','08','10','03');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00005','���','2016','05','26','19','02','17');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00005','���','2016','05','27','09','52','27');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00005','���','2016','05','27','16','34','57');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00005','���','2016','05','30','11','53','25');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00005','���','2016','05','30','15','59','15');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00005','���','2016','05','31','09','44','15');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00005','���','2016','05','31','19','33','18');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00001','���','2016','06','16','11','38','51');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00001','���','2016','06','16','11','38','54');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00002','���','2016','06','16','11','39','23');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00002','���','2016','06','16','11','39','26');
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00001','�ް�','2016','06','01',null,null,null);
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00001','�ް�','2016','06','02',null,null,null);
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00001','�ް�','2016','06','03',null,null,null);
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00001','�ް�','2016','06','04',null,null,null);
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00001','�ް�','2016','06','05',null,null,null);
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00001','�ް�','2016','06','06',null,null,null);
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00001','�ް�','2016','06','07',null,null,null);
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00001','�ް�','2016','06','08',null,null,null);
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00001','�ް�','2016','06','09',null,null,null);
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00001','�ް�','2016','06','10',null,null,null);
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00002','����','2016','06','10',null,null,null);
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00002','����','2016','06','11',null,null,null);
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00002','����','2016','06','12',null,null,null);
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00002','����','2016','06','13',null,null,null);
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00002','����','2016','06','14',null,null,null);
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00002','����','2016','06','15',null,null,null);
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00003','������','2016','06','07',null,null,null);
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00003','������','2016','06','08',null,null,null);
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00003','������','2016','06','09',null,null,null);
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00004','�İ�(����)','2016','06','06',null,null,null);
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00004','�İ�(����)','2016','06','07',null,null,null);
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00004','�İ�(����)','2016','06','08',null,null,null);
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00005','�ް�','2016','06','16',null,null,null);
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00005','�ް�','2016','06','17',null,null,null);
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00005','�ް�','2016','06','18',null,null,null);
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00005','�ް�','2016','06','19',null,null,null);
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00005','�ް�','2016','06','20',null,null,null);
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00005','�ް�','2016','06','21',null,null,null);
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00005','�ް�','2016','06','22',null,null,null);
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00005','�ް�','2016','06','23',null,null,null);
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00005','�ް�','2016','06','24',null,null,null);
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00005','�ް�','2016','06','25',null,null,null);
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00005','�ް�','2016','06','26',null,null,null);
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00005','�ް�','2016','06','27',null,null,null);
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00005','�ް�','2016','06','28',null,null,null);
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00005','�ް�','2016','06','29',null,null,null);
Insert into COMMUTE_MANAGEMENT (COMMUTE_NUM,EMP_NUM,STATUS,YEAR,MONTH,DAY,HOUR,MINUTE,SECOND) values (commute_seq.nextval,'00005','�ް�','2016','06','30',null,null,null);

Insert into ETC_PAY_TABLE (ETC_CODE,ETC_NAME,ETC_PAY) values ('00001','�ð��ܼ���','1.5');
Insert into ETC_PAY_TABLE (ETC_CODE,ETC_NAME,ETC_PAY) values ('00002','�ָ��ٹ�����','1.5');
Insert into ETC_PAY_TABLE (ETC_CODE,ETC_NAME,ETC_PAY) values ('00003','�Ĵ�','150000');
Insert into ETC_PAY_TABLE (ETC_CODE,ETC_NAME,ETC_PAY) values ('00004','�����','150000');
Insert into ETC_PAY_TABLE (ETC_CODE,ETC_NAME,ETC_PAY) values ('00005','�󿩱�','0');
Insert into ETC_PAY_TABLE (ETC_CODE,ETC_NAME,ETC_PAY) values ('00006','��������','-1');

Insert into EMP_ABSENCE_LIST (EMP_ABSENCE_LIST_CODE,EMP_NUM,STATUS,START_DATE,END_DATE) values (emp_absence_list_seq.nextval,'00001','�ް�','2016-06-01','2016-06-10');
Insert into EMP_ABSENCE_LIST (EMP_ABSENCE_LIST_CODE,EMP_NUM,STATUS,START_DATE,END_DATE) values (emp_absence_list_seq.nextval,'00002','����','2016-06-10','2016-06-15');
Insert into EMP_ABSENCE_LIST (EMP_ABSENCE_LIST_CODE,EMP_NUM,STATUS,START_DATE,END_DATE) values (emp_absence_list_seq.nextval,'00003','������','2016-06-07','2016-06-09');
Insert into EMP_ABSENCE_LIST (EMP_ABSENCE_LIST_CODE,EMP_NUM,STATUS,START_DATE,END_DATE) values (emp_absence_list_seq.nextval,'00004','�İ�(����)','2016-06-06','2016-06-08');
Insert into EMP_ABSENCE_LIST (EMP_ABSENCE_LIST_CODE,EMP_NUM,STATUS,START_DATE,END_DATE) values (emp_absence_list_seq.nextval,'00005','�ް�','2016-06-16','2016-06-30');

Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (775,780,0,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (785,790,0,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (800,805,0,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (805,810,0,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (810,815,0,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (825,830,0,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (845,850,0,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (855,860,0,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (860,865,0,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (865,870,0,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (875,880,0,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (890,895,0,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (925,930,0,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (930,935,0,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (935,940,0,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (950,955,0,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (960,965,0,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (965,970,0,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (975,980,0,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (985,990,0,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (990,995,0,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1020,1025,0,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1035,1040,0,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1045,1050,0,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1065,1070,1110,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1070,1075,1180,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1075,1080,1250,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1085,1090,1390,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1100,1105,1600,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1105,1110,1670,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1135,1140,2090,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1140,1145,2160,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1145,1150,2230,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1155,1160,2370,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1165,1170,2500,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1180,1185,2710,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1190,1195,2850,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1210,1215,3130,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1215,1220,3200,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1220,1225,3270,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1250,1255,3700,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1260,1265,3910,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1265,1270,4010,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1270,1275,4120,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1275,1280,4220,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1320,1325,5150,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1330,1335,5360,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1335,1340,5460,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1350,1355,5770,1270,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1355,1360,5870,1370,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1375,1380,6290,1790,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1390,1395,6600,2100,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1405,1410,6910,2410,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1420,1425,7210,2710,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1425,1430,7320,2820,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1430,1435,7420,2920,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1435,1440,7520,3020,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1455,1460,7940,3440,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1475,1480,8350,3850,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1480,1485,8450,3950,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1490,1495,8660,4160,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1530,1540,9540,5040,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1550,1560,9950,5450,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1560,1570,10160,5660,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1580,1590,10570,6070,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1590,1600,10780,6280,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1630,1640,11600,7100,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1650,1660,12020,7520,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1660,1670,12220,7720,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1670,1680,12430,7930,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1720,1730,13460,8960,1040,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1740,1750,13880,9380,1440,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1780,1790,14700,10200,2230,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1810,1820,15320,10820,2830,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1820,1830,15530,11030,3020,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1830,1840,15730,11230,3220,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1850,1860,16150,11650,3620,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1860,1870,16350,11850,3820,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1870,1880,16560,12060,4020,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1910,1920,17390,12890,4810,1440,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1930,1940,17800,13300,5210,1830,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1940,1950,18010,13510,5410,2030,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1950,1960,18210,13710,5600,2230,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1980,1990,18880,14330,6200,2820,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2020,2030,20170,15160,6990,3620,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2030,2040,20490,15370,7190,3820,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2040,2050,20810,15570,7390,4020,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2060,2070,21450,15990,7790,4410,1040,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2070,2080,21770,16190,7990,4610,1240,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2080,2090,22090,16400,8180,4810,1430,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2090,2100,22420,16600,8380,5010,1630,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2100,2110,22740,16810,8580,5210,1830,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2120,2130,23380,17220,8980,5600,2230,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2150,2160,24340,17840,9570,6200,2820,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2160,2170,24660,18050,9770,6400,3020,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2170,2180,24990,18260,9970,6600,3220,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2180,2190,25310,18460,10170,6790,3420,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2200,2210,25950,18950,10570,7190,3820,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2220,2230,26590,19590,10960,7590,4210,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2240,2250,27240,20240,11360,7980,4610,1230,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2250,2260,27560,20560,11560,8180,4810,1430,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2260,2270,27880,20880,11760,8380,5010,1630,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2270,2280,28200,21200,11960,8580,5210,1830,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2280,2290,28520,21520,12150,8780,5400,2030,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2310,2320,29480,22480,12750,9370,6000,2620,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2320,2330,29810,22810,12950,9570,6200,2820,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2340,2350,30450,23450,13340,9970,6590,3220,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2350,2360,30770,23770,13540,10170,6790,3420,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2360,2370,31090,24090,13740,10370,6990,3620,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2370,2380,31410,24410,13940,10560,7190,3810,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2380,2390,31970,24730,14140,10760,7390,4010,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2390,2400,32770,25050,14340,10960,7590,4210,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2400,2410,33570,25380,14530,11160,7780,4410,1030,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2420,2430,35180,26020,14930,11560,8180,4810,1430,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2430,2440,35980,26340,15130,11760,8380,5010,1630,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2440,2450,36790,26660,15330,11950,8580,5200,1830,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2450,2460,37590,26980,15530,12150,8780,5400,2030,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2480,2490,40000,27950,16120,12750,9370,6000,2620,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2500,2510,41630,28600,16530,13150,9780,6400,3030,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2510,2520,42490,28940,16740,13360,9990,6610,3240,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2520,2530,43340,29280,16950,13580,10200,6830,3450,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2530,2540,44200,29630,17160,13790,10410,7040,3660,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2540,2550,45050,29970,17370,14000,10620,7250,3870,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2550,2560,45910,30310,17590,14210,10840,7460,4090,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2560,2570,46770,30650,17800,14420,11050,7670,4300,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2570,2580,47620,31000,18010,14630,11260,7880,4510,1130,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2580,2590,48480,31340,18220,14850,11470,8100,4720,1350,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2590,2600,49330,31830,18430,15060,11680,8310,4930,1560,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2600,2610,50190,32690,18650,15270,11900,8520,5150,1770,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2610,2620,51040,33540,18920,15480,12110,8730,5360,1980,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2620,2630,51900,34400,19250,15690,12320,8940,5570,2190,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2640,2650,53610,36110,19910,16120,12740,9370,5990,2620,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2650,2660,54470,36970,20240,16330,12960,9580,6210,2830,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2670,2680,56180,38680,20900,16750,13380,10000,6630,3250,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2680,2690,57040,39540,21230,16970,13590,10220,6840,3470,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2690,2700,57890,40390,21560,17180,13800,10430,7050,3680,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2710,2720,59600,42100,22220,17600,14230,10850,7480,4100,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2720,2730,60460,42960,22550,17810,14440,11060,7690,4310,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2730,2740,61310,43810,22880,18030,14650,11280,7900,4530,1150,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2740,2750,62170,44670,23210,18240,14860,11490,8110,4740,1360,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2750,2760,63030,45530,23540,18450,15070,11700,8320,4950,1570,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2760,2770,63880,46380,23870,18660,15290,11910,8540,5160,1790,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2770,2780,64740,47240,24200,18950,15500,12120,8750,5370,2000,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2780,2790,65590,48090,24520,19270,15710,12340,8960,5590,2210,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2790,2800,66450,48950,24850,19600,15920,12550,9170,5800,2420,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2800,2810,67300,49800,25180,19930,16130,12760,9380,6010,2630,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2810,2820,68160,50660,25510,20260,16350,12970,9600,6220,2850,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2820,2830,69020,51520,25840,20590,16560,13180,9810,6430,3060,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2830,2840,69870,52370,26170,20920,16770,13400,10020,6650,3270,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2840,2850,70730,53230,26500,21250,16980,13610,10230,6860,3480,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2850,2860,71580,54080,26830,21580,17190,13820,10440,7070,3690,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2860,2870,72440,54940,27160,21910,17410,14030,10660,7280,3910,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2870,2880,73290,55790,27490,22240,17620,14240,10870,7490,4120,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2880,2890,74150,56650,27820,22570,17830,14460,11080,7710,4330,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2890,2900,75010,57510,28150,22900,18040,14670,11290,7920,4540,1170,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2900,2910,75860,58360,28480,23230,18250,14880,11500,8130,4750,1380,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2910,2920,76720,59220,28810,23560,18470,15090,11720,8340,4970,1590,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2920,2930,77570,60070,29140,23890,18680,15300,11930,8550,5180,1800,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2930,2940,78430,60930,29470,24220,18970,15510,12140,8760,5390,2010,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2940,2950,79280,61780,29800,24550,19300,15730,12350,8980,5600,2230,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2950,2960,80140,62640,30130,24880,19630,15940,12560,9190,5810,2440,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2960,2970,81000,63500,30460,25210,19960,16150,12780,9400,6030,2650,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2970,2980,81850,64350,30790,25540,20290,16360,12990,9610,6240,2860,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2980,2990,82710,65210,31120,25870,20620,16570,13200,9820,6450,3070,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2990,3000,83560,66060,31450,26200,20950,16790,13410,10040,6660,3290,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (3000,3020,84850,67350,32490,26690,21440,17100,13730,10350,6980,3600,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (3020,3040,86560,69060,34140,27350,22100,17530,14150,10780,7400,4030,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (3040,3060,88270,70770,35790,28010,22760,17950,14580,11200,7830,4450,1080);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (3060,3080,89980,72480,37440,28670,23420,18380,15000,11630,8250,4880,1500);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (3080,3100,91690,74190,39080,29330,24080,18830,15430,12050,8680,5300,1930);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (3100,3120,93400,75900,40730,29990,24740,19490,15850,12470,9100,5720,2350);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (3120,3140,95760,77620,42380,30650,25400,20150,16270,12900,9520,6150,2770);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (3140,3160,98210,79330,44030,31310,26060,20810,16700,13320,9950,6570,3200);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (3160,3180,100650,81040,45680,32550,26720,21470,17120,13750,10370,7000,3620);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (3180,3200,103100,82750,47330,34200,27380,22130,17540,14170,10790,7420,4040);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (3200,3220,105540,84460,48980,35850,28040,22790,17970,14590,11220,7840,4470);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (3220,3240,107990,86170,50620,37500,28700,23450,18390,15020,11640,8270,4890);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (3240,3260,110430,87880,52270,39150,29360,24110,18860,15440,12070,8690,5320);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (3260,3280,112880,89600,53920,40800,30020,24770,19520,15870,12490,9120,5740);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (3280,3300,115320,91310,55570,42440,30670,25420,20170,16290,12910,9540,6160);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (3300,3320,117770,93020,57220,44090,31330,26080,20830,16710,13340,9960,6590);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (3320,3340,120210,95210,58870,45740,32620,26740,21490,17140,13760,10390,7010);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (3340,3360,122660,97660,60440,47320,34190,27370,22120,17540,14170,10790,7420);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (3360,3380,125100,100100,62010,48880,35760,28000,22750,17950,14570,11200,7820);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (3380,3400,127550,102550,63570,50450,37320,28630,23380,18350,14970,11600,8220);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (3400,3420,129990,104990,65140,52010,38890,29250,24000,18750,15370,12000,8620);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (3420,3440,132440,107440,66700,53580,40450,29880,24630,19380,15780,12400,9030);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (3440,3460,134880,109880,68270,55140,42020,30500,25250,20000,16180,12800,9430);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (3460,3480,137330,112330,69830,56710,43580,31130,25880,20630,16580,13210,9830);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (3480,3500,139770,114770,71400,58270,45150,32020,26510,21260,16980,13610,10230);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (3500,3520,142220,117220,72960,59840,46710,33590,27130,21880,17390,14010,10640);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (3520,3540,144660,119660,74530,61400,48280,35150,27760,22510,17790,14410,11040);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (3540,3560,147110,122110,76090,62960,49840,36710,28380,23130,18190,14820,11440);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (3560,3580,149550,124550,77650,64530,51400,38280,29010,23760,18590,15220,11840);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (3580,3600,152000,127000,79220,66090,52970,39840,29630,24380,19130,15620,12250);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (3600,3620,154440,129440,80780,67660,54530,41410,30260,25010,19760,16020,12650);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (3620,3640,156890,131890,82350,69220,56100,42970,30890,25640,20390,16420,13050);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (3640,3660,159330,134330,83910,70790,57660,44540,31510,26260,21010,16830,13450);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (3660,3680,161780,136780,85480,72350,59230,46100,32980,26890,21640,17230,13850);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (3680,3700,164220,139220,87040,73920,60790,47670,34540,27510,22260,17630,14260);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (3700,3720,166670,141670,88610,75480,62360,49230,36110,28140,22890,18030,14660);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (3720,3740,169110,144110,90170,77050,63920,50800,37670,28770,23520,18440,15060);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (3740,3760,171560,146560,91730,78610,65480,52360,39230,29390,24140,18890,15460);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (3760,3780,178920,151090,95250,81630,68510,55380,42260,30600,25350,20100,16240);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (3780,3800,181590,153740,97700,83350,70220,57100,43970,31290,26040,20790,16680);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (3800,3820,184260,156400,100140,85060,71930,58810,45680,32560,26720,21470,17120);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (3820,3840,186930,159050,102590,86770,73640,60520,47390,34270,27400,22150,17560);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (3840,3860,189600,161710,105030,88480,75350,62230,49100,35980,28090,22840,18000);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (3860,3880,192270,164360,107480,90190,77070,63940,50820,37690,28770,23520,18440);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (3880,3900,194940,167020,109920,91900,78780,65650,52530,39400,29460,24210,18960);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (3900,3920,197610,169670,112370,93620,80490,67360,54240,41110,30140,24890,19640);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (3920,3940,200280,172330,114810,96060,82200,69080,55950,42830,30830,25580,20330);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (3940,3960,202950,174980,117260,98510,83910,70790,57660,44540,31510,26260,21010);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (3960,3980,205620,177640,119700,100950,85620,72500,59370,46250,33120,26950,21700);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (3980,4000,208350,180360,122220,103470,87380,74260,61130,48010,34880,27650,22400);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (4000,4020,211160,183150,124800,106050,89190,76060,62940,49810,36690,28370,23120);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (4020,4040,213960,185940,127380,108630,90990,77870,64740,51620,38490,29090,23840);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (4040,4060,216770,188730,129960,111210,92800,79680,66550,53430,40300,29820,24570);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (4060,4080,219570,191520,132540,113790,95040,81480,68360,55230,42110,30540,25290);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (4080,4100,222380,194310,135120,116370,97620,83290,70160,57040,43910,31260,26010);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (4100,4120,225180,197100,137700,118950,100200,85090,71970,58840,45720,32590,26730);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (4120,4140,227990,199890,140280,121530,102780,86900,73770,60650,47520,34400,27460);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (4140,4160,230790,202680,142860,124110,105360,88710,75580,62460,49330,36210,28180);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (4160,4180,233600,205470,145440,126690,107940,90510,77390,64260,51140,38010,28900);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (4180,4200,236400,208260,148020,129270,110520,92320,79190,66070,52940,39820,29620);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (4200,4220,239210,211050,150600,131850,113100,94350,81000,67870,54750,41620,30350);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (4220,4240,242010,213840,153180,134430,115680,96930,82800,69680,56550,43430,31070);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (4240,4260,244820,216630,155760,137010,118260,99510,84610,71490,58360,45240,32110);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (4260,4280,247620,219420,158340,139590,120840,102090,86420,73290,60170,47040,33920);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (4280,4300,250430,222210,160920,142170,123420,104670,88220,75100,61970,48850,35720);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (4300,4320,253230,225000,163500,144750,126000,107250,90030,76900,63780,50650,37530);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (4320,4340,256040,227790,166080,147330,128580,109830,91830,78710,65580,52460,39330);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (4340,4360,258840,230580,168660,149910,131160,112410,93660,80520,67390,54270,41140);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (4360,4380,261650,233370,171240,152490,133740,114990,96240,82320,69200,56070,42950);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (4380,4400,264450,236160,173820,155070,136320,117570,98820,84130,71000,57880,44750);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (4400,4420,267260,238950,176400,157650,138900,120150,101400,85930,72810,59680,46560);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (4420,4440,270060,241740,178980,160230,141480,122730,103980,87740,74610,61490,48360);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (4440,4460,272870,244530,181560,162810,144060,125310,106560,89550,76420,63300,50170);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (4460,4480,275670,247320,184140,165390,146640,127890,109140,91350,78230,65100,51980);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (4480,4500,278480,250110,186720,167970,149220,130470,111720,93160,80030,66910,53780);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (4500,4520,281280,252900,189300,170550,151800,133050,114300,95550,81840,68710,55590);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (4520,4540,284090,255690,191880,173130,154380,135630,116880,98130,83640,70520,57390);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (4540,4560,286890,258480,194460,175710,156960,138210,119460,100710,85450,72330,59200);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (4560,4580,289700,261270,197040,178290,159540,140790,122040,103290,87260,74130,61010);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (4580,4600,295000,266560,202120,183370,164620,145870,127120,108370,89620,75940,62810);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (4600,4620,297810,269350,204700,185950,167200,148450,129700,110950,92200,77740,64620);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (4620,4640,300610,272140,207280,188530,169780,151030,132280,113530,94780,79550,66420);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (4640,4660,303420,274930,209860,191110,172360,153610,134860,116110,97360,81360,68230);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (4660,4680,306220,277720,212440,193690,174940,156190,137440,118690,99940,83160,70040);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (4680,4700,309030,280510,215020,196270,177520,158770,140020,121270,102520,84970,71840);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (4700,4720,311830,283300,217600,198850,180100,161350,142600,123850,105100,86770,73650);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (4720,4740,314640,286090,220180,201430,182680,163930,145180,126430,107680,88930,75450);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (4740,4760,317440,288880,222760,204010,185260,166510,147760,129010,110260,91510,77260);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (4760,4780,320250,291670,225340,206590,187840,169090,150340,131590,112840,94090,79070);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (4780,4800,323050,294460,227920,209170,190420,171670,152920,134170,115420,96670,80870);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (4800,4820,325860,297250,230500,211750,193000,174250,155500,136750,118000,99250,82680);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (4820,4840,328660,300040,233080,214330,195580,176830,158080,139330,120580,101830,84480);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (4840,4860,331470,302830,235660,216910,198160,179410,160660,141910,123160,104410,86290);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (4860,4880,334270,305620,238240,219490,200740,181990,163240,144490,125740,106990,88240);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (4880,4900,337080,308410,240820,222070,203320,184570,165820,147070,128320,109570,90820);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (4900,4920,339880,311200,243400,224650,205900,187150,168400,149650,130900,112150,93400);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (4920,4940,342690,313990,245980,227230,208480,189730,170980,152230,133480,114730,95980);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (4940,4960,345490,316780,248560,229810,211060,192310,173560,154810,136060,117310,98560);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (4960,4980,348300,319570,251140,232390,213640,194890,176140,157390,138640,119890,101140);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (4980,5000,351100,322360,253720,234970,216220,197470,178720,159970,141220,122470,103720);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (5000,5020,353910,325150,256300,237550,218800,200050,181300,162550,143800,125050,106300);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (5020,5040,356710,327940,258880,240130,221380,202630,183880,165130,146380,127630,108880);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (5040,5060,359520,330730,261460,242710,223960,205210,186460,167710,148960,130210,111460);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (5060,5080,362320,333520,264040,245290,226540,207790,189040,170290,151540,132790,114040);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (5080,5100,365130,336310,266620,247870,229120,210370,191620,172870,154120,135370,116620);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (5100,5120,367930,339100,269200,250450,231700,212950,194200,175450,156700,137950,119200);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (5120,5140,370740,341890,271780,253030,234280,215530,196780,178030,159280,140530,121780);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (5140,5160,373540,344680,274360,255610,236860,218110,199360,180610,161860,143110,124360);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (5160,5180,376350,347470,276940,258190,239440,220690,201940,183190,164440,145690,126940);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (5180,5200,379150,350260,279520,260770,242020,223270,204520,185770,167020,148270,129520);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (5200,5220,381960,353050,282100,263350,244600,225850,207100,188350,169600,150850,132100);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (5220,5240,384760,355840,284680,265930,247180,228430,209680,190930,172180,153430,134680);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (5240,5260,387570,358630,287260,268510,249760,231010,212260,193510,174760,156010,137260);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (5260,5280,390370,361420,289840,271090,252340,233590,214840,196090,177340,158590,139840);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (5280,5300,393180,364210,292420,273670,254920,236170,217420,198670,179920,161170,142420);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (5300,5320,395980,367000,295000,276250,257500,238750,220000,201250,182500,163750,145000);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (5320,5340,398790,369790,297580,278830,260080,241330,222580,203830,185080,166330,147580);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (5340,5360,401590,372580,300160,281410,262660,243910,225160,206410,187660,168910,150160);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (5360,5380,404400,375370,302740,283990,265240,246490,227740,208990,190240,171490,152740);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (5380,5400,407200,378160,305320,286570,267820,249070,230320,211570,192820,174070,155320);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (5400,5420,410010,380950,307900,289150,270400,251650,232900,214150,195400,176650,157900);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (5420,5440,412810,383740,310480,291730,272980,254230,235480,216730,197980,179230,160480);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (5440,5460,415620,386530,313060,294310,275560,256810,238060,219310,200560,181810,163060);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (5460,5480,418420,389320,315640,296890,278140,259390,240640,221890,203140,184390,165640);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (5480,5500,421230,392110,318220,299470,280720,261970,243220,224470,205720,186970,168220);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (5500,5520,424030,394900,320800,302050,283300,264550,245800,227050,208300,189550,170800);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (5520,5540,426840,397690,323380,304630,285880,267130,248380,229630,210880,192130,173380);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (5540,5560,429640,400480,325960,307210,288460,269710,250960,232210,213460,194710,175960);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (5560,5580,432450,403270,328540,309790,291040,272290,253540,234790,216040,197290,178540);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (5580,5600,436910,406060,331120,312370,293620,274870,256120,237370,218620,199870,181120);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (5600,5620,441400,408850,333700,314950,296200,277450,258700,239950,221200,202450,183700);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (5620,5640,445880,411640,336280,317530,298780,280030,261280,242530,223780,205030,186280);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (5640,5660,450370,414430,338860,320110,301360,282610,263860,245110,226360,207610,188860);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (5660,5680,454860,417220,341440,322690,303940,285190,266440,247690,228940,210190,191440);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (5680,5700,459350,420010,344020,325270,306520,287770,269020,250270,231520,212770,194020);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (5700,5720,463840,422800,346600,327850,309100,290350,271600,252850,234100,215350,196600);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (5720,5740,468320,425590,349180,330430,311680,292930,274180,255430,236680,217930,199180);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (5740,5760,472810,428380,351760,333010,314260,295510,276760,258010,239260,220510,201760);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (5760,5780,477300,431170,354340,335590,316840,298090,279340,260590,241840,223090,204340);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (5780,5800,481790,434840,356920,338170,319420,300670,281920,263170,244420,225670,206920);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (5800,5820,486280,439300,359500,340750,322000,303250,284500,265750,247000,228250,209500);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (5820,5840,490760,443770,362080,343330,324580,305830,287080,268330,249580,230830,212080);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (5840,5860,517620,470600,390540,371790,353040,334290,315540,296790,278040,259290,240540);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (5860,5880,524660,477620,395680,376930,358180,339430,320680,301930,283180,264430,245680);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (5880,5900,529200,482130,398320,379570,360820,342070,323320,304570,285820,267070,248320);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (5900,5920,533730,486640,400960,382210,363460,344710,325960,307210,288460,269710,250960);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (5920,5940,538270,491150,403600,384850,366100,347350,328600,309850,291100,272350,253600);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (5940,5960,542800,495660,406240,387490,368740,349990,331240,312490,293740,274990,256240);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (5960,5980,547340,500180,408880,390130,371380,352630,333880,315130,296380,277630,258880);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (5980,6000,551880,504690,411520,392770,374020,355270,336520,317770,299020,280270,261520);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (6000,6020,556410,509200,414160,395410,376660,357910,339160,320410,301660,282910,264160);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (6020,6040,560950,513710,416800,398050,379300,360550,341800,323050,304300,285550,266800);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (6040,6060,565480,518220,419440,400690,381940,363190,344440,325690,306940,288190,269440);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (6060,6080,570020,522740,422080,403330,384580,365830,347080,328330,309580,290830,272080);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (6080,6100,574560,527250,424720,405970,387220,368470,349720,330970,312220,293470,274720);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (6100,6120,579090,531760,427360,408610,389860,371110,352360,333610,314860,296110,277360);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (6120,6140,583630,536270,430000,411250,392500,373750,355000,336250,317500,298750,280000);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (6140,6160,588160,540780,432640,413890,395140,376390,357640,338890,320140,301390,282640);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (6160,6180,592700,545300,435280,416530,397780,379030,360280,341530,322780,304030,285280);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (6180,6200,597240,549810,437920,419170,400420,381670,362920,344170,325420,306670,287920);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (6200,6220,601770,554320,440560,421810,403060,384310,365560,346810,328060,309310,290560);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (6220,6240,606310,558830,443200,424450,405700,386950,368200,349450,330700,311950,293200);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (6240,6260,610840,563340,447340,427090,408340,389590,370840,352090,333340,314590,295840);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (6260,6280,615380,567860,451570,429730,410980,392230,373480,354730,335980,317230,298480);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (6280,6300,619920,572370,455790,432370,413620,394870,376120,357370,338620,319870,301120);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (6300,6320,624450,576880,460020,435010,416260,397510,378760,360010,341260,322510,303760);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (6320,6340,628990,581390,464240,437650,418900,400150,381400,362650,343900,325150,306400);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (6340,6360,633520,585900,468460,440290,421540,402790,384040,365290,346540,327790,309040);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (6360,6380,638060,590420,472690,442930,424180,405430,386680,367930,349180,330430,311680);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (6380,6400,642600,594930,476910,446910,426820,408070,389320,370570,351820,333070,314320);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (6400,6420,647130,599440,481140,451140,429460,410710,391960,373210,354460,335710,316960);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (6420,6440,651670,603950,485360,455360,432100,413350,394600,375850,357100,338350,319600);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (6440,6460,656200,608460,489580,459580,434740,415990,397240,378490,359740,340990,322240);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (6460,6480,660740,612980,493810,463810,437380,418630,399880,381130,362380,343630,324880);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (6480,6500,665280,617490,498030,468030,440020,421270,402520,383770,365020,346270,327520);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (6500,6520,669810,622000,502260,472260,442660,423910,405160,386410,367660,348910,330160);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (6520,6540,674350,626510,506480,476480,446480,426550,407800,389050,370300,351550,332800);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (6540,6560,678880,631020,510700,480700,450700,429190,410440,391690,372940,354190,335440);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (6560,6580,683420,635540,514930,484930,454930,431830,413080,394330,375580,356830,338080);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (6580,6600,687960,640050,519150,489150,459150,434470,415720,396970,378220,359470,340720);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (6600,6620,692490,644560,523380,493380,463380,437110,418360,399610,380860,362110,343360);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (6620,6640,697030,649070,527600,497600,467600,439750,421000,402250,383500,364750,346000);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (6640,6660,701560,653580,531820,501820,471820,442390,423640,404890,386140,367390,348640);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (6660,6680,706100,658100,536050,506050,476050,446050,426280,407530,388780,370030,351280);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (6680,6700,710640,662610,540270,510270,480270,450270,428920,410170,391420,372670,353920);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (6700,6720,715170,667120,544500,514500,484500,454500,431560,412810,394060,375310,356560);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (6720,6740,719710,671630,548720,518720,488720,458720,434200,415450,396700,377950,359200);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (6740,6760,724240,676140,552940,522940,492940,462940,436840,418090,399340,380590,361840);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (6760,6780,728780,680660,557170,527170,497170,467170,439480,420730,401980,383230,364480);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (6780,6800,733320,685170,561390,531390,501390,471390,442120,423370,404620,385870,367120);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (6800,6820,737850,689680,565620,535620,505620,475620,445620,426010,407260,388510,369760);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (6820,6840,742390,694190,569840,539840,509840,479840,449840,428650,409900,391150,372400);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (6840,6860,746920,698700,574060,544060,514060,484060,454060,431290,412540,393790,375040);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (6860,6880,751460,703220,578290,548290,518290,488290,458290,433930,415180,396430,377680);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (6880,6900,756000,707730,582510,552510,522510,492510,462510,436570,417820,399070,380320);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (6900,6920,760530,712240,586740,556740,526740,496740,466740,439210,420460,401710,382960);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (6920,6940,765070,716750,590960,560960,530960,500960,470960,441850,423100,404350,385600);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (6940,6960,769600,721260,595180,565180,535180,505180,475180,445180,425740,406990,388240);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (6960,6980,774140,725780,599410,569410,539410,509410,479410,449410,428380,409630,390880);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (6980,7000,778680,730290,603630,573630,543630,513630,483630,453630,431020,412270,393520);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (7000,7020,783210,734800,607860,577860,547860,517860,487860,457860,433660,414910,396160);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (7020,7040,787750,739310,612080,582080,552080,522080,492080,462080,436300,417550,398800);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (7040,7060,792280,743820,616300,586300,556300,526300,496300,466300,438940,420190,401440);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (7060,7080,796820,748340,620530,590530,560530,530530,500530,470530,441580,422830,404080);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (7080,7100,801360,752850,624750,594750,564750,534750,504750,474750,444750,425470,406720);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (7100,7120,805890,757360,628980,598980,568980,538980,508980,478980,448980,428110,409360);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (7120,7140,810430,761870,633200,603200,573200,543200,513200,483200,453200,430750,412000);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (7140,7160,814960,766380,637420,607420,577420,547420,517420,487420,457420,433390,414640);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (7160,7180,819500,770900,641650,611650,581650,551650,521650,491650,461650,436030,417280);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (7180,7200,824040,775410,645870,615870,585870,555870,525870,495870,465870,438670,419920);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (7200,7220,828570,779920,650100,620100,590100,560100,530100,500100,470100,441310,422560);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (7220,7240,833110,784430,654320,624320,594320,564320,534320,504320,474320,444320,425200);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (7240,7260,837640,788940,658540,628540,598540,568540,538540,508540,478540,448540,427840);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (7260,7280,842180,793460,662770,632770,602770,572770,542770,512770,482770,452770,430480);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (7280,7300,846720,797970,666990,636990,606990,576990,546990,516990,486990,456990,433120);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (7300,7320,851250,802480,671220,641220,611220,581220,551220,521220,491220,461220,435760);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (7320,7340,855790,806990,675440,645440,615440,585440,555440,525440,495440,465440,438400);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (7340,7360,860320,811500,679660,649660,619660,589660,559660,529660,499660,469660,441040);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (7360,7380,864860,816020,683890,653890,623890,593890,563890,533890,503890,473890,443890);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (7380,7400,869400,820530,688110,658110,628110,598110,568110,538110,508110,478110,448110);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (7400,7420,873930,825040,692340,662340,632340,602340,572340,542340,512340,482340,452340);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (7420,7440,878470,829550,696560,666560,636560,606560,576560,546560,516560,486560,456560);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (7440,7460,883000,834060,700780,670780,640780,610780,580780,550780,520780,490780,460780);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (7460,7480,887540,838580,705010,675010,645010,615010,585010,555010,525010,495010,465010);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (7480,7500,892080,843090,709230,679230,649230,619230,589230,559230,529230,499230,469230);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (7500,7520,896610,847600,713460,683460,653460,623460,593460,563460,533460,503460,473460);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (7520,7540,901150,852110,717680,687680,657680,627680,597680,567680,537680,507680,477680);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (7540,7560,905680,856620,721900,691900,661900,631900,601900,571900,541900,511900,481900);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (7560,7580,910220,861140,726130,696130,666130,636130,606130,576130,546130,516130,486130);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (7580,7600,914760,865650,730350,700350,670350,640350,610350,580350,550350,520350,490350);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (7600,7620,919290,870160,734580,704580,674580,644580,614580,584580,554580,524580,494580);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (7620,7640,923830,874670,738800,708800,678800,648800,618800,588800,558800,528800,498800);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (7640,7660,928360,879180,743020,713020,683020,653020,623020,593020,563020,533020,503020);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (7660,7680,932900,883700,747250,717250,687250,657250,627250,597250,567250,537250,507250);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (7680,7700,937440,888210,751470,721470,691470,661470,631470,601470,571470,541470,511470);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (7700,7720,941970,892720,755700,725700,695700,665700,635700,605700,575700,545700,515700);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (7720,7740,946510,897230,759920,729920,699920,669920,639920,609920,579920,549920,519920);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (7740,7760,951040,901740,764140,734140,704140,674140,644140,614140,584140,554140,524140);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (7760,7780,955580,906260,768370,738370,708370,678370,648370,618370,588370,558370,528370);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (7780,7800,960120,910770,772590,742590,712590,682590,652590,622590,592590,562590,532590);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (7800,7820,964650,915280,776820,746820,716820,686820,656820,626820,596820,566820,536820);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (7820,7840,969190,919790,781040,751040,721040,691040,661040,631040,601040,571040,541040);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (7840,7860,973720,924300,785260,755260,725260,695260,665260,635260,605260,575260,545260);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (7860,7880,978260,928820,789490,759490,729490,699490,669490,639490,609490,579490,549490);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (7880,7900,982800,933330,793710,763710,733710,703710,673710,643710,613710,583710,553710);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (7900,7920,987330,937840,797940,767940,737940,707940,677940,647940,617940,587940,557940);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (7920,7940,991870,942350,802160,772160,742160,712160,682160,652160,622160,592160,562160);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (7940,7960,996400,946860,806380,776380,746380,716380,686380,656380,626380,596380,566380);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (7960,7980,1000940,951380,810610,780610,750610,720610,690610,660610,630610,600610,570610);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (7980,8000,1005480,955890,814830,784830,754830,724830,694830,664830,634830,604830,574830);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (8000,8020,1010010,960400,819060,789060,759060,729060,699060,669060,639060,609060,579060);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (8020,8040,1014550,964910,823280,793280,763280,733280,703280,673280,643280,613280,583280);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (8040,8060,1019080,969420,827500,797500,767500,737500,707500,677500,647500,617500,587500);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (8060,8080,1023620,973940,831730,801730,771730,741730,711730,681730,651730,621730,591730);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (8080,8100,1028160,978450,835950,805950,775950,745950,715950,685950,655950,625950,595950);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (8100,8120,1032690,982960,840180,810180,780180,750180,720180,690180,660180,630180,600180);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (8120,8140,1037230,987470,844400,814400,784400,754400,724400,694400,664400,634400,604400);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (8140,8160,1041760,991980,848620,818620,788620,758620,728620,698620,668620,638620,608620);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (8160,8180,1046300,996500,852850,822850,792850,762850,732850,702850,672850,642850,612850);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (8180,8200,1050840,1001010,857070,827070,797070,767070,737070,707070,677070,647070,617070);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (8200,8220,1055370,1005520,861300,831300,801300,771300,741300,711300,681300,651300,621300);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (8220,8240,1059910,1010030,865520,835520,805520,775520,745520,715520,685520,655520,625520);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (8240,8260,1064440,1014540,869740,839740,809740,779740,749740,719740,689740,659740,629740);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (8260,8280,1068980,1019060,873970,843970,813970,783970,753970,723970,693970,663970,633970);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (8280,8300,1073520,1023570,878190,848190,818190,788190,758190,728190,698190,668190,638190);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (8300,8320,1078050,1028080,882420,852420,822420,792420,762420,732420,702420,672420,642420);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (8320,8340,1082590,1032590,886640,856640,826640,796640,766640,736640,706640,676640,646640);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (8340,8360,1087240,1037220,890980,860980,830980,800980,770980,740980,710980,680980,650980);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (8360,8380,1091920,1041880,895350,865350,835350,805350,775350,745350,715350,685350,655350);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (8380,8400,1096600,1046540,899720,869720,839720,809720,779720,749720,719720,689720,659720);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (8400,8420,1101280,1051190,904090,874090,844090,814090,784090,754090,724090,694090,664090);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (8420,8440,1105960,1055850,908460,878460,848460,818460,788460,758460,728460,698460,668460);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (8440,8460,1110640,1060500,912820,882820,852820,822820,792820,762820,732820,702820,672820);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (8460,8480,1115320,1065160,917190,887190,857190,827190,797190,767190,737190,707190,677190);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (8480,8500,1120000,1069820,921560,891560,861560,831560,801560,771560,741560,711560,681560);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (8500,8520,1124680,1074470,925930,895930,865930,835930,805930,775930,745930,715930,685930);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (8520,8540,1129360,1079130,930300,900300,870300,840300,810300,780300,750300,720300,690300);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (8540,8560,1134040,1083780,934660,904660,874660,844660,814660,784660,754660,724660,694660);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (8560,8580,1138720,1088440,939030,909030,879030,849030,819030,789030,759030,729030,699030);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (8580,8600,1143400,1093100,943400,913400,883400,853400,823400,793400,763400,733400,703400);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (8600,8620,1148080,1097750,947770,917770,887770,857770,827770,797770,767770,737770,707770);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (8620,8640,1152760,1102410,952140,922140,892140,862140,832140,802140,772140,742140,712140);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (8640,8660,1157440,1107060,956500,926500,896500,866500,836500,806500,776500,746500,716500);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (8660,8680,1162120,1111720,960870,930870,900870,870870,840870,810870,780870,750870,720870);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (8680,8700,1166800,1116380,965240,935240,905240,875240,845240,815240,785240,755240,725240);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (8700,8720,1171480,1121030,969610,939610,909610,879610,849610,819610,789610,759610,729610);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (8720,8740,1176160,1125690,973980,943980,913980,883980,853980,823980,793980,763980,733980);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (8740,8760,1180840,1130340,978340,948340,918340,888340,858340,828340,798340,768340,738340);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (8760,8780,1185520,1135000,982710,952710,922710,892710,862710,832710,802710,772710,742710);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (8780,8800,1190200,1139660,987080,957080,927080,897080,867080,837080,807080,777080,747080);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (8800,8820,1194880,1144310,991450,961450,931450,901450,871450,841450,811450,781450,751450);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (8820,8840,1199560,1148970,995820,965820,935820,905820,875820,845820,815820,785820,755820);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (8840,8860,1204240,1153620,1000180,970180,940180,910180,880180,850180,820180,790180,760180);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (8860,8880,1208920,1158280,1004550,974550,944550,914550,884550,854550,824550,794550,764550);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (8880,8900,1213600,1162940,1008920,978920,948920,918920,888920,858920,828920,798920,768920);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (8900,8920,1218280,1167590,1013290,983290,953290,923290,893290,863290,833290,803290,773290);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (8920,8940,1222960,1172250,1017660,987660,957660,927660,897660,867660,837660,807660,777660);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (8940,8960,1227640,1176900,1022020,992020,962020,932020,902020,872020,842020,812020,782020);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (8960,8980,1232320,1181560,1026390,996390,966390,936390,906390,876390,846390,816390,786390);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (8980,9000,1237000,1186220,1030760,1000760,970760,940760,910760,880760,850760,820760,790760);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (9000,9020,1241680,1190870,1035130,1005130,975130,945130,915130,885130,855130,825130,795130);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (9020,9040,1246360,1195530,1039500,1009500,979500,949500,919500,889500,859500,829500,799500);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (9040,9060,1251040,1200180,1043860,1013860,983860,953860,923860,893860,863860,833860,803860);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (9060,9080,1255720,1204840,1048230,1018230,988230,958230,928230,898230,868230,838230,808230);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (9080,9100,1260400,1209500,1052600,1022600,992600,962600,932600,902600,872600,842600,812600);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (9100,9120,1265080,1214150,1056970,1026970,996970,966970,936970,906970,876970,846970,816970);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (9120,9140,1269760,1218810,1061340,1031340,1001340,971340,941340,911340,881340,851340,821340);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (9140,9160,1274440,1223460,1065700,1035700,1005700,975700,945700,915700,885700,855700,825700);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (9160,9180,1279120,1228120,1070070,1040070,1010070,980070,950070,920070,890070,860070,830070);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (9180,9200,1284020,1232780,1074440,1044440,1014440,984440,954440,924440,894440,864440,834440);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (9200,9220,1290850,1237430,1078810,1048810,1018810,988810,958810,928810,898810,868810,838810);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (9220,9240,1297670,1242090,1083180,1053180,1023180,993180,963180,933180,903180,873180,843180);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (9240,9260,1304500,1246740,1087540,1057540,1027540,997540,967540,937540,907540,877540,847540);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (9260,9280,1311320,1251400,1091910,1061910,1031910,1001910,971910,941910,911910,881910,851910);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (9280,9300,1318150,1256060,1096280,1066280,1036280,1006280,976280,946280,916280,886280,856280);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (9300,9320,1324970,1260710,1100650,1070650,1040650,1010650,980650,950650,920650,890650,860650);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (9320,9340,1331800,1265370,1105020,1075020,1045020,1015020,985020,955020,925020,895020,865020);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (9340,9360,1338620,1270020,1109380,1079380,1049380,1019380,989380,959380,929380,899380,869380);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (9360,9380,1345450,1274680,1113750,1083750,1053750,1023750,993750,963750,933750,903750,873750);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (9380,9400,1352270,1279340,1118120,1088120,1058120,1028120,998120,968120,938120,908120,878120);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (9400,9420,1359100,1284300,1122490,1092490,1062490,1032490,1002490,972490,942490,912490,882490);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (9420,9440,1365920,1291090,1126860,1096860,1066860,1036860,1006860,976860,946860,916860,886860);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (9440,9460,1372750,1297880,1131220,1101220,1071220,1041220,1011220,981220,951220,921220,891220);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (9460,9480,1379570,1304670,1135590,1105590,1075590,1045590,1015590,985590,955590,925590,895590);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (9480,9500,1386400,1311460,1139960,1109960,1079960,1049960,1019960,989960,959960,929960,899960);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (9500,9520,1393220,1318250,1144330,1114330,1084330,1054330,1024330,994330,964330,934330,904330);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (9520,9540,1400050,1325040,1148700,1118700,1088700,1058700,1028700,998700,968700,938700,908700);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (9540,9560,1406870,1331830,1153060,1123060,1093060,1063060,1033060,1003060,973060,943060,913060);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (9560,9580,1413700,1338620,1157430,1127430,1097430,1067430,1037430,1007430,977430,947430,917430);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (9580,9600,1420520,1345410,1161800,1131800,1101800,1071800,1041800,1011800,981800,951800,921800);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (9600,9620,1427350,1352200,1166170,1136170,1106170,1076170,1046170,1016170,986170,956170,926170);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (9620,9640,1434170,1358990,1170540,1140540,1110540,1080540,1050540,1020540,990540,960540,930540);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (9640,9660,1441000,1365780,1174900,1144900,1114900,1084900,1054900,1024900,994900,964900,934900);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (9660,9680,1447820,1372570,1179270,1149270,1119270,1089270,1059270,1029270,999270,969270,939270);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (9680,9700,1454650,1379360,1183640,1153640,1123640,1093640,1063640,1033640,1003640,973640,943640);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (9700,9720,1461470,1386150,1188010,1158010,1128010,1098010,1068010,1038010,1008010,978010,948010);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (9720,9740,1468300,1392940,1192380,1162380,1132380,1102380,1072380,1042380,1012380,982380,952380);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (9740,9760,1475120,1399730,1196740,1166740,1136740,1106740,1076740,1046740,1016740,986740,956740);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (9760,9780,1481950,1406520,1201110,1171110,1141110,1111110,1081110,1051110,1021110,991110,961110);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (9780,9800,1488770,1413310,1205480,1175480,1145480,1115480,1085480,1055480,1025480,995480,965480);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (9800,9820,1495600,1420100,1209850,1179850,1149850,1119850,1089850,1059850,1029850,999850,969850);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (9820,9840,1502420,1426890,1214220,1184220,1154220,1124220,1094220,1064220,1034220,1004220,974220);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (9840,9860,1509250,1433680,1218580,1188580,1158580,1128580,1098580,1068580,1038580,1008580,978580);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (9860,9880,1516070,1440470,1222950,1192950,1162950,1132950,1102950,1072950,1042950,1012950,982950);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (9880,9900,1522900,1447260,1227320,1197320,1167320,1137320,1107320,1077320,1047320,1017320,987320);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (9900,9920,1529720,1454050,1231690,1201690,1171690,1141690,1111690,1081690,1051690,1021690,991690);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (9920,9940,1536550,1460840,1236060,1206060,1176060,1146060,1116060,1086060,1056060,1026060,996060);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (9940,9960,1543370,1467630,1240420,1210420,1180420,1150420,1120420,1090420,1060420,1030420,1000420);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (9960,9980,1550200,1474420,1244790,1214790,1184790,1154790,1124790,1094790,1064790,1034790,1004790);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (9980,10000,1557020,1481210,1249160,1219160,1189160,1159160,1129160,1099160,1069160,1039160,1009160);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (10000,10000,1560440,1484600,1251340,1221340,1191340,1161340,1131340,1101340,1071340,1041340,1011340);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1200,1205,2990,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1225,1230,3340,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1255,1260,3810,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1285,1290,4430,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1315,1320,5050,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1345,1350,5670,1170,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1380,1385,6390,1890,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1415,1420,7110,2610,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1450,1455,7830,3330,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1485,1490,8560,4060,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1540,1550,9740,5240,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1610,1620,11190,6690,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1690,1700,12840,8340,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1760,1770,14290,9790,1830,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1840,1850,15940,11440,3420,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (790,795,0,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (820,825,0,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (850,855,0,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (880,885,0,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (910,915,0,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (940,945,0,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (970,975,0,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1000,1005,0,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1030,1035,0,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1060,1065,1040,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1095,1100,1530,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1125,1130,1950,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1160,1165,2440,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1195,1200,2920,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1240,1245,3550,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1280,1285,4320,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1325,1330,5250,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1365,1370,6080,1580,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1410,1415,7010,2510,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1460,1465,8040,3540,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1510,1520,9120,4620,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1600,1610,10980,6480,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1700,1710,13050,8550,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1790,1800,14910,10410,2430,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1890,1900,16970,12470,4410,1040,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2000,2010,19520,14750,6600,3220,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (795,800,0,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (830,835,0,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (870,875,0,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (915,920,0,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (955,960,0,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (995,1000,0,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1040,1045,0,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1080,1085,1320,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1130,1135,2020,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1175,1180,2640,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1230,1235,3410,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1290,1295,4530,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1340,1345,5560,1060,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1400,1405,6800,2300,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1445,1450,7730,3230,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1520,1530,9330,4830,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1640,1650,11810,7310,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1770,1780,14500,10000,2030,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1880,1890,16770,12270,4220,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2010,2020,19850,14950,6800,3420,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2130,2140,23700,17430,9180,5800,2430,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (780,785,0,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (840,845,0,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (895,900,0,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (945,950,0,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1005,1010,0,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1055,1060,0,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1110,1115,1740,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1170,1175,2570,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1245,1250,3620,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1310,1315,4940,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1385,1390,6490,1990,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1465,1470,8140,3640,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1570,1580,10360,5860,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1730,1740,13670,9170,1240,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1900,1910,17180,12680,4610,1240,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2050,2060,21130,15780,7590,4210,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2190,2200,25630,18670,10370,6990,3620,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2330,2340,30130,23130,13150,9770,6400,3020,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (835,840,0,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (905,910,0,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (980,985,0,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1050,1055,0,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1120,1125,1880,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1205,1210,3060,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1295,1300,4630,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1370,1375,6180,1680,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1470,1475,8250,3750,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1620,1630,11400,6900,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1800,1810,15110,10610,2630,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1960,1970,18420,13920,5800,2430,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2140,2150,24020,17640,9380,6000,2630,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2290,2300,28840,21840,12350,8980,5600,2230,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2460,2470,38390,27300,15730,12350,8980,5600,2230,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (815,820,0,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (920,925,0,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1010,1015,0,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1090,1095,1460,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1185,1190,2780,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1300,1305,4740,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1395,1400,6700,2200,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1495,1500,8760,4260,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1680,1690,12640,8140,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1920,1930,17590,13090,5010,1630,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2110,2120,23060,17020,8780,5400,2030,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2300,2310,29160,22160,12550,9180,5800,2430,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2490,2500,40800,28270,16320,12950,9570,6200,2820,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2660,2670,55320,37820,20570,16540,13170,9790,6420,3040,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (900,905,0,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1015,1020,0,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1115,1120,1810,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1235,1240,3480,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1360,1365,5980,1480,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1500,1510,8920,4420,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1750,1760,14080,9580,1640,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1990,2000,19200,14540,6400,3020,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2210,2220,26270,19270,10760,7390,4010,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2410,2420,34380,25700,14730,11360,7980,4610,1230,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2630,2640,52760,35260,19580,15910,12530,9160,5780,2410,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (770,775,0,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (885,890,0,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1025,1030,0,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1150,1155,2300,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1305,1310,4840,0,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1440,1445,7630,3130,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1710,1720,13260,8760,0,0,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (1970,1980,18630,14130,6000,2630,0,0,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2230,2240,26910,19910,11160,7790,4410,1040,0,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2470,2480,39200,27630,15920,12550,9170,5800,2420,0,0,0,0);
Insert into INCOME_TAX (INCOME_LOW,INCOME_HIGH,FAMILY1,FAMILY2,FAMILY3,FAMILY4,FAMILY5,FAMILY6,FAMILY7,FAMILY8,FAMILY9,FAMILY10,FAMILY11) values (2700,2710,58750,41250,21890,17390,14020,10640,7270,3890,0,0,0);

--����



Insert into USER_MEMBER (U_NUM,U_ID,U_PWD,U_POSITION,U_NAME,U_PHONE,U_EMAIL,U_TEAM,U_JOINDATE,U_MODIFYDATE) values (user_member_sequence.nextval,'admin','admin','admin','admin','admin',null,'admin',to_date('16/06/11','RR/MM/DD'),to_date('16/07/23','RR/MM/DD'));
Insert into USER_MEMBER (U_NUM,U_ID,U_PWD,U_POSITION,U_NAME,U_PHONE,U_EMAIL,U_TEAM,U_JOINDATE,U_MODIFYDATE) values (user_member_sequence.nextval,'00002','00002','�ڵ������','����ȣ','01024312342','chlwnsgh@naver.com','����μ�',to_date('16/07/25','RR/MM/DD'),to_date('16/07/25','RR/MM/DD'));
Insert into USER_MEMBER (U_NUM,U_ID,U_PWD,U_POSITION,U_NAME,U_PHONE,U_EMAIL,U_TEAM,U_JOINDATE,U_MODIFYDATE) values (user_member_sequence.nextval,'00003','00003','������','������','01045632363','wjdwlgns@naver.com','�����μ�',to_date('16/07/25','RR/MM/DD'),to_date('16/07/25','RR/MM/DD'));
Insert into USER_MEMBER (U_NUM,U_ID,U_PWD,U_POSITION,U_NAME,U_PHONE,U_EMAIL,U_TEAM,U_JOINDATE,U_MODIFYDATE) values (user_member_sequence.nextval,'00001','00001','��ȣ��','���ٿ�','01042141244','wjdekdns@naver.com','�濵������',to_date('16/07/25','RR/MM/DD'),to_date('16/07/25','RR/MM/DD'));
Insert into USER_MEMBER (U_NUM,U_ID,U_PWD,U_POSITION,U_NAME,U_PHONE,U_EMAIL,U_TEAM,U_JOINDATE,U_MODIFYDATE) values (user_member_sequence.nextval,'00004','00004','�ǻ�','����ȯ','01023421155','wjdtjsghks@naver.com','����μ�',to_date('16/07/25','RR/MM/DD'),to_date('16/07/25','RR/MM/DD'));
Insert into USER_MEMBER (U_NUM,U_ID,U_PWD,U_POSITION,U_NAME,U_PHONE,U_EMAIL,U_TEAM,U_JOINDATE,U_MODIFYDATE) values (user_member_sequence.nextval,'00006','00006','��ȣ��','������','01034531231','tlswjddms@gmail.com','����μ�',to_date('16/07/25','RR/MM/DD'),to_date('16/07/25','RR/MM/DD'));



Insert into ROLE_KOREA (NUM,C_AUTHORITY_NAME,C_KOREA_NAME) values (1,'view','��밡��');
Insert into ROLE_KOREA (NUM,C_AUTHORITY_NAME,C_KOREA_NAME) values (2,'nothing','���Ѿ���');
Insert into ROLE_KOREA (NUM,C_AUTHORITY_NAME,C_KOREA_NAME) values (3,'readOnly','�б�');
Insert into ROLE_KOREA (NUM,C_AUTHORITY_NAME,C_KOREA_NAME) values (4,'readWrite','�б�/����');
Insert into ROLE_KOREA (NUM,C_AUTHORITY_NAME,C_KOREA_NAME) values (5,'anything','������');
Insert into ROLE_KOREA (NUM,C_AUTHORITY_NAME,C_KOREA_NAME) values (6,'master','������');



Insert into SECURITY_ROLE (R_ID,R_AUTHORITY) values ('admin','ROLE_general');
Insert into SECURITY_ROLE (R_ID,R_AUTHORITY) values ('00001','ROLE_general');
Insert into SECURITY_ROLE (R_ID,R_AUTHORITY) values ('00002','ROLE_general');
Insert into SECURITY_ROLE (R_ID,R_AUTHORITY) values ('00003','ROLE_general');
Insert into SECURITY_ROLE (R_ID,R_AUTHORITY) values ('00004','ROLE_general');
Insert into SECURITY_ROLE (R_ID,R_AUTHORITY) values ('00006','ROLE_general');



Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('reservation_page2','anything','00001','ROLE_reservation_page2_anything');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('reservation_page3','anything','00001','ROLE_reservation_page3_anything');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('reservation_page1','anything','00001','ROLE_reservation_page1_anything');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('reservation_page','view','00001','ROLE_reservation_page_view');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('board_page3','anything','00001','ROLE_board_page3_anything');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('board_page2','anything','00001','ROLE_board_page2_anything');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('board_page1','anything','00001','ROLE_board_page1_anything');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('board_page','view','00001','ROLE_board_page_view');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('admin_page2','anything','00001','ROLE_admin_page2_anything');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('admin_page1','readOnly','00001','ROLE_admin_page1_readOnly');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('admin_page','view','00001','ROLE_admin_page_view');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('accounting_page3','anything','00001','ROLE_accounting_page3_anything');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('accounting_page2','anything','00001','ROLE_accounting_page2_anything');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('accounting_page1','anything','00001','ROLE_accounting_page1_anything');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('accounting_page','view','00001','ROLE_accounting_page_view');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('inventory_page3','anything','00001','ROLE_inventory_page3_anything');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('inventory_page2','anything','00001','ROLE_inventory_page2_anything');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('inventory_page1','anything','00001','ROLE_inventory_page1_anything');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('inventory_page','view','00001','ROLE_inventory_page_view');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('human_resources_page3','nothing','00001','ROLE_human_resources_page3_nothing');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('human_resources_page2','nothing','00001','ROLE_human_resources_page2_nothing');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('human_resources_page1','nothing','00001','ROLE_human_resources_page1_nothing');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('human_resources_page','nothing','00001','ROLE_human_resources_page_nothing');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('patient_page3','anything','00001','ROLE_patient_page3_anything');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('patient_page2','anything','00001','ROLE_patient_page2_anything');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('patient_page1','anything','00001','ROLE_patient_page1_anything');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('patient_page','view','00001','ROLE_patient_page_view');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('reservation_page4','anything','00001','ROLE_reservation_page4_anything');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('board_page2','anything','00002','ROLE_board_page2_anything');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('board_page3','anything','00002','ROLE_board_page3_anything');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('reservation_page','nothing','00002','ROLE_reservation_page_nothing');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('board_page','view','00002','ROLE_board_page_view');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('admin_page2','anything','00002','ROLE_admin_page2_anything');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('admin_page1','readOnly','00002','ROLE_admin_page1_readOnly');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('admin_page','view','00002','ROLE_admin_page_view');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('accounting_page3','anything','00002','ROLE_accounting_page3_anything');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('accounting_page2','anything','00002','ROLE_accounting_page2_anything');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('accounting_page1','anything','00002','ROLE_accounting_page1_anything');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('accounting_page','view','00002','ROLE_accounting_page_view');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('inventory_page3','anything','00002','ROLE_inventory_page3_anything');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('inventory_page2','anything','00002','ROLE_inventory_page2_anything');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('inventory_page1','anything','00002','ROLE_inventory_page1_anything');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('inventory_page','view','00002','ROLE_inventory_page_view');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('human_resources_page3','nothing','00002','ROLE_human_resources_page3_nothing');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('human_resources_page2','nothing','00002','ROLE_human_resources_page2_nothing');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('human_resources_page1','nothing','00002','ROLE_human_resources_page1_nothing');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('human_resources_page','nothing','00002','ROLE_human_resources_page_nothing');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('patient_page3','nothing','00002','ROLE_patient_page3_nothing');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('patient_page2','nothing','00002','ROLE_patient_page2_nothing');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('patient_page1','nothing','00002','ROLE_patient_page1_nothing');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('patient_page','nothing','00002','ROLE_patient_page_nothing');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('reservation_page4','nothing','00002','ROLE_reservation_page4_nothing');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('reservation_page3','nothing','00002','ROLE_reservation_page3_nothing');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('reservation_page2','nothing','00002','ROLE_reservation_page2_nothing');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('reservation_page1','nothing','00002','ROLE_reservation_page1_nothing');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('board_page1','anything','00002','ROLE_board_page1_anything');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('board_page3','master','00003','ROLE_board_page3_master');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('reservation_page2','master','00003','ROLE_reservation_page2_master');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('reservation_page3','master','00003','ROLE_reservation_page3_master');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('reservation_page4','master','00003','ROLE_reservation_page4_master');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('patient_page','view','00003','ROLE_patient_page_view');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('patient_page1','master','00003','ROLE_patient_page1_master');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('patient_page2','master','00003','ROLE_patient_page2_master');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('patient_page3','master','00003','ROLE_patient_page3_master');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('human_resources_page','view','00003','ROLE_human_resources_page_view');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('human_resources_page1','master','00003','ROLE_human_resources_page1_master');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('human_resources_page2','master','00003','ROLE_human_resources_page2_master');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('human_resources_page3','master','00003','ROLE_human_resources_page3_master');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('human_resources_page4','master','00003','ROLE_human_resources_page4_master');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('inventory_page','view','00003','ROLE_inventory_page_view');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('inventory_page1','master','00003','ROLE_inventory_page1_master');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('inventory_page2','master','00003','ROLE_inventory_page2_master');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('inventory_page3','master','00003','ROLE_inventory_page3_master');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('accounting_page','view','00003','ROLE_accounting_page_view');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('accounting_page1','master','00003','ROLE_accounting_page1_master');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('accounting_page2','master','00003','ROLE_accounting_page2_master');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('accounting_page3','master','00003','ROLE_accounting_page3_master');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('admin_page','view','00003','ROLE_admin_page_view');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('admin_page1','master','00003','ROLE_admin_page1_master');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('admin_page2','master','00003','ROLE_admin_page2_master');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('reservation_page','view','00003','ROLE_reservation_page_view');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('board_page','view','00003','ROLE_board_page_view');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('board_page1','master','00003','ROLE_board_page1_master');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('board_page2','master','00003','ROLE_board_page2_master');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('reservation_page1','master','00003','ROLE_reservation_page1_master');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('reservation_page','view','00004','ROLE_reservation_page_view');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('reservation_page1','anything','00004','ROLE_reservation_page1_anything');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('board_page3','anything','00004','ROLE_board_page3_anything');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('board_page2','anything','00004','ROLE_board_page2_anything');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('board_page1','anything','00004','ROLE_board_page1_anything');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('board_page','view','00004','ROLE_board_page_view');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('admin_page2','anything','00004','ROLE_admin_page2_anything');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('admin_page1','anything','00004','ROLE_admin_page1_anything');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('admin_page','view','00004','ROLE_admin_page_view');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('accounting_page3','anything','00004','ROLE_accounting_page3_anything');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('accounting_page2','anything','00004','ROLE_accounting_page2_anything');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('accounting_page1','anything','00004','ROLE_accounting_page1_anything');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('accounting_page','view','00004','ROLE_accounting_page_view');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('inventory_page3','anything','00004','ROLE_inventory_page3_anything');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('inventory_page2','anything','00004','ROLE_inventory_page2_anything');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('inventory_page1','anything','00004','ROLE_inventory_page1_anything');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('inventory_page','view','00004','ROLE_inventory_page_view');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('human_resources_page3','nothing','00004','ROLE_human_resources_page3_nothing');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('human_resources_page2','nothing','00004','ROLE_human_resources_page2_nothing');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('human_resources_page1','nothing','00004','ROLE_human_resources_page1_nothing');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('human_resources_page','nothing','00004','ROLE_human_resources_page_nothing');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('patient_page3','anything','00004','ROLE_patient_page3_anything');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('patient_page2','anything','00004','ROLE_patient_page2_anything');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('patient_page1','anything','00004','ROLE_patient_page1_anything');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('patient_page','view','00004','ROLE_patient_page_view');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('reservation_page4','anything','00004','ROLE_reservation_page4_anything');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('reservation_page3','anything','00004','ROLE_reservation_page3_anything');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('reservation_page2','anything','00004','ROLE_reservation_page2_anything');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('reservation_page2','nothing','00006','ROLE_reservation_page2_nothing');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('reservation_page1','nothing','00006','ROLE_reservation_page1_nothing');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('board_page3','nothing','00006','ROLE_board_page3_nothing');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('board_page2','nothing','00006','ROLE_board_page2_nothing');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('board_page1','nothing','00006','ROLE_board_page1_nothing');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('board_page','nothing','00006','ROLE_board_page_nothing');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('admin_page2','nothing','00006','ROLE_admin_page2_nothing');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('admin_page1','nothing','00006','ROLE_admin_page1_nothing');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('admin_page','nothing','00006','ROLE_admin_page_nothing');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('accounting_page3','nothing','00006','ROLE_accounting_page3_nothing');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('accounting_page2','nothing','00006','ROLE_accounting_page2_nothing');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('accounting_page1','nothing','00006','ROLE_accounting_page1_nothing');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('accounting_page','nothing','00006','ROLE_accounting_page_nothing');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('inventory_page3','nothing','00006','ROLE_inventory_page3_nothing');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('inventory_page2','nothing','00006','ROLE_inventory_page2_nothing');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('inventory_page1','nothing','00006','ROLE_inventory_page1_nothing');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('inventory_page','nothing','00006','ROLE_inventory_page_nothing');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('human_resources_page3','nothing','00006','ROLE_human_resources_page3_nothing');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('human_resources_page2','nothing','00006','ROLE_human_resources_page2_nothing');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('human_resources_page1','nothing','00006','ROLE_human_resources_page1_nothing');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('human_resources_page','nothing','00006','ROLE_human_resources_page_nothing');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('patient_page3','nothing','00006','ROLE_patient_page3_nothing');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('patient_page2','nothing','00006','ROLE_patient_page2_nothing');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('patient_page1','nothing','00006','ROLE_patient_page1_nothing');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('patient_page','nothing','00006','ROLE_patient_page_nothing');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('reservation_page4','nothing','00006','ROLE_reservation_page4_nothing');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('reservation_page3','nothing','00006','ROLE_reservation_page3_nothing');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('reservation_page','nothing','00006','ROLE_reservation_page_nothing');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('reservation_page','view','admin','ROLE_reservation_page_view');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('reservation_page1','master','admin','ROLE_reservation_page1_master');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('reservation_page2','master','admin','ROLE_reservation_page2_master');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('reservation_page3','master','admin','ROLE_reservation_page3_master');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('reservation_page4','master','admin','ROLE_reservation_page4_master');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('patient_page','view','admin','ROLE_patient_page_view');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('patient_page1','master','admin','ROLE_patient_page1_master');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('patient_page2','master','admin','ROLE_patient_page2_master');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('patient_page3','master','admin','ROLE_patient_page3_master');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('human_resources_page','view','admin','ROLE_human_resources_page_view');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('human_resources_page1','master','admin','ROLE_human_resources_page1_master');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('human_resources_page2','master','admin','ROLE_human_resources_page2_master');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('human_resources_page3','master','admin','ROLE_human_resources_page3_master');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('human_resources_page4','master','admin','ROLE_human_resources_page4_master');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('inventory_page','view','admin','ROLE_inventory_page_view');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('inventory_page1','master','admin','ROLE_inventory_page1_master');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('inventory_page2','master','admin','ROLE_inventory_page2_master');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('inventory_page3','master','admin','ROLE_inventory_page3_master');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('accounting_page','view','admin','ROLE_accounting_page_view');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('accounting_page1','master','admin','ROLE_accounting_page1_master');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('accounting_page2','master','admin','ROLE_accounting_page2_master');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('accounting_page3','master','admin','ROLE_accounting_page3_master');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('admin_page','view','admin','ROLE_admin_page_view');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('admin_page1','master','admin','ROLE_admin_page1_master');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('admin_page2','master','admin','ROLE_admin_page2_master');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('board_page','view','admin','ROLE_board_page_view');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('board_page1','master','admin','ROLE_board_page1_master');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('board_page2','master','admin','ROLE_board_page2_master');
Insert into ROLE_COMPARISON (C_REFERENCE,C_AUTHORITY_NAME,C_ID,C_AUTHORITY) values ('board_page3','master','admin','ROLE_board_page3_master');




commit;

