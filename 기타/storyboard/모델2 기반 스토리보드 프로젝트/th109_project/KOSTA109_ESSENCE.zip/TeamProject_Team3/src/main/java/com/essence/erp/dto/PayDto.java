package com.essence.erp.dto;

import java.util.Date;

public class PayDto {
	int pay_num,total_pay,real_pay, income_tax,residence_tax,health_insurance;
	int  unemployment_insurance,nation_pension,etx_pay,basic_pay;
	int  bonus,incentive_pay,food_pay,transportation_pay;
	public int getPay_num() {
		return pay_num;
	}
	public void setPay_num(int pay_num) {
		this.pay_num = pay_num;
	}
	public int getTotal_pay() {
		return total_pay;
	}
	public void setTotal_pay(int total_pay) {
		this.total_pay = total_pay;
	}
	public int getReal_pay() {
		return real_pay;
	}
	public void setReal_pay(int real_pay) {
		this.real_pay = real_pay;
	}
	public int getIncome_tax() {
		return income_tax;
	}
	public void setIncome_tax(int income_tax) {
		this.income_tax = income_tax;
	}
	public int getResidence_tax() {
		return residence_tax;
	}
	public void setResidence_tax(int residence_tax) {
		this.residence_tax = residence_tax;
	}
	public int getHealth_insurance() {
		return health_insurance;
	}
	public void setHealth_insurance(int health_insurance) {
		this.health_insurance = health_insurance;
	}
	public int getUnemployment_insurance() {
		return unemployment_insurance;
	}
	public void setUnemployment_insurance(int unemployment_insurance) {
		this.unemployment_insurance = unemployment_insurance;
	}
	public int getNation_pension() {
		return nation_pension;
	}
	public void setNation_pension(int nation_pension) {
		this.nation_pension = nation_pension;
	}
	public int getEtx_pay() {
		return etx_pay;
	}
	public void setEtx_pay(int etx_pay) {
		this.etx_pay = etx_pay;
	}
	public int getBasic_pay() {
		return basic_pay;
	}
	public void setBasic_pay(int basic_pay) {
		this.basic_pay = basic_pay;
	}
	public int getBonus() {
		return bonus;
	}
	public void setBonus(int bonus) {
		this.bonus = bonus;
	}
	public int getIncentive_pay() {
		return incentive_pay;
	}
	public void setIncentive_pay(int incentive_pay) {
		this.incentive_pay = incentive_pay;
	}
	public int getFood_pay() {
		return food_pay;
	}
	public void setFood_pay(int food_pay) {
		this.food_pay = food_pay;
	}
	public int getTransportation_pay() {
		return transportation_pay;
	}
	public void setTransportation_pay(int transportation_pay) {
		this.transportation_pay = transportation_pay;
	}
	
}
