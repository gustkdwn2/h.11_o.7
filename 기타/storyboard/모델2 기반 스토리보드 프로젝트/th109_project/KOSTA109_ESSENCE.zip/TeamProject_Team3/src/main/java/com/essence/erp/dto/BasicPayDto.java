package com.essence.erp.dto;

public class BasicPayDto {
	String duty_responsibility_code;
	int basic_pay;
	public String getDuty_responsibility_code() {
		return duty_responsibility_code;
	}
	public void setDuty_responsibility_code(String duty_responsibility_code) {
		this.duty_responsibility_code = duty_responsibility_code;
	}
	public int getBasic_pay() {
		return basic_pay;
	}
	public void setBasic_pay(int basic_pay) {
		this.basic_pay = basic_pay;
	}
}
