package com.essence.erp.dto;

public class Role_InsertDto {
	private String patient_page0,human_resources_page0,inventory_page0,accounting_page0,admin_page0,reservation_page0,board_page0;
	private String patient_page1,human_resources_page1,inventory_page1,accounting_page1,admin_page1,reservation_page1,board_page1;
	private String patient_page2,human_resources_page2,inventory_page2,admin_page2,reservation_page2,board_page2,accounting_page2;
	private String human_resources_page3,inventory_page3,board_page3,reservation_page3,patient_page3;
	private String human_resources_page4;
	
	private String c_reference ,c_authority;
	private String c_id;
	private String c_authority_name;
	
	
	
	
	
	
	public String getHuman_resources_page4() {
		return human_resources_page4;
	}
	public void setHuman_resources_page4(String human_resources_page4) {
		this.human_resources_page4 = human_resources_page4;
	}
	
	public String getPatient_page3() {
		return patient_page3;
	}
	public void setPatient_page3(String patient_page3) {
		this.patient_page3 = patient_page3;
	}
	public String getReservation_page3() {
		return reservation_page3;
	}
	public void setReservation_page3(String reservation_page3) {
		this.reservation_page3 = reservation_page3;
	}
	public String getAccounting_page2() {
		return accounting_page2;
	}
	public void setAccounting_page2(String accounting_page2) {
		this.accounting_page2 = accounting_page2;
	}
	public String getC_authority_name() {
		return c_authority_name;
	}
	public void setC_authority_name(String c_authority_name) {
		this.c_authority_name = c_authority_name;
	}
	public String getC_id() {
		return c_id;
	}
	public void setC_id(String c_id) {
		this.c_id = c_id;
	}
	public Role_InsertDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getC_reference() {
		return c_reference;
	}
	public void setC_reference(String c_reference) {
		this.c_reference = c_reference;
	}
	public String getC_authority() {
		return c_authority;
	}
	public void setC_authority(String c_authority) {
		this.c_authority = c_authority;
	}

	public String getPatient_page0() {
		return patient_page0;
	}
	public void setPatient_page0(String patient_page0) {
		this.patient_page0 = patient_page0;
	}
	public String getHuman_resources_page0() {
		return human_resources_page0;
	}
	public void setHuman_resources_page0(String human_resources_page0) {
		this.human_resources_page0 = human_resources_page0;
	}
	public String getInventory_page0() {
		return inventory_page0;
	}
	public void setInventory_page0(String inventory_page0) {
		this.inventory_page0 = inventory_page0;
	}
	public String getAccounting_page0() {
		return accounting_page0;
	}
	public void setAccounting_page0(String accounting_page0) {
		this.accounting_page0 = accounting_page0;
	}
	public String getAdmin_page0() {
		return admin_page0;
	}
	public void setAdmin_page0(String admin_page0) {
		this.admin_page0 = admin_page0;
	}
	public String getReservation_page0() {
		return reservation_page0;
	}
	public void setReservation_page0(String reservation_page0) {
		this.reservation_page0 = reservation_page0;
	}
	public String getBoard_page0() {
		return board_page0;
	}
	public void setBoard_page0(String board_page0) {
		this.board_page0 = board_page0;
	}
	public String getPatient_page1() {
		return patient_page1;
	}
	public void setPatient_page1(String patient_page1) {
		this.patient_page1 = patient_page1;
	}
	public String getHuman_resources_page1() {
		return human_resources_page1;
	}
	public void setHuman_resources_page1(String human_resources_page1) {
		this.human_resources_page1 = human_resources_page1;
	}
	public String getInventory_page1() {
		return inventory_page1;
	}
	public void setInventory_page1(String inventory_page1) {
		this.inventory_page1 = inventory_page1;
	}
	public String getAccounting_page1() {
		return accounting_page1;
	}
	public void setAccounting_page1(String accounting_page1) {
		this.accounting_page1 = accounting_page1;
	}
	public String getAdmin_page1() {
		return admin_page1;
	}
	public void setAdmin_page1(String admin_page1) {
		this.admin_page1 = admin_page1;
	}
	public String getReservation_page1() {
		return reservation_page1;
	}
	public void setReservation_page1(String reservation_page1) {
		this.reservation_page1 = reservation_page1;
	}
	public String getBoard_page1() {
		return board_page1;
	}
	public void setBoard_page1(String board_page1) {
		this.board_page1 = board_page1;
	}
	public String getPatient_page2() {
		return patient_page2;
	}
	public void setPatient_page2(String patient_page2) {
		this.patient_page2 = patient_page2;
	}
	public String getHuman_resources_page2() {
		return human_resources_page2;
	}
	public void setHuman_resources_page2(String human_resources_page2) {
		this.human_resources_page2 = human_resources_page2;
	}
	public String getInventory_page2() {
		return inventory_page2;
	}
	public void setInventory_page2(String inventory_page2) {
		this.inventory_page2 = inventory_page2;
	}
	public String getAdmin_page2() {
		return admin_page2;
	}
	public void setAdmin_page2(String admin_page2) {
		this.admin_page2 = admin_page2;
	}
	public String getReservation_page2() {
		return reservation_page2;
	}
	public void setReservation_page2(String reservation_page2) {
		this.reservation_page2 = reservation_page2;
	}
	public String getBoard_page2() {
		return board_page2;
	}
	public void setBoard_page2(String board_page2) {
		this.board_page2 = board_page2;
	}
	public String getHuman_resources_page3() {
		return human_resources_page3;
	}
	public void setHuman_resources_page3(String human_resources_page3) {
		this.human_resources_page3 = human_resources_page3;
	}
	public String getInventory_page3() {
		return inventory_page3;
	}
	public void setInventory_page3(String inventory_page3) {
		this.inventory_page3 = inventory_page3;
	}
	public String getBoard_page3() {
		return board_page3;
	}
	public void setBoard_page3(String board_page3) {
		this.board_page3 = board_page3;
	}
	
	
}
