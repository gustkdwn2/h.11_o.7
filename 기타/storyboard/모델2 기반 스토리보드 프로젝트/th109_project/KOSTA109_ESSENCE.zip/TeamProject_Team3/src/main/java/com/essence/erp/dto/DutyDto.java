package com.essence.erp.dto;

//직책 Dto
public class DutyDto {

	String duty_responsibility_code,duty_responsibility;

	public String getDuty_responsibility_code() {
		return duty_responsibility_code;
	}

	public void setDuty_responsibility_code(String duty_responsibility_code) {
		this.duty_responsibility_code = duty_responsibility_code;
	}

	public String getDuty_responsibility() {
		return duty_responsibility;
	}

	public void setDuty_responsibility(String duty_responsibility) {
		this.duty_responsibility = duty_responsibility;
	}
	
}
